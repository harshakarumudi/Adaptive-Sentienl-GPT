import os
import sys
import json
import torch
import torch.nn as nn
import torch.nn.functional as F
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from models.gnn.gnn_model import AdaptiveSentinelGNN
from analysis.graph_visualizer import AttackGraphBuilder


def generate_benign_scenarios() -> List[Dict[str, Any]]:
    """Generates 15 benign security log and event graph scenarios."""
    scenarios = []
    hosts = [f"WORKSTATION-{i:02d}" for i in range(1, 10)] + [f"SERVER-{i:02d}" for i in range(1, 7)]
    users = ["alice_user", "bob_user", "charlie_dev", "david_admin", "system_svc", "backup_agent", "spooler_svc", "update_user", "hr_user", "finance_user", "it_helpdesk", "qa_user", "analyst_1", "guest_user", "service_acct"]

    for idx in range(15):
        host = hosts[idx % len(hosts)]
        user = users[idx % len(users)]
        evt_id = 4624 if idx % 2 == 0 else 4688
        evt_type = "Successful Logon" if evt_id == 4624 else "Process Creation"
        proc = "explorer.exe" if evt_id == 4624 else ("svchost.exe" if idx % 3 == 0 else "taskhostw.exe")

        logs = [
            {
                "hostname": host,
                "event_id": evt_id,
                "event_type": evt_type,
                "severity": "Low",
                "source": "synthetic",
                "user": user,
                "process_name": proc,
                "timestamp": f"2026-10-03T10:{idx:02d}:00Z"
            },
            {
                "hostname": host,
                "event_id": 4624,
                "event_type": "Successful Logon",
                "severity": "Informational",
                "source": "synthetic",
                "user": "SYSTEM",
                "process_name": "lsass.exe",
                "timestamp": f"2026-10-03T10:{idx:02d}:05Z"
            }
        ]
        scenarios.append({
            "type": "benign",
            "name": f"Benign Activity Graph #{idx+1} ({host})",
            "incidents": [],
            "logs": logs
        })
    return scenarios


def generate_attack_scenarios() -> List[Dict[str, Any]]:
    """Generates 15 attack security graph scenarios covering major MITRE ATT&CK tactics."""
    return [
        # 1. APT29 Cozy Bear Credential Access
        {
            "type": "attack",
            "name": "APT29 Cozy Bear Credential Access",
            "incidents": [
                {
                    "incident_id": "INC-APT29",
                    "incident_name": "APT29 Cozy Bear Credential Access",
                    "severity": "Critical",
                    "affected_host": "WORKSTATION-01",
                    "affected_user": "admin_user",
                    "confidence": 95,
                    "alerts": [
                        {
                            "alert_name": "LSASS Memory Dump",
                            "mitre_technique": "T1003",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 10,
                                "event_type": "Process Access",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "SYSTEM",
                                "process_name": "mimikatz.exe",
                                "rule_id": "60800",
                                "mitre_techniques": ["T1003"]
                            }
                        },
                        {
                            "alert_name": "Failed Authentication",
                            "mitre_technique": "T1110",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 4625,
                                "event_type": "Logon Failure",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "admin_user",
                                "source_ip": "192.168.1.100",
                                "rule_id": "60106",
                                "mitre_techniques": ["T1110"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 2. APT28 Fancy Bear Spearphishing
        {
            "type": "attack",
            "name": "APT28 Fancy Bear Spearphishing Execution",
            "incidents": [
                {
                    "incident_id": "INC-APT28",
                    "incident_name": "APT28 Fancy Bear PowerShell C2",
                    "severity": "Critical",
                    "affected_host": "FINANCE-PC",
                    "affected_user": "finance_mgr",
                    "confidence": 92,
                    "alerts": [
                        {
                            "alert_name": "Encoded PowerShell Script Execution",
                            "mitre_technique": "T1059.001",
                            "mitre_tactic": "Execution",
                            "event": {
                                "event_id": 4688,
                                "event_type": "Process Creation",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "finance_mgr",
                                "process_name": "powershell.exe",
                                "command_line": "powershell.exe -e aW52b2tlLXdlYnJlcXVlc3Q=",
                                "rule_id": "60801",
                                "mitre_techniques": ["T1059.001"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 3. Ransomware Volume Shadow Copy Deletion
        {
            "type": "attack",
            "name": "Ransomware Volume Shadow Copy Destruction",
            "incidents": [
                {
                    "incident_id": "INC-RANSOM-01",
                    "incident_name": "Ransomware Inhibit System Recovery",
                    "severity": "Critical",
                    "affected_host": "FILESERVER-01",
                    "affected_user": "SYSTEM",
                    "confidence": 98,
                    "alerts": [
                        {
                            "alert_name": "VSSAdmin Shadow Copy Deletion",
                            "mitre_technique": "T1490",
                            "mitre_tactic": "Impact",
                            "event": {
                                "event_id": 4688,
                                "event_type": "Process Creation",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "SYSTEM",
                                "process_name": "vssadmin.exe",
                                "command_line": "vssadmin.exe delete shadows /all /quiet",
                                "rule_id": "60805",
                                "mitre_techniques": ["T1490"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 4. Brute Force & PsExec Lateral Movement
        {
            "type": "attack",
            "name": "Brute Force & PsExec Lateral Movement",
            "incidents": [
                {
                    "incident_id": "INC-BRUTE-LAT",
                    "incident_name": "Brute Force & PsExec Lateral Movement",
                    "severity": "High",
                    "affected_host": "DC-PRIMARY",
                    "affected_user": "domain_admin",
                    "confidence": 90,
                    "alerts": [
                        {
                            "alert_name": "Brute Force Password Spraying",
                            "mitre_technique": "T1110.003",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 4625,
                                "event_type": "Logon Failure",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "domain_admin",
                                "source_ip": "10.0.0.88",
                                "rule_id": "60106",
                                "mitre_techniques": ["T1110.003"]
                            }
                        },
                        {
                            "alert_name": "PsExec Remote Execution Service",
                            "mitre_technique": "T1021.002",
                            "mitre_tactic": "Lateral Movement",
                            "event": {
                                "event_id": 7045,
                                "event_type": "Service Installation",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "SYSTEM",
                                "process_name": "psexesvc.exe",
                                "rule_id": "60810",
                                "mitre_techniques": ["T1021.002"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 5. Kerberoasting Campaign
        {
            "type": "attack",
            "name": "Kerberoasting Ticket Harvesting",
            "incidents": [
                {
                    "incident_id": "INC-KERB-01",
                    "incident_name": "Kerberoasting SPN Ticket Harvesting",
                    "severity": "High",
                    "affected_host": "DC-PRIMARY",
                    "affected_user": "svc_sql",
                    "confidence": 88,
                    "alerts": [
                        {
                            "alert_name": "RC4 Kerberos Ticket Request",
                            "mitre_technique": "T1558.003",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 4769,
                                "event_type": "Kerberos Service Ticket",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "svc_sql",
                                "rule_id": "60820",
                                "mitre_techniques": ["T1558.003"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 6. NTDS.dit Active Directory Database Dump
        {
            "type": "attack",
            "name": "NTDS.dit Domain Credential Dump",
            "incidents": [
                {
                    "incident_id": "INC-NTDS-01",
                    "incident_name": "NTDS.dit Domain Credential Dump",
                    "severity": "Critical",
                    "affected_host": "DC-SECONDARY",
                    "affected_user": "SYSTEM",
                    "confidence": 97,
                    "alerts": [
                        {
                            "alert_name": "Ntdsutil AD Snapshot Creation",
                            "mitre_technique": "T1003.003",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 4688,
                                "event_type": "Process Creation",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "SYSTEM",
                                "process_name": "ntdsutil.exe",
                                "command_line": "ntdsutil \"ac i ntds\" \"ifm\" \"create full C:\\Windows\\Temp\\ntds\" q q",
                                "rule_id": "60825",
                                "mitre_techniques": ["T1003.003"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 7. Defender Antivirus Disablement
        {
            "type": "attack",
            "name": "Windows Defender Real-Time Protection Tampering",
            "incidents": [
                {
                    "incident_id": "INC-DEFENDER-01",
                    "incident_name": "Defender Real-Time Protection Disabled",
                    "severity": "High",
                    "affected_host": "WORKSTATION-08",
                    "affected_user": "local_admin",
                    "confidence": 91,
                    "alerts": [
                        {
                            "alert_name": "Antivirus Defense Evasion",
                            "mitre_technique": "T1562.001",
                            "mitre_tactic": "Defense Evasion",
                            "event": {
                                "event_id": 5001,
                                "event_type": "Defender Disabled",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "local_admin",
                                "process_name": "powershell.exe",
                                "rule_id": "60830",
                                "mitre_techniques": ["T1562.001"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 8. Scheduled Task Persistence
        {
            "type": "attack",
            "name": "Persistence via Scheduled Task Creation",
            "incidents": [
                {
                    "incident_id": "INC-TASK-01",
                    "incident_name": "Malicious Scheduled Task Registration",
                    "severity": "High",
                    "affected_host": "WORKSTATION-04",
                    "affected_user": "user_pc4",
                    "confidence": 87,
                    "alerts": [
                        {
                            "alert_name": "Schtasks Persistence Trigger",
                            "mitre_technique": "T1053.005",
                            "mitre_tactic": "Persistence",
                            "event": {
                                "event_id": 4698,
                                "event_type": "Scheduled Task Created",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "user_pc4",
                                "process_name": "schtasks.exe",
                                "rule_id": "60835",
                                "mitre_techniques": ["T1053.005"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 9. Registry Run Key Auto-start Persistence
        {
            "type": "attack",
            "name": "Registry Auto-start Run Key Modification",
            "incidents": [
                {
                    "incident_id": "INC-REG-01",
                    "incident_name": "HKCU Run Key Registry Persistence",
                    "severity": "Medium",
                    "affected_host": "WORKSTATION-05",
                    "affected_user": "user_pc5",
                    "confidence": 82,
                    "alerts": [
                        {
                            "alert_name": "Registry Key Modified",
                            "mitre_technique": "T1547.001",
                            "mitre_tactic": "Persistence",
                            "event": {
                                "event_id": 13,
                                "event_type": "Registry Modification",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "user_pc5",
                                "process_name": "reg.exe",
                                "rule_id": "60840",
                                "mitre_techniques": ["T1547.001"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 10. Process Hollowing / Memory Injection
        {
            "type": "attack",
            "name": "Process Injection Into Svchost",
            "incidents": [
                {
                    "incident_id": "INC-INJECT-01",
                    "incident_name": "Process Hollowing via CreateRemoteThread",
                    "severity": "Critical",
                    "affected_host": "SERVER-03",
                    "affected_user": "SYSTEM",
                    "confidence": 96,
                    "alerts": [
                        {
                            "alert_name": "Remote Thread Injection",
                            "mitre_technique": "T1055",
                            "mitre_tactic": "Defense Evasion",
                            "event": {
                                "event_id": 8,
                                "event_type": "CreateRemoteThread",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "SYSTEM",
                                "process_name": "svchost.exe",
                                "rule_id": "60845",
                                "mitre_techniques": ["T1055"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 11. Web Shell Execution
        {
            "type": "attack",
            "name": "IIS Web Shell Command Execution",
            "incidents": [
                {
                    "incident_id": "INC-WEBSHELL-01",
                    "incident_name": "IIS Worker Spawning CMD Subshell",
                    "severity": "Critical",
                    "affected_host": "WEBSERVER-01",
                    "affected_user": "IUSR",
                    "confidence": 94,
                    "alerts": [
                        {
                            "alert_name": "Web Shell Command Execution",
                            "mitre_technique": "T1505.003",
                            "mitre_tactic": "Persistence",
                            "event": {
                                "event_id": 4688,
                                "event_type": "Process Creation",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "IUSR",
                                "process_name": "cmd.exe",
                                "command_line": "cmd.exe /c whoami & net user",
                                "rule_id": "60850",
                                "mitre_techniques": ["T1505.003"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 12. DNS Tunneling Data Exfiltration
        {
            "type": "attack",
            "name": "DNS Query High-Volume Data Exfiltration",
            "incidents": [
                {
                    "incident_id": "INC-DNS-01",
                    "incident_name": "DNS Tunneling Protocol Abuse",
                    "severity": "High",
                    "affected_host": "DEV-STATION",
                    "affected_user": "dev_user",
                    "confidence": 89,
                    "alerts": [
                        {
                            "alert_name": "Suspicious High Entropy Subdomain Query",
                            "mitre_technique": "T1071.004",
                            "mitre_tactic": "Exfiltration",
                            "event": {
                                "event_id": 22,
                                "event_type": "DNS Query",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "dev_user",
                                "process_name": "nslookup.exe",
                                "rule_id": "60855",
                                "mitre_techniques": ["T1071.004"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 13. Pass-the-Hash NTLM Authentication
        {
            "type": "attack",
            "name": "Pass-the-Hash NTLM Administrative Session",
            "incidents": [
                {
                    "incident_id": "INC-PTH-01",
                    "incident_name": "Pass-the-Hash NTLM Session Hijack",
                    "severity": "High",
                    "affected_host": "DB-PRIMARY",
                    "affected_user": "sa_admin",
                    "confidence": 88,
                    "alerts": [
                        {
                            "alert_name": "NTLM Type 9 Logon Anomaly",
                            "mitre_technique": "T1550.002",
                            "mitre_tactic": "Lateral Movement",
                            "event": {
                                "event_id": 4624,
                                "event_type": "Successful Logon",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "sa_admin",
                                "rule_id": "60860",
                                "mitre_techniques": ["T1550.002"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 14. UAC Bypass via MMC / Registry
        {
            "type": "attack",
            "name": "Bypass User Account Control via MMC",
            "incidents": [
                {
                    "incident_id": "INC-UAC-01",
                    "incident_name": "UAC Hijacking via Registry Key",
                    "severity": "High",
                    "affected_host": "WORKSTATION-09",
                    "affected_user": "user_pc9",
                    "confidence": 86,
                    "alerts": [
                        {
                            "alert_name": "UAC Privilege Escalation",
                            "mitre_technique": "T1548.002",
                            "mitre_tactic": "Privilege Escalation",
                            "event": {
                                "event_id": 4688,
                                "event_type": "Process Creation",
                                "severity": "High",
                                "source": "synthetic",
                                "user": "user_pc9",
                                "process_name": "mmc.exe",
                                "rule_id": "60865",
                                "mitre_techniques": ["T1548.002"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        },
        # 15. Golden Ticket Active Directory Ticket Forgery
        {
            "type": "attack",
            "name": "Golden Ticket Kerberos TGT Forgery",
            "incidents": [
                {
                    "incident_id": "INC-GOLDEN-01",
                    "incident_name": "KRBTGT Hash Forgery Active Directory",
                    "severity": "Critical",
                    "affected_host": "DC-PRIMARY",
                    "affected_user": "krbtgt",
                    "confidence": 99,
                    "alerts": [
                        {
                            "alert_name": "Golden Ticket Kerberos Grant",
                            "mitre_technique": "T1558.001",
                            "mitre_tactic": "Credential Access",
                            "event": {
                                "event_id": 4768,
                                "event_type": "Kerberos TGT Request",
                                "severity": "Critical",
                                "source": "synthetic",
                                "user": "krbtgt",
                                "rule_id": "60870",
                                "mitre_techniques": ["T1558.001"]
                            }
                        }
                    ]
                }
            ],
            "logs": []
        }
    ]


def generate_multi_graph_dataset() -> List[Dict[str, Any]]:
    """
    Constructs a dataset of independent security graph instances (both benign and attack).
    Returns list of dicts with keys: name, type, x (Tensor), edge_index (Tensor), y (Tensor), num_nodes, num_edges.
    """
    scenarios = generate_benign_scenarios() + generate_attack_scenarios()
    dataset = []

    for sc in scenarios:
        builder = AttackGraphBuilder()
        builder.build_graph(incidents=sc["incidents"], logs=sc["logs"])
        gnn_data = builder.export_gnn_features()

        node_feats = []
        labels = []

        for nf in gnn_data["node_features"]:
            feat_vec = [
                float(nf["type_code"]),
                float(nf["severity_weight"]),
                float(nf["in_degree"]),
                float(nf["out_degree"]),
                float(nf["total_degree"])
            ]
            node_feats.append(feat_vec)
            # Node label: 1.0 = Anomalous (Incident, MITRE Technique, or Critical/High Alert in Attack Scenarios), 0.0 = Benign
            is_anomaly = 1.0 if sc["type"] == "attack" and (nf["severity_weight"] >= 3.0 or nf["type_code"] in (0, 7)) else 0.0
            labels.append(is_anomaly)

        x = torch.tensor(node_feats, dtype=torch.float)
        y = torch.tensor(labels, dtype=torch.float)
        src_idx, dst_idx = gnn_data["edge_index"]
        edge_index = torch.tensor([src_idx, dst_idx], dtype=torch.long)

        dataset.append({
            "name": sc["name"],
            "type": sc["type"],
            "x": x,
            "edge_index": edge_index,
            "y": y,
            "num_nodes": len(node_feats),
            "num_edges": len(src_idx)
        })

    return dataset


def compute_class_balance(graphs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Computes total node count, benign nodes, anomalous nodes, and anomalous percentage."""
    total_nodes = sum(g["num_nodes"] for g in graphs)
    anomalous_nodes = sum(int(g["y"].sum().item()) for g in graphs)
    benign_nodes = total_nodes - anomalous_nodes
    pct_anomalous = round((anomalous_nodes / max(1, total_nodes)) * 100.0, 2)
    return {
        "total_nodes": total_nodes,
        "benign_nodes": benign_nodes,
        "anomalous_nodes": anomalous_nodes,
        "anomalous_percentage": pct_anomalous
    }


class FeatureOnlyBaseline(nn.Module):
    """Linear Logistic Regression Baseline operating solely on node features (Non-GNN)."""

    def __init__(self, in_features: int = 5):
        super().__init__()
        self.linear = nn.Linear(in_features, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.sigmoid(self.linear(x)).squeeze(-1)


def evaluate_non_gnn_baseline(
    train_graphs: List[Dict[str, Any]],
    test_graphs: List[Dict[str, Any]],
    pos_weight: float
) -> Dict[str, Any]:
    """Trains and evaluates a Non-GNN feature-only linear baseline model across the test graph split."""
    baseline_model = FeatureOnlyBaseline(in_features=5)
    optimizer = torch.optim.Adam(baseline_model.parameters(), lr=0.01)

    train_x = torch.cat([g["x"] for g in train_graphs], dim=0)
    train_y = torch.cat([g["y"] for g in train_graphs], dim=0)

    baseline_model.train()
    for _ in range(100):
        optimizer.zero_grad()
        p = baseline_model(train_x)
        w = train_y * pos_weight + (1.0 - train_y) * 1.0
        l = F.binary_cross_entropy(p, train_y, weight=w)
        l.backward()
        optimizer.step()

    baseline_model.eval()
    all_preds = []
    all_targets = []
    with torch.no_grad():
        for g in test_graphs:
            p = baseline_model(g["x"])
            preds = (p >= 0.5).float()
            all_preds.extend(preds.tolist())
            all_targets.extend(g["y"].tolist())

    preds_t = torch.tensor(all_preds)
    targets_t = torch.tensor(all_targets)

    correct = (preds_t == targets_t).sum().item()
    accuracy = float(correct) / max(1, len(preds_t))
    tp = ((preds_t == 1.0) & (targets_t == 1.0)).sum().item()
    fp = ((preds_t == 1.0) & (targets_t == 0.0)).sum().item()
    fn = ((preds_t == 0.0) & (targets_t == 1.0)).sum().item()

    precision = float(tp) / max(1, tp + fp)
    recall = float(tp) / max(1, tp + fn)
    f1 = (2 * precision * recall) / max(1e-6, precision + recall)

    return {
        "baseline_type": "Feature-Only Linear Logistic Regression (Non-GNN)",
        "accuracy": round(accuracy, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4)
    }


def train_gnn_model(epochs: int = 50, lr: float = 0.01) -> Dict[str, Any]:
    """
    Trains AdaptiveSentinelGNN model on multi-graph dataset using graph-level splitting,
    handles class balance with weighted loss, evaluates test metrics against a Non-GNN baseline,
    and saves checkpoint & metadata.
    """
    print("=== Training AdaptiveSentinelGNN Model (Graph-Level Split & Weighted Loss) ===")

    dataset = generate_multi_graph_dataset()
    num_graphs = len(dataset)

    # Graph-Level Permutation & Splitting (70% Train / 15% Val / 15% Test)
    torch.manual_seed(42)
    perm = torch.randperm(num_graphs).tolist()
    n_train = int(0.70 * num_graphs)
    n_val = int(0.15 * num_graphs)

    train_graphs = [dataset[i] for i in perm[:n_train]]
    val_graphs = [dataset[i] for i in perm[n_train:n_train + n_val]]
    test_graphs = [dataset[i] for i in perm[n_train + n_val:]]

    cb_total = compute_class_balance(dataset)
    cb_train = compute_class_balance(train_graphs)
    cb_val = compute_class_balance(val_graphs)
    cb_test = compute_class_balance(test_graphs)

    # Class Balance Weighted BCE Loss
    pos_weight = float(cb_train["benign_nodes"]) / max(1.0, float(cb_train["anomalous_nodes"]))

    print(f"[+] Total Graphs: {num_graphs} | Train: {len(train_graphs)} | Val: {len(val_graphs)} | Test: {len(test_graphs)}")
    print(f"[+] Total Nodes : {cb_total['total_nodes']} (Anomalous: {cb_total['anomalous_nodes']} [{cb_total['anomalous_percentage']}%])")
    print(f"[+] Train Pos Weight: {pos_weight:.4f}")

    model = AdaptiveSentinelGNN(in_channels=5, hidden_channels=16, num_layers=2)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)

    model.train()
    for epoch in range(1, epochs + 1):
        epoch_loss = 0.0
        for g in train_graphs:
            x, edge_index, y = g["x"], g["edge_index"], g["y"]
            optimizer.zero_grad()
            _, scores = model(x, edge_index)
            weight = y * pos_weight + (1.0 - y) * 1.0
            loss = F.binary_cross_entropy(scores, y, weight=weight)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()

        if epoch % 10 == 0:
            model.eval()
            val_loss_sum = 0.0
            with torch.no_grad():
                for g in val_graphs:
                    x, edge_index, y = g["x"], g["edge_index"], g["y"]
                    _, scores = model(x, edge_index)
                    weight = y * pos_weight + (1.0 - y) * 1.0
                    val_loss_sum += F.binary_cross_entropy(scores, y, weight=weight).item()
            avg_train_loss = epoch_loss / max(1, len(train_graphs))
            avg_val_loss = val_loss_sum / max(1, len(val_graphs))
            print(f"Epoch {epoch:02d}/{epochs} | Avg Train Loss: {avg_train_loss:.4f} | Avg Val Loss: {avg_val_loss:.4f}")
            model.train()

    # Evaluate GNN on Test Graphs
    model.eval()
    all_test_preds = []
    all_test_targets = []
    test_loss_sum = 0.0

    with torch.no_grad():
        for g in test_graphs:
            x, edge_index, y = g["x"], g["edge_index"], g["y"]
            _, scores = model(x, edge_index)
            weight = y * pos_weight + (1.0 - y) * 1.0
            test_loss_sum += F.binary_cross_entropy(scores, y, weight=weight).item()
            preds = (scores >= 0.5).float()
            all_test_preds.extend(preds.tolist())
            all_test_targets.extend(y.tolist())

    test_loss = test_loss_sum / max(1, len(test_graphs))
    preds_t = torch.tensor(all_test_preds)
    targets_t = torch.tensor(all_test_targets)

    correct = (preds_t == targets_t).sum().item()
    accuracy = float(correct) / max(1, len(preds_t))
    tp = ((preds_t == 1.0) & (targets_t == 1.0)).sum().item()
    fp = ((preds_t == 1.0) & (targets_t == 0.0)).sum().item()
    tn = ((preds_t == 0.0) & (targets_t == 0.0)).sum().item()
    fn = ((preds_t == 0.0) & (targets_t == 1.0)).sum().item()

    precision = float(tp) / max(1, tp + fp)
    recall = float(tp) / max(1, tp + fn)
    f1 = (2 * precision * recall) / max(1e-6, precision + recall)

    print(f"\n--- Final GNN Test Split Metrics (Graph-Level Split) ---")
    print(f"Test Loss     : {test_loss:.4f}")
    print(f"Test Accuracy : {accuracy:.4f} ({accuracy*100:.1f}%)")
    print(f"Test Precision: {precision:.4f}")
    print(f"Test Recall   : {recall:.4f}")
    print(f"Test F1 Score : {f1:.4f}")

    # Non-GNN Baseline Evaluation
    baseline_metrics = evaluate_non_gnn_baseline(train_graphs, test_graphs, pos_weight)
    print(f"\n--- Non-GNN Baseline Metrics ---")
    print(f"Baseline Accuracy : {baseline_metrics['accuracy']:.4f}")
    print(f"Baseline Precision: {baseline_metrics['precision']:.4f}")
    print(f"Baseline Recall   : {baseline_metrics['recall']:.4f}")
    print(f"Baseline F1 Score : {baseline_metrics['f1']:.4f}")

    # Save Checkpoint & Metadata
    model_dir = Path(__file__).resolve().parent
    model_dir.mkdir(parents=True, exist_ok=True)
    ckpt_path = model_dir / "adaptivesentinel_gnn.pt"
    meta_path = model_dir / "gnn_metadata.json"

    torch.save(model.state_dict(), ckpt_path)

    metadata = {
        "model_name": "AdaptiveSentinelGNN (GCN Architecture)",
        "version": "v1.1.0",
        "training_date": datetime.now().isoformat(),
        "in_channels": 5,
        "hidden_channels": 16,
        "num_layers": 2,
        "dataset_type": "Multi-Graph Controlled Synthetic Security Dataset (Graph-Level Split)",
        "dataset_split": f"70% Train ({len(train_graphs)} graphs) / 15% Val ({len(val_graphs)} graphs) / 15% Test ({len(test_graphs)} graphs)",
        "total_graphs": num_graphs,
        "num_train_graphs": len(train_graphs),
        "num_val_graphs": len(val_graphs),
        "num_test_graphs": len(test_graphs),
        "class_balance": {
            "total_dataset": cb_total,
            "train_split": cb_train,
            "val_split": cb_val,
            "test_split": cb_test,
            "train_pos_weight": round(pos_weight, 4)
        },
        "metrics": {
            "test_loss": round(test_loss, 4),
            "test_accuracy": round(accuracy, 4),
            "test_precision": round(precision, 4),
            "test_recall": round(recall, 4),
            "test_f1": round(f1, 4),
            "confusion_matrix": {
                "tp": tp,
                "fp": fp,
                "tn": tn,
                "fn": fn
            }
        },
        "baseline_comparison": baseline_metrics
    }

    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"\n[+] Checkpoint saved to: {ckpt_path}")
    print(f"[+] Metadata saved to  : {meta_path}")

    return metadata


if __name__ == "__main__":
    train_gnn_model()
