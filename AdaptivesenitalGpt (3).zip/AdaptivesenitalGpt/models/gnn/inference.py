import os
import sys
import json
import torch
from pathlib import Path
from typing import Dict, Any, List, Optional

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from models.gnn.gnn_model import AdaptiveSentinelGNN
from analysis.graph_visualizer import AttackGraphBuilder


def run_gnn_inference(
    incidents: Optional[List[Dict[str, Any]]] = None,
    logs: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    Executes actual forward pass through PyTorch AdaptiveSentinelGNN model
    on current attack graph data. Maps model scores back to node IDs and
    ranks top risk nodes alongside associated graph evidence.
    """
    model_dir = Path(__file__).resolve().parent
    ckpt_path = model_dir / "adaptivesentinel_gnn.pt"
    meta_path = model_dir / "gnn_metadata.json"

    # Check model checkpoint existence
    if not ckpt_path.exists():
        try:
            from models.gnn.train import train_gnn_model
            train_gnn_model()
        except Exception as e:
            return {
                "status": "MODEL NOT AVAILABLE",
                "model_architecture": "GCN",
                "inference_status": "INACTIVE",
                "reason": f"Model checkpoint missing or error: {e}",
                "node_scores": {},
                "top_risk_nodes": []
            }

    # Load Metadata
    metadata = {}
    if meta_path.exists():
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                metadata = json.load(f)
        except Exception:
            pass

    # Load Model Checkpoint
    in_channels = metadata.get("in_channels", 5)
    hidden_channels = metadata.get("hidden_channels", 16)
    model = AdaptiveSentinelGNN(in_channels=in_channels, hidden_channels=hidden_channels)
    
    try:
        model.load_state_dict(torch.load(ckpt_path, map_location=torch.device('cpu')))
        model.eval()
    except Exception as e:
        return {
            "status": "ERROR",
            "model_architecture": "GCN",
            "inference_status": "INACTIVE",
            "reason": f"Failed to load checkpoint state: {e}",
            "node_scores": {},
            "top_risk_nodes": []
        }

    # Build Current Attack Graph & Export Features
    builder = AttackGraphBuilder()
    G = builder.build_graph(incidents=incidents, logs=logs)
    gnn_data = builder.export_gnn_features()

    if gnn_data["num_nodes"] == 0:
        return {
            "status": "TRAINED",
            "model_architecture": "GCN",
            "inference_status": "ACTIVE (EMPTY GRAPH)",
            "inference_source": "NO TELEMETRY MATCH",
            "analyzed_nodes": 0,
            "analyzed_edges": 0,
            "highest_risk_score": 0.0,
            "avg_risk_score": 0.0,
            "node_scores": {},
            "top_risk_nodes": [],
            "metadata": metadata
        }

    # Convert Exported Features to PyTorch Tensors
    node_feats = [
        [
            float(nf["type_code"]),
            float(nf["severity_weight"]),
            float(nf["in_degree"]),
            float(nf["out_degree"]),
            float(nf["total_degree"])
        ]
        for nf in gnn_data["node_features"]
    ]
    x = torch.tensor(node_feats, dtype=torch.float)
    src_idx, dst_idx = gnn_data["edge_index"]
    edge_index = torch.tensor([src_idx, dst_idx], dtype=torch.long)

    # Perform Model Forward Pass
    with torch.no_grad():
        _embeddings, scores = model(x, edge_index)
        scores_list = scores.tolist()

    # Map GNN Risk Scores back to Node String IDs
    node_mapping_inv = {idx: node_id for node_id, idx in gnn_data["node_mapping"].items()}
    node_scores = {}
    top_nodes_list = []

    for idx, score_val in enumerate(scores_list):
        node_id = node_mapping_inv.get(idx, f"NODE-{idx}")
        score_round = round(float(score_val), 4)
        node_scores[node_id] = score_round

        node_data = G.nodes[node_id] if G.has_node(node_id) else {}

        # Associated Graph Evidence Extraction
        neighbors = list(G.neighbors(node_id)) if G.has_node(node_id) else []
        predecessors = list(G.predecessors(node_id)) if G.has_node(node_id) else []
        connected_edges_count = len(neighbors) + len(predecessors)

        top_nodes_list.append({
            "node_id": node_id,
            "label": node_data.get("label", node_id),
            "type": node_data.get("type", "Unknown"),
            "gnn_risk_score": score_round,
            "event_severity": node_data.get("severity", "N/A"),
            "associated_graph_evidence": {
                "hostname": node_data.get("hostname", "N/A"),
                "event_id": node_data.get("event_id", "N/A"),
                "rule_id": node_data.get("rule_id", "N/A"),
                "mitre_technique": node_data.get("mitre_technique", "N/A"),
                "incident_id": node_data.get("incident_id", "N/A"),
                "timestamp": node_data.get("timestamp", "N/A"),
                "connected_nodes_count": connected_edges_count
            }
        })

    # Sort Top Risk Nodes descending by GNN Risk Score
    top_nodes_list.sort(key=lambda item: item["gnn_risk_score"], reverse=True)

    highest_score = top_nodes_list[0]["gnn_risk_score"] if top_nodes_list else 0.0
    avg_score = round(sum(scores_list) / len(scores_list), 4) if scores_list else 0.0

    has_real_nxlog = any(
        G.nodes[n].get("source") == "real_nxlog_windows"
        for n in G.nodes()
    ) if G else False

    inference_src = "REAL NXLOG TELEMETRY" if has_real_nxlog else "MULTI-SOURCE PIPELINE GRAPH"

    return {
        "status": "TRAINED",
        "model_architecture": "GCN (PyTorch AdaptiveSentinelGNN)",
        "inference_status": "ACTIVE",
        "inference_source": inference_src,
        "analyzed_nodes": gnn_data["num_nodes"],
        "analyzed_edges": gnn_data["num_edges"],
        "highest_risk_score": highest_score,
        "avg_risk_score": avg_score,
        "node_scores": node_scores,
        "top_risk_nodes": top_nodes_list[:10],
        "metadata": metadata
    }
