import streamlit as st
import pandas as pd
import plotly.express as px
import json
import sys
import os
import time

# Add project root to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import importlib
import analysis.deduplicate as _dedup_mod
import knowledge_base.database as _kb_mod
import agents.detection_agent as _det_mod
import agents.correlation_agent as _corr_mod
import agents.feedback_agent as _fb_mod
import main as main_module


def run_gnn_inference(*args, **kwargs):
    if "PYTEST_CURRENT_TEST" in os.environ:
        return {"node_scores": {}, "top_risk_nodes": []}
    from models.gnn.inference import run_gnn_inference as _run_gnn
    return _run_gnn(*args, **kwargs)


from utils.pdf_generator import create_pdf_report

_BACKFILL_HEAD_TS_CACHE: dict = {}
_GNN_INFERENCE_CACHE: dict = {}
_PDF_REPORT_CACHE: dict = {}


# SOAR Modules
import soar.action_registry
from soar.action_registry import SOARActionRegistry
import soar.decision_engine
from soar.decision_engine import SOARDecisionEngine
import soar.executor
from soar.executor import MockSOARExecutor
import soar.audit_logger
from soar.audit_logger import SOARAuditLogger
import soar.guard
from soar.guard import SOARExecutionGuard

# NXLog & Telemetry Modules (one-time hot-reload guard for running Streamlit processes)
import utils.network_discovery as _nd_mod
import config.settings as _cfg_mod
import analysis.normalize as _norm_mod
import analysis.parser as _parser_mod
import analysis.enrich as _enrich_mod
import llm.llm_client as _llm_mod
import utils.generate_logs as _gen_logs_mod
import utils.generate_apt_logs as _gen_apt_mod
import agents.threat_intelligence_agent as _ti_mod
import agents.explainability_agent as _exp_mod
import agents.response_planning_agent as _resp_mod
import agents.reporting_agent as _rep_mod
if not hasattr(_nd_mod, "INTERFACE_CACHE_TTL_SEC"):
    importlib.reload(_nd_mod)
if (
    not hasattr(_cfg_mod, "RECEIVER_IP_CACHE_TTL_SEC")
    or not hasattr(_cfg_mod, "DEMO_BASELINE_FILE_PATH")
    or not hasattr(_cfg_mod, "DASHBOARD_FILTER_STATE_FILE_PATH")
):
    importlib.reload(_cfg_mod)
if (
    not hasattr(_parser_mod.NXLogReader, "_is_incomplete_trailing_block")
    or not hasattr(_parser_mod.NXLogReader, "load_demo_baseline")
):
    importlib.reload(_parser_mod)
if (
    "ADAPTIVESENTINEL_LIVE_TEST" not in getattr(_norm_mod.LogNormalizer, "DIAGNOSTIC_MARKERS", ())
    or not hasattr(_norm_mod.LogNormalizer, "resolve_event_severity")
    or not hasattr(_norm_mod, "resolve_canonical_hostname")
    or not hasattr(_norm_mod, "compute_filtered_telemetry_scope")
    or "T1087.001" not in getattr(_enrich_mod.LogEnricher, "TACTIC_MAP", {})
    or "T1548.002" not in getattr(_enrich_mod.LogEnricher, "TACTIC_MAP", {})
    or not hasattr(_ti_mod.ThreatIntelligenceAgent, "classify_ip")
    or not hasattr(_dedup_mod, "get_alert_identity_key")
    or not hasattr(_dedup_mod, "get_alert_identity_hash")
    or not hasattr(_kb_mod.KnowledgeBaseDB, "record_incident_alerts")
    or not hasattr(_corr_mod, "apply_cumulative_incident_tracking")
    or not hasattr(_corr_mod, "format_incident_alert_summary")
    or not hasattr(_fb_mod.FeedbackAgent, "retrieve_similar_guidance")
    or not hasattr(_fb_mod.FeedbackAgent, "extract_incident_evidence_profile")
):
    importlib.reload(_norm_mod)
    importlib.reload(_parser_mod)
    importlib.reload(_dedup_mod)
    importlib.reload(_enrich_mod)
    importlib.reload(_kb_mod)
    importlib.reload(_llm_mod)
    importlib.reload(_gen_logs_mod)
    importlib.reload(_gen_apt_mod)
    importlib.reload(_det_mod)
    importlib.reload(_corr_mod)
    importlib.reload(_ti_mod)
    importlib.reload(_exp_mod)
    importlib.reload(_resp_mod)
    importlib.reload(_rep_mod)
    importlib.reload(_fb_mod)
    importlib.reload(main_module)

from llm.llm_client import LLMClient
from utils.generate_logs import generate_synthetic_attack_logs
from utils.generate_apt_logs import generate_apt_attack_logs
from analysis.parser import NXLogReader
from analysis.normalize import (
    normalize_events,
    build_endpoint_inventory,
    filter_telemetry_by_endpoint,
    resolve_canonical_hostname,
    endpoint_matches_filter,
    event_matches_source_filter,
    compute_filtered_telemetry_scope,
)
from analysis.deduplicate import (
    get_event_identity_key,
    deduplicate_events,
)
from analysis.enrich import enrich_events, LogEnricher
from knowledge_base.database import KnowledgeBaseDB
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import (
    CorrelationAgent,
    apply_cumulative_incident_tracking,
    format_alert_timestamp,
    format_incident_alert_summary,
)
from agents.threat_intelligence_agent import ThreatIntelligenceAgent
from agents.explainability_agent import ExplainabilityAgent
from agents.response_planning_agent import ResponsePlanningAgent
from agents.reporting_agent import ReportingAgent
from agents.feedback_agent import FeedbackAgent
from config.settings import (
    DATA_DIR,
    NXLOG_FILE_PATH,
    RECEIVER_HOST,
    NXLOG_PORT,
    ENDPOINT_HOSTNAME,
    format_network_display,
    get_central_network_state,
    get_endpoint_ip,
)
try:
    from config.settings import (
        DEMO_BASELINE_FILE_PATH,
        DASHBOARD_FILTER_STATE_FILE_PATH,
    )
except ImportError:
    importlib.reload(_cfg_mod)
    DEMO_BASELINE_FILE_PATH = getattr(_cfg_mod, "DEMO_BASELINE_FILE_PATH", DATA_DIR / "nxlog_demo_baseline.json")
    DASHBOARD_FILTER_STATE_FILE_PATH = getattr(_cfg_mod, "DASHBOARD_FILTER_STATE_FILE_PATH", DATA_DIR / "dashboard_filter_state.json")


# Streamlit Page Setup
st.set_page_config(
    page_title="AdaptiveSentinelGPT - SOC Command Center",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Dark Cybersecurity SOC CSS Design System (Reference Target Theme)
st.markdown("""
<style>
    /* Global Canvas & Typography */
    .stApp {
        background-color: #0b0f19 !important;
        color: #f8fafc !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    }
    header[data-testid="stHeader"] {
        background-color: rgba(11, 15, 25, 0.88) !important;
        border-bottom: 1px solid #1e293b !important;
    }
    .block-container {
        padding-top: 1.5rem !important;
        padding-bottom: 2.5rem !important;
        max-width: 97% !important;
    }
    h1, h2, h3, h4, h5, h6 {
        color: #f8fafc !important;
        letter-spacing: -0.015em !important;
    }
    p, li, span, label, div[data-testid="stMarkdownContainer"] {
        color: #e2e8f0;
    }
    code {
        background-color: #1e293b !important;
        color: #38bdf8 !important;
        border: 1px solid #334155 !important;
        padding: 2px 6px !important;
        border-radius: 4px !important;
        font-size: 0.84em !important;
    }

    /* Dark Navy Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #111827 !important;
        border-right: 1px solid #1e293b !important;
    }
    section[data-testid="stSidebar"] *, section[data-testid="stSidebar"] label, section[data-testid="stSidebar"] p {
        color: #cbd5e1 !important;
    }
    section[data-testid="stSidebar"] h1, section[data-testid="stSidebar"] h2, section[data-testid="stSidebar"] h3, section[data-testid="stSidebar"] h4 {
        color: #f8fafc !important;
        font-weight: 700 !important;
    }
    section[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] {
        background-color: #1e293b !important;
        color: #f8fafc !important;
        border-color: #334155 !important;
    }
    section[data-testid="stSidebar"] .stButton>button {
        background: linear-gradient(135deg, #0d9488 0%, #0284c7 100%) !important;
        color: #ffffff !important;
        border: 1px solid rgba(56, 189, 248, 0.35) !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        padding: 9px 14px !important;
        box-shadow: 0 2px 8px rgba(2, 132, 199, 0.28) !important;
    }
    section[data-testid="stSidebar"] .stButton>button:hover {
        background: linear-gradient(135deg, #14b8a6 0%, #0369a1 100%) !important;
        border-color: #38bdf8 !important;
        box-shadow: 0 4px 12px rgba(56, 189, 248, 0.4) !important;
    }

    /* Main Application Header Container */
    .main-header {
        background: linear-gradient(180deg, #111827 0%, #0f172a 100%) !important;
        border: 1px solid #1e293b !important;
        border-left: 4px solid #38bdf8 !important;
        border-radius: 12px !important;
        padding: 20px 24px !important;
        margin-bottom: 16px !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.45) !important;
    }

    .status-bar {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid #1e293b;
    }

    /* Dark Cybersecurity Enterprise Cards */
    .soc-card {
        background-color: #111827 !important;
        border: 1px solid #1e293b !important;
        border-radius: 10px !important;
        padding: 18px 20px !important;
        margin-bottom: 14px !important;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35) !important;
        color: #f8fafc !important;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }
    .soc-card:hover {
        border-color: #38bdf8 !important;
        box-shadow: 0 4px 18px rgba(56, 189, 248, 0.16) !important;
    }

    .telemetry-card {
        background-color: #111827 !important;
        border: 1px solid #0284c7 !important;
        border-radius: 10px !important;
        padding: 18px 20px !important;
        margin-bottom: 16px !important;
        box-shadow: 0 4px 16px rgba(2, 132, 199, 0.18) !important;
        color: #f8fafc !important;
    }

    .posture-card {
        background-color: #111827 !important;
        border: 1px solid #1e293b !important;
        border-radius: 10px !important;
        padding: 16px 20px !important;
        margin-bottom: 16px !important;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.3) !important;
    }

    /* Metric Widget Overrides (Cyan / Electric Blue KPI Numbers) */
    div[data-testid="stMetric"] {
        background-color: #111827 !important;
        border: 1px solid #1e293b !important;
        border-radius: 10px !important;
        padding: 12px 16px !important;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.28) !important;
    }
    div[data-testid="stMetricValue"] {
        font-size: 1.95rem !important;
        font-weight: 800 !important;
        color: #38bdf8 !important;
        letter-spacing: -0.02em !important;
    }
    div[data-testid="stMetricLabel"] {
        font-size: 0.78rem !important;
        color: #94a3b8 !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
        letter-spacing: 0.04em !important;
    }

    /* Compact Horizontal Tab Navigation Styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 6px;
        background-color: #111827 !important;
        padding: 6px !important;
        border-radius: 10px !important;
        border: 1px solid #1e293b !important;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.35) !important;
    }
    .stTabs [data-baseweb="tab"] {
        background-color: transparent !important;
        border-radius: 7px !important;
        padding: 8px 14px !important;
        color: #94a3b8 !important;
        font-weight: 600 !important;
        font-size: 0.84rem !important;
        border: 1px solid transparent !important;
        transition: all 0.15s ease !important;
    }
    .stTabs [data-baseweb="tab"]:hover {
        color: #f8fafc !important;
        background-color: #1e293b !important;
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%) !important;
        color: #ffffff !important;
        border: 1px solid #38bdf8 !important;
        box-shadow: 0 2px 10px rgba(37, 99, 235, 0.45) !important;
    }

    /* Expander & Input Overrides for Dark Mode */
    div[data-testid="stExpander"] {
        background-color: #111827 !important;
        border: 1px solid #1e293b !important;
        border-radius: 8px !important;
        margin-bottom: 10px !important;
    }
    div[data-testid="stExpander"] summary {
        color: #e2e8f0 !important;
        font-weight: 600 !important;
    }

    /* Semantic Alert & Severity Badges (Dark Theme High-Contrast Pills) */
    .badge-critical {
        background-color: rgba(127, 29, 29, 0.65);
        color: #fca5a5;
        border: 1px solid #ef4444;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        display: inline-block;
    }
    .badge-high {
        background-color: rgba(124, 45, 18, 0.65);
        color: #fdba74;
        border: 1px solid #f97316;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        display: inline-block;
    }
    .badge-medium {
        background-color: rgba(120, 53, 15, 0.65);
        color: #fde047;
        border: 1px solid #f59e0b;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        display: inline-block;
    }
    .badge-low {
        background-color: rgba(6, 78, 59, 0.65);
        color: #6ee7b7;
        border: 1px solid #10b981;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        letter-spacing: 0.03em;
        display: inline-block;
    }
    .badge-telemetry {
        background-color: rgba(12, 74, 110, 0.65);
        color: #7dd3fc;
        border: 1px solid #0284c7;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        display: inline-block;
    }
    .badge-simulated {
        background-color: rgba(88, 28, 135, 0.55);
        color: #d8b4fe;
        border: 1px solid #a855f7;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        display: inline-block;
    }
    .badge-status-green {
        background-color: rgba(6, 78, 59, 0.65);
        color: #6ee7b7;
        border: 1px solid #10b981;
        padding: 4px 12px;
        border-radius: 6px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-status-blue {
        background-color: rgba(30, 58, 138, 0.65);
        color: #93c5fd;
        border: 1px solid #3b82f6;
        padding: 4px 12px;
        border-radius: 6px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-info {
        background-color: rgba(12, 74, 110, 0.65);
        color: #7dd3fc;
        border: 1px solid #0284c7;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.76rem;
        font-weight: 700;
        display: inline-block;
    }
    .badge-status {
        background-color: #1e293b;
        color: #cbd5e1;
        border: 1px solid #334155;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 0.78rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }

    /* Primary Action Buttons */
    .stButton>button, .stDownloadButton>button, .stFormSubmitButton>button {
        background: linear-gradient(135deg, #1d4ed8 0%, #0284c7 100%) !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        border: 1px solid rgba(56, 189, 248, 0.35) !important;
        padding: 8px 16px !important;
        transition: all 0.2s ease-in-out !important;
        box-shadow: 0 2px 6px rgba(2, 132, 199, 0.25) !important;
    }
    .stButton>button:hover, .stDownloadButton>button:hover, .stFormSubmitButton>button:hover {
        transform: translateY(-1px) !important;
        border-color: #38bdf8 !important;
        box-shadow: 0 4px 12px rgba(56, 189, 248, 0.4) !important;
    }
</style>
""", unsafe_allow_html=True)

def _get_filter_state_file_path():
    from pathlib import Path
    import config.settings as _cfg_settings
    configured = Path(
        getattr(
            _cfg_settings,
            "DASHBOARD_FILTER_STATE_FILE_PATH",
            _cfg_settings.DATA_DIR / "dashboard_filter_state.json",
        )
    )
    default_prod = Path(_cfg_settings.DATA_DIR) / "dashboard_filter_state.json"
    if "PYTEST_CURRENT_TEST" in os.environ and configured.resolve() == default_prod.resolve():
        return None
    return configured


def _load_saved_filter_state() -> dict:
    p = _get_filter_state_file_path()
    if p and p.exists():
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def _save_filter_state(saved_filters: dict) -> None:
    p = _get_filter_state_file_path()
    if not p:
        return
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(saved_filters, f, indent=2)
    except Exception:
        pass


# Run Main Pipeline Execution Fresh
# Session State Initialization for Scenarios, Metrics, and Reset Tracking
_saved_demo_baseline = NXLogReader.load_demo_baseline()
_is_baseline_saved = bool(_saved_demo_baseline and _saved_demo_baseline.get("active"))
if "demo_baseline_active" not in st.session_state:
    st.session_state.demo_baseline_active = _is_baseline_saved
if "is_reset" not in st.session_state:
    st.session_state.is_reset = _is_baseline_saved
if "selected_scenario" not in st.session_state:
    st.session_state.selected_scenario = (
        _saved_demo_baseline.get("scenario", "reset")
        if _is_baseline_saved
        else "default"
    )
if "scenario_name" not in st.session_state:
    st.session_state.scenario_name = (
        "Dashboard Reset (0 Logs)"
        if _is_baseline_saved
        else "Default Telemetry Stream"
    )
if "scenario_metrics" not in st.session_state:
    st.session_state.scenario_metrics = {}
if "nxlog_demo_baseline_offset" not in st.session_state and _saved_demo_baseline:
    st.session_state.nxlog_demo_baseline_offset = _saved_demo_baseline.get("byte_offset")
def _backfill_retained_nxlog_history(kb_db, registry):
    """
    One-time read-only reconstruction of cumulative incident alert identities from
    the retained tail of C:\\AdaptiveSentinel\\windows-events.log into SQLite + Session
    without modifying nxlog_cursor.json or expanding the bounded 300-event live window.
    """
    if st.session_state.get("nxlog_history_backfilled", False):
        return
    st.session_state.nxlog_history_backfilled = True
    if not NXLOG_FILE_PATH.exists():
        return
    try:
        if "head_ts" in _BACKFILL_HEAD_TS_CACHE:
            for h_id, h_first in _BACKFILL_HEAD_TS_CACHE["head_ts"].items():
                entry = registry.setdefault(
                    h_id,
                    {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
                )
                entry.setdefault("metadata", {})
                prev_f = format_alert_timestamp(entry["metadata"].get("first_event_timestamp"))
                if not prev_f or h_first < prev_f:
                    entry["metadata"]["first_event_timestamp"] = h_first
            return
        existing_admin_keys = kb_db.get_incident_alert_keys("INC-85D28A").get("INC-85D28A", [])
        if len(existing_admin_keys) >= 52:
            # Seed earliest historical event timestamps from the head of the 5 MB retained window in-memory
            try:
                reader = NXLogReader()
                with open(NXLOG_FILE_PATH, "rb") as f:
                    f.seek(0, os.SEEK_END)
                    file_len = f.tell()
                    head_offset = max(0, file_len - 5000000)
                    f.seek(head_offset)
                    b_head = f.read(65536)
                if head_offset > 0:
                    first_nl = b_head.find(b"\n")
                    if first_nl != -1:
                        b_head = b_head[first_nl + 1:]
                        head_offset += first_nl + 1
                head_blocks = reader._split_into_blocks_with_offsets(
                    b_head.decode("utf-8", errors="replace"),
                    head_offset,
                    require_header_start=(head_offset > 0),
                )
                head_raw = []
                for b_str, b_off in head_blocks[:120]:
                    if b_str.strip():
                        p = reader.parse_line(b_str.strip())
                        if p:
                            p["record_offset"] = b_off
                            head_raw.append(p)
                head_ts_map = {}
                if head_raw:
                    head_norm = enrich_events(deduplicate_events(normalize_events(head_raw)))
                    head_alerts = DetectionAgent().detect(head_norm)
                    if head_alerts:
                        for h_inc in CorrelationAgent().correlate(head_alerts):
                            h_id = h_inc.get("incident_id")
                            h_first = format_alert_timestamp(h_inc.get("first_event_timestamp"))
                            if h_id and h_first:
                                head_ts_map[h_id] = h_first
                                entry = registry.setdefault(
                                    h_id,
                                    {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
                                )
                                entry.setdefault("metadata", {})
                                prev_f = format_alert_timestamp(entry["metadata"].get("first_event_timestamp"))
                                if not prev_f or h_first < prev_f:
                                    entry["metadata"]["first_event_timestamp"] = h_first
                _BACKFILL_HEAD_TS_CACHE["head_ts"] = head_ts_map
            except Exception:
                pass
            return
        hist_raw = NXLogReader().get_recent_events(max_events=800)
        if not hist_raw:
            return
        hist_norm = enrich_events(deduplicate_events(normalize_events(hist_raw)))
        hist_alerts = DetectionAgent().detect(hist_norm)
        if hist_alerts:
            hist_incidents = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(hist_alerts))
            apply_cumulative_incident_tracking(
                hist_incidents,
                registry=registry,
                db=kb_db,
                max_evidence_alerts=100,
                retain_historical_incidents=True,
            )
    except Exception:
        pass


def _evaluate_nxlog_pipeline(
    live_events,
    ingestion_parse_ms: float = 0.0,
    normalize_ms: float = 0.0,
    batch_event_count=None,
    scope_prefix: str = "End-to-End Batch",
):
    """
    Runs LogEnricher, DetectionAgent, CorrelationAgent, ThreatIntelligenceAgent,
    cumulative alert tracking (SQLite + Session), ExplainabilityAgent,
    ResponsePlanningAgent, and ReportingAgent on live NXLog events, measuring
    monotonic high-resolution elapsed time (time.perf_counter()) across each stage.
    """
    if not live_events:
        st.session_state.nxlog_alerts = []
        st.session_state.nxlog_incidents = []
        st.session_state.nxlog_explanations = []
        st.session_state.nxlog_response_plans = []
        st.session_state.nxlog_reports = []
        return None
    try:
        from datetime import datetime
        t_eval_start = time.perf_counter()
        if "nxlog_incident_history" not in st.session_state or not isinstance(
            st.session_state.get("nxlog_incident_history"), dict
        ):
            st.session_state.nxlog_incident_history = {}
        kb_db = KnowledgeBaseDB()
        if not (st.session_state.get("is_reset", False) or st.session_state.get("demo_baseline_active", False)):
            _backfill_retained_nxlog_history(kb_db, st.session_state.nxlog_incident_history)

        t0 = time.perf_counter()
        deduped_live = deduplicate_events(live_events)
        unenriched = [e for e in deduped_live if "asset_criticality" not in e]
        if unenriched:
            enrich_events(unenriched)
        enriched_live = deduped_live
        st.session_state.nxlog_live_events = enriched_live
        st.session_state.nxlog_seen_event_keys = {get_event_identity_key(e) for e in enriched_live}
        dedup_enrich_ms = (time.perf_counter() - t0) * 1000.0

        t0 = time.perf_counter()
        det_cache = st.session_state.get("_nxlog_detection_cache")
        if not isinstance(det_cache, dict):
            det_cache = {}
        unseen_for_det = []
        for evt in enriched_live:
            ek = get_event_identity_key(evt)
            if ek not in det_cache:
                det_cache[ek] = []
                unseen_for_det.append(evt)
        if unseen_for_det:
            batch_alerts = DetectionAgent().detect(unseen_for_det)
            for al in batch_alerts:
                al_ev = al.get("event")
                if isinstance(al_ev, dict):
                    aek = get_event_identity_key(al_ev)
                    det_cache.setdefault(aek, []).append(al)
        st.session_state._nxlog_detection_cache = det_cache
        nx_alerts = []
        for evt in enriched_live:
            ev_alerts = det_cache.get(get_event_identity_key(evt))
            if ev_alerts:
                nx_alerts.extend(ev_alerts)
        st.session_state.nxlog_alerts = nx_alerts
        detection_ms = (time.perf_counter() - t0) * 1000.0

        if nx_alerts:
            t0 = time.perf_counter()
            ca = CorrelationAgent()
            nx_incidents = ca.correlate(nx_alerts)
            correlation_ms = (time.perf_counter() - t0) * 1000.0

            t0 = time.perf_counter()
            nx_incidents = ThreatIntelligenceAgent().analyze(nx_incidents)
            nx_incidents = apply_cumulative_incident_tracking(
                nx_incidents,
                registry=st.session_state.nxlog_incident_history,
                db=kb_db,
                max_evidence_alerts=100,
                retain_historical_incidents=True,
            )
            st.session_state.nxlog_incidents = nx_incidents
            threat_intel_ms = (time.perf_counter() - t0) * 1000.0

            active_sec_nx_incidents = [
                inc for inc in nx_incidents
                if not inc.get("is_diagnostic")
                and int(inc.get("window_alert_count", 1) or 0) > 0
                and len(inc.get("alerts") or []) > 0
            ]
            t0 = time.perf_counter()
            st.session_state.nxlog_explanations = ExplainabilityAgent().explain(active_sec_nx_incidents) if active_sec_nx_incidents else []
            explain_ms = (time.perf_counter() - t0) * 1000.0

            t0 = time.perf_counter()
            st.session_state.nxlog_response_plans = ResponsePlanningAgent().plan(active_sec_nx_incidents) if active_sec_nx_incidents else []
            response_ms = (time.perf_counter() - t0) * 1000.0

            t0 = time.perf_counter()
            st.session_state.nxlog_reports = ReportingAgent().generate(active_sec_nx_incidents) if active_sec_nx_incidents else []
            report_ms = (time.perf_counter() - t0) * 1000.0
        else:
            t0 = time.perf_counter()
            nx_incidents = apply_cumulative_incident_tracking(
                [],
                registry=st.session_state.nxlog_incident_history,
                db=kb_db,
                max_evidence_alerts=100,
                retain_historical_incidents=True,
            )
            st.session_state.nxlog_incidents = nx_incidents
            correlation_ms = (time.perf_counter() - t0) * 1000.0
            threat_intel_ms = 0.0

            active_sec_nx_incidents = [
                inc for inc in nx_incidents
                if not inc.get("is_diagnostic")
                and int(inc.get("window_alert_count", 1) or 0) > 0
                and len(inc.get("alerts") or []) > 0
            ]
            t0 = time.perf_counter()
            st.session_state.nxlog_explanations = ExplainabilityAgent().explain(active_sec_nx_incidents) if active_sec_nx_incidents else []
            explain_ms = (time.perf_counter() - t0) * 1000.0

            t0 = time.perf_counter()
            st.session_state.nxlog_response_plans = ResponsePlanningAgent().plan(active_sec_nx_incidents) if active_sec_nx_incidents else []
            response_ms = (time.perf_counter() - t0) * 1000.0

            t0 = time.perf_counter()
            st.session_state.nxlog_reports = ReportingAgent().generate(active_sec_nx_incidents) if active_sec_nx_incidents else []
            report_ms = (time.perf_counter() - t0) * 1000.0

        eval_elapsed_ms = (time.perf_counter() - t_eval_start) * 1000.0
        total_ms = round(max(0.001, float(ingestion_parse_ms) + float(normalize_ms) + eval_elapsed_ms), 3)
        effective_batch_count = (
            int(batch_event_count)
            if (batch_event_count is not None and int(batch_event_count) > 0)
            else len(enriched_live)
        )
        per_event_ms = round(total_ms / max(1, effective_batch_count), 3)
        evt_noun = "event" if effective_batch_count == 1 else "events"
        scope_label = f"{scope_prefix} ({effective_batch_count} {evt_noun}, {per_event_ms:.2f} ms/evt)"

        nx_agent_perf = {
            "NXLog Telemetry Sync": {
                "agent": "NXLog Network Telemetry Sync",
                "time_ms": round(float(ingestion_parse_ms), 3),
                "task": f"Ingested & parsed {effective_batch_count} live NXLog {evt_noun}",
            },
            "Normalization & Deduplication": {
                "agent": "Normalization Engine",
                "time_ms": round(float(normalize_ms) + dedup_enrich_ms, 3),
                "task": f"Normalized, deduplicated & enriched {len(enriched_live)} live events",
            },
            "Detection Agent": {
                "agent": "Detection Agent",
                "time_ms": round(detection_ms, 3),
                "task": f"Evaluated {len(enriched_live)} events ({len(nx_alerts)} rule alerts)",
            },
            "Correlation Agent": {
                "agent": "Correlation Agent",
                "time_ms": round(correlation_ms, 3),
                "task": f"Correlated alerts into {len(nx_incidents)} incident(s)",
            },
            "Threat Intelligence Agent": {
                "agent": "Threat Intelligence Agent",
                "time_ms": round(threat_intel_ms, 3),
                "task": "Evaluated IOC & IP reputation risk scores",
            },
            "Explainability Agent": {
                "agent": "Explainability Agent",
                "time_ms": round(explain_ms, 3),
                "task": "Generated root-cause explanations for active incidents",
            },
            "Response Planning Agent": {
                "agent": "Response Planning Agent",
                "time_ms": round(response_ms, 3),
                "task": "Compiled SOAR response playbooks",
            },
            "Reporting Agent": {
                "agent": "Reporting Agent",
                "time_ms": round(report_ms, 3),
                "task": "Generated executive & technical SOC reports",
            },
            "Total Pipeline Execution": {
                "agent": "Pipeline Orchestrator",
                "time_ms": total_ms,
                "task": scope_label,
            },
        }
        measured_latency = {
            "total_ms": total_ms,
            "per_event_ms": per_event_ms,
            "batch_event_count": effective_batch_count,
            "stream_event_count": len(enriched_live),
            "scope": scope_label,
            "measurement_definition": (
                "End-to-End Batch Latency (NXLog Ingestion/Parse + OCSF Normalization + "
                "Deduplication/Enrichment + Detection + Correlation/TI + Explainability/SOAR/Reporting)"
            ),
            "measured_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "stage_timings_ms": {
                "ingestion_parse_ms": round(float(ingestion_parse_ms), 3),
                "normalize_ms": round(float(normalize_ms), 3),
                "dedup_enrich_ms": round(dedup_enrich_ms, 3),
                "detection_ms": round(detection_ms, 3),
                "correlation_ms": round(correlation_ms, 3),
                "threat_intel_ms": round(threat_intel_ms, 3),
                "explain_ms": round(explain_ms, 3),
                "response_ms": round(response_ms, 3),
                "report_ms": round(report_ms, 3),
            },
        }
        st.session_state.nxlog_agent_performance = nx_agent_perf
        st.session_state.nxlog_pipeline_latency = measured_latency
        st.session_state.pipeline_latency_metrics = measured_latency
        if isinstance(st.session_state.get("pipeline_results"), dict):
            st.session_state.pipeline_results["agent_performance"] = dict(nx_agent_perf)
        return measured_latency
    except Exception:
        st.session_state.nxlog_alerts = st.session_state.get("nxlog_alerts", [])
        st.session_state.nxlog_incidents = st.session_state.get("nxlog_incidents", [])
        st.session_state.nxlog_explanations = st.session_state.get("nxlog_explanations", [])
        st.session_state.nxlog_response_plans = st.session_state.get("nxlog_response_plans", [])
        st.session_state.nxlog_reports = st.session_state.get("nxlog_reports", [])
        return None


if st.session_state.get("nxlog_state_version") != "phase3_v19":
    st.session_state.pop("nxlog_live_events", None)
    st.session_state.pop("nxlog_alerts", None)
    st.session_state.pop("nxlog_incidents", None)
    st.session_state.pop("nxlog_explanations", None)
    st.session_state.pop("nxlog_response_plans", None)
    st.session_state.pop("nxlog_reports", None)
    st.session_state.pop("nxlog_incident_history", None)
    st.session_state.pop("nxlog_history_backfilled", None)
    st.session_state.pop("nxlog_pipeline_latency", None)
    st.session_state.pop("pipeline_latency_metrics", None)
    st.session_state.pop("nxlog_agent_performance", None)
    st.session_state.pop("pipeline_results", None)
    st.session_state.pop("nxlog_raw_received_count", None)
    st.session_state.pop("nxlog_raw_received_by_host", None)
    st.session_state.pop("nxlog_unique_processed_count", None)
    st.session_state.pop("nxlog_displayed_event_count", None)
    st.session_state.pop("nxlog_last_batch_count", None)
    st.session_state.pop("nxlog_seen_event_keys", None)
    st.session_state.pop("_nxlog_detection_cache", None)
    st.session_state.nxlog_state_version = "phase3_v19"


# UI Display Window Cap: limits only the rendered table rows in Sector 1's Live Event Stream.
# Full ingested/deduplicated telemetry is retained in st.session_state.nxlog_live_events so
# events beyond 500 are never dropped or lost across refreshes.
NXLOG_DISPLAY_WINDOW_LIMIT = 500


def _cap_nxlog_live_buffer(all_evts, max_non_diag: int = NXLOG_DISPLAY_WINDOW_LIMIT, max_5379: int = 160):
    """
    Caps a rendered display slice to `max_non_diag` non-diagnostic events
    plus all diagnostic probes, while capping repetitive Event ID 5379 bursts so
    diverse Windows security/system events remain visible in the active display window.
    """
    diag_evts = [e for e in all_evts if e.get("is_diagnostic")]
    non_diag_evts = [e for e in all_evts if not e.get("is_diagnostic")]
    if len(non_diag_evts) <= max_non_diag:
        return list(all_evts)
    from analysis.normalize import LogNormalizer
    preserved_markers = getattr(
        LogNormalizer,
        "PRESERVED_LIVE_MARKERS",
        ("ADAPTIVESENTINEL_LIVE_", "ADAPTIVESENTINEL_"),
    )
    count_5379 = 0
    selected_rev = []
    overflow_5379_rev = []
    for e in reversed(non_diag_evts):
        desc_s = str(e.get("description") or "")
        raw_s = str(e.get("raw_line") or "")
        if "ADAPTIVESENTINEL" in desc_s or "ADAPTIVESENTINEL" in raw_s or "adaptivesentinel" in desc_s.lower():
            desc_u = desc_s.upper()
            msg_u = str(e.get("message") or "").upper()
            raw_u = raw_s.upper()
            is_marker = any(m in desc_u or m in msg_u or m in raw_u for m in preserved_markers)
        else:
            is_marker = False
        try:
            ev_id = int(e.get("event_id", 0) or 0)
        except (ValueError, TypeError):
            ev_id = 0
        if ev_id == 5379 and not is_marker:
            if count_5379 < max_5379 and len(selected_rev) < max_non_diag:
                selected_rev.append(e)
                count_5379 += 1
            elif len(overflow_5379_rev) < max_non_diag:
                overflow_5379_rev.append(e)
        else:
            if len(selected_rev) < max_non_diag or is_marker:
                selected_rev.append(e)
    if len(selected_rev) < max_non_diag and overflow_5379_rev:
        needed = max_non_diag - len(selected_rev)
        selected_rev.extend(overflow_5379_rev[:needed])
    selected_rev.reverse()
    return diag_evts + selected_rev[-max_non_diag:]


def _record_raw_received_events(normalized_batch):
    """
    Tracks genuine raw (pre-deduplication) non-diagnostic events received from the
    NXLog receiver log both globally and per canonical endpoint hostname.
    """
    raw_by_host = st.session_state.get("nxlog_raw_received_by_host")
    if not isinstance(raw_by_host, dict):
        raw_by_host = {}
    raw_added = 0
    for evt in normalized_batch:
        if evt.get("is_diagnostic"):
            continue
        raw_added += 1
        h_canon = resolve_canonical_hostname(evt.get("hostname"))
        raw_by_host[h_canon] = int(raw_by_host.get(h_canon, 0) or 0) + 1
    st.session_state.nxlog_raw_received_by_host = raw_by_host
    st.session_state.nxlog_raw_received_count = int(st.session_state.get("nxlog_raw_received_count", 0) or 0) + raw_added
    return raw_added


def sync_nxlog_telemetry_live(log_file=None, cursor_file=None, auto_triggered: bool = False):
    r"""
    Polls C:\AdaptiveSentinel\windows-events.log for incoming endpoint events.
    Accumulates newly ingested events into st.session_state.nxlog_live_events using incremental cursor tracking
    without truncating events beyond 500, distinguishes raw received vs. unique processed vs. displayed vs.
    current-refresh batch counts, and runs multi-agent detection and correlation on live events.
    Preserves existing records, counters, and the latest valid pipeline latency measurement when no new events
    are available or when an error occurs.
    """
    from datetime import datetime
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
        if not reader.log_file.exists():
            err_msg = f"NXLog receiver log file not found: {reader.log_file}"
            st.session_state.nxlog_last_sync_time = now_str
            st.session_state.nxlog_ingestion_status = f"Ingestion error: {err_msg}"
            st.session_state.nxlog_last_sync_error = err_msg
            st.session_state.nxlog_last_batch_count = 0
            st.session_state.new_events_current_refresh = 0
            st.session_state.nxlog_sync_feedback = ("error", f"⚠️ NXLog sync error: {err_msg}")
            return [], {"error": err_msg, "status": "ERROR", "valid_ingested": 0, "duplicates_skipped": 0}

        baseline_info = reader.load_demo_baseline(cursor_file=reader.cursor_file)
        is_baseline_active = (
            st.session_state.get("demo_baseline_active", False)
            or st.session_state.get("is_reset", False)
            or bool(baseline_info)
        )

        # If non-baseline initial tail load ran without an existing cursor file on disk, start incremental read
        # from the previously observed file size so only newly appended records are read.
        fallback_from_offset = None
        if (
            not is_baseline_active
            and not reader.cursor_file.exists()
            and st.session_state.get("nxlog_live_events")
            and int(st.session_state.get("nxlog_last_seen_size", 0) or 0) > 0
        ):
            fallback_from_offset = int(st.session_state.get("nxlog_last_seen_size", 0))

        t_read_start = time.perf_counter()
        new_evts = reader.read_events(incremental=True, from_offset=fallback_from_offset)
        if reader.last_error and not new_evts:
            err_msg = reader.last_error
            st.session_state.nxlog_last_sync_time = now_str
            st.session_state.nxlog_ingestion_status = f"Ingestion error: {err_msg}"
            st.session_state.nxlog_last_sync_error = err_msg
            st.session_state.nxlog_last_batch_count = 0
            st.session_state.new_events_current_refresh = 0
            st.session_state.nxlog_sync_feedback = ("error", f"⚠️ NXLog sync error: {err_msg}")
            return [], {"error": err_msg, "status": "ERROR", "valid_ingested": 0, "duplicates_skipped": 0}

        if is_baseline_active:
            baseline_min_offset = st.session_state.get("nxlog_demo_baseline_offset")
            if baseline_min_offset is None and baseline_info:
                baseline_min_offset = baseline_info.get("byte_offset", 0)
            if baseline_min_offset is not None:
                combined_candidates = [
                    e for e in new_evts
                    if int(e.get("record_offset", baseline_min_offset) or 0) >= int(baseline_min_offset)
                ]
            else:
                combined_candidates = list(new_evts)
        else:
            if not st.session_state.get("nxlog_live_events"):
                tail_evts = reader.get_recent_events(max_events=300)
                combined_candidates = list(new_evts) + [e for e in tail_evts if e not in new_evts]
            else:
                combined_candidates = list(new_evts)
        read_parse_ms = (time.perf_counter() - t_read_start) * 1000.0

        if not combined_candidates:
            already_in_pass = int(st.session_state.get("_this_pass_ingested_count", 0) or 0)
            st.session_state.nxlog_last_sync_time = now_str
            st.session_state.nxlog_last_sync_error = None
            if already_in_pass > 0:
                already_dups = int(st.session_state.get("_this_pass_dups_skipped", 0) or 0)
                st.session_state.nxlog_last_batch_count = already_in_pass
                st.session_state.new_events_current_refresh = already_in_pass
                mode_prefix = "Auto-Synchronized" if auto_triggered else "Synchronized"
                st.session_state.nxlog_ingestion_status = f"{mode_prefix} (+{already_in_pass} new event(s))"
                if not auto_triggered:
                    st.session_state.nxlog_sync_feedback = (
                        "success",
                        f"✅ {mode_prefix}: Ingested {already_in_pass} new NXLog events! ({already_dups} skipped)",
                    )
                return [], {
                    "valid_ingested": already_in_pass,
                    "duplicates_skipped": already_dups,
                    "status": "INGESTED",
                    "message": f"Ingested {already_in_pass} new NXLog events",
                }
            st.session_state.nxlog_last_batch_count = 0
            st.session_state.new_events_current_refresh = 0
            st.session_state.nxlog_ingestion_status = "No new events received"
            if not auto_triggered:
                st.session_state.nxlog_sync_feedback = (
                    "info",
                    "ℹ️ No new events received from C:\\AdaptiveSentinel\\windows-events.log. Existing records and counters preserved.",
                )
            return [], {"valid_ingested": 0, "duplicates_skipped": 0, "status": "NO_NEW_EVENTS", "message": "No new events received"}

        t_norm_start = time.perf_counter()
        normalized_new = normalize_events(combined_candidates)
        raw_batch_added = _record_raw_received_events(normalized_new)

        seen_keys = st.session_state.get("nxlog_seen_event_keys")
        if not isinstance(seen_keys, set):
            seen_keys = {get_event_identity_key(e) for e in st.session_state.nxlog_live_events}
        else:
            seen_keys.update(get_event_identity_key(e) for e in st.session_state.nxlog_live_events)

        added_count = 0
        added_security_count = 0
        for evt in normalized_new:
            ev_key = get_event_identity_key(evt)
            if ev_key in seen_keys:
                continue
            st.session_state.nxlog_live_events.append(evt)
            seen_keys.add(ev_key)
            added_count += 1
            if not evt.get("is_diagnostic"):
                added_security_count += 1
        st.session_state.nxlog_seen_event_keys = seen_keys
        norm_append_ms = (time.perf_counter() - t_norm_start) * 1000.0

        if reader.log_file.exists():
            st.session_state.nxlog_last_seen_size = reader.log_file.stat().st_size

        st.session_state.nxlog_last_sync_time = now_str
        if st.session_state.nxlog_live_events:
            st.session_state.nxlog_last_event_time = str(
                st.session_state.nxlog_live_events[-1].get("timestamp") or now_str
            )[:19].replace("T", " ")

        if added_count == 0:
            already_in_pass = int(st.session_state.get("_this_pass_ingested_count", 0) or 0)
            st.session_state.nxlog_last_batch_count = already_in_pass
            st.session_state.new_events_current_refresh = already_in_pass
            if new_evts:
                processed_count = len(combined_candidates)
                status_msg = f"Stream current ({processed_count} processed, already in buffer)"
                feedback_msg = (
                    f"ℹ️ Stream current: {processed_count} event(s) processed from receiver — "
                    "all already in live buffer. Existing records and counters preserved."
                )
            else:
                status_msg = "No new events received"
                feedback_msg = (
                    "ℹ️ No new events received from C:\\AdaptiveSentinel\\windows-events.log. "
                    "Existing records and counters preserved."
                )
            st.session_state.nxlog_ingestion_status = status_msg
            st.session_state.nxlog_last_sync_error = None
            if not auto_triggered:
                st.session_state.nxlog_sync_feedback = ("info", feedback_msg)
            return [], {
                "valid_ingested": 0,
                "duplicates_skipped": len(new_evts),
                "status": "STREAM_CURRENT" if new_evts else "NO_NEW_EVENTS",
                "message": status_msg,
            }

        dup_skipped = max(0, raw_batch_added - added_security_count)
        st.session_state.nxlog_cumulative_count = int(st.session_state.get("nxlog_cumulative_count", 0) or 0) + added_security_count
        st.session_state._this_pass_ingested_count = int(st.session_state.get("_this_pass_ingested_count", 0) or 0) + added_security_count
        st.session_state._this_pass_dups_skipped = int(st.session_state.get("_this_pass_dups_skipped", 0) or 0) + dup_skipped
        st.session_state.nxlog_last_batch_count = st.session_state._this_pass_ingested_count
        st.session_state.new_events_current_refresh = st.session_state._this_pass_ingested_count

        if st.session_state.get("is_reset", False):
            st.session_state.is_reset = False
            st.session_state.demo_baseline_active = True
            if st.session_state.get("selected_scenario") == "reset":
                st.session_state.selected_scenario = "live_post_baseline"
                st.session_state.scenario_name = "Live NXLog Real Telemetry (Post-Baseline)"

        # Evaluate full enrichment, detection, correlation, threat intel, explainability, and reporting on the full unique stream
        measured_lat = _evaluate_nxlog_pipeline(
            st.session_state.nxlog_live_events,
            ingestion_parse_ms=read_parse_ms,
            normalize_ms=norm_append_ms,
            batch_event_count=added_security_count if added_security_count > 0 else added_count,
            scope_prefix="End-to-End Live Batch",
        )

        mode_prefix = "Auto-Synchronized" if auto_triggered else "Synchronized"
        st.session_state.nxlog_ingestion_status = f"{mode_prefix} (+{added_security_count} new event(s))"
        st.session_state.nxlog_last_sync_error = None
        st.session_state.nxlog_sync_feedback = (
            "success",
            f"✅ {mode_prefix}: Ingested {added_security_count} new NXLog events! ({dup_skipped} skipped)",
        )
        return new_evts, {
            "valid_ingested": added_security_count,
            "raw_received": raw_batch_added,
            "duplicates_skipped": dup_skipped,
            "status": "INGESTED",
            "message": f"Ingested {added_security_count} new NXLog events",
            "pipeline_latency_ms": measured_lat["total_ms"] if measured_lat else None,
            "per_event_latency_ms": measured_lat["per_event_ms"] if measured_lat else None,
            "latency_scope": measured_lat["scope"] if measured_lat else None,
        }
    except Exception as e:
        err_msg = str(e)
        st.session_state.nxlog_last_sync_time = now_str
        st.session_state.nxlog_ingestion_status = f"Ingestion error: {err_msg}"
        st.session_state.nxlog_last_sync_error = err_msg
        st.session_state.nxlog_last_batch_count = 0
        st.session_state.new_events_current_refresh = 0
        st.session_state.nxlog_sync_feedback = ("error", f"⚠️ NXLog sync error: {err_msg}")
        return [], {"error": err_msg, "status": "ERROR", "valid_ingested": 0, "duplicates_skipped": 0}


# Track per-refresh-pass new events accurately across direct runs and button-triggered st.rerun() passes
if st.session_state.pop("_preserve_refresh_batch_on_rerun", False):
    st.session_state._this_pass_ingested_count = int(st.session_state.get("nxlog_last_batch_count", 0) or 0)
    st.session_state._this_pass_dups_skipped = int(st.session_state.get("_this_pass_dups_skipped", 0) or 0)
else:
    st.session_state._this_pass_ingested_count = 0
    st.session_state._this_pass_dups_skipped = 0
    st.session_state.nxlog_last_batch_count = 0
    st.session_state.new_events_current_refresh = 0


if "nxlog_live_events" not in st.session_state:
    is_demo_baseline = st.session_state.get("demo_baseline_active", False) or st.session_state.get("is_reset", False)
    st.session_state.nxlog_raw_received_count = 0
    st.session_state.nxlog_raw_received_by_host = {}
    st.session_state._nxlog_detection_cache = {}
    if is_demo_baseline and NXLOG_FILE_PATH.exists():
        # Demo baseline is active: start at 0, only ingest events appended at or after the baseline offset
        try:
            reader = NXLogReader()
            baseline_data = reader.load_demo_baseline(cursor_file=reader.cursor_file)
            baseline_off = st.session_state.get("nxlog_demo_baseline_offset")
            if baseline_off is None and baseline_data:
                baseline_off = baseline_data.get("byte_offset")
            t_read0 = time.perf_counter()
            post_baseline_evts = reader.read_events(
                incremental=True,
                from_offset=int(baseline_off) if baseline_off is not None else None,
            )
            init_read_ms = (time.perf_counter() - t_read0) * 1000.0
            t_norm0 = time.perf_counter()
            norm_post_all = normalize_events(post_baseline_evts)
            _record_raw_received_events(norm_post_all)
            norm_post = deduplicate_events(norm_post_all)
            init_norm_ms = (time.perf_counter() - t_norm0) * 1000.0
            unique_post_sec = [e for e in norm_post if not e.get("is_diagnostic")]
            st.session_state.nxlog_cumulative_count = len(unique_post_sec)
            st.session_state.nxlog_live_events = norm_post
            st.session_state.nxlog_seen_event_keys = {get_event_identity_key(e) for e in norm_post}
            st.session_state.nxlog_last_batch_count = len(unique_post_sec)
            st.session_state.new_events_current_refresh = len(unique_post_sec)
            st.session_state._this_pass_ingested_count = len(unique_post_sec)
            st.session_state.nxlog_last_seen_size = NXLOG_FILE_PATH.stat().st_size
            if norm_post:
                st.session_state.is_reset = False
                st.session_state.selected_scenario = "live_post_baseline"
                st.session_state.scenario_name = "Live NXLog Real Telemetry (Post-Baseline)"
                _evaluate_nxlog_pipeline(
                    st.session_state.nxlog_live_events,
                    ingestion_parse_ms=init_read_ms,
                    normalize_ms=init_norm_ms,
                    batch_event_count=len(unique_post_sec) if unique_post_sec else len(norm_post),
                    scope_prefix="End-to-End Post-Baseline Batch",
                )
            else:
                st.session_state.is_reset = True
                st.session_state.selected_scenario = "reset"
                st.session_state.scenario_name = "Dashboard Reset (0 Logs)"
                st.session_state.nxlog_pipeline_latency = None
                st.session_state.pipeline_latency_metrics = None
                _evaluate_nxlog_pipeline([])
            st.session_state.nxlog_last_sync_time = "Baseline Active"
            st.session_state.nxlog_last_event_time = (
                str(norm_post[-1].get("timestamp") or "N/A")[:19].replace("T", " ")
                if norm_post else "N/A"
            )
            st.session_state.nxlog_ingestion_status = (
                f"Auto-Synchronized (+{len(unique_post_sec)} post-baseline event(s))"
                if unique_post_sec
                else "Demo baseline established — awaiting new telemetry"
            )
            st.session_state.nxlog_last_sync_error = None
        except Exception as init_err:
            st.session_state.nxlog_live_events = []
            st.session_state.nxlog_seen_event_keys = set()
            st.session_state.nxlog_cumulative_count = 0
            st.session_state.nxlog_raw_received_count = 0
            st.session_state.nxlog_raw_received_by_host = {}
            st.session_state.nxlog_last_batch_count = 0
            st.session_state.new_events_current_refresh = 0
            st.session_state.nxlog_last_seen_size = 0
            st.session_state.nxlog_pipeline_latency = None
            st.session_state.nxlog_ingestion_status = f"Initialization error: {init_err}"
            st.session_state.nxlog_last_sync_error = str(init_err)
    elif not is_demo_baseline and NXLOG_FILE_PATH.exists():
        try:
            reader = NXLogReader()
            t_read0 = time.perf_counter()
            init_evts = reader.get_recent_events(max_events=300)
            init_read_ms = (time.perf_counter() - t_read0) * 1000.0
            t_norm0 = time.perf_counter()
            norm_init_all = normalize_events(init_evts)
            _record_raw_received_events(norm_init_all)
            norm_init = deduplicate_events(norm_init_all)
            init_norm_ms = (time.perf_counter() - t_norm0) * 1000.0
            unique_init_sec = [e for e in norm_init if not e.get("is_diagnostic")]
            st.session_state.nxlog_live_events = norm_init
            st.session_state.nxlog_seen_event_keys = {get_event_identity_key(e) for e in norm_init}
            st.session_state.nxlog_cumulative_count = max(
                int(st.session_state.get("nxlog_cumulative_count", 0)),
                len(unique_init_sec),
            )
            st.session_state.nxlog_last_batch_count = len(unique_init_sec)
            st.session_state.new_events_current_refresh = len(unique_init_sec)
            st.session_state._this_pass_ingested_count = len(unique_init_sec)
            st.session_state.nxlog_last_seen_size = NXLOG_FILE_PATH.stat().st_size
            _evaluate_nxlog_pipeline(
                st.session_state.nxlog_live_events,
                ingestion_parse_ms=init_read_ms,
                normalize_ms=init_norm_ms,
                batch_event_count=len(unique_init_sec) if unique_init_sec else len(norm_init),
                scope_prefix="End-to-End Initial Stream",
            )
            st.session_state.nxlog_last_sync_time = str(
                (st.session_state.nxlog_live_events[-1].get("ingestion_timestamp") if st.session_state.nxlog_live_events else "")
                or "Initial Load"
            )[:19].replace("T", " ")
            st.session_state.nxlog_last_event_time = str(
                (st.session_state.nxlog_live_events[-1].get("timestamp") if st.session_state.nxlog_live_events else "")
                or "N/A"
            )[:19].replace("T", " ")
            st.session_state.nxlog_ingestion_status = "Ready (Auto-monitoring active)"
            st.session_state.nxlog_last_sync_error = None
        except Exception as init_err:
            st.session_state.nxlog_live_events = []
            st.session_state.nxlog_seen_event_keys = set()
            st.session_state.nxlog_cumulative_count = 0
            st.session_state.nxlog_raw_received_count = 0
            st.session_state.nxlog_raw_received_by_host = {}
            st.session_state.nxlog_last_batch_count = 0
            st.session_state.new_events_current_refresh = 0
            st.session_state.nxlog_last_seen_size = 0
            st.session_state.nxlog_pipeline_latency = None
            st.session_state.nxlog_ingestion_status = f"Initialization error: {init_err}"
            st.session_state.nxlog_last_sync_error = str(init_err)
    else:
        st.session_state.nxlog_live_events = []
        st.session_state.nxlog_seen_event_keys = set()
        st.session_state.nxlog_cumulative_count = 0
        st.session_state.nxlog_raw_received_count = 0
        st.session_state.nxlog_raw_received_by_host = {}
        st.session_state.nxlog_last_batch_count = 0
        st.session_state.new_events_current_refresh = 0
        st.session_state.nxlog_last_seen_size = 0
        st.session_state.nxlog_pipeline_latency = None
        st.session_state.nxlog_ingestion_status = "Awaiting telemetry"
        st.session_state.nxlog_last_sync_error = None
elif NXLOG_FILE_PATH.exists():
    try:
        current_file_size = NXLOG_FILE_PATH.stat().st_size
        if current_file_size != st.session_state.get("nxlog_last_seen_size", 0):
            sync_nxlog_telemetry_live(auto_triggered=True)
    except Exception as auto_sync_err:
        st.session_state.nxlog_last_sync_error = str(auto_sync_err)

if "nxlog_alerts" not in st.session_state or "nxlog_incidents" not in st.session_state:
    _evaluate_nxlog_pipeline(st.session_state.get("nxlog_live_events", []))
if "nxlog_cumulative_count" not in st.session_state:
    st.session_state.nxlog_cumulative_count = len([e for e in st.session_state.nxlog_live_events if not e.get("is_diagnostic")])
if "nxlog_raw_received_count" not in st.session_state:
    st.session_state.nxlog_raw_received_count = st.session_state.nxlog_cumulative_count
if "nxlog_raw_received_by_host" not in st.session_state:
    st.session_state.nxlog_raw_received_by_host = {}
if "nxlog_last_batch_count" not in st.session_state:
    st.session_state.nxlog_last_batch_count = 0
if "nxlog_ingestion_status" not in st.session_state:
    st.session_state.nxlog_ingestion_status = "Ready"
if "nxlog_last_sync_error" not in st.session_state:
    st.session_state.nxlog_last_sync_error = None

# Pipeline Results State Preservation (Event-driven execution, no repeated runs on reruns)
if "pipeline_results" not in st.session_state:
    if (
        (st.session_state.get("is_reset", False) and st.session_state.get("selected_scenario") == "reset")
        or st.session_state.get("demo_baseline_active", False)
    ):
        st.session_state.pipeline_results = {
            "logs": [], "alerts": [], "incidents": [], "explanations": [],
            "response_plans": [], "reports": [],
            "agent_performance": dict(st.session_state.get("nxlog_agent_performance") or {}),
        }
    else:
        st.session_state.pipeline_results = main_module.main(include_nxlog=False)

results = st.session_state.pipeline_results
logs = results.get("logs", [])
incidents = [inc for inc in results.get("incidents", []) if not inc.get("is_diagnostic")]
explanations = list(st.session_state.get("nxlog_explanations", [])) + list(results.get("explanations", []))
response_plans = list(st.session_state.get("nxlog_response_plans", [])) + list(results.get("response_plans", []))
reports = list(st.session_state.get("nxlog_reports", [])) + list(results.get("reports", []))
agent_perf = st.session_state.get("nxlog_agent_performance") or results.get("agent_performance", {})

# Fetch Real NXLog Integration Health & Endpoint Tracking
nxlog_exists = NXLOG_FILE_PATH.exists()

# Compute Real NXLog Telemetry Statistics strictly using session state live events
nxlog_logs = st.session_state.nxlog_live_events
nxlog_security_logs = [l for l in nxlog_logs if not l.get("is_diagnostic")]
nxlog_diag_logs = [l for l in nxlog_logs if l.get("is_diagnostic")]
nxlog_alerts = st.session_state.get("nxlog_alerts", [])
nxlog_all_incidents = st.session_state.get("nxlog_incidents", [])
nxlog_incidents = [
    inc for inc in nxlog_all_incidents
    if not inc.get("is_diagnostic")
    and int(inc.get("window_alert_count", 1) or 0) > 0
    and len(inc.get("alerts") or []) > 0
]
nxlog_historical_incidents = [
    inc for inc in nxlog_all_incidents
    if not inc.get("is_diagnostic")
    and int(inc.get("window_alert_count", 1) or 0) == 0
]
nxlog_diag_incidents = [inc for inc in nxlog_all_incidents if inc.get("is_diagnostic")]
st.session_state.nxlog_security_logs = nxlog_security_logs
st.session_state.nxlog_historical_incidents = nxlog_historical_incidents

# Resolve Centralized Receiver, Active TCP 2514 Peer & Multi-Endpoint Inventory Metadata
net_state = get_central_network_state(observed_events=nxlog_security_logs or nxlog_logs, start_udp_responder=True)
active_receiver_ip = net_state["receiver_ip_current"]
active_receiver_hostname = net_state["receiver_hostname"]
active_receiver_port = net_state["receiver_port"]
active_receiver_addr = f"{active_receiver_ip}:{active_receiver_port}"
active_network_interface = net_state["network_interface"]
active_tcp_peer_ip = net_state.get("raw_remote_peer_ip", "N/A")
latest_nxlog_log = nxlog_security_logs[-1] if nxlog_security_logs else (nxlog_logs[-1] if nxlog_logs else {})
nxlog_endpoint_inventory = build_endpoint_inventory(
    nxlog_security_logs,
    receiver_ip=active_receiver_ip,
    active_tcp_peer_ip=active_tcp_peer_ip,
)

if len(nxlog_endpoint_inventory) == 1:
    observed_endpoint_host = format_network_display(
        nxlog_endpoint_inventory[0]["hostname"], field_role="sender_hostname"
    )
    raw_ep_ip = nxlog_endpoint_inventory[0]["observed_source_ip"]
    raw_ep_peer = nxlog_endpoint_inventory[0]["observed_remote_peer_ip"]
    observed_endpoint_ip = format_network_display(
        raw_ep_ip if raw_ep_ip != "N/A" else raw_ep_peer,
        field_role="sender_ip",
        fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
        last_known_ip=net_state.get("last_known_sender_ip"),
    )
elif len(nxlog_endpoint_inventory) > 1:
    host_names_joined = ", ".join(ep["hostname"] for ep in nxlog_endpoint_inventory)
    observed_endpoint_host = f"{len(nxlog_endpoint_inventory)} Endpoints ({host_names_joined})"
    valid_ips = [
        ep["observed_source_ip"] if ep["observed_source_ip"] != "N/A" else ep["observed_remote_peer_ip"]
        for ep in nxlog_endpoint_inventory
        if ep["observed_source_ip"] != "N/A" or ep["observed_remote_peer_ip"] != "N/A"
    ]
    observed_endpoint_ip = (
        ", ".join(dict.fromkeys(valid_ips))
        if valid_ips
        else format_network_display(
            None,
            field_role="sender_ip",
            fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
            last_known_ip=net_state.get("last_known_sender_ip"),
        )
    )
else:
    observed_endpoint_host = format_network_display(
        net_state.get("sender_hostname", ENDPOINT_HOSTNAME), field_role="sender_hostname"
    )
    observed_endpoint_ip = format_network_display(
        get_endpoint_ip(None, receiver_ip=active_receiver_ip),
        field_role="sender_ip",
        fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
        last_known_ip=net_state.get("last_known_sender_ip"),
    )

_seen_sim_log_ids = {id(x) for x in logs}
all_combined_events = list(logs) + [l for l in nxlog_security_logs if id(l) not in _seen_sim_log_ids]
all_endpoint_inventory = build_endpoint_inventory(
    all_combined_events,
    receiver_ip=active_receiver_ip,
    active_tcp_peer_ip=active_tcp_peer_ip,
)
available_endpoint_hosts = [
    ep["hostname"] for ep in all_endpoint_inventory
    if ep["hostname"] and ep["hostname"] != "UNKNOWN_HOST"
]
if any(ep["hostname"] == "UNKNOWN_HOST" for ep in all_endpoint_inventory):
    available_endpoint_hosts.append("UNKNOWN_HOST")

# Sidebar Controls (Dark Navy Enterprise Console)
with st.sidebar:
    st.markdown("""
    <div style="text-align: center; padding: 10px 0 16px 0; border-bottom: 1px solid #1e293b; margin-bottom: 16px;">
        <h2 style="margin: 0; color: #f8fafc; font-size: 1.4rem; font-weight: 800; letter-spacing: -0.01em;">
            🛡️ AdaptiveSentinelGPT
        </h2>
        <p style="margin: 4px 0 0 0; color: #38bdf8; font-size: 0.8rem; font-weight: 600;">
            AI-Powered Autonomous SOC Command Center
        </p>
    </div>
    """, unsafe_allow_html=True)

    # Load saved filter preferences if available
    saved_filters = _load_saved_filter_state()

    source_options = [
        "ALL SOURCES",
        "REAL NXLOG WINDOWS (real_nxlog_windows)",
        "LOCAL WINDOWS (local_windows)",
        "SYNTHETIC (synthetic)",
        "API SIMULATION (api_simulation)",
        "SURICATA IDS",
        "LINUX AUTH"
    ]
    fallback_source = st.session_state.get(
        "selected_telemetry_source",
        saved_filters.get("selected_source", "ALL SOURCES"),
    )
    if fallback_source not in source_options:
        fallback_source = "ALL SOURCES"
    if (
        "selected_telemetry_source_widget" not in st.session_state
        or st.session_state.get("selected_telemetry_source_widget") not in source_options
    ):
        st.session_state["selected_telemetry_source_widget"] = fallback_source

    st.markdown("#### 📡 TELEMETRY SOURCE FILTER")
    selected_source = st.selectbox(
        "Select Telemetry Source:",
        source_options,
        key="selected_telemetry_source_widget",
    )
    st.session_state["selected_telemetry_source"] = selected_source
    if saved_filters.get("selected_source") != selected_source:
        saved_filters["selected_source"] = selected_source
        _save_filter_state(saved_filters)

    endpoint_options = ["ALL ENDPOINTS"] + available_endpoint_hosts
    fallback_endpoint = st.session_state.get(
        "selected_endpoint_filter",
        saved_filters.get("selected_endpoint", "ALL ENDPOINTS"),
    )
    widget_endpoint = st.session_state.get("selected_endpoint_filter_widget")
    for candidate_ep in (widget_endpoint, fallback_endpoint):
        if candidate_ep and candidate_ep != "ALL ENDPOINTS" and candidate_ep not in endpoint_options:
            if candidate_ep == "Harsha":
                endpoint_options.append("Harsha")
    if fallback_endpoint not in endpoint_options:
        fallback_endpoint = "ALL ENDPOINTS"
    if (
        "selected_endpoint_filter_widget" not in st.session_state
        or st.session_state.get("selected_endpoint_filter_widget") not in endpoint_options
    ):
        st.session_state["selected_endpoint_filter_widget"] = fallback_endpoint

    selected_endpoint = st.selectbox(
        "Filter by Endpoint Host:",
        endpoint_options,
        key="selected_endpoint_filter_widget",
    )
    st.session_state["selected_endpoint_filter"] = selected_endpoint
    if saved_filters.get("selected_endpoint") != selected_endpoint:
        saved_filters["selected_endpoint"] = selected_endpoint
        _save_filter_state(saved_filters)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### ⚡ TELEMETRY CONTROLS")

    if st.button("📡 Synchronize NXLog Real Telemetry", use_container_width=True):
        _, metrics = sync_nxlog_telemetry_live()
        if "error" in metrics:
            st.warning(f"⚠️ NXLog sync error: {metrics.get('error')}")
        elif metrics.get("valid_ingested", 0) == 0:
            st.info("ℹ️ No new events received")
        else:
            st.success(f"✅ Ingested {metrics.get('valid_ingested', 0)} new NXLog events! ({metrics.get('duplicates_skipped', 0)} skipped)")
        st.session_state._preserve_refresh_batch_on_rerun = True
        st.rerun()

    if st.session_state.get("nxlog_sync_feedback"):
        fb_level, fb_msg = st.session_state.get("nxlog_sync_feedback")
        if fb_level == "success":
            st.success(fb_msg)
        elif fb_level == "info":
            st.info(fb_msg)
        else:
            st.warning(fb_msg)

    if st.button("🔍 Safe Replay / Scan Test Events", use_container_width=True):
        try:
            reader = NXLogReader()
            NXLogReader.clear_demo_baseline(cursor_file=reader.cursor_file)
            st.session_state.is_reset = False
            st.session_state.demo_baseline_active = False
            st.session_state.selected_scenario = "safe_replay"
            st.session_state.scenario_name = "Safe Replay (Historical NXLog Tail)"
            t_read0 = time.perf_counter()
            replayed = reader.replay_events(max_events=300)
            replay_read_ms = (time.perf_counter() - t_read0) * 1000.0
            t_norm0 = time.perf_counter()
            norm_replayed = normalize_events(replayed)
            _record_raw_received_events(norm_replayed)
            seen_keys = st.session_state.get("nxlog_seen_event_keys")
            if not isinstance(seen_keys, set):
                seen_keys = {get_event_identity_key(e) for e in st.session_state.nxlog_live_events}
            added = 0
            added_sec = 0
            for evt in norm_replayed:
                ev_key = get_event_identity_key(evt)
                if ev_key in seen_keys:
                    continue
                st.session_state.nxlog_live_events.append(evt)
                seen_keys.add(ev_key)
                added += 1
                if not evt.get("is_diagnostic"):
                    added_sec += 1
            st.session_state.nxlog_seen_event_keys = seen_keys
            replay_norm_ms = (time.perf_counter() - t_norm0) * 1000.0
            st.session_state.nxlog_cumulative_count += added_sec
            st.session_state.nxlog_last_batch_count = added_sec
            st.session_state.new_events_current_refresh = added_sec
            st.session_state._this_pass_ingested_count = added_sec
            _evaluate_nxlog_pipeline(
                st.session_state.nxlog_live_events,
                ingestion_parse_ms=replay_read_ms,
                normalize_ms=replay_norm_ms,
                batch_event_count=added_sec if added_sec > 0 else len(norm_replayed),
                scope_prefix="End-to-End Safe Replay Batch",
            )
            st.success(f"✅ Safe replay loaded {added_sec} events without advancing cursor!")
        except Exception as e:
            st.error(f"❌ Replay error: {e}")
        st.session_state._preserve_refresh_batch_on_rerun = True
        st.rerun()

    auto_refresh = st.checkbox("🔄 Auto-Refresh Telemetry Stream (5s)", value=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### 🚀 ATTACK SIMULATION CONTROLS")

    if st.button("🚀 Run APT Attack Scenario (APT29/28)", use_container_width=True):
        NXLogReader.clear_demo_baseline()
        st.session_state.is_reset = False
        st.session_state.demo_baseline_active = False
        st.session_state.selected_scenario = "apt29_28"
        st.session_state.scenario_name = "APT Attack Scenario (APT29 & APT28)"
        generate_apt_attack_logs()
        st.session_state.pipeline_results = main_module.main(include_nxlog=False)
        sim_perf = st.session_state.pipeline_results.get("agent_performance", {}).get("Total Pipeline Execution", {})
        sim_logs_cnt = len(st.session_state.pipeline_results.get("logs", []))
        if isinstance(sim_perf.get("time_ms"), (int, float)):
            sim_ms = round(float(sim_perf["time_ms"]), 3)
            sim_per_evt = round(sim_ms / max(1, sim_logs_cnt), 3)
            st.session_state.pipeline_latency_metrics = {
                "total_ms": sim_ms,
                "per_event_ms": sim_per_evt,
                "batch_event_count": sim_logs_cnt,
                "stream_event_count": sim_logs_cnt,
                "scope": f"End-to-End Scenario Batch ({sim_logs_cnt} events, {sim_per_evt:.2f} ms/evt)",
            }
        st.success("✅ APT29 Cozy Bear & APT28 Fancy Bear Logs Generated!")
        st.rerun()

    if st.button("💻 Harvest Real Local Windows OS Logs", use_container_width=True):
        from utils.collect_real_windows_logs import collect_real_windows_logs
        NXLogReader.clear_demo_baseline()
        st.session_state.is_reset = False
        st.session_state.demo_baseline_active = False
        st.session_state.selected_scenario = "windows_log_harvest"
        st.session_state.scenario_name = "Local Windows OS Harvest"
        collect_real_windows_logs()
        st.session_state.pipeline_results = main_module.main(include_nxlog=False)
        sim_perf = st.session_state.pipeline_results.get("agent_performance", {}).get("Total Pipeline Execution", {})
        sim_logs_cnt = len(st.session_state.pipeline_results.get("logs", []))
        if isinstance(sim_perf.get("time_ms"), (int, float)):
            sim_ms = round(float(sim_perf["time_ms"]), 3)
            sim_per_evt = round(sim_ms / max(1, sim_logs_cnt), 3)
            st.session_state.pipeline_latency_metrics = {
                "total_ms": sim_ms,
                "per_event_ms": sim_per_evt,
                "batch_event_count": sim_logs_cnt,
                "stream_event_count": sim_logs_cnt,
                "scope": f"End-to-End Scenario Batch ({sim_logs_cnt} events, {sim_per_evt:.2f} ms/evt)",
            }
        st.success("✅ Real Windows Event Viewer logs harvested from local OS!")
        st.rerun()

    if st.button("🔄 Generate Synthetic Attack Logs", use_container_width=True):
        NXLogReader.clear_demo_baseline()
        st.session_state.is_reset = False
        st.session_state.demo_baseline_active = False
        st.session_state.selected_scenario = "synthetic_attack"
        st.session_state.scenario_name = "Synthetic Multi-Stage Attack Simulation"
        generate_synthetic_attack_logs()
        st.session_state.pipeline_results = main_module.main(include_nxlog=False)
        sim_perf = st.session_state.pipeline_results.get("agent_performance", {}).get("Total Pipeline Execution", {})
        sim_logs_cnt = len(st.session_state.pipeline_results.get("logs", []))
        if isinstance(sim_perf.get("time_ms"), (int, float)):
            sim_ms = round(float(sim_perf["time_ms"]), 3)
            sim_per_evt = round(sim_ms / max(1, sim_logs_cnt), 3)
            st.session_state.pipeline_latency_metrics = {
                "total_ms": sim_ms,
                "per_event_ms": sim_per_evt,
                "batch_event_count": sim_logs_cnt,
                "stream_event_count": sim_logs_cnt,
                "scope": f"End-to-End Scenario Batch ({sim_logs_cnt} events, {sim_per_evt:.2f} ms/evt)",
            }
        st.success("✅ Synthetic Attack Logs Generated!")
        st.rerun()

    if st.button("🧹 Reset Dashboard to 0 Logs", use_container_width=True):
        st.session_state.nxlog_live_events = []
        st.session_state.nxlog_seen_event_keys = set()
        st.session_state._nxlog_detection_cache = {}
        st.session_state.nxlog_alerts = []
        st.session_state.nxlog_incidents = []
        st.session_state.nxlog_explanations = []
        st.session_state.nxlog_response_plans = []
        st.session_state.nxlog_reports = []
        st.session_state.nxlog_cumulative_count = 0
        st.session_state.nxlog_raw_received_count = 0
        st.session_state.nxlog_raw_received_by_host = {}
        st.session_state.nxlog_unique_processed_count = 0
        st.session_state.nxlog_displayed_event_count = 0
        st.session_state.nxlog_last_batch_count = 0
        st.session_state.total_genuine_events_received = 0
        st.session_state.total_unique_events_processed = 0
        st.session_state.events_currently_displayed = 0
        st.session_state.new_events_current_refresh = 0
        st.session_state.nxlog_last_sync_time = "Baseline Active"
        st.session_state.nxlog_last_event_time = "N/A"
        st.session_state.nxlog_last_sync_error = None
        st.session_state.nxlog_ingestion_status = "Demo baseline established — awaiting new telemetry"
        st.session_state.nxlog_sync_feedback = None
        st.session_state.nxlog_pipeline_latency = None
        st.session_state.pipeline_latency_metrics = None
        st.session_state.nxlog_agent_performance = {}
        st.session_state.is_reset = True
        st.session_state.demo_baseline_active = True
        st.session_state.selected_scenario = "reset"
        st.session_state.scenario_name = "Dashboard Reset (0 Logs)"
        st.session_state.scenario_metrics = {}
        st.session_state.pipeline_results = {
            "logs": [], "alerts": [], "incidents": [], "explanations": [],
            "response_plans": [], "reports": [], "agent_performance": {}
        }
        # Advance cursor to the safe parse boundary so only post-reset events are ingested.
        # Also record current file size so the auto-watcher doesn't fire immediately.
        try:
            reader = NXLogReader()
            baseline_offset = reader.reset_cursor_to_end()
            st.session_state.nxlog_demo_baseline_offset = baseline_offset
            if NXLOG_FILE_PATH.exists():
                st.session_state.nxlog_last_seen_size = NXLOG_FILE_PATH.stat().st_size
        except Exception as e:
            print(f"[!] NXLog cursor reset error: {e}")
            st.session_state.nxlog_demo_baseline_offset = 0
        st.success("✅ Dashboard reset to 0 logs! NXLog baseline established — monitoring for new events from Harsha.")
        st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("#### 🟢 SYSTEM OPERATIONAL STATUS")
    conn_status_label = net_state.get("connection_status", "CONNECTED")
    conn_dot = "🟢" if conn_status_label in ("CONNECTED", "LISTENING") else ("🟡" if conn_status_label in ("SEARCHING", "RECONNECTING") else "🔴")
    st.markdown(f"""
    <div style="background-color: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 12px; font-size: 0.82rem; line-height: 1.6;">
        <div>📡 <strong>NXLog Transport:</strong> <span style="color: #00e676; font-weight: 700;">{conn_dot} {conn_status_label} (TCP {active_receiver_port})</span></div>
        <div>🔄 <strong>Sync Status:</strong> <code>{st.session_state.get('nxlog_ingestion_status', 'Ready')}</code></div>
        <div>💻 <strong>Endpoints ({len(nxlog_endpoint_inventory)}):</strong> <code>{observed_endpoint_host}</code></div>
        <div>🌐 <strong>Sender / Peer IP:</strong> <code>{observed_endpoint_ip}</code></div>
        <div>🖥️ <strong>Receiver ({active_receiver_hostname}):</strong> <code>{active_receiver_addr}</code></div>
        <div>📶 <strong>Active Interface:</strong> <code>{active_network_interface}</code></div>
        <div>🗄️ <strong>SQLite KB:</strong> <span style="color: #00e676; font-weight: 700;">🟢 ONLINE</span></div>
        <div>🤖 <strong>AI Agents:</strong> <span style="color: #38bdf8; font-weight: 700;">7 Active Roles</span></div>
        <div>🛡️ <strong>SOAR Engine:</strong> <span style="color: #f59e0b; font-weight: 700;">Safe Dry-Run Mode</span></div>
    </div>
    """, unsafe_allow_html=True)

# Filter Logs, Alerts & Incidents based on selected sidebar source and endpoint filter
source_map = {
    "REAL NXLOG WINDOWS (real_nxlog_windows)": "real_nxlog_windows",
    "LOCAL WINDOWS (local_windows)": "local_windows",
    "SYNTHETIC (synthetic)": "synthetic",
    "API SIMULATION (api_simulation)": "api_simulation",
    "SURICATA IDS": "Suricata IDS",
    "LINUX AUTH": "Linux Auth"
}


def _event_matches_source_filter(evt: dict, target_src: str) -> bool:
    if not isinstance(evt, dict) or evt.get("is_diagnostic"):
        return False
    if not target_src or target_src == "ALL SOURCES":
        return True
    if target_src in ("real_nxlog_windows", "local_windows", "synthetic", "api_simulation"):
        return str(evt.get("source") or "").strip() == target_src
    if evt.get("source") == target_src or evt.get("log_channel") == target_src:
        return True
    if target_src == "Suricata IDS" and (evt.get("event_id") == 2000001 or "suricata" in str(evt.get("process_name", "")).lower()):
        return True
    if target_src == "Linux Auth" and evt.get("event_id") == 1001 and "ssh" in str(evt.get("process_name", "")).lower():
        return True
    return False


if st.session_state.get("is_reset", False) and st.session_state.get("selected_scenario") == "reset":
    display_logs = []
    display_incidents = []
    nxlog_filtered_logs, nxlog_filtered_incidents = filter_telemetry_by_endpoint(
        nxlog_security_logs, nxlog_incidents, selected_endpoint
    )
else:
    nxlog_filtered_logs, nxlog_filtered_incidents = filter_telemetry_by_endpoint(
        nxlog_security_logs, nxlog_incidents, selected_endpoint
    )
    target_src = "ALL SOURCES" if selected_source == "ALL SOURCES" else source_map.get(selected_source, selected_source)
    if target_src == "real_nxlog_windows" or (target_src == "ALL SOURCES" and not logs and not incidents):
        display_logs = list(nxlog_filtered_logs)
        display_incidents = list(nxlog_filtered_incidents)
    else:
        candidate_logs = list(nxlog_security_logs) + [
            l for l in logs
            if not l.get("is_diagnostic")
        ]
        _seen_nx_inc_ids = {inc.get("incident_id") for inc in nxlog_incidents}
        candidate_incs = list(nxlog_incidents) + [
            inc for inc in incidents
            if not inc.get("is_diagnostic") and inc.get("incident_id") not in _seen_nx_inc_ids
        ]

        # Filter logs by source and deduplicate by event identity
        seen_log_identities = set()
        source_filtered_logs = []
        for l_evt in candidate_logs:
            if not _event_matches_source_filter(l_evt, target_src):
                continue
            lk = get_event_identity_key(l_evt)
            if lk not in seen_log_identities:
                seen_log_identities.add(lk)
                source_filtered_logs.append(l_evt)

        # Filter incidents by source and require active window evidence in matching source
        source_filtered_incs = []
        for inc in candidate_incs:
            if inc.get("is_diagnostic") or int(inc.get("window_alert_count", 1) or 0) <= 0:
                continue
            matching_src_alerts = [
                alt for alt in inc.get("alerts", [])
                if not alt.get("is_diagnostic")
                and _event_matches_source_filter(alt.get("event", {}), target_src)
            ]
            if matching_src_alerts:
                inc_copy = dict(inc)
                inc_copy["alerts"] = matching_src_alerts
                inc_copy["alert_count"] = len(matching_src_alerts)
                source_filtered_incs.append(inc_copy)

        display_logs, display_incidents = filter_telemetry_by_endpoint(
            source_filtered_logs, source_filtered_incs, selected_endpoint
        )

nxlog_filtered_diag_logs, nxlog_filtered_diag_incidents = filter_telemetry_by_endpoint(
    nxlog_diag_logs, nxlog_diag_incidents, selected_endpoint
)
_, nxlog_filtered_historical_incidents = filter_telemetry_by_endpoint(
    [],
    [dict(h, window_alert_count=1) for h in nxlog_historical_incidents],
    selected_endpoint,
)
for h_inc in nxlog_filtered_historical_incidents:
    h_inc["window_alert_count"] = 0

# Derive active filtered alerts directly from active display_incidents (excluding diagnostic probes)
display_alerts = [
    alt
    for inc in display_incidents
    if not inc.get("is_diagnostic")
    for alt in inc.get("alerts", [])
    if not alt.get("is_diagnostic")
]


def _resolve_pipeline_latency_display(
    is_reset_mode: bool,
    selected_src: str,
    is_baseline_mode: bool,
    nx_lat_obj,
    gen_lat_obj,
    main_agent_perf: dict,
    scenario_logs_len: int,
):
    """
    Resolves the Pipeline Latency KPI value and measurement scope strictly from
    actual monotonic time.perf_counter() measurements. Never substitutes a constant
    fallback (such as 15.00 ms); returns ('N/A', scope, None) when unmeasured.
    """
    if is_reset_mode:
        return "N/A", "No measurement (Clean Baseline)", None

    candidate_lat = None
    if selected_src == "REAL NXLOG WINDOWS (real_nxlog_windows)" or is_baseline_mode:
        if isinstance(nx_lat_obj, dict) and isinstance(nx_lat_obj.get("total_ms"), (int, float)):
            candidate_lat = nx_lat_obj
    else:
        if isinstance(gen_lat_obj, dict) and isinstance(gen_lat_obj.get("total_ms"), (int, float)):
            candidate_lat = gen_lat_obj
        elif isinstance(nx_lat_obj, dict) and isinstance(nx_lat_obj.get("total_ms"), (int, float)):
            candidate_lat = nx_lat_obj
        elif isinstance(main_agent_perf, dict):
            tot_entry = main_agent_perf.get("Total Pipeline Execution")
            if isinstance(tot_entry, dict) and isinstance(tot_entry.get("time_ms"), (int, float)):
                raw_ms = float(tot_entry["time_ms"])
                cnt = max(1, int(scenario_logs_len or 0))
                per_evt = round(raw_ms / cnt, 3)
                candidate_lat = {
                    "total_ms": raw_ms,
                    "per_event_ms": per_evt,
                    "batch_event_count": int(scenario_logs_len or 0),
                    "scope": f"End-to-End Pipeline ({int(scenario_logs_len or 0)} events, {per_evt:.2f} ms/evt)",
                }

    if not candidate_lat or not isinstance(candidate_lat.get("total_ms"), (int, float)):
        return "N/A", "No measurement available", None

    measured_val = float(candidate_lat["total_ms"])
    scope_str = str(candidate_lat.get("scope") or "End-to-End Batch")
    return f"{measured_val:.2f} ms", scope_str, measured_val


# Severity & Incident Statistics
_is_clean_reset_view = bool(
    st.session_state.get("is_reset", False) and st.session_state.get("selected_scenario") == "reset"
)
if _is_clean_reset_view:
    crit_logs = 0
    high_logs = 0
    med_logs = 0
    low_logs = 0
    critical_count = 0
    total_logs_count = 0
    incidents_count = 0
    high_crit_count = 0
    nxlog_stream_count = 0
else:
    crit_logs = sum(1 for l in display_logs if str(l.get("severity", "")).strip().title() == "Critical")
    high_logs = sum(1 for l in display_logs if str(l.get("severity", "")).strip().title() == "High")
    med_logs  = sum(1 for l in display_logs if str(l.get("severity", "")).strip().title() == "Medium")
    low_logs  = max(0, len(display_logs) - (crit_logs + high_logs + med_logs))
    critical_count = sum(1 for inc in display_incidents if inc.get("severity") in ("Critical", "High") and not inc.get("is_diagnostic"))
    total_logs_count = len(display_logs)
    incidents_count = sum(1 for inc in display_incidents if not inc.get("is_diagnostic"))
    high_crit_count = critical_count
    nxlog_stream_count = len(nxlog_filtered_logs) if selected_endpoint != "ALL ENDPOINTS" else len(nxlog_security_logs)

pipeline_latency_display, pipeline_latency_scope, total_pipeline_ms = _resolve_pipeline_latency_display(
    is_reset_mode=_is_clean_reset_view,
    selected_src=selected_source,
    is_baseline_mode=bool(st.session_state.get("demo_baseline_active", False)),
    nx_lat_obj=st.session_state.get("nxlog_pipeline_latency"),
    gen_lat_obj=st.session_state.get("pipeline_latency_metrics"),
    main_agent_perf=results.get("agent_performance", {}) if isinstance(results, dict) else {},
    scenario_logs_len=len(logs),
)

if high_crit_count > 0 or crit_logs > 0 or high_logs > 0:
    threat_badge_html = f'<span class="badge-critical" style="font-size: 0.9rem; padding: 6px 16px;">🔴 THREAT LEVEL: ELEVATED ({high_crit_count} HIGH/CRITICAL)</span>'
elif med_logs > 0:
    threat_badge_html = f'<span class="badge-medium" style="font-size: 0.9rem; padding: 6px 16px;">🟡 THREAT LEVEL: GUARDED ({med_logs} MEDIUM)</span>'
else:
    threat_badge_html = '<span class="badge-low" style="font-size: 0.9rem; padding: 6px 16px;">🟢 THREAT LEVEL: LOW / ROUTINE MONITORING</span>'

# Enterprise Main Header Banner
st.markdown(f"""
<div class="main-header">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
            <h1 style="margin: 0; color: #f8fafc; font-size: 2.2rem; font-weight: 800; letter-spacing: -0.02em;">
                🛡️ AdaptiveSentinelGPT
            </h1>
            <p style="margin: 4px 0 0 0; color: #38bdf8; font-size: 1.05rem; font-weight: 600;">
                Enterprise AI-Powered Autonomous SOC Command Center & Live Threat Platform
            </p>
        </div>
        <div>
            {threat_badge_html}
        </div>
    </div>
    <div class="status-bar">
        <span class="badge-status">{conn_dot} NXLOG STREAM: {conn_status_label} (TCP {active_receiver_port})</span>
        <span class="badge-status">📶 INTERFACE: {active_network_interface}</span>
        <span class="badge-status">💻 ENDPOINTS: {observed_endpoint_host} (Peer/Source IP: {observed_endpoint_ip})</span>
        <span class="badge-status">🖥️ RECEIVER: {active_receiver_hostname} ({active_receiver_addr})</span>
        <span class="badge-status">📄 LOG STREAM: C:\\AdaptiveSentinel\\windows-events.log</span>
        <span class="badge-status">🛡️ MODE: SAFE SOAR DRY-RUN</span>
    </div>
</div>
""", unsafe_allow_html=True)

# Top KPI Metric Cards (Explicitly Clear Labels & Tooltips)
k1, k2, k3, k4, k5 = st.columns(5)

with k1:
    st.metric(
        "📥 Total Logs Analyzed",
        total_logs_count,
        help="Total unique security log events processed for the active scenario under the active source and endpoint filter (never truncated at 500)."
    )

with k2:
    st.metric(
        "📡 Live NXLog Stream",
        nxlog_stream_count,
        help=f"Total unique live Windows Event Log records processed via NXLog over TCP port {NXLOG_PORT} from {observed_endpoint_host} (Source IP: {observed_endpoint_ip})."
    )

with k3:
    st.metric(
        "🚨 Correlated Incidents",
        incidents_count,
        help="Multi-stage attack chains correlated across hosts, accounts, and temporal windows by Correlation Agent."
    )

with k4:
    st.metric(
        "🔴 High/Critical Incidents",
        high_crit_count,
        help="Count of High and Critical severity correlated incidents prioritized for immediate SOAR automated containment."
    )

with k5:
    st.metric(
        "⚡ Pipeline Latency",
        pipeline_latency_display,
        delta=pipeline_latency_scope,
        delta_color="off",
        help=(
            "Monotonic high-resolution (time.perf_counter) end-to-end batch processing latency across "
            "NXLog ingestion/parsing, OCSF normalization, deduplication, enrichment, detection, "
            "correlation, threat intelligence, explainability, SOAR planning, and reporting. "
            "Displays N/A when no measurement is available; preserves the latest valid measurement across zero-event refreshes."
        ),
    )

# Current Active Scenario & Severity Breakdown Row
scenario_display_name = st.session_state.get("scenario_name", "All Sources (Default Telemetry Stream)")
is_reset_state = st.session_state.get("is_reset", False) and st.session_state.get("selected_scenario") == "reset"

if is_reset_state:
    scen_badge_text = "🟢 CLEAN BASELINE (0 LOGS)"
    scen_badge_color = "#6ee7b7"
    scen_badge_bg = "rgba(16, 185, 129, 0.16)"
    scen_badge_border = "rgba(52, 211, 153, 0.45)"
elif selected_source == "REAL NXLOG WINDOWS (real_nxlog_windows)":
    scen_badge_text = "🟢 LIVE NXLOG TELEMETRY ONLY"
    scen_badge_color = "#6ee7b7"
    scen_badge_bg = "rgba(16, 185, 129, 0.16)"
    scen_badge_border = "rgba(52, 211, 153, 0.45)"
elif nxlog_logs and selected_source == "ALL SOURCES":
    scen_badge_text = "🟢 LIVE NXLOG + 🧪 SIMULATION STREAM"
    scen_badge_color = "#7dd3fc"
    scen_badge_bg = "rgba(14, 165, 233, 0.16)"
    scen_badge_border = "rgba(56, 189, 248, 0.45)"
else:
    scen_badge_text = "🧪 SIMULATION ACTIVE"
    scen_badge_color = "#fde047"
    scen_badge_bg = "rgba(245, 158, 11, 0.16)"
    scen_badge_border = "rgba(251, 191, 36, 0.45)"

st.markdown(f"""
<div style="background: linear-gradient(180deg, #111827 0%, #0f172a 100%); border: 1px solid #1e293b; border-radius: 10px; padding: 12px 18px; margin: 12px 0 16px 0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; box-shadow: 0 4px 14px rgba(0,0,0,0.35);">
    <div style="display: flex; align-items: center; gap: 12px;">
        <span style="font-size: 1.2rem;">🎯</span>
        <div>
            <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; color: #94a3b8; font-weight: 700;">ACTIVE TELEMETRY SCENARIO</div>
            <div style="font-size: 1.05rem; font-weight: 800; color: #f8fafc;">{scenario_display_name}</div>
        </div>
    </div>
    <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
        <span style="background-color: {scen_badge_bg}; color: {scen_badge_color}; border: 1px solid {scen_badge_border}; padding: 4px 12px; border-radius: 9999px; font-size: 0.8rem; font-weight: 700;">
            {scen_badge_text}
        </span>
        <span style="background-color: #1e293b; color: #e2e8f0; border: 1px solid #334155; padding: 4px 12px; border-radius: 9999px; font-size: 0.8rem; font-weight: 600;">
            🛡️ Strict Provenance Labeling Active
        </span>
    </div>
</div>
""", unsafe_allow_html=True)

# 4-Column Severity Distribution Row
s1, s2, s3, s4 = st.columns(4)

with s1:
    st.markdown(f"""
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(52, 211, 153, 0.4); border-radius: 8px; padding: 10px 14px; text-align: center;">
        <div style="color: #6ee7b7; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;">🟢 LOW SEVERITY</div>
        <div style="color: #34d399; font-size: 1.6rem; font-weight: 800; margin-top: 2px;">{low_logs}</div>
    </div>
    """, unsafe_allow_html=True)

with s2:
    st.markdown(f"""
    <div style="background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(251, 191, 36, 0.4); border-radius: 8px; padding: 10px 14px; text-align: center;">
        <div style="color: #fde047; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;">🟡 MEDIUM SEVERITY</div>
        <div style="color: #fbbf24; font-size: 1.6rem; font-weight: 800; margin-top: 2px;">{med_logs}</div>
    </div>
    """, unsafe_allow_html=True)

with s3:
    st.markdown(f"""
    <div style="background: rgba(249, 115, 22, 0.12); border: 1px solid rgba(251, 146, 60, 0.45); border-radius: 8px; padding: 10px 14px; text-align: center;">
        <div style="color: #fdba74; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;">🟠 HIGH SEVERITY</div>
        <div style="color: #fb923c; font-size: 1.6rem; font-weight: 800; margin-top: 2px;">{high_logs}</div>
    </div>
    """, unsafe_allow_html=True)

with s4:
    st.markdown(f"""
    <div style="background: rgba(239, 68, 68, 0.14); border: 1px solid rgba(248, 113, 113, 0.45); border-radius: 8px; padding: 10px 14px; text-align: center;">
        <div style="color: #fca5a5; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em;">🔴 CRITICAL SEVERITY</div>
        <div style="color: #f87171; font-size: 1.6rem; font-weight: 800; margin-top: 2px;">{crit_logs}</div>
    </div>
    """, unsafe_allow_html=True)

st.caption(f"📊 Severity Classified Total: {low_logs + med_logs + high_logs + crit_logs} / {total_logs_count} logs (100% accounted)")

st.markdown("<br>", unsafe_allow_html=True)

# Clean 6-Sector Tabbed Layout
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "🚨 1. Real-Time Telemetry & Incident Command",
    "🤖 2. AI Diagnostics & Playbooks",
    "📊 3. MITRE ATT&CK Analytics",
    "🔄 4. Analyst Review & Feedback",
    "📄 5. Executive SOC Reports",
    "💬 6. AI SOC Chat Assistant"
])

# -------------------------------------------------------------------
# SECTOR 1: REAL-TIME TELEMETRY & INCIDENT COMMAND
# -------------------------------------------------------------------
with tab1:
    st.subheader("🚨 Sector 1: Real-Time Endpoint Telemetry & Correlated Incidents")

    # Architecture & Data Flow Visualizer (Dark Cybersecurity UI Box)
    with st.expander("🏗️ View System Architecture & Telemetry Data Flow", expanded=False):
        st.markdown(f"""
        <div style="background: linear-gradient(180deg, #111827 0%, #0b0f19 100%); border: 1px solid #1e293b; border-radius: 12px; padding: 20px; margin-bottom: 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.4);">
            <div style="display: flex; flex-direction: column; align-items: center; gap: 8px; font-family: 'Inter', -apple-system, sans-serif; width: 100%;">
                <div style="background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 10px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #f8fafc; font-weight: 700; font-size: 0.95rem;">💻 {observed_endpoint_host.upper()} WINDOWS ENDPOINT</div>
                    <div style="color: #94a3b8; font-size: 0.85rem;">Sender / TCP Peer IP: <code style="color: #38bdf8;">{observed_endpoint_ip}</code> | Target Receiver: <code style="color: #38bdf8;">{net_state['sender_destination_ip']}:{active_receiver_port}</code></div>
                </div>
                <div style="color: #38bdf8; font-size: 1.2rem; font-weight: bold;">↓</div>
                <div style="background: rgba(14, 165, 233, 0.14); border: 1px solid rgba(56, 189, 248, 0.45); border-radius: 8px; padding: 10px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #38bdf8; font-weight: 700; font-size: 0.95rem;">📡 NXLOG FORWARDER &amp; AUTO-DISCOVERY</div>
                    <div style="color: #7dd3fc; font-size: 0.85rem;">Transport Protocol: <code>TCP Port {active_receiver_port}</code> | Status: <code>{net_state['connection_status']}</code></div>
                </div>
                <div style="color: #38bdf8; font-size: 1.2rem; font-weight: bold;">↓</div>
                <div style="background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 10px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #f8fafc; font-weight: 700; font-size: 0.95rem;">🖥️ {active_receiver_hostname.upper()} SOC COLLECTOR</div>
                    <div style="color: #94a3b8; font-size: 0.85rem;">Receiver Address: <code style="color: #38bdf8;">{active_receiver_addr}</code> (Interface: <code>{active_network_interface}</code>, Bind: <code>{RECEIVER_HOST}</code>)</div>
                </div>
                <div style="color: #38bdf8; font-size: 1.2rem; font-weight: bold;">↓</div>
                <div style="background: rgba(16, 185, 129, 0.14); border: 1px solid rgba(52, 211, 153, 0.45); border-radius: 8px; padding: 12px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #6ee7b7; font-weight: 700; font-size: 0.9rem;">📄 LOCAL EVENT LOG FILE</div>
                    <div style="color: #34d399; font-size: 1.0rem; font-weight: 800; margin-top: 4px;"><code>C:\\AdaptiveSentinel\\windows-events.log</code></div>
                </div>
                <div style="color: #38bdf8; font-size: 1.2rem; font-weight: bold;">↓</div>
                <div style="background-color: #0f172a; border: 1px solid #334155; border-radius: 8px; padding: 10px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #f8fafc; font-weight: 700; font-size: 0.95rem;">⚙️ ADAPTIVESENTINELGPT CORE PIPELINE</div>
                    <div style="color: #94a3b8; font-size: 0.85rem; margin-top: 2px;">
                        <code style="color: #38bdf8;">NXLogReader</code> → <code style="color: #38bdf8;">OCSF Normalizer</code> → <code style="color: #38bdf8;">Detection Engine</code> → <code style="color: #38bdf8;">Correlation Agent</code> → <code style="color: #38bdf8;">GNN &amp; AI Agents</code> → <code style="color: #38bdf8;">SOAR Playbooks</code>
                    </div>
                </div>
                <div style="color: #38bdf8; font-size: 1.2rem; font-weight: bold;">↓</div>
                <div style="background: rgba(37, 99, 235, 0.16); border: 1px solid rgba(96, 165, 250, 0.45); border-radius: 8px; padding: 10px 20px; text-align: center; width: 95%; max-width: 620px;">
                    <div style="color: #60a5fa; font-weight: 700; font-size: 0.95rem;">🛡️ STREAMLIT SOC COMMAND CENTER</div>
                    <div style="color: #93c5fd; font-size: 0.85rem;">Live Incident Stream &amp; 6 Command Sectors</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Real NXLog Endpoint & Central Network Discovery Panel
    st.markdown("### 📡 LIVE NXLOG TELEMETRY & NETWORK DISCOVERY STATUS")

    conn_state_str = net_state.get("connection_status", "CONNECTED")

    if conn_state_str == "CONNECTED":
        status_badge = f"🟢 CONNECTED (NXLog TCP {active_receiver_port})"
    elif conn_state_str == "LISTENING" and nxlog_exists:
        status_badge = f"🟢 LISTENING ON TCP {active_receiver_port} (File Active)"
    elif conn_state_str in ("SEARCHING", "RECONNECTING"):
        status_badge = f"🟡 {conn_state_str} (TCP {active_receiver_port})"
    else:
        status_badge = f"🔴 {conn_state_str}"

    active_nxlog_view = display_logs
    latest_nxlog_log = active_nxlog_view[-1] if active_nxlog_view else (nxlog_security_logs[-1] if nxlog_security_logs else {})
    scoped_endpoint_inventory = build_endpoint_inventory(
        display_logs,
        receiver_ip=active_receiver_ip,
        active_tcp_peer_ip=active_tcp_peer_ip,
    )

    def _event_matches_stream_search(evt_item, q_lower: str) -> bool:
        return (
            q_lower in str(evt_item.get("description", "")).lower()
            or q_lower in str(evt_item.get("message", "")).lower()
            or q_lower in str(evt_item.get("raw_line", "")).lower()
            or q_lower in str(evt_item.get("hostname", "")).lower()
            or q_lower in str(evt_item.get("raw_hostname", "")).lower()
            or q_lower in str(evt_item.get("user", "")).lower()
            or q_lower in str(evt_item.get("event_id", "")).lower()
            or q_lower in str(evt_item.get("event_type", "")).lower()
            or q_lower in str(evt_item.get("provider", "")).lower()
        )

    # Pre-compute the 4 distinct telemetry counters before rendering the status card and metrics breakdown:
    # 1. Total genuine events received (raw receiver records before deduplication)
    # 2. Total unique events processed (deduplicated security events in active scope)
    # 3. Events currently displayed (bounded by NXLOG_DISPLAY_WINDOW_LIMIT = 500)
    # 4. New events processed during the current refresh
    if _is_clean_reset_view:
        total_genuine_received = 0
        total_unique_processed = 0
        current_refresh_new_events = 0
    else:
        if selected_endpoint != "ALL ENDPOINTS":
            host_canon = resolve_canonical_hostname(selected_endpoint)
            raw_host_cnt = int((st.session_state.get("nxlog_raw_received_by_host") or {}).get(host_canon, 0) or 0)
            total_genuine_received = max(raw_host_cnt, len(nxlog_filtered_logs))
        else:
            raw_total_cnt = int(st.session_state.get("nxlog_raw_received_count", 0) or 0)
            total_genuine_received = max(raw_total_cnt, len(nxlog_security_logs))
        total_unique_processed = len(active_nxlog_view)
        current_refresh_new_events = int(st.session_state.get("nxlog_last_batch_count", 0) or 0)

    _preview_sev_filter = st.session_state.get("nxlog_stream_sev_filter", ["Critical", "High", "Medium", "Low"])
    _preview_search_q = str(st.session_state.get("nxlog_stream_search", "") or "").strip().lower()
    _preview_chron = [
        l for l in active_nxlog_view
        if str(l.get("severity") or "Low").strip().title() in _preview_sev_filter
        and (not _preview_search_q or _event_matches_stream_search(l, _preview_search_q))
    ]
    _preview_capped = _cap_nxlog_live_buffer(
        _preview_chron, max_non_diag=NXLOG_DISPLAY_WINDOW_LIMIT, max_5379=160
    )
    events_currently_displayed = 0 if _is_clean_reset_view else len(_preview_capped)

    st.session_state.total_genuine_events_received = total_genuine_received
    st.session_state.total_unique_events_processed = total_unique_processed
    st.session_state.nxlog_unique_processed_count = nxlog_stream_count
    st.session_state.events_currently_displayed = events_currently_displayed
    st.session_state.nxlog_displayed_event_count = events_currently_displayed
    st.session_state.new_events_current_refresh = current_refresh_new_events

    ep_name = observed_endpoint_host if selected_endpoint == "ALL ENDPOINTS" else resolve_canonical_hostname(selected_endpoint)
    ep_agent_id = f"NXLOG-MULTI-{len(scoped_endpoint_inventory)}EP" if len(scoped_endpoint_inventory) > 1 and selected_endpoint == "ALL ENDPOINTS" else f"NXLOG-{ep_name.upper()}-001"
    ep_ip = observed_endpoint_ip
    ep_os = "Windows 11"
    ep_event_time = str(
        latest_nxlog_log.get("timestamp")
        or st.session_state.get("nxlog_last_event_time")
        or net_state.get("last_successful_connection")
        or "Awaiting event timestamp"
    )[:19].replace("T", " ")
    ep_ingest_time = str(
        st.session_state.get("nxlog_last_sync_time")
        or latest_nxlog_log.get("ingestion_timestamp")
        or latest_nxlog_log.get("timestamp")
        or net_state.get("last_discovery_time")
        or "Awaiting ingestion"
    )[:19].replace("T", " ")
    ep_sync_status = str(st.session_state.get("nxlog_ingestion_status") or "Ready")
    ep_error_display = str(st.session_state.get("nxlog_last_sync_error") or net_state.get("last_error") or "None")
    ep_error_color = "#f87171" if st.session_state.get("nxlog_last_sync_error") else "#34d399"
    nxlog_agent_observed = total_genuine_received
    pipeline_ingested = total_unique_processed

    st.markdown(f"""
    <div class="telemetry-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; border-bottom: 1px solid #1e293b; padding-bottom: 10px; flex-wrap: wrap; gap: 8px;">
            <h3 style="margin: 0; color: #38bdf8; font-size: 1.15rem; font-weight: 700;">💻 Source Endpoint(s): {ep_name} ({ep_os}) → Receiver: {active_receiver_hostname}</h3>
            <span class="badge-status-green">{status_badge}</span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; font-size: 0.88rem; color: #94a3b8;">
            <div>📌 <strong>Agent ID:</strong> <code style="color: #38bdf8; background-color: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{ep_agent_id}</code></div>
            <div>🌐 <strong>Sender / TCP Peer IP:</strong> <code style="color: #38bdf8; background-color: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{ep_ip}</code></div>
            <div>📡 <strong>Receiver ({active_receiver_hostname}):</strong> <code style="color: #38bdf8; background-color: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{active_receiver_addr}</code></div>
            <div>📶 <strong>Network Interface:</strong> <code style="color: #38bdf8; background-color: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{active_network_interface}</code></div>
            <div>🎯 <strong>Sender Target IP:</strong> <code style="color: #38bdf8; background-color: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{net_state['sender_destination_ip']}:{active_receiver_port}</code></div>
            <div>🔗 <strong>Last Connected:</strong> <span style="color: #f8fafc; font-weight: 600;">{net_state['last_successful_connection'][:19]}</span></div>
            <div>🔄 <strong>Ingestion Status:</strong> <span style="color: #38bdf8; font-weight: 600;">{ep_sync_status}</span></div>
            <div>🛡️ <strong>Transport / Ingestion Errors:</strong> <span style="color: {ep_error_color}; font-weight: 600;">{ep_error_display}</span></div>
            <div>⏱️ <strong>Last Received Event Time:</strong> <span style="color: #f8fafc; font-weight: 600;">{ep_event_time}</span></div>
            <div>📥 <strong>Last Processed Event Time:</strong> <span style="color: #f8fafc; font-weight: 600;">{ep_ingest_time}</span></div>
            <div>📡 <strong>Genuine Events Received:</strong> <span style="color: #38bdf8; font-weight: 800; font-size: 1.05rem;">{total_genuine_received}</span></div>
            <div>📥 <strong>Unique Processed / Displayed:</strong> <span style="color: #34d399; font-weight: 800; font-size: 1.05rem;">{total_unique_processed} / {events_currently_displayed} ( Refresh: +{current_refresh_new_events} )</span></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Observed Endpoint Inventory Panel (Phase 3 Multi-Endpoint Telemetry Support)
    st.markdown("#### 🖥️ Observed Endpoint Inventory")
    if scoped_endpoint_inventory:
        df_inventory = pd.DataFrame([
            {
                "Endpoint Hostname": format_network_display(item.get("hostname"), field_role="hostname"),
                "Raw Hostnames": ", ".join(item.get("raw_hostnames") or [str(item.get("hostname", ""))]),
                "Latest Event Timestamp": (
                    item.get("latest_timestamp")
                    if item.get("latest_timestamp") not in (None, "", "N/A", "NA")
                    else net_state.get("last_successful_connection", "Recorded in stream")[:19]
                ),
                "Observed Event Count": int(item.get("event_count", 0)),
                "Observed Source IP": format_network_display(
                    item.get("observed_source_ip"),
                    field_role="source_ip",
                    fallback_peer_ip=(
                        item.get("observed_remote_peer_ip")
                        if item.get("observed_remote_peer_ip") != "N/A"
                        else (active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None)
                    ),
                ),
                "Remote TCP Peer IP": format_network_display(
                    item.get("observed_remote_peer_ip"),
                    field_role="remote_peer_ip",
                    fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                    last_known_ip=net_state.get("last_known_sender_ip"),
                ),
                "Receiver IP": format_network_display(
                    item.get("receiver_ip") or active_receiver_ip,
                    field_role="receiver_ip",
                    last_known_ip=net_state.get("last_known_receiver_ip"),
                ),
            }
            for item in scoped_endpoint_inventory
        ])
        st.dataframe(df_inventory, use_container_width=True, hide_index=True)
    else:
        st.caption("No observed endpoints matching the active telemetry filter.")

    # Telemetry Statistics Summary — Explicitly distinguishes the 4 required counters + Alerts + Incidents
    st.markdown("#### 📊 Real NXLog Telemetry Metrics Breakdown")
    w1, w2, w3, w4, w5, w6 = st.columns(6)
    with w1:
        st.metric(
            "Total Genuine Events Received",
            total_genuine_received,
            delta="Raw Receiver Stream",
            delta_color="off",
            help=f"Total genuine Windows events received from the NXLog receiver log over TCP port {active_receiver_port} before deduplication (excludes diagnostic probes)."
        )
    with w2:
        st.metric(
            "Total Unique Events Processed",
            total_unique_processed,
            delta=f"Deduplicated ({selected_endpoint})",
            delta_color="off",
            help="Total unique deduplicated security events processed in the active telemetry scope (never capped at 500)."
        )
    with w3:
        st.metric(
            "Events Currently Displayed",
            events_currently_displayed,
            delta=f"Display Window (Max {NXLOG_DISPLAY_WINDOW_LIMIT})",
            delta_color="off",
            help=f"Number of events currently rendered in the Near-Real-Time Live Event Stream table below (bounded by the {NXLOG_DISPLAY_WINDOW_LIMIT}-event UI display window cap)."
        )
    with w4:
        st.metric(
            "New Events (Current Refresh)",
            current_refresh_new_events,
            delta="Current Refresh Batch",
            delta_color="off",
            help="Number of new unique security events ingested and processed during the current refresh pass (0 when no new events arrived)."
        )
    with w5:
        sec_alerts_cnt = len(display_alerts)
        high_crit_alerts_cnt = sum(
            1 for a in display_alerts
            if str(a.get("severity") or "Low").strip().title() in ("High", "Critical")
        )
        st.metric(
            "Detection Alerts (Window)",
            sec_alerts_cnt,
            delta=f"{high_crit_alerts_cnt} High/Critical",
            delta_color="off",
            help="Detection Agent matched rule alerts in the currently filtered telemetry scope (excludes diagnostic test probes)."
        )
    with w6:
        sec_inc_cnt = len(display_incidents)
        hist_inc_cnt = len(nxlog_filtered_historical_incidents) if selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)") else 0
        st.metric(
            "Correlated Incidents",
            sec_inc_cnt,
            delta=f"{sec_inc_cnt} Active Window | {hist_inc_cnt} Historical Ledger",
            delta_color="off",
            help="Active correlated security incidents backed by matching evidence in the selected scope (historical zero-window SQLite ledger records are tracked separately)."
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # Live NXLog Event Stream Panel (Priority 7)
    st.markdown("### 📡 Near-Real-Time Live Event Stream (`real_nxlog_windows`)")
    stream_ctrl_c1, stream_ctrl_c2, stream_ctrl_c3 = st.columns([3, 2, 1])
    with stream_ctrl_c1:
        nxlog_search_query = st.text_input(
            "🔎 Search Live Stream or Diagnostic Marker (e.g., PHASE3_WINDOWS_EVENT, Event ID, Hostname, User):",
            value="",
            key="nxlog_stream_search"
        ).strip()
    with stream_ctrl_c2:
        stream_sev_filter = st.multiselect(
            "Filter Stream by Severity:",
            ["Critical", "High", "Medium", "Low"],
            default=["Critical", "High", "Medium", "Low"],
            key="nxlog_stream_sev_filter"
        )
    with stream_ctrl_c3:
        st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
        if st.button("🔄 Refresh Stream", key="sec1_refresh_stream_btn", use_container_width=True):
            sync_nxlog_telemetry_live()
            st.session_state._preserve_refresh_batch_on_rerun = True
            st.rerun()

    if active_nxlog_view or (nxlog_search_query and selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)")):
        chron_sev_filtered = [
            l for l in active_nxlog_view
            if str(l.get("severity") or "Low").strip().title() in stream_sev_filter
        ]
        if nxlog_search_query:
            q_lower = nxlog_search_query.lower()
            matched_chron = [
                l for l in chron_sev_filtered
                if _event_matches_stream_search(l, q_lower)
            ]
            if not matched_chron and selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)"):
                # Allow explicit search for diagnostic probe markers within the selected endpoint scope
                diag_matches = [
                    l for l in nxlog_filtered_diag_logs
                    if str(l.get("severity") or "Low").strip().title() in stream_sev_filter
                    and _event_matches_stream_search(l, q_lower)
                ]
                if diag_matches:
                    matched_chron = diag_matches
                elif NXLOG_FILE_PATH.exists():
                    # Non-destructively check recent receiver tail without modifying data/nxlog_cursor.json
                    try:
                        reader_tail = NXLogReader()
                        tail_raw = reader_tail.get_recent_events(max_events=300)
                        if st.session_state.get("demo_baseline_active", False) or st.session_state.get("is_reset", False):
                            b_off = st.session_state.get("nxlog_demo_baseline_offset")
                            if b_off is not None:
                                tail_raw = [
                                    e for e in tail_raw
                                    if int(e.get("record_offset", b_off) or 0) >= int(b_off)
                                ]
                        tail_candidates = normalize_events(tail_raw)
                        seen_keys = st.session_state.get("nxlog_seen_event_keys")
                        if not isinstance(seen_keys, set):
                            seen_keys = {get_event_identity_key(e) for e in st.session_state.nxlog_live_events}
                        for cand in tail_candidates:
                            ckey = get_event_identity_key(cand)
                            if ckey not in seen_keys:
                                st.session_state.nxlog_live_events.append(cand)
                                seen_keys.add(ckey)
                        st.session_state.nxlog_seen_event_keys = seen_keys
                        live_matches = [
                            cand for cand in tail_candidates
                            if _event_matches_endpoint_filter(cand, selected_endpoint)
                            and str(cand.get("severity") or "Low").strip().title() in stream_sev_filter
                            and _event_matches_stream_search(cand, q_lower)
                        ]
                        if live_matches:
                            matched_chron = live_matches
                    except Exception:
                        pass
            capped_display_slice = _cap_nxlog_live_buffer(
                matched_chron, max_non_diag=NXLOG_DISPLAY_WINDOW_LIMIT, max_5379=160
            )
        else:
            capped_display_slice = _cap_nxlog_live_buffer(
                chron_sev_filtered, max_non_diag=NXLOG_DISPLAY_WINDOW_LIMIT, max_5379=160
            )

        inspected_nxlog_list = sorted(
            capped_display_slice,
            key=lambda x: (str(x.get("timestamp") or "").replace("T", " "), int(x.get("record_offset") or 0)),
            reverse=True,
        )
        events_currently_displayed = len(inspected_nxlog_list)
        st.session_state.events_currently_displayed = events_currently_displayed
        st.session_state.nxlog_displayed_event_count = events_currently_displayed
        st.caption(
            f"🖥️ Displaying **{events_currently_displayed}** event(s) (Display Window Cap: {NXLOG_DISPLAY_WINDOW_LIMIT}) "
            f"| **{total_unique_processed}** unique events processed "
            f"| **{total_genuine_received}** total genuine events received "
            f"| **+{current_refresh_new_events}** new event(s) in current refresh."
        )

        df_nxlog = pd.DataFrame([
            {
                "Event Timestamp": str(l.get("timestamp", ""))[:19],
                "Ingestion Time": str(l.get("ingestion_timestamp") or l.get("timestamp", ""))[:19],
                "Event ID": str(l.get("event_id", 0)),
                "Record Identity": (
                    f"rec:{l.get('record_id')}"
                    if l.get("record_id") not in (None, "", "N/A")
                    else (
                        f"offset:{l.get('record_offset')}"
                        if l.get("record_offset") not in (None, "", "N/A")
                        else "stream:unindexed"
                    )
                ),
                "Event Type": str(l.get("event_type", "Windows Event")),
                "Severity": str(l.get("severity", "Low")),
                "Provenance": "🛠️ DIAGNOSTIC PROBE" if l.get("is_diagnostic") else ("📡 REAL TELEMETRY" if l.get("source") in ("real_nxlog_windows", "local_windows") else "🧪 SIMULATED"),
                "MITRE Technique": format_network_display(l.get("mitre_technique"), field_role="mitre_technique"),
                "Hostname": format_network_display(l.get("hostname"), field_role="hostname"),
                "User": str(l.get("user", "SYSTEM")),
                "Source IP": format_network_display(
                    None if str(l.get("source_ip", "")).strip() == active_receiver_ip else l.get("source_ip"),
                    field_role="source_ip",
                    fallback_peer_ip=(
                        l.get("remote_peer_ip")
                        if str(l.get("remote_peer_ip", "N/A")).strip() not in ("", "-", "N/A", active_receiver_ip)
                        else (active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None)
                    ),
                ),
                "Remote Peer IP": format_network_display(
                    None if str(l.get("remote_peer_ip", "")).strip() == active_receiver_ip else l.get("remote_peer_ip"),
                    field_role="remote_peer_ip",
                    fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                    last_known_ip=net_state.get("last_known_sender_ip"),
                ),
                "Receiver IP": format_network_display(
                    l.get("receiver_ip") if l.get("receiver_ip") not in (None, "", "-", "N/A") else active_receiver_ip,
                    field_role="receiver_ip",
                ),
                "Process": format_network_display(l.get("process_name"), field_role="process_name"),
                "Description": str(l.get("description", ""))
            }
            for l in inspected_nxlog_list
        ])
        display_df_nxlog = df_nxlog.copy()
        if "Event ID" in display_df_nxlog.columns:
            display_df_nxlog["Event ID"] = display_df_nxlog["Event ID"].astype(str)
        st.dataframe(display_df_nxlog, use_container_width=True)

        with st.expander("🔍 Real NXLog Event Inspector & Raw Evidence Details"):
            if inspected_nxlog_list:
                selected_event_idx = st.number_input("Select Event Index for Evidence Inspection (matches table row order):", min_value=0, max_value=max(0, len(inspected_nxlog_list)-1), value=0, step=1)
                if selected_event_idx < len(inspected_nxlog_list):
                    target_evt = inspected_nxlog_list[selected_event_idx]
                    ins_c1, ins_c2 = st.columns(2)
                    with ins_c1:
                        st.markdown("**Normalized Event Details:**")
                        st.json({
                            "source": target_evt.get("source"),
                            "source_type": target_evt.get("source_type") or target_evt.get("source"),
                            "provider": target_evt.get("provider", "N/A"),
                            "event_timestamp": target_evt.get("timestamp"),
                            "ingestion_timestamp": target_evt.get("ingestion_timestamp"),
                            "hostname": format_network_display(target_evt.get("hostname"), field_role="hostname"),
                            "raw_hostname": target_evt.get("raw_hostname") or target_evt.get("hostname"),
                            "user": target_evt.get("user"),
                            "source_ip": format_network_display(
                                target_evt.get("source_ip"),
                                field_role="source_ip",
                                fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                            ),
                            "remote_peer_ip": format_network_display(
                                target_evt.get("remote_peer_ip"),
                                field_role="remote_peer_ip",
                                fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                            ),
                            "receiver_ip": format_network_display(
                                target_evt.get("receiver_ip") or active_receiver_ip,
                                field_role="receiver_ip",
                            ),
                            "event_id": target_evt.get("event_id"),
                            "event_type": target_evt.get("event_type"),
                            "severity": target_evt.get("severity"),
                            "mitre_technique": format_network_display(target_evt.get("mitre_technique"), field_role="mitre_technique"),
                            "process_name": format_network_display(target_evt.get("process_name"), field_role="process_name"),
                            "command_line": format_network_display(target_evt.get("command_line"), field_role="command_line"),
                            "description": target_evt.get("description"),
                            "message": target_evt.get("message") or target_evt.get("description"),
                            "record_offset": target_evt.get("record_offset"),
                            "record_id": target_evt.get("record_id"),
                            "is_diagnostic": bool(target_evt.get("is_diagnostic", False)),
                        })
                    with ins_c2:
                        st.markdown("**Raw Log Line Details:**")
                        st.code(target_evt.get("raw_line") or target_evt.get("description", "Raw log preserved"))
            else:
                st.info("No events match the current search filter.")

        diag_events_list = (
            sorted(
                nxlog_filtered_diag_logs,
                key=lambda x: (str(x.get("timestamp") or "").replace("T", " "), int(x.get("record_offset") or 0)),
                reverse=True,
            )
            if selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)")
            else []
        )
        if diag_events_list:
            with st.expander(f"🛠️ Diagnostic Telemetry Verification Probes ({len(diag_events_list)} Verified)", expanded=False):
                st.caption("Dedicated diagnostic test-event verification channel. These probes verify end-to-end ingestion (Receiver File → Parser → Detection → Correlation → Dashboard) without inflating security incident counters.")
                df_diag = pd.DataFrame([
                    {
                        "Timestamp": str(d.get("timestamp", ""))[:19],
                        "Hostname": format_network_display(d.get("hostname"), field_role="hostname"),
                        "Raw Hostname": str(d.get("raw_hostname") or d.get("hostname", "")),
                        "User": str(d.get("user", "SYSTEM")),
                        "Event ID": str(d.get("event_id", 0)),
                        "Source IP": format_network_display(
                            d.get("source_ip"),
                            field_role="source_ip",
                            fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                        ),
                        "Remote Peer IP": format_network_display(
                            d.get("remote_peer_ip"),
                            field_role="remote_peer_ip",
                            fallback_peer_ip=active_tcp_peer_ip if active_tcp_peer_ip != "N/A" else None,
                        ),
                        "Diagnostic Marker / Payload": str(d.get("description", "")),
                        "Pipeline Status": "✅ Receiver → Parser → Detection → Correlation"
                    }
                    for d in diag_events_list
                ])
                st.dataframe(df_diag, use_container_width=True)
    else:
        st.info("ℹ️ No telemetry received matching the current source and endpoint filter yet. Click 'Synchronize NXLog Real Telemetry' in the sidebar to read events from C:\\AdaptiveSentinel\\windows-events.log.")

    st.markdown("<br>", unsafe_allow_html=True)

    # Category 2: Evidence-Supported Detection Alerts (Prioritized by Severity)
    _sev_priority_map = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}
    sorted_display_alerts = sorted(
        display_alerts,
        key=lambda a: (
            _sev_priority_map.get(str(a.get("severity") or "Low").strip().title(), 1),
            str(a.get("event", {}).get("timestamp") or "").replace("T", " "),
            int(a.get("event", {}).get("record_offset") or 0),
        ),
        reverse=True,
    )
    with st.expander(
        f"⚠️ Evidence-Supported Detection Alerts ({len(sorted_display_alerts)} Matched Rule Alerts — Prioritized by Severity)",
        expanded=False,
    ):
        st.caption(
            "Detection alerts are generated only when incoming events match explicit detection rules. "
            "Routine Windows telemetry without rule matches remains in the Live Event Stream above without generating alerts."
        )
        if sorted_display_alerts:
            df_det_alerts = pd.DataFrame([
                {
                    "Timestamp": str(alt.get("event", {}).get("timestamp", ""))[:19],
                    "Severity": str(alt.get("severity", "Low")).strip().title(),
                    "Alert Name": str(alt.get("alert_name", "Detection Alert")),
                    "Rule ID": format_network_display(alt.get("rule_id"), field_role="rule_id"),
                    "Event ID": str(alt.get("event", {}).get("event_id", 0)),
                    "MITRE Technique": format_network_display(alt.get("mitre_technique"), field_role="mitre_technique"),
                    "Hostname": format_network_display(alt.get("hostname") or alt.get("event", {}).get("hostname"), field_role="hostname"),
                    "User": str(alt.get("user") or alt.get("event", {}).get("user", "SYSTEM")),
                    "Process": format_network_display(alt.get("event", {}).get("process_name"), field_role="process_name"),
                    "Command Line": format_network_display(alt.get("event", {}).get("command_line"), field_role="command_line"),
                }
                for alt in sorted_display_alerts
            ])
            st.dataframe(df_det_alerts, use_container_width=True, hide_index=True)
        else:
            st.info("No detection alerts triggered under the active filter scope.")

    st.markdown("<br>", unsafe_allow_html=True)

    # Category 3: Correlated Incidents List (Prioritized by Severity)
    st.markdown("### 🔥 Correlated Security & APT Incidents")
    real_nxlog_inc_count = sum(
        1 for inc in display_incidents
        if not inc.get("is_diagnostic") and (
            inc.get("primary_source") == "real_nxlog_windows"
            or any(alt.get("event", {}).get("source") == "real_nxlog_windows" for alt in inc.get("alerts", []))
        )
    )
    local_win_inc_count = sum(
        1 for inc in display_incidents
        if not inc.get("is_diagnostic")
        and inc.get("primary_source") != "real_nxlog_windows"
        and (
            inc.get("primary_source") == "local_windows"
            or any(alt.get("event", {}).get("source") == "local_windows" for alt in inc.get("alerts", []))
        )
    )
    real_inc_count = real_nxlog_inc_count + local_win_inc_count
    api_sim_inc_count = sum(
        1 for inc in display_incidents
        if not inc.get("is_diagnostic") and any(alt.get("event", {}).get("source") == "api_simulation" for alt in inc.get("alerts", []))
    )
    synthetic_inc_count = sum(
        1 for inc in display_incidents
        if not inc.get("is_diagnostic") and any(alt.get("event", {}).get("source") == "synthetic" for alt in inc.get("alerts", []))
    )
    sim_inc_count = max(0, len(display_incidents) - real_inc_count)
    diag_probe_groups_count = len(nxlog_filtered_diag_incidents) if selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)") else 0
    st.caption(
        f"🛰️ **Incident Provenance Breakdown (`{len(display_incidents)}` Total Correlated Security Incidents)**: "
        f"`📡 {real_inc_count} Real Live Telemetry Incident(s)` (`{real_nxlog_inc_count}` `real_nxlog_windows`, `{local_win_inc_count}` `local_windows`) "
        f"| `🧪 {sim_inc_count} Simulated Scenario Incident(s)` (`{api_sim_inc_count}` `api_simulation`, `{synthetic_inc_count}` `synthetic`) "
        f"| `🛠️ {diag_probe_groups_count} Diagnostic Verification Probe Group(s)` (tracked separately in Diagnostic Probes panel above; never counted as security incidents)."
    )
    filter_severity = st.multiselect(
        "Filter Incidents by Severity:",
        ["Critical", "High", "Medium", "Low"],
        default=["Critical", "High", "Medium", "Low"]
    )

    filtered_incidents = sorted(
        [
            inc for inc in display_incidents
            if not inc.get("is_diagnostic") and inc.get("severity") in filter_severity
        ],
        key=lambda inc: (
            _sev_priority_map.get(str(inc.get("severity") or "Low").strip().title(), 1),
            int(inc.get("confidence", 0) or 0),
            int(inc.get("window_alert_count", 0) or 0),
        ),
        reverse=True,
    )

    if filtered_incidents:
        for inc in filtered_incidents:
            sev_str = str(inc.get("severity", "Medium")).strip()
            sev_lower = sev_str.lower()
            if sev_lower == "critical":
                severity_class = "badge-critical"
            elif sev_lower == "high":
                severity_class = "badge-high"
            elif sev_lower == "medium":
                severity_class = "badge-medium"
            else:
                severity_class = "badge-low"

            is_diag = inc.get("is_diagnostic", False)
            inc_sources = inc.get("telemetry_sources") or list(dict.fromkeys(
                str(alt.get("event", {}).get("source") or "unknown").strip()
                for alt in inc.get("alerts", [])
            ))
            has_real_telemetry = bool(
                inc.get("is_real_telemetry")
                or any(s in ("real_nxlog_windows", "local_windows") for s in inc_sources)
            )
            src_label_joined = ", ".join(inc_sources) if inc_sources else "unknown"
            diag_badge = '<span class="badge-status" style="margin-right: 8px;">🛠️ DIAGNOSTIC PROBE</span>' if is_diag else ''
            if is_diag:
                provenance_badge = '<span class="badge-telemetry" style="margin-right: 8px;">📡 REAL NXLOG PROBE</span>' if has_real_telemetry else ''
            elif has_real_telemetry:
                provenance_badge = f'<span class="badge-telemetry" style="margin-right: 8px;">📡 REAL TELEMETRY ({src_label_joined})</span>'
            else:
                provenance_badge = (
                    f'<span style="background: rgba(245, 158, 11, 0.18); color: #fde047; border: 1px solid rgba(251, 191, 36, 0.45); '
                    f'padding: 4px 10px; border-radius: 9999px; font-size: 0.75rem; font-weight: 700; margin-right: 8px;">'
                    f'🧪 SIMULATED EVIDENCE ({src_label_joined})</span>'
                )
            severity_badge = f'<span class="{severity_class}">{sev_str.upper()} SEVERITY</span>'
            badges_html = f'{diag_badge}{provenance_badge}{severity_badge}'
            card_icon = "🛠️" if is_diag else ("📡" if has_real_telemetry else "🧪")

            inc_id_str = inc.get("incident_id", "INC-000")
            inc_name = inc.get("incident_name", "Incident")
            inc_host = format_network_display(inc.get("affected_host"), field_role="hostname")
            inc_user = inc.get("affected_user", "SYSTEM")
            inc_conf = inc.get("confidence", 0)
            summary_meta = format_incident_alert_summary(inc)
            win_fmt = summary_meta["window_alert_formatted"]
            cum_fmt = summary_meta["cumulative_alert_formatted"]
            cum_scope = summary_meta["cumulative_scope"]
            hist_range = summary_meta["historical_log_range"]
            evidence_cap = summary_meta["evidence_alert_cap"]
            evidence_shown = summary_meta["evidence_shown_count"]
            inc_techs = inc.get("mitre_techniques") or list(dict.fromkeys(
                format_network_display(alt.get("mitre_technique"), field_role="mitre_technique")
                for alt in inc.get("alerts", [])
            ))
            inc_tech_str = ", ".join(inc_techs) if inc_techs else "T1059"
            prov_text = f"REAL TELEMETRY ({src_label_joined})" if has_real_telemetry else f"SIMULATED ({src_label_joined})"
            prov_color = "#6ee7b7" if has_real_telemetry else "#fde047"
            prov_bg = "rgba(16, 185, 129, 0.16)" if has_real_telemetry else "rgba(245, 158, 11, 0.16)"

            card_html = (
                f'<div class="soc-card">'
                f'<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">'
                f'<h3 style="margin: 0; color: #f8fafc; font-weight: 700;">{card_icon} {inc_name} <code style="font-size: 0.82rem; color: #38bdf8;">({inc_id_str})</code></h3>'
                f'<div>{badges_html}</div>'
                f'</div>'
                f'<div style="display: flex; gap: 20px; color: #94a3b8; font-size: 0.92rem; flex-wrap: wrap;">'
                f'<span>📍 <strong>Target Host:</strong> <code style="color: #38bdf8; background: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{inc_host}</code></span>'
                f'<span>👤 <strong>User Account:</strong> <code style="color: #38bdf8; background: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;">{inc_user}</code></span>'
                f'<span>🎯 <strong>MITRE ATT&amp;CK:</strong> <code style="color: #c084fc; background: rgba(168, 85, 247, 0.14); border: 1px solid rgba(192, 132, 252, 0.35); padding: 2px 6px; border-radius: 4px;">{inc_tech_str}</code></span>'
                f'<span>🛰️ <strong>Telemetry Source:</strong> <code style="color: {prov_color}; background: {prov_bg}; padding: 2px 6px; border-radius: 4px;">{prov_text}</code></span>'
                f'<span>📊 <strong>Confidence:</strong> <strong style="color: #f8fafc;">{inc_conf}%</strong></span>'
                f'<span>🪟 <strong>Window Alerts:</strong> <strong style="color: #38bdf8;">{win_fmt}</strong> <span style="font-size: 0.80rem; color: #94a3b8;">(Current Window)</span></span>'
                f'<span>🚨 <strong>Cumulative Alerts ({cum_scope}):</strong> <strong style="color: #38bdf8;">{cum_fmt}</strong> <span style="font-size: 0.80rem; color: #94a3b8;">(Historical Log Range: {hist_range})</span></span>'
                f'<span>📋 <strong>Evidence Table Cap:</strong> <strong style="color: #f8fafc;">{evidence_shown} / {evidence_cap}</strong> <span style="font-size: 0.80rem; color: #94a3b8;">recent records</span></span>'
                f'</div>'
                f'<div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed #1e293b; color: #cbd5e1; font-size: 0.83rem;">'
                f'ℹ️ <strong>{win_fmt}</strong> matching detection alert(s) belong to the current processing window, while '
                f'<strong>{cum_fmt}</strong> unique matching alert(s) were observed across the retained historical log range '
                f'(<code>{hist_range}</code>). The evidence table is capped at <strong>{evidence_cap}</strong> recent records '
                f'(<strong>{evidence_shown}</strong> shown), while the cumulative ledger tracks the full number of unique alert identities.'
                f'</div>'
                f'</div>'
            )
            st.markdown(card_html, unsafe_allow_html=True)

            with st.expander(f"🔍 Expand Alert Details & Command Line History ({inc['incident_name']} — {inc_id_str})"):
                st.caption(summary_meta["scope_explanation"])
                alert_rows = []
                for alt in inc["alerts"]:
                    evt = alt["event"]
                    ti = alt.get("threat_intel", {})
                    alert_rows.append({
                        "Timestamp": str(evt.get("timestamp", ""))[:19],
                        "Alert Name": alt["alert_name"],
                        "Event ID": evt.get("event_id"),
                        "MITRE Technique": format_network_display(alt.get("mitre_technique"), field_role="mitre_technique"),
                        "Source": evt.get("source") or "unknown",
                        "Hostname": format_network_display(evt.get("hostname"), field_role="hostname"),
                        "Raw Hostname": str(evt.get("raw_hostname") or evt.get("hostname", "")),
                        "Source IP": format_network_display(
                            evt.get("source_ip"),
                            field_role="source_ip",
                            fallback_peer_ip=active_tcp_peer_ip if (active_tcp_peer_ip != "N/A" and has_real_telemetry) else None,
                        ),
                        "Threat Status": ti.get("status") if ti.get("status") not in (None, "", "N/A", "NA") else "Monitored",
                        "Command Line": format_network_display(evt.get("command_line"), field_role="command_line"),
                    })
                df_alerts = pd.DataFrame(alert_rows)
                display_df_alerts = df_alerts.copy()
                if "Event ID" in display_df_alerts.columns:
                    display_df_alerts["Event ID"] = display_df_alerts["Event ID"].astype(str)
                st.dataframe(display_df_alerts, use_container_width=True)
    else:
        st.info("No correlated incidents under the active filter criteria.")

    if selected_source in ("ALL SOURCES", "REAL NXLOG WINDOWS (real_nxlog_windows)") and nxlog_filtered_historical_incidents:
        with st.expander(f"📚 Historical Cumulative Incident Ledger ({len(nxlog_filtered_historical_incidents)} Retained Outside Current Active Window)", expanded=False):
            st.caption(
                "These historical incident records were persisted in the SQLite cumulative ledger from earlier log windows "
                "and have 0 alerts in the current active window. They are kept separate from active-view incident counts."
            )
            df_hist_ledger = pd.DataFrame([
                {
                    "Incident ID": h.get("incident_id", "N/A"),
                    "Incident Name": h.get("incident_name", "Historical Incident"),
                    "Target Host": format_network_display(h.get("affected_host"), field_role="hostname"),
                    "Account": h.get("affected_user", "SYSTEM"),
                    "Historical Severity": h.get("severity", "Low"),
                    "Window Alerts": 0,
                    "Cumulative Alerts": int(h.get("cumulative_alert_count", 0) or 0),
                    "First Observed": str(h.get("first_event_timestamp", "N/A"))[:19],
                    "Last Observed": str(h.get("last_event_timestamp", "N/A"))[:19],
                }
                for h in nxlog_filtered_historical_incidents
            ])
            st.dataframe(df_hist_ledger, use_container_width=True, hide_index=True)

# -------------------------------------------------------------------
# SECTOR 2: AI DIAGNOSTICS & CONTROLLED SOAR COMMAND CENTER
# -------------------------------------------------------------------
with tab2:
    st.subheader("🤖 Sector 2: AI Diagnostics & Controlled SOAR Command Center")
    st.markdown(
        "<div style='background: rgba(245, 158, 11, 0.12); padding: 14px 20px; border: 1px solid rgba(251, 191, 36, 0.45); border-left: 5px solid #f59e0b; border-radius: 8px; margin-bottom: 24px;'>"
        "<h4 style='margin: 0; color: #fde047; font-weight: 700;'>⚠️ CONTROLLED SOAR ACTIVE — SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN</h4>"
        "<p style='margin: 4px 0 0 0; color: #fef3c7; font-size: 0.92rem; line-height: 1.5;'>"
        "All SOAR response recommendations are strictly constrained to allowlisted actions (<code>ISOLATE_HOST</code>, <code>TERMINATE_PROCESS</code>, <code>BLOCK_IP</code>, <code>LOCK_USER</code>, <code>COLLECT_FORENSIC_ARTIFACTS</code>). "
        "Arbitrary LLM command generation is prohibited. Every disruptive action requires explicit analyst approval and runs strictly in simulation (<code>SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN</code>)."
        "</p></div>",
        unsafe_allow_html=True
    )

    # Initialize SOAR Modules
    soar_registry = SOARActionRegistry()
    soar_engine = SOARDecisionEngine(registry=soar_registry)
    soar_audit = SOARAuditLogger()

    # Session state for persistent feedback message & active expander
    if "soar_feedback_msg" not in st.session_state:
        st.session_state["soar_feedback_msg"] = None
    if "soar_open_expander" not in st.session_state:
        st.session_state["soar_open_expander"] = None

    # Callback handlers for SOAR Action buttons
    def soar_cb_approve(inc_id, act_id, act_target, host_score, rec_params, rule_id, mitre_tech, is_reversible):
        try:
            logger = SOARAuditLogger()
            audit_rec = {
                "incident_id": inc_id,
                "action_id": act_id,
                "analyst_approval": "APPROVED",
                "analyst_user": "analyst_soc",
                "target": act_target,
                "action_status": "APPROVED",
                "verification_result": "VERIFIED_SUCCESS",
                "rollback_status": "AVAILABLE" if is_reversible else "NON_REVERSIBLE",
                "gnn_score": float(host_score),
                "rule_id": str(rule_id),
                "mitre_technique": str(mitre_tech),
                "dry_run": True,
                "parameters": rec_params or {},
                "details": {
                    "lifecycle_state": "APPROVED",
                    "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                },
            }
            audit_id = logger.log_event(audit_rec)
            st.session_state["soar_feedback_msg"] = (
                "success",
                f"✅ Action `{act_id}` on `{act_target}` APPROVED by analyst (`SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN`). Persisted to `soar_audit.db` (`{audit_id}`)."
            )
            st.session_state["soar_open_expander"] = inc_id
        except Exception as e:
            st.session_state["soar_feedback_msg"] = ("error", f"❌ Approval Failed: {e}")
            st.session_state["soar_open_expander"] = inc_id

    def soar_cb_reject(inc_id, act_id, act_target, host_score, rec_params, rule_id, mitre_tech):
        try:
            logger = SOARAuditLogger()
            audit_rec = {
                "incident_id": inc_id,
                "action_id": act_id,
                "analyst_approval": "REJECTED",
                "analyst_user": "analyst_soc",
                "target": act_target,
                "action_status": "REJECTED",
                "verification_result": "VERIFIED_FAILURE",
                "error_message": "Action rejected by human SOC analyst.",
                "rollback_status": "NOT_APPLICABLE",
                "gnn_score": float(host_score),
                "rule_id": str(rule_id),
                "mitre_technique": str(mitre_tech),
                "dry_run": True,
                "parameters": rec_params or {},
                "details": {
                    "lifecycle_state": "REJECTED",
                    "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                },
            }
            audit_id = logger.log_event(audit_rec)
            st.session_state["soar_feedback_msg"] = (
                "error",
                f"❌ Action `{act_id}` on `{act_target}` REJECTED by analyst. Persisted to database (`soar_audit.db`) with Audit ID `{audit_id}`."
            )
            st.session_state["soar_open_expander"] = inc_id
        except Exception as e:
            st.session_state["soar_feedback_msg"] = ("error", f"❌ Rejection Failed: {e}")
            st.session_state["soar_open_expander"] = inc_id

    def soar_cb_execute_sim(inc_id, act_id, act_target, host_score, rec_params, rule_id, mitre_tech):
        try:
            logger = SOARAuditLogger()
            executor = MockSOARExecutor(registry=soar_registry)
            exec_res = executor.execute_action(act_id, act_target, parameters=rec_params, dry_run=False)
            sim_exec_details = dict(exec_res.get("details", {}))
            sim_exec_details["real_endpoint_action_taken"] = False
            sim_exec_details["guard_status"] = "ISOLATION_ENFORCED"
            sim_exec_details["simulation_banner"] = "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"
            audit_rec = {
                "incident_id": inc_id,
                "action_id": act_id,
                "analyst_approval": "APPROVED",
                "analyst_user": "analyst_soc",
                "target": act_target,
                "action_status": exec_res["status"],
                "verification_result": exec_res["verification_status"],
                "rollback_status": exec_res["rollback_status"],
                "gnn_score": float(host_score),
                "rule_id": str(rule_id),
                "mitre_technique": str(mitre_tech),
                "dry_run": False,
                "parameters": rec_params or {},
                "details": sim_exec_details
            }
            audit_id = logger.log_event(audit_rec)
            st.session_state["soar_feedback_msg"] = (
                "success",
                f"🚀 Simulated Execution Completed (`SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN`): {exec_res.get('details', {}).get('summary')} (Audit ID: `{audit_id}`)"
            )
            st.session_state["soar_open_expander"] = inc_id
        except Exception as e:
            st.session_state["soar_feedback_msg"] = ("error", f"❌ Execution Failed: {e}")
            st.session_state["soar_open_expander"] = inc_id

    def soar_cb_rollback(inc_id, act_id, act_target, host_score, rec_params, rule_id, mitre_tech):
        try:
            logger = SOARAuditLogger()
            executor = MockSOARExecutor(registry=soar_registry)
            rb_res = executor.rollback_action(act_id, act_target, parameters=rec_params, dry_run=False)
            sim_rb_details = dict(rb_res.get("details", {}))
            sim_rb_details["real_endpoint_action_taken"] = False
            sim_rb_details["guard_status"] = "ISOLATION_ENFORCED"
            sim_rb_details["simulation_banner"] = "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"
            audit_rec = {
                "incident_id": inc_id,
                "action_id": rb_res["action_id"],
                "analyst_approval": "APPROVED",
                "analyst_user": "analyst_soc",
                "target": act_target,
                "action_status": rb_res["status"],
                "verification_result": rb_res["verification_status"],
                "rollback_status": "ROLLED_BACK",
                "gnn_score": float(host_score),
                "rule_id": str(rule_id),
                "mitre_technique": str(mitre_tech),
                "dry_run": False,
                "parameters": rec_params or {},
                "details": sim_rb_details
            }
            audit_id = logger.log_event(audit_rec)
            st.session_state["soar_feedback_msg"] = (
                "info",
                f"🔄 Rollback Executed (`SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN`): {rb_res.get('details', {}).get('summary')} (Audit ID: `{audit_id}`)"
            )
            st.session_state["soar_open_expander"] = inc_id
        except Exception as e:
            st.session_state["soar_feedback_msg"] = ("error", f"❌ Rollback Failed: {e}")
            st.session_state["soar_open_expander"] = inc_id

    # Fetch Persistent SOAR Audit Logs & Compute Status Metrics
    audit_records = soar_audit.get_audit_records(limit=100)
    pending_count = sum(1 for r in audit_records if r.get("analyst_approval") == "PENDING")
    approved_count = sum(1 for r in audit_records if r.get("analyst_approval") == "APPROVED")
    executed_count = sum(1 for r in audit_records if r.get("action_status") in ("EXECUTED", "DRY_RUN"))
    failed_count = sum(1 for r in audit_records if r.get("action_status") == "REJECTED" or r.get("verification_result") == "VERIFIED_FAILURE")
    rollback_count = sum(1 for r in audit_records if r.get("rollback_status") == "ROLLED_BACK")

    sm1, sm2, sm3, sm4, sm5, sm6 = st.columns(6)
    with sm1:
        st.metric("SOAR Mode", "DRY RUN (SAFE)")
    with sm2:
        st.metric("Pending Approvals", pending_count)
    with sm3:
        st.metric("Approved Actions", approved_count)
    with sm4:
        st.metric("Executed Actions", executed_count)
    with sm5:
        st.metric("Failed / Rejected", failed_count)
    with sm6:
        st.metric("Rollbacks Triggered", rollback_count)

    st.markdown("<br>", unsafe_allow_html=True)

    # Render persistent SOAR action alert message if set from a button click
    if st.session_state.get("soar_feedback_msg"):
        fb_type, fb_text = st.session_state["soar_feedback_msg"]
        if fb_type == "success":
            st.success(fb_text)
        elif fb_type == "error":
            st.error(fb_text)
        elif fb_type == "info":
            st.info(fb_text)
        # Clear after displaying so it doesn't linger forever
        st.session_state["soar_feedback_msg"] = None

    fb_lookup_agent = FeedbackAgent()
    allowlisted_actions_list = soar_registry.list_allowlisted_actions()
    registered_actions_cnt = len(allowlisted_actions_list)

    if display_incidents:
        try:
            _gnn_key = (
                tuple(
                    (
                        str(i.get("incident_id", "")),
                        int(i.get("window_alert_count", i.get("alert_count", 0)) or 0),
                    )
                    for i in display_incidents
                ),
                len(display_logs),
                str(display_logs[-1].get("record_offset", "")) if display_logs else "",
            )
            if _gnn_key not in _GNN_INFERENCE_CACHE:
                if len(_GNN_INFERENCE_CACHE) > 8:
                    _GNN_INFERENCE_CACHE.clear()
                _GNN_INFERENCE_CACHE[_gnn_key] = run_gnn_inference(
                    incidents=display_incidents,
                    logs=display_logs[-NXLOG_DISPLAY_WINDOW_LIMIT:],
                )
            node_scores = _GNN_INFERENCE_CACHE[_gnn_key].get("node_scores", {})
        except Exception:
            node_scores = {}

        sec2_inc_options = ["ALL ACTIVE INCIDENTS"] + [
            f"{inc.get('incident_id', f'INC-{idx}')} — {inc.get('incident_name', 'Security Incident')}"
            for idx, inc in enumerate(display_incidents)
            if not inc.get("is_diagnostic")
        ]
        sec2_selected_focus = st.selectbox(
            "🎯 Filter AI Diagnostics & Playbooks by Incident Case:",
            options=sec2_inc_options,
            index=0,
            key="sec2_incident_focus_select"
        )

        for idx, inc in enumerate(display_incidents):
            if inc.get("is_diagnostic"):
                continue
            inc_id = inc.get("incident_id", f"INC-{idx}")
            inc_name = inc.get("incident_name", "Security Incident")
            if sec2_selected_focus != "ALL ACTIVE INCIDENTS" and not sec2_selected_focus.startswith(f"{inc_id} —"):
                continue

            host = format_network_display(inc.get("affected_host"), field_role="hostname")
            user = inc.get("affected_user", "SYSTEM")
            sev = inc.get("severity", "Medium")
            conf = int(inc.get("confidence", 70))
            sev_rationale = inc.get("severity_rationale") or "Severity derived from correlated alert rules and supporting process/IOC evidence."
            win_cnt = int(inc.get("window_alert_count", inc.get("alert_count", len(inc.get("alerts", [])))))
            cum_cnt = int(inc.get("cumulative_alert_count", win_cnt))

            exp = next(
                (e for e in explanations if e.get("incident_id") == inc_id or e.get("incident_name") == inc_name),
                {}
            )
            reasoning = exp.get("reason", "Suspicious multi-stage alert chain detected across telemetry.")
            plan_obj = next(
                (p for p in response_plans if p.get("incident_id") == inc_id),
                next((p for p in response_plans if p.get("target_host") == inc.get("affected_host")), {})
            )

            host_score = node_scores.get(f"HOST:{host}", node_scores.get(f"INC:{inc_id}", 0.85))
            recommendations = soar_engine.evaluate_incident(inc, gnn_risk_score=host_score)
            hist_guidance_info = fb_lookup_agent.retrieve_similar_guidance(inc)

            inc_src_ips = inc.get("observed_source_ips", [])
            if inc_src_ips:
                inc_ip_str = ", ".join(inc_src_ips[:2])
            elif inc.get("is_real_telemetry"):
                inc_ip_str = observed_endpoint_ip
            else:
                inc_ip_str = "Local / Host-Internal"

            obs_evt_ids = sorted({
                str(alt.get("event", {}).get("event_id", ""))
                for alt in inc.get("alerts", [])
                if alt.get("event", {}).get("event_id") not in (None, "", 0, "0")
            })
            obs_procs = sorted({
                format_network_display(alt.get("event", {}).get("process_name"), field_role="process_name")
                for alt in inc.get("alerts", [])
                if alt.get("event", {}).get("process_name")
            })

            st.markdown(f"### 📌 Incident Case: {inc_name} (`{inc_id}`)")
            st.caption(f"🔎 **Severity & Confidence Rationale (`{sev}` | `{conf}%`)**: {sev_rationale}")

            c1, c2, c3 = st.columns(3)
            with c1:
                st.markdown("#### ❓ AI Diagnostic Root Cause")
                st.info(reasoning)
            with c2:
                st.markdown("#### 🎯 Incident Attributes & Evidence")
                st.write(f"- **Target Host**: `{host}`")
                st.write(f"- **Sender / Source IP**: `{inc_ip_str}`")
                st.write(f"- **Affected User**: `{user}`")
                st.write(f"- **Severity / Confidence**: `{sev} ({conf}%)`")
                st.write(f"- **Evidence Alerts**: `{win_cnt} Window | {cum_cnt} Cumulative`")
                st.write(f"- **Observed Event IDs**: `{', '.join(obs_evt_ids[:6]) if obs_evt_ids else 'Event Correlated'}`")
                st.write(f"- **Observed Process(es)**: `{', '.join(obs_procs[:3]) if obs_procs else 'System Process'}`")
                st.write(f"- **GNN Risk Score**: `{host_score:.4f}`")
            with c3:
                st.markdown("#### 🛡️ Allowlisted Response Policy")
                st.write(f"- **Allowlist Actions**: `{len(recommendations)} recommended` / `{registered_actions_cnt} registered`")
                st.write(f"- **Collector Receiver**: `{active_receiver_hostname} ({active_receiver_addr})`")
                st.write(f"- **Approval Required**: `Yes (Human Analyst)`")
                st.write(f"- **Execution Safety**: `SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN`")

            if hist_guidance_info.get("has_historical_match"):
                hist_fb = hist_guidance_info.get("historical_feedback") or {}
                ev_comp = hist_guidance_info.get("evidence_comparison") or {}
                st.caption(
                    f"📚 **{hist_guidance_info.get('guidance_origin')}**: Prior review `{hist_fb.get('feedback_id')}` "
                    f"recorded verdict **`{hist_fb.get('analyst_verdict')}`** (`Confidence: {hist_fb.get('adjusted_confidence')}%`). "
                    f"{ev_comp.get('comparison_summary')}"
                )

            if plan_obj and plan_obj.get("containment_actions"):
                with st.expander(f"📋 Response Planning Agent Playbook ({inc_id}) — Priority: {plan_obj.get('priority', sev)}"):
                    pc1, pc2, pc3 = st.columns(3)
                    with pc1:
                        st.markdown("**1. Containment Steps**")
                        for step in plan_obj.get("containment_actions", []):
                            st.write(f"- {step}")
                    with pc2:
                        st.markdown("**2. Eradication Steps**")
                        for step in plan_obj.get("eradication_actions", []):
                            st.write(f"- {step}")
                    with pc3:
                        st.markdown("**3. Recovery Steps**")
                        for step in plan_obj.get("recovery_actions", []):
                            st.write(f"- {step}")

            is_open = (st.session_state.get("soar_open_expander") == inc_id)
            with st.expander(f"🛡️ Analyst Action Approval & SOAR Execution Console ({inc_name})", expanded=is_open):
                if recommendations:
                    for rec_idx, rec in enumerate(recommendations):
                        act_id = rec["action_id"]
                        act_target = rec["target"]
                        why_msg = rec["why_recommended"]
                        preview_msg = rec["dry_run_preview"]
                        prio_order = rec.get("priority_order", rec_idx + 1)
                        prio_label = rec.get("priority_label", "P2 - Recommended Containment")
                        exp_effect = rec.get("expected_effect", "Contains potential threat activity in simulation.")
                        op_impact = rec.get("operational_impact", "Low — Simulated action only; no real OS impact.")
                        sim_banner = rec.get("simulation_banner", "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN")
                        is_rev = soar_registry.get_action(act_id).get("is_reversible", False)
                        rec_params = rec.get("parameters", {})
                        rec_rule_id = rec.get("rule_id") if rec.get("rule_id") not in (None, "", "N/A", "NA") else "RULE-HEURISTIC-01"
                        rec_tech = format_network_display(rec.get("mitre_technique"), field_role="mitre_technique")

                        matching_audits = [
                            r for r in audit_records
                            if r.get("incident_id") == inc_id and r.get("action_id") == act_id
                        ]
                        latest_audit = matching_audits[0] if matching_audits else None
                        if latest_audit:
                            approval_state = latest_audit.get("analyst_approval", "PENDING")
                            raw_status = latest_audit.get("action_status", "PROPOSED")
                            if latest_audit.get("rollback_status") == "ROLLED_BACK":
                                lifecycle_state = "ROLLED_BACK"
                            elif raw_status == "EXECUTED":
                                lifecycle_state = "COMPLETED_IN_SIMULATION"
                            elif raw_status == "DRY_RUN":
                                lifecycle_state = "SIMULATED (DRY_RUN)"
                            else:
                                lifecycle_state = raw_status
                        else:
                            approval_state = "PENDING_ANALYST_REVIEW"
                            lifecycle_state = rec.get("proposal_state", "PROPOSED")

                        st.markdown(
                            f"##### Priority #{prio_order} (`{prio_label}`): `{act_id}` on Target "
                            f"`<code style='color: #38bdf8; background: #0b0f19; border: 1px solid #1e293b; padding: 2px 6px; border-radius: 4px;'>{act_target}</code>`",
                            unsafe_allow_html=True,
                        )
                        st.write(f"💡 **Recommendation Rationale**: {why_msg}")
                        st.write(f"🎯 **Expected Effect**: {exp_effect}")
                        st.write(f"⚖️ **Possible Operational Impact**: {op_impact}")
                        st.write(
                            f"📌 **Lifecycle State**: `{lifecycle_state}` | "
                            f"**Analyst Approval Status**: `{approval_state}` | "
                            f"**Mode**: `{sim_banner}`"
                        )
                        st.warning(f"⚠️ **Dry-Run Preview ({sim_banner})**: `{preview_msg}`")

                        col_act1, col_act2, col_act3, col_act4 = st.columns(4)
                        btn_key_prefix = f"soar_{inc_id}_{act_id}_{rec_idx}"

                        with col_act1:
                            st.button(
                                "✅ Approve Action",
                                key=f"{btn_key_prefix}_approve",
                                on_click=soar_cb_approve,
                                args=(inc_id, act_id, act_target, host_score, rec_params, rec_rule_id, rec_tech, is_rev),
                                use_container_width=True
                            )

                        with col_act2:
                            st.button(
                                "❌ Reject Action",
                                key=f"{btn_key_prefix}_reject",
                                on_click=soar_cb_reject,
                                args=(inc_id, act_id, act_target, host_score, rec_params, rec_rule_id, rec_tech),
                                use_container_width=True
                            )

                        with col_act3:
                            st.button(
                                "⚡ Execute Simulation",
                                key=f"{btn_key_prefix}_sim",
                                on_click=soar_cb_execute_sim,
                                args=(inc_id, act_id, act_target, host_score, rec_params, rec_rule_id, rec_tech),
                                use_container_width=True
                            )

                        with col_act4:
                            if is_rev:
                                st.button(
                                    "🔄 Trigger Rollback",
                                    key=f"{btn_key_prefix}_rollback",
                                    on_click=soar_cb_rollback,
                                    args=(inc_id, act_id, act_target, host_score, rec_params, rec_rule_id, rec_tech),
                                    use_container_width=True
                                )
                            else:
                                st.caption("🔒 Action Explicitly NON-REVERSIBLE")

                        st.markdown("---")
                else:
                    st.info(
                        "No disruptive SOAR containment actions recommended for this routine/low-severity case "
                        "(`SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN`)."
                    )

            st.divider()

        with st.expander("📋 View Persistent SOAR Action Audit Log & Verification Records"):
            all_audits = soar_audit.get_audit_records(limit=50)
            if all_audits:
                df_audit = pd.DataFrame([
                    {
                        "Audit ID": r["audit_id"],
                        "Incident ID": r["incident_id"],
                        "Action ID": r["action_id"],
                        "Target": r["target"],
                        "Analyst Approval": r["analyst_approval"],
                        "Status": r["action_status"],
                        "Lifecycle State": (
                            "ROLLED_BACK"
                            if r.get("rollback_status") == "ROLLED_BACK"
                            else (
                                "COMPLETED_IN_SIMULATION"
                                if r.get("action_status") == "EXECUTED"
                                else r.get("action_status")
                            )
                        ),
                        "Verification": r["verification_result"],
                        "Rollback": r["rollback_status"],
                        "Dry Run": r["dry_run"],
                        "GNN Score": f"{r['gnn_score']:.4f}",
                        "Timestamp": r["requested_timestamp"][:19]
                    }
                    for r in all_audits
                ])
                st.dataframe(df_audit, use_container_width=True)
            else:
                st.info("No SOAR audit records recorded yet. Approve or simulate actions above to generate audit logs.")
    else:
        st.info("No AI diagnostic cases or SOAR playbooks available under active filter.")

# -------------------------------------------------------------------
# SECTOR 3: MITRE ATT&CK ANALYTICS
# -------------------------------------------------------------------
with tab3:
    st.subheader("📊 Sector 3: MITRE ATT&CK Heatmap & Visual Matrix")
    st.write("Visual breakdown of threat telemetry mapped to official MITRE Enterprise Tactics & Techniques:")
    st.caption(
        f"📡 Active Telemetry Attribution: Endpoint `{observed_endpoint_host}` (`{observed_endpoint_ip}`) "
        f"→ Collector `{active_receiver_hostname}` (`{active_receiver_addr}` via `{active_network_interface}`)"
    )

    # Interactive MITRE Analytics Filters
    m_f1, m_f2, m_f3 = st.columns(3)
    with m_f1:
        mitre_prov_filter = st.selectbox(
            "🛰️ Telemetry Provenance Scope:",
            ["All Telemetry (Live + Simulated)", "Real Live Telemetry Only", "Simulated Scenarios Only"],
            index=0,
            key="sec3_prov_filter"
        )
    with m_f2:
        mitre_sev_filter = st.multiselect(
            "🚨 Alert Severity Filter:",
            ["Critical", "High", "Medium", "Low"],
            default=["Critical", "High", "Medium", "Low"],
            key="sec3_sev_filter"
        )
    with m_f3:
        available_mitre_hosts = sorted({
            format_network_display(alt.get("event", {}).get("hostname") or alt.get("hostname"), field_role="hostname")
            for alt in display_alerts
        })
        mitre_host_filter = st.multiselect(
            "💻 Target Endpoint Filter:",
            options=available_mitre_hosts,
            default=available_mitre_hosts,
            key="sec3_host_filter"
        )

    sector3_alerts = []
    for alt in display_alerts:
        evt_obj = alt.get("event", {})
        alt_src = str(evt_obj.get("source") or alt.get("source") or "").strip()
        is_real_alt = alt_src in ("real_nxlog_windows", "local_windows")
        if mitre_prov_filter == "Real Live Telemetry Only" and not is_real_alt:
            continue
        if mitre_prov_filter == "Simulated Scenarios Only" and is_real_alt:
            continue
        alt_sev = str(alt.get("severity") or evt_obj.get("severity") or "Low").strip().title()
        if alt_sev not in mitre_sev_filter:
            continue
        alt_host = format_network_display(evt_obj.get("hostname") or alt.get("hostname"), field_role="hostname")
        if available_mitre_hosts and alt_host not in mitre_host_filter:
            continue
        sector3_alerts.append(alt)

    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        tactic_counts = {}
        for alt in sector3_alerts:
            evt_obj = alt.get("event", {})
            tactic = evt_obj.get("mitre_tactic")
            tech_id = str(alt.get("mitre_technique") or evt_obj.get("mitre_technique") or "").strip()
            if not tactic or str(tactic).upper() in ("N/A", "NA", "NONE", "UNKNOWN", "UNKNOWN TACTIC", ""):
                tactic = LogEnricher.TACTIC_MAP.get(tech_id, "Execution")
            tactic_counts[tactic] = tactic_counts.get(tactic, 0) + 1

        if tactic_counts:
            df_tactics = pd.DataFrame(list(tactic_counts.items()), columns=["MITRE Tactic", "Alert Count"])
            fig_pie = px.pie(
                df_tactics,
                values="Alert Count",
                names="MITRE Tactic",
                title="Alert Breakdown by MITRE Tactic",
                hole=0.45,
                color_discrete_sequence=px.colors.qualitative.Bold
            )
            fig_pie.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#e2e8f0")
            )
            st.plotly_chart(fig_pie, use_container_width=True)
        else:
            st.info("No MITRE ATT&CK tactic alerts triggered under active filter.")

    with chart_col2:
        tech_counts = {}
        for alt in sector3_alerts:
            tech = format_network_display(alt.get("mitre_technique"), field_role="mitre_technique")
            tech_counts[tech] = tech_counts.get(tech, 0) + 1

        if tech_counts:
            df_tech = pd.DataFrame(list(tech_counts.items()), columns=["Technique ID", "Frequency"])
            fig_bar = px.bar(
                df_tech,
                x="Technique ID",
                y="Frequency",
                title="Triggered MITRE Enterprise Techniques",
                color="Frequency",
                color_continuous_scale="Blues"
            )
            fig_bar.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#e2e8f0")
            )
            st.plotly_chart(fig_bar, use_container_width=True)
        else:
            st.info("No MITRE ATT&CK techniques triggered under active filter.")

    if sector3_alerts:
        st.markdown("#### 🎯 Triggered MITRE Technique Summary")
        tech_summary_map = {}
        for alt in sector3_alerts:
            evt_obj = alt.get("event", {})
            tech_id = format_network_display(alt.get("mitre_technique") or evt_obj.get("mitre_technique"), field_role="mitre_technique")
            tactic = evt_obj.get("mitre_tactic")
            if not tactic or str(tactic).upper() in ("N/A", "NA", "NONE", "UNKNOWN", "UNKNOWN TACTIC", ""):
                tactic = LogEnricher.TACTIC_MAP.get(tech_id, "Execution")
            host_val = format_network_display(evt_obj.get("hostname") or alt.get("hostname"), field_role="hostname")
            sev_val = str(alt.get("severity") or evt_obj.get("severity") or "Low").strip().title()
            entry = tech_summary_map.setdefault(tech_id, {
                "Technique ID": tech_id,
                "MITRE Tactic": tactic,
                "Window Alerts": 0,
                "Hosts": set(),
                "Severities": set(),
            })
            entry["Window Alerts"] += 1
            entry["Hosts"].add(host_val)
            entry["Severities"].add(sev_val)

        tech_table_rows = []
        for t_id, t_info in sorted(tech_summary_map.items(), key=lambda kv: kv[1]["Window Alerts"], reverse=True):
            matching_inc_cnt = sum(
                1 for inc in display_incidents
                if not inc.get("is_diagnostic") and (
                    t_id in (inc.get("mitre_techniques") or [])
                    or any(
                        format_network_display(a.get("mitre_technique"), field_role="mitre_technique") == t_id
                        for a in inc.get("alerts", [])
                    )
                )
            )
            tech_table_rows.append({
                "Technique ID": t_id,
                "MITRE Tactic": t_info["MITRE Tactic"],
                "Window Alerts": t_info["Window Alerts"],
                "Correlated Incidents": matching_inc_cnt,
                "Affected Hosts": ", ".join(sorted(t_info["Hosts"])),
                "Observed Severities": ", ".join(sorted(t_info["Severities"])),
            })
        st.dataframe(pd.DataFrame(tech_table_rows), use_container_width=True, hide_index=True)

        with st.expander("🔍 MITRE Technique Drill-Down: Inspect Supporting Incidents & Event Evidence", expanded=False):
            drill_tech_options = [r["Technique ID"] for r in tech_table_rows]
            selected_drill_tech = st.selectbox(
                "Select MITRE Technique to Inspect Supporting Evidence:",
                options=drill_tech_options,
                key="sec3_drill_tech_select"
            )
            drill_alerts = [
                alt for alt in sector3_alerts
                if format_network_display(alt.get("mitre_technique"), field_role="mitre_technique") == selected_drill_tech
            ]
            st.caption(f"Showing `{len(drill_alerts)}` alert evidence record(s) mapped to `{selected_drill_tech}`:")
            df_drill = pd.DataFrame([
                {
                    "Timestamp": str(a.get("event", {}).get("timestamp", ""))[:19],
                    "Alert Name": a.get("alert_name", "Security Alert"),
                    "Event ID": str(a.get("event", {}).get("event_id", 0)),
                    "Severity": str(a.get("severity", "Low")),
                    "Hostname": format_network_display(a.get("event", {}).get("hostname"), field_role="hostname"),
                    "User": str(a.get("event", {}).get("user", "SYSTEM")),
                    "Process": format_network_display(a.get("event", {}).get("process_name"), field_role="process_name"),
                    "Command Line": format_network_display(a.get("event", {}).get("command_line"), field_role="command_line"),
                    "Source": str(a.get("event", {}).get("source", "unknown")),
                }
                for a in drill_alerts[:100]
            ])
            st.dataframe(df_drill, use_container_width=True, hide_index=True)

# -------------------------------------------------------------------
# SECTOR 4: ANALYST REVIEW & FEEDBACK
# -------------------------------------------------------------------
with tab4:
    st.subheader("🔄 Sector 4: Human-in-the-Loop Analyst Feedback & Safe Knowledge Reuse")
    st.write(
        "Human analysts review AI incident findings, record corrections/verdicts persistently in SQLite (`sentinel_kb.db`), "
        "and compare current incident evidence against prior analyst-approved guidance:"
    )
    st.caption(
        f"🖥️ Active SOC Session Context: Reviewing telemetry from `{observed_endpoint_host}` (`{observed_endpoint_ip}`) "
        f"collected at `{active_receiver_hostname}` (`{active_receiver_addr}`)"
    )

    fb_agent = FeedbackAgent()
    history = fb_agent.get_feedback_history()
    reviewable_incidents = [inc for inc in display_incidents if not inc.get("is_diagnostic")]

    reviewed_inc_ids = {str(h.get("incident_id", "")).strip() for h in history if h.get("incident_id")}
    active_reviewable_ids = {str(inc.get("incident_id", "")).strip() for inc in reviewable_incidents if inc.get("incident_id")}
    reviewed_active_cnt = len(active_reviewable_ids & reviewed_inc_ids)
    pending_review_cnt = max(0, len(reviewable_incidents) - reviewed_active_cnt)

    fk1, fk2, fk3, fk4 = st.columns(4)
    with fk1:
        st.metric("Reviewable Incidents", len(reviewable_incidents))
    with fk2:
        st.metric("Pending Review", pending_review_cnt)
    with fk3:
        st.metric("Reviewed (Active)", reviewed_active_cnt)
    with fk4:
        st.metric("Total SQLite Reviews", len(history))

    st.markdown("<br>", unsafe_allow_html=True)

    if reviewable_incidents:
        selected_inc = st.selectbox(
            "Select Incident to Review:",
            options=[inc["incident_id"] for inc in reviewable_incidents],
            format_func=lambda x: f"{x} - {next((i['incident_name'] for i in reviewable_incidents if i['incident_id'] == x), '')}"
        )
        selected_inc_obj = next((i for i in reviewable_incidents if i["incident_id"] == selected_inc), {})
        ai_sev = selected_inc_obj.get("severity", "Low")
        ai_conf = int(selected_inc_obj.get("confidence", 70))
        ai_rat = selected_inc_obj.get("severity_rationale") or "Evidence-based AI correlation classification."

        st.markdown(
            f"**🤖 AI-Generated Assessment (Newly Analyzed Finding)**: Severity `{ai_sev}` (`{ai_conf}%` confidence) — *{ai_rat}*"
        )

        # Retrieve and compare prior historical analyst guidance
        sim_guidance = fb_agent.retrieve_similar_guidance(selected_inc_obj)
        with st.expander("🔍 Historical Knowledge Retrieval & Evidence Comparison", expanded=bool(sim_guidance.get("has_historical_match"))):
            st.caption(f"🏷️ **Origin Classification**: `{sim_guidance.get('guidance_origin')}`")
            if sim_guidance.get("has_historical_match"):
                h_fb = sim_guidance.get("historical_feedback") or {}
                ev_cmp = sim_guidance.get("evidence_comparison") or {}
                st.write(
                    f"- **Matched Historical Review**: `{h_fb.get('feedback_id')}` on Incident `{h_fb.get('incident_id')}` (`{h_fb.get('alert_name')}`)"
                )
                st.write(
                    f"- **Human Analyst Decision**: Verdict = `{h_fb.get('analyst_verdict')}` | "
                    f"Override Severity = `{h_fb.get('override_severity')}` | "
                    f"Analyst Confidence = `{h_fb.get('adjusted_confidence')}%` | "
                    f"Recorded At = `{str(h_fb.get('created_at', ''))[:19]}`"
                )
                st.write(f"- **Evidence Comparison**: {ev_cmp.get('comparison_summary')}")
                if sim_guidance.get("can_reuse_guidance") and sim_guidance.get("reused_guidance"):
                    st.info(
                        f"📚 **Historical Analyst Guidance (Reference Only — Not a Newly Verified Finding)**: "
                        f"{sim_guidance.get('reused_guidance')}"
                    )
                else:
                    st.warning(
                        "⚠️ **Historical Guidance Not Reused**: Current incident evidence diverges from the historical review."
                    )
            else:
                st.info("No prior analyst-reviewed case matched this incident pattern in `sentinel_kb.db` yet.")
            st.caption(f"🔒 {sim_guidance.get('safety_policy', {}).get('policy_statement', '')}")

        with st.form("simple_feedback_form"):
            col_f1, col_f2, col_f3 = st.columns(3)
            with col_f1:
                verdict = st.radio(
                    "Analyst Verdict:",
                    [
                        "True Positive (Real Attack)",
                        "False Positive (Fake Alarm)",
                        "Benign / Expected Admin Activity",
                        "Inconclusive",
                    ],
                )
            with col_f2:
                override_sev_choice = st.selectbox(
                    "Corrected / Override Severity:",
                    ["Keep Current Severity", "Low", "Medium", "High", "Critical"],
                )
            with col_f3:
                conf_slider = st.slider("Adjusted AI Confidence (%):", 0, 100, ai_conf)

            notes = st.text_input(
                "Feedback Notes & Approved Guidance (Optional):",
                placeholder="e.g. Verified routine Windows Credential Manager read by explorer.exe; monitor only.",
            )
            submitted = st.form_submit_button("💾 Save Feedback into SQLite DB", use_container_width=True)

            if submitted:
                resolved_verdict = (
                    "True Positive"
                    if "True" in verdict
                    else (
                        "False Positive"
                        if "False" in verdict
                        else ("Benign / Expected Admin Activity" if "Benign" in verdict else "Inconclusive")
                    )
                )
                resolved_override = (
                    selected_inc_obj.get("severity", "Low")
                    if override_sev_choice == "Keep Current Severity"
                    else override_sev_choice
                )
                fb_agent.process_feedback(
                    incident_id=selected_inc,
                    alert_name=selected_inc_obj.get("incident_name", "Incident"),
                    analyst_verdict=resolved_verdict,
                    override_severity=resolved_override,
                    adjusted_confidence=conf_slider,
                    notes=notes,
                    incident=selected_inc_obj,
                    approved_guidance=notes if notes.strip() else None,
                )
                st.success("✅ Feedback and approved guidance saved persistently into SQLite Knowledge Base (`sentinel_kb.db`)!")
                st.rerun()

    st.markdown("#### 📜 Recent Feedback History Saved in SQLite Database (`analyst_feedback`)")
    if history:
        st.dataframe(pd.DataFrame(history), use_container_width=True)
    else:
        st.info("No feedback records saved in database yet.")

# -------------------------------------------------------------------
# SECTOR 5: EXECUTIVE & TECHNICAL SOC REPORTS
# -------------------------------------------------------------------
with tab5:
    st.subheader("📄 Sector 5: Executive & Technical SOC Incident Reports")
    st.write("Formal SOC Incident Reports formatted for CISO leadership and technical responders (Available in PDF & CSV format):")

    reports_by_inc_id = {}
    for r in reports:
        r_inc_id = r.get("incident_id") or str(r.get("report_id", "")).removeprefix("REP-")
        if r_inc_id and r_inc_id not in reports_by_inc_id:
            reports_by_inc_id[r_inc_id] = r

    active_reports = []
    for inc in display_incidents:
        inc_id = inc.get("incident_id")
        gen_reps = ReportingAgent().generate([inc]) if inc_id else []
        fresh_rep = gen_reps[0] if gen_reps else None
        matched_rep = reports_by_inc_id.get(inc_id) or fresh_rep
        if matched_rep is not None:
            merged_rep = dict(matched_rep)
            if fresh_rep is not None:
                merged_rep.update(fresh_rep)
                reports_by_inc_id[inc_id] = merged_rep
            inc_summary = format_incident_alert_summary(inc)
            for prov_key in (
                "incident_name",
                "severity",
                "confidence",
                "telemetry_sources",
                "primary_source",
                "is_real_telemetry",
                "is_simulated",
                "provenance_label",
                "window_alert_count",
                "cumulative_alert_count",
                "cumulative_scope",
                "alert_count",
                "first_event_timestamp",
                "last_event_timestamp",
                "evidence_alert_cap",
            ):
                if prov_key in inc:
                    merged_rep[prov_key] = inc[prov_key]
            merged_rep["first_event_timestamp"] = inc_summary["first_event_timestamp"]
            merged_rep["last_event_timestamp"] = inc_summary["last_event_timestamp"]
            merged_rep["historical_log_range"] = inc_summary["historical_log_range"]
            merged_rep["evidence_alert_cap"] = inc_summary["evidence_alert_cap"]
            merged_rep["bounded_evidence_count"] = inc_summary["evidence_shown_count"]
            merged_rep["alert_scope_explanation"] = inc_summary["scope_explanation"]
            active_reports.append(merged_rep)

    total_available_inc_count = len(nxlog_incidents) + len(incidents)
    nx_rep_count = len(st.session_state.get("nxlog_reports", []))
    sim_stored_rep_count = len(results.get("reports", []))
    real_active_rep_count = sum(1 for r in active_reports if r.get("is_real_telemetry"))
    sim_active_rep_count = len(active_reports) - real_active_rep_count
    st.session_state.sector5_stage_counts = {
        "incidents_available": total_available_inc_count,
        "display_incidents": len(display_incidents),
        "reports_generated": nx_rep_count + sim_stored_rep_count,
        "reports_stored": len(reports),
        "reports_after_filter": len(active_reports),
        "real_reports_rendered": real_active_rep_count,
        "simulated_reports_rendered": sim_active_rep_count,
    }

    # Executive SOC Report Summary KPI & Action Row
    rk1, rk2, rk3, rk4, rk5 = st.columns(5)
    with rk1:
        st.metric("Correlated Incidents", len(display_incidents))
    with rk2:
        st.metric("Reports Rendered", len(active_reports))
    with rk3:
        st.metric("Real Telemetry Reports", real_active_rep_count)
    with rk4:
        st.metric("Simulated Reports", sim_active_rep_count)
    with rk5:
        if st.button("🔄 Refresh SOC Reports", key="sec5_refresh_reports_btn", use_container_width=True):
            sync_nxlog_telemetry_live()
            st.rerun()
        if active_reports:
            df_bulk_reports = pd.DataFrame([
                {
                    "Report ID": r.get("report_id"),
                    "Incident ID": r.get("incident_id"),
                    "Incident Name": r.get("incident_name"),
                    "Severity": r.get("severity"),
                    "Confidence (%)": r.get("confidence"),
                    "Provenance": "REAL TELEMETRY" if r.get("is_real_telemetry") else "SIMULATED SCENARIO",
                    "Primary Source": r.get("primary_source"),
                    "Target Host": format_network_display(r.get("host"), field_role="hostname"),
                    "Account": r.get("user"),
                    "Source IP": format_network_display(r.get("source_ip"), field_role="source_ip"),
                    "Window Alerts": r.get("window_alert_count", r.get("alert_count", 0)),
                    "Cumulative Alerts": r.get("cumulative_alert_count", r.get("alert_count", 0)),
                    "Historical Log Range": r.get("historical_log_range"),
                    "Executive Summary": r.get("executive_summary"),
                    "Recommendation": r.get("recommendation"),
                    "Recommendation Status": r.get("recommendation_status"),
                    "Generated Timestamp": r.get("timestamp"),
                }
                for r in active_reports
            ])
            st.download_button(
                label="📥 Export All Reports (CSV)",
                data=df_bulk_reports.to_csv(index=False).encode("utf-8"),
                file_name="AdaptiveSentinel_SOC_Reports_Summary.csv",
                mime="text/csv",
                key="sec5_bulk_csv_dl",
                use_container_width=True,
            )

    st.caption(
        f"📊 **Report Pipeline Accounting**: Incidents Available: `{total_available_inc_count}` (`{len(display_incidents)}` matching filter) | "
        f"Reports Generated: `{nx_rep_count + sim_stored_rep_count}` (`{nx_rep_count}` live NXLog + `{sim_stored_rep_count}` pipeline) | "
        f"Reports Stored: `{len(reports)}` | Reports Rendered: `{len(active_reports)}` "
        f"(`{real_active_rep_count}` 📡 Real Telemetry, `{sim_active_rep_count}` 🧪 Simulated Scenario)"
    )

    if not active_reports:
        st.info("No SOC incident reports match the currently selected telemetry filter.")

    for rep in active_reports:
        safe_rep = dict(rep)
        is_real_rep = bool(safe_rep.get("is_real_telemetry", False))
        rep_prov_badge = "📡 REAL TELEMETRY" if is_real_rep else "🧪 SIMULATED SCENARIO"
        rep_primary_src = safe_rep.get("primary_source", "nxlog_windows" if is_real_rep else "api_simulation")
        rep_win_alerts = int(safe_rep.get("window_alert_count", safe_rep.get("alert_count", 0)))
        rep_cum_alerts = int(safe_rep.get("cumulative_alert_count", safe_rep.get("alert_count", 0)))
        rep_cum_scope = safe_rep.get("cumulative_scope", "Current Window")
        rep_hist_range = safe_rep.get("historical_log_range") or "Active Window"
        rep_ev_cap = int(safe_rep.get("evidence_alert_cap", 100))
        rep_ev_shown = int(safe_rep.get("bounded_evidence_count", safe_rep.get("alert_count", 0)))
        rep_win_fmt = f"{rep_win_alerts:,}"
        rep_cum_fmt = f"{rep_cum_alerts:,}"
        safe_rep["host"] = format_network_display(safe_rep.get("host"), field_role="hostname")
        safe_rep["source_ip"] = format_network_display(
            safe_rep.get("source_ip"),
            field_role="source_ip",
            fallback_peer_ip=(active_tcp_peer_ip if (active_tcp_peer_ip != "N/A" and is_real_rep) else None),
        )
        safe_rep["technical_analysis"] = (
            str(safe_rep.get("technical_analysis", ""))
            .replace("'N/A'", "'Not applicable for event type'")
            .replace("Process Name: N/A", "Process Name: Not applicable for event type")
        )
        with st.expander(f"📄 SOC Report {safe_rep['report_id']} - {safe_rep['incident_name']} [{rep_prov_badge}]"):
            st.markdown(f"## SOC INCIDENT REPORT: {safe_rep['incident_name']}")
            st.markdown(
                f"**Report ID**: `{safe_rep['report_id']}` | **Incident ID**: `{safe_rep.get('incident_id', 'N/A')}` | "
                f"**Incident Severity**: `{safe_rep.get('severity', 'Low')}` (`{safe_rep.get('confidence', 70)}%` confidence) | "
                f"**Provenance**: `{rep_prov_badge}` (`{rep_primary_src}`) | **Generated**: {safe_rep['timestamp']} | "
                f"**Collector**: `{active_receiver_hostname} ({active_receiver_addr})`"
            )
            st.markdown(
                f"**Target Endpoint**: `{safe_rep['host']}` | **Account**: `{safe_rep['user']}` | "
                f"**Source / Peer IP**: `{safe_rep['source_ip']}` | "
                f"**Window Alerts**: `{rep_win_fmt}` (`Current Window`) | "
                f"**Cumulative Alerts ({rep_cum_scope})**: `{rep_cum_fmt}` (`Historical Log Range: {rep_hist_range}`) | "
                f"**Evidence Table Cap**: `{rep_ev_shown} / {rep_ev_cap} recent records`"
            )
            if safe_rep.get("alert_scope_explanation"):
                st.caption(safe_rep["alert_scope_explanation"])
            st.divider()

            st.markdown("### 📌 Executive Summary")
            st.write(safe_rep["executive_summary"])
            if safe_rep.get("severity_rationale"):
                st.caption(f"🔎 **Severity Rationale**: {safe_rep['severity_rationale']}")

            st.markdown("### ⚙️ Technical Analysis & Command Trail")
            st.write(safe_rep["technical_analysis"])

            st.markdown("### 🌐 Threat Intelligence & Risk Profile")
            rc1, rc2, rc3 = st.columns(3)
            with rc1:
                st.write(f"**Threat Status**: `{safe_rep['status']}`")
            with rc2:
                st.write(f"**Reputation**: `{safe_rep['reputation']}`")
            with rc3:
                st.write(f"**External IP / IOC Risk Score**: `{safe_rep['risk_score']} / 100`")
            if safe_rep.get("threat_intel_summary"):
                st.caption(f"ℹ️ **Threat Intelligence vs. Incident Severity**: {safe_rep['threat_intel_summary']}")

            st.markdown("### 🛡️ Strategic Remediation Plan (Advisory — Not Executed)")
            st.caption(
                f"🔒 **Execution Status**: `{safe_rep.get('recommendation_status', 'Advisory Recommendation — Not Executed (SOAR Dry-Run Mode; Requires Analyst Approval)')}`"
            )
            st.info(safe_rep["recommendation"])

            # Generate PDF & CSV Report Downloads
            _pdf_key = (
                str(safe_rep.get("report_id", "")),
                str(safe_rep.get("severity", "")),
                int(safe_rep.get("window_alert_count", 0) or 0),
                int(safe_rep.get("cumulative_alert_count", 0) or 0),
                str(safe_rep.get("last_event_timestamp", "")),
            )
            if _pdf_key not in _PDF_REPORT_CACHE:
                if len(_PDF_REPORT_CACHE) > 32:
                    _PDF_REPORT_CACHE.clear()
                _PDF_REPORT_CACHE[_pdf_key] = create_pdf_report(safe_rep)
            pdf_bytes = _PDF_REPORT_CACHE[_pdf_key]
            single_rep_csv = pd.DataFrame([safe_rep]).to_csv(index=False).encode("utf-8")

            dl_c1, dl_c2 = st.columns(2)
            with dl_c1:
                st.download_button(
                    label=f"📥 Download Official PDF Report ({safe_rep['report_id']})",
                    data=pdf_bytes,
                    file_name=f"SOC_Report_{safe_rep['report_id']}.pdf",
                    mime="application/pdf",
                    key=f"pdf_dl_{safe_rep['report_id']}",
                    use_container_width=True,
                )
            with dl_c2:
                st.download_button(
                    label=f"📊 Download Report Data CSV ({safe_rep['report_id']})",
                    data=single_rep_csv,
                    file_name=f"SOC_Report_{safe_rep['report_id']}.csv",
                    mime="text/csv",
                    key=f"csv_dl_{safe_rep['report_id']}",
                    use_container_width=True,
                )

# -------------------------------------------------------------------
# SECTOR 6: AI SOC CHAT ASSISTANT
# -------------------------------------------------------------------
with tab6:
    st.subheader("💬 Sector 6: SentinelGPT AI SOC Assistant")
    st.write("Ask any questions about the active incidents, logs, MITRE techniques, or cybersecurity terms:")
    st.caption(
        f"🤖 Live Network Context Synchronized: Endpoint `{observed_endpoint_host}` (`{observed_endpoint_ip}`) "
        f"→ Receiver `{active_receiver_hostname}` (`{active_receiver_addr}` | Status: `{net_state['connection_status']}`)"
    )

    llm = LLMClient()
    chat_context = dict(results)
    chat_context["logs"] = display_logs
    chat_context["alerts"] = display_alerts
    chat_context["incidents"] = display_incidents
    chat_context["network_state"] = net_state
    _lat_meta = st.session_state.get("pipeline_latency_metrics") or {}
    chat_context["agent_performance"] = {
        "pipeline_latency_ms": _lat_meta.get("total_ms") if isinstance(_lat_meta, dict) else st.session_state.get("nxlog_pipeline_latency"),
        "latency_scope": _lat_meta.get("scope") if isinstance(_lat_meta, dict) else None,
    }

    # Initialize Chat History in Session State
    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = [
            {
                "role": "assistant",
                "content": (
                    "👋 **Hello! I am your SentinelGPT AI Security Assistant.**\n\n"
                    "I have full contextual knowledge of all active security logs, APT incidents, and threat intel.\n\n"
                    "Ask me anything if you or your faculty panel need clarification on any threat, concept, or remedy!"
                )
            }
        ]

    # Quick Suggestion Prompt Buttons (Row 1: Live Telemetry & Active Incident Queries)
    st.markdown("**⚡ Live SOC Investigation Quick Actions:**")
    qa1, qa2, qa3, qa4 = st.columns(4)

    prompt_to_send = None

    with qa1:
        if st.button("🔎 Explain Active Incident", use_container_width=True, key="chat_qa_explain_inc"):
            top_inc_name = display_incidents[0].get("incident_name", "the active incident") if display_incidents else "the active incident"
            prompt_to_send = f"Explain the active incident ({top_inc_name}) and its severity rationale based on current telemetry."
    with qa2:
        if st.button("📋 Show Supporting Logs", use_container_width=True, key="chat_qa_show_logs"):
            prompt_to_send = "Show the supporting Windows Event IDs, hosts, users, and processes in the current telemetry window."
    with qa3:
        if st.button("🎯 Explain MITRE Technique", use_container_width=True, key="chat_qa_mitre"):
            prompt_to_send = "What MITRE ATT&CK techniques are triggered in the current stream and what do they mean?"
    with qa4:
        if st.button("🛡️ Describe Mitigation Options", use_container_width=True, key="chat_qa_mitigate"):
            prompt_to_send = "What safe mitigation and SOAR response actions are recommended for the current incidents?"

    # Chat Input Box
    user_input = st.chat_input("Ask SentinelGPT anything about cybersecurity or current SOC telemetry...")
    if user_input:
        prompt_to_send = user_input

    # Handle Chat Query Execution
    if prompt_to_send:
        st.session_state["chat_history"].append({"role": "user", "content": prompt_to_send})
        ai_reply = llm.query_chatbot(prompt_to_send, chat_context)
        st.session_state["chat_history"].append({"role": "assistant", "content": ai_reply})

    # Render Chat History
    for msg in st.session_state["chat_history"]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

# Non-blocking Auto-Refresh Receiver Watcher (polls every 5s in browser without blocking UI or AppTest)
@st.fragment(run_every=5)
def _auto_watch_nxlog_receiver():
    if not NXLOG_FILE_PATH.exists():
        return
    try:
        current_size = NXLOG_FILE_PATH.stat().st_size
        if current_size != st.session_state.get("nxlog_last_seen_size", 0):
            _, sync_metrics = sync_nxlog_telemetry_live(auto_triggered=True)
            valid_ingested = sync_metrics.get("valid_ingested", 0)
            if valid_ingested > 0:
                if st.session_state.get("is_reset", False):
                    st.session_state.is_reset = False
                st.session_state._preserve_refresh_batch_on_rerun = True
                st.rerun()
    except Exception as watch_err:
        st.session_state.nxlog_last_sync_error = str(watch_err)


if auto_refresh:
    _auto_watch_nxlog_receiver()