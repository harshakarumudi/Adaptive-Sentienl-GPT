# AdaptiveSentinelGPT — Final System Evaluation & Benchmark Report

**Generated Date**: 2026-10-05T00:40:03  
**System Version**: v1.1.0 (Phase 8.1 Final Harmonized Evaluation)  
**Evaluation Scope**: End-to-End Multi-Agent SOC Automation, PyTorch GNN Anomaly Scoring, Real NXLog Telemetry, Controlled SOAR.

---

## 1. Controlled Synthetic GNN Benchmark Evaluation

*Note: Controlled synthetic evaluation is benchmarked on 30 independent graph topologies split at the graph level (70/15/15) to eliminate node data leakage.*

- **Model Architecture**: AdaptiveSentinelGNN (2-Layer GCN, 5 Input Channels, 16 Hidden Dim)
- **Dataset Topology**: 30 Total Graphs (21 Train | 4 Val | 5 Test)
- **Benchmark Nodes**: 178 Nodes (63 Anomalous [35.39%] | 115 Benign)
- **Loss Function**: Weighted BCE Loss (`pos_weight = 1.7872`)

### GNN Test Split Performance vs Non-GNN Baseline

| Evaluation Metric | AdaptiveSentinelGNN (GCN) | Non-GNN Baseline (Feature Reg) | Delta / Improvement |
|-------------------|---------------------------|--------------------------------|---------------------|
| **Accuracy** | 93.33% | 83.33% | **+10.00%** |
| **Precision** | 1.0000 | 0.8182 | **+0.1818** |
| **Recall** | 0.8333 | 0.7500 | **+0.0833** |
| **F1 Score** | 0.9091 | 0.7826 | **+0.1265** |
| **Test Loss** | 0.2207 | N/A | N/A |

**Confusion Matrix**: `TP=10`, `FP=0`, `TN=18`, `FN=2`

---

## 2. Live NXLog Telemetry Evaluation

*Note: Measured directly from active NXLog Agent (Harsha - Windows 11 endpoint to Sujith - TCP 2514). Ground-truth accuracy is uncalibrated as live endpoints lack verified target labels.*

- **Monitored Endpoint**: `Harsha Laptop (NXLog TCP 2514)` (`IP: 10.184.216.159`)
- **Total NXLog Events Observed**: `62802`
- **Events Successfully Ingested**: `63162`
- **Suspicious Alerts Flagged**: `15`
- **Correlated Incidents**: `8`
- **MITRE Techniques Observed**: `T1003.001, T1059.001, T1078, T1110, T1110.001`
- **GNN Live Inference Latency**: Min `7.945 ms` | Avg `9.39 ms` | Max `16.833 ms`

---

## 3. Pipeline Throughput & Latency Accounting Breakdown

- **Total Logs Processed**: `63162 events`
- **Orchestrator Wall Clock Time**: `4.0038 seconds` (`4003.847 ms`)
- **Sum of All Stage Latencies**: `3960.839 ms` (NXLog Sync: `2699.076 ms` + In-Memory Compute: `1261.763 ms`)
- **Pipeline Throughput**: `15775.33 events/second`

| Pipeline Stage / Agent | Latency (ms) | Scope / Operational Task |
|------------------------|--------------|--------------------------|
| **NXLog Telemetry Network Sync** | `2699.076 ms` | Tail & parse C:\AdaptiveSentinel\windows-events.log |
| **Log Ingestion & Parsing** | `10.95 ms` | In-memory JSON/JSONL raw log parsing |
| **Normalization & Deduplication** | `1098.554 ms` | In-memory OCSF schema mapping & deduplication |
| **Detection Agent** | `138.398 ms` | In-memory MITRE ATT&CK rule heuristics scan |
| **Correlation Agent** | `0.501 ms` | In-memory graph incident aggregation |
| **Threat Intelligence Agent** | `7.784 ms` | SQLite IOC database lookup & risk scoring |
| **GNN Inference Engine** | `9.39 ms` | PyTorch AdaptiveSentinelGNN forward pass |
| **Explainability Agent** | `0.31 ms` | In-memory root-cause rationale compilation |
| **SOAR Decision Engine** | `2.208 ms` | Allowlisted response recommendation generation |
| **Reporting Agent** | `0.375 ms` | Executive & technical report formatting |
| **Feedback Agent** | `2.683 ms` | Human-in-the-Loop SQLite audit lookup |
| **Pure Agent Compute Sum** | **`1261.763 ms`** | **Total In-Memory Agent Computing Time** |
| **All Stages Sum** | **`3960.839 ms`** | **Sum of Network Sync + Agent Computing Stages** |
| **Total Orchestrator Wall Clock** | **`4003.847 ms`** | **Complete End-to-End Execution Cycle** |

---

## 4. Resource Usage

- **Process CPU Time**: `3937.5 ms`
- **Peak RAM Memory Allocated**: `90.17 MB`
- **Measurement Method**: `Python tracemalloc & process_time`

---

## 5. Controlled SOAR Evaluation & Security Validation

### Simulated SOAR Execution Metrics
- **Recommendations Generated**: `28`
- **Actions Approved**: `0`
- **Actions Rejected**: `0`
- **Dry-Run Previews Generated**: `0` (`100%`)
- **Simulated Executions**: `0`
- **Successful Verifications**: `0` (`VERIFIED_SUCCESS`)
- **Rollback Operations**: `0`
- **Rejected Invalid Action Requests**: `6`

### Security Validation Checks

| Security Requirement / Constraint | Status | Enforced Mechanism |
|-----------------------------------|--------|---------------------|
| Arbitrary Shell Commands Rejected | `PASSED` | Enforced by `SOARActionRegistry` allowlist |
| Unknown SOAR Actions Rejected | `PASSED` | Enforced by `SOARActionRegistry` allowlist |
| Invalid IP Addresses Rejected | `PASSED` | Validated via Python `ipaddress` parser |
| Loopback IP Addresses Rejected | `PASSED` | Explicit `127.0.0.1` / Loopback Block |
| Wildcard Host Targets Rejected | `PASSED` | Wildcards `*` / `ALL` Rejected |
| Empty Targets Rejected | `PASSED` | Non-Empty String Requirement |
| Unapproved Action Blocked | `PASSED` | Requires Explicit Human Analyst Approval |
| Analyst Rejection Blocks Execution | `PASSED` | Audit Logger `REJECTED` Status Enforcement |
| Dry-Run Safety Enforced | `PASSED` | `DRY RUN — NO SYSTEM CHANGE` Mode Active |
| Secrets Protected | `PASSED` | No API keys/credentials exposed in code |
| GNN Cannot Execute Actions | `PASSED` | GNN Restricted to Risk Scoring |
| LLM Cannot Execute Commands | `PASSED` | LLM Restricted to Rationale Text |

---

## 6. System Classification & Research Integrity Statement

This system is classified as a **Controlled AI-assisted SOAR prototype with human-in-the-loop analyst approval and simulated execution**. Real-world operating system isolation, IP blocking, and account lockouts are kept disabled in mock simulation mode to prevent endpoint disruption. Benchmark metrics are derived strictly from graph-level controlled synthetic security datasets, while live NXLog telemetry is presented separately without uncalibrated accuracy claims.
