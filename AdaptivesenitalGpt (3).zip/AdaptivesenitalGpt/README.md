# 🛡 AdaptiveSentinelGPT

> **A Multi-Agent AI Framework for Security Operations Center (SOC) Automation, Threat Detection, and Incident Response**

[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Framework](https://img.shields.io/badge/Architecture-Multi--Agent%20AI-green.svg)](#architecture)
[![Dashboard](https://img.shields.io/badge/UI-Streamlit%20Command%20Center-orange.svg)](#soc-dashboard)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 📌 Executive Summary

**AdaptiveSentinelGPT** is a next-generation autonomous AI framework designed to solve the critical challenges facing modern Security Operations Centers (SOCs): **alert fatigue, high mean-time-to-detect (MTTD), false positives, and fragmented threat context**.

By leveraging a team of **7 specialized autonomous AI agents**, AdaptiveSentinelGPT ingests multi-source logs (Windows Security Events, Sysmon, Linux Auth, Suricata IDS), normalizes them into OCSF schema, correlates atomic events into complex multi-stage attack chains, enriches alerts with Threat Intelligence, generates natural language AI explainability rationale via LLMs (Ollama / Llama 3 / Gemini / Heuristic Engine), executes automated SOAR response playbooks, and continuously improves via a **Human-in-the-Loop Analyst Feedback Agent**.

---

## 🏛 Framework Architecture & Live NXLog Deployment

AdaptiveSentinelGPT supports both real-time live network telemetry collection from remote endpoints via NXLog syslog streaming and synthetic multi-source attack log processing.

```
+-----------------------------------------------------------------------------------+
|                        HARSHA ENDPOINT (10.184.216.159)                           |
|  Windows Event Logs (Security 4624, 4625, 4688, 1102, Sysmon 1, 3, etc.)          |
|                                        ↓                                          |
|                                 NXLog Service                                     |
+----------------------------------------+------------------------------------------+
                                         | TCP 2514 Syslog Stream
                                         v
+-----------------------------------------------------------------------------------+
|                        SUJITH SOC ANALYST LAPTOP (10.184.216.57)                  |
|                                 NXLog Collector                                   |
|                                        ↓                                          |
|                     C:\AdaptiveSentinel\windows-events.log                        |
|                                        ↓                                          |
|                          AdaptiveSentinelGPT Engine                               |
|       - Incremental NXLogReader (data/nxlog_cursor.json persistent tracking)      |
|       - OCSF Schema Normalizer & Category Mapper                                  |
|       - 7 Autonomous AI Agents (Detection, Correlation, Threat Intel, etc.)       |
|       - Heterogeneous Graph Neural Network (GNN Risk Scoring)                     |
|       - SOAR Automated Response Engine (Isolation, Process Termination)           |
|                                        ↓                                          |
|                 Streamlit Command Center (http://localhost:8501)                  |
+-----------------------------------------------------------------------------------+
```

---

## 🤖 Adaptive Multi-Agent Roles

1. **Detection Agent**: Evaluates normalized log streams against MITRE ATT&CK enterprise signatures, statistical thresholds, and anomaly indicators.
2. **Correlation Agent**: Collapses atomic alerts into correlated multi-stage Incident attack chains across hosts, accounts, and temporal windows.
3. **Threat Intelligence Agent**: Enriches incidents with IP reputation scoring, known malicious C2 IOC matching, and threat categories.
4. **Explainability Agent**: Leverages LLM reasoning to produce clear, structured root-cause analysis, key evidence, and attack flow explanations.
5. **Response Planning Agent**: Generates automated SOAR response playbooks across Containment, Eradication, and Recovery phases.
6. **Reporting Agent**: Formats formal SOC Incident Reports structured for technical responders and executive CISO leadership.
7. **Feedback Agent**: Captures Human-in-the-Loop analyst reviews (True Positive / False Positive, severity overrides) and dynamically tunes detection weights in the SQLite Adaptive Knowledge Base.

---

## ⚡ Quick Start Guide

### 1. Prerequisites & Installation
Ensure Python 3.10 or higher is installed on your system.

```bash
git clone https://github.com/sujithkumar3616/AdaptiveSentinelGPT.git
cd AdaptiveSentinelGPT

# Install required dependencies
pip install -r requirements.txt
```

### 2. Live NXLog Networking Setup (Two-Laptop Deployment)
To capture live Windows Security events from remote Windows endpoints:
1. Install **NXLog Community Edition** on the remote Windows endpoint (e.g. Harsha `10.184.216.159`).
2. Configure remote NXLog `nxlog.conf` to stream `im_msvistalog` over TCP port `2514` to Sujith (`10.184.216.57`).
3. Install NXLog on the analyst machine to listen on TCP port `2514` and output to `C:\AdaptiveSentinel\windows-events.log`.

### 3. Generate Live Demo Attack Events
To simulate live attack scenarios into the live NXLog pipeline during demonstrations:

```bash
# Scenario 1: Normal System Activity & Logon
python scripts/generate_demo_events.py --demo 1

# Scenario 2: Failed Logon Attack & Brute Force
python scripts/generate_demo_events.py --demo 2

# Scenario 3: Suspicious Process Execution (Mimikatz / LSASS Dump)
python scripts/generate_demo_events.py --demo 3

# Scenario 4: Critical Defense Evasion (Audit Log Clear - Event ID 1102)
python scripts/generate_demo_events.py --demo 4
```

### 4. Run Main Pipeline via Terminal
Execute the end-to-end multi-agent detection, GNN scoring, and SOAR pipeline:

```bash
python main.py
```

### 5. Launch Interactive SOC Dashboard
Launch the dark-themed Streamlit SOC Command Center:

```bash
streamlit run dashboard/app.py
```

### 6. Run System Benchmarks & Final Evaluation
Execute the quantitative benchmark script to evaluate MTTD, F1-Score, GNN risk scoring, and SOAR execution times:

```bash
python utils/run_final_evaluation.py
```

---

## 📂 Project Structure

```
AdaptiveSentinelGPT/
├── agents/                      # 7 Autonomous AI Security Agents
│   ├── detection_agent.py
│   ├── correlation_agent.py
│   ├── threat_intelligence_agent.py
│   ├── explainability_agent.py
│   ├── response_planning_agent.py
│   ├── reporting_agent.py
│   └── feedback_agent.py
├── analysis/                    # Ingestion & Normalization Layer
│   ├── parser.py                # Incremental NXLogReader & Syslog Parsing
│   ├── normalize.py             # OCSF Normalization
│   ├── deduplicate.py           # Alert Deduplication Engine
│   ├── enrich.py                # Threat Context & GeoIP Enrichment
│   └── graph_visualizer.py      # Network Attack Graph Visualizer
├── config/                      # System Configurations
│   └── settings.py              # NXLog Paths, Network IPs, Thresholds
├── dashboard/                   # Interactive SOC Command Center UI
│   └── app.py                   # 10-Sector Streamlit Dashboard
├── data/                        # Log Storage, Persistent Cursor & Reports
│   ├── nxlog_cursor.json        # Incremental Ingestion Offset Tracker
│   ├── final_evaluation.json    # Evaluation Telemetry Metrics
│   └── FINAL_EVALUATION_REPORT.md
├── models/                      # Schemas & GNN Machine Learning
│   ├── gnn/                     # Heterogeneous GNN Training & Inference
│   └── schemas.py               # Pydantic Schemas
├── scripts/                     # Live Demo Attack Generator
│   └── generate_demo_events.py
├── soar/                        # Automated Incident Response Engine
│   ├── audit_logger.py
│   ├── decision_engine.py
│   └── executor.py
├── tests/                       # Automated Unit & Integration Test Suite
│   ├── test_nxlog_ingestion.py
│   ├── test_analysis.py
│   ├── test_agents.py
│   └── test_kb.py
├── utils/                       # Synthetic Attack Generator & Benchmark Runners
│   ├── generate_logs.py
│   └── run_final_evaluation.py
├── main.py                      # Pipeline Orchestrator
└── requirements.txt             # Python Package Dependencies
```

---

## 📜 Capstone Academic Deliverables

For evaluation panels and Phase 1 review documentation, refer to the detailed markdown files in `docs/`:
- [Project Overview](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Project_Overview.md)
- [System Architecture](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Architecture.md)
- [Multi-Agent Specifications](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Agents.md)
- [Technology Stack & Market Comparison](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Technology_Stack.md)
- [Attack Scenarios & Use Cases](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Use_Case.md)
- [Phase 1 Capstone Review Report](file:///c:/Users/sujit/OneDrive/Desktop/AdaptivesenitalGpt/docs/Phase1_Review_Report.md)
