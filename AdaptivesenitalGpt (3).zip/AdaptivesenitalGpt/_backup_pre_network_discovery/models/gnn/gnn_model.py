import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class GraphConvLayer(nn.Module):
    """
    Message-Passing Graph Convolution layer that aggregates neighborhood node features
    weighted by degree normalization matrix D^{-1/2} A D^{-1/2}.
    """

    def __init__(self, in_features: int, out_features: int):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for message passing aggregation.
        x: [num_nodes, in_features]
        edge_index: [2, num_edges]
        """
        num_nodes = x.size(0)
        out = self.linear(x)

        if edge_index.size(1) == 0:
            return out

        src, dst = edge_index[0], edge_index[1]

        # Compute degree normalization vector
        deg = torch.zeros(num_nodes, device=x.device)
        deg.scatter_add_(0, dst, torch.ones_like(dst, dtype=torch.float))
        deg = torch.clamp(deg, min=1.0)
        norm = 1.0 / torch.sqrt(deg)

        # Message passing aggregation: A_norm * H
        aggregated = torch.zeros_like(out)
        weighted_out = out * norm.unsqueeze(-1)
        aggregated.index_add_(0, dst, weighted_out[src])

        return (out + aggregated) * norm.unsqueeze(-1)


class AdaptiveSentinelGNN(nn.Module):
    """
    Graph Neural Network (GNN / GCN) for Node-Level Security Risk & Anomaly Scoring.
    Contains graph convolution layers, activation, dropout, and a risk scoring head.
    Outputs node-level probability risk scores in [0.0, 1.0].
    """

    def __init__(self, in_channels: int = 5, hidden_channels: int = 16, num_layers: int = 2):
        super().__init__()
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers

        self.conv1 = GraphConvLayer(in_channels, hidden_channels)
        self.conv2 = GraphConvLayer(hidden_channels, hidden_channels)
        self.classifier = nn.Linear(hidden_channels, 1)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Runs GNN forward pass.
        Returns:
            node_embeddings: [num_nodes, hidden_channels]
            node_risk_scores: [num_nodes] in range [0.0, 1.0]
        """
        h = F.relu(self.conv1(x, edge_index))
        h = F.dropout(h, p=0.1, training=self.training)
        h_embed = F.relu(self.conv2(h, edge_index))
        logits = self.classifier(h_embed)
        scores = torch.sigmoid(logits).squeeze(-1)
        return h_embed, scores
