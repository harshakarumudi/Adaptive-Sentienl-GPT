from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class LogEvent(BaseModel):
    timestamp: str
    source: str = "Windows"  # Windows, Linux, Sysmon, Suricata, Zeek
    event_id: int
    hostname: str
    user: Optional[str] = "SYSTEM"
    source_ip: Optional[str] = "127.0.0.1"
    destination_ip: Optional[str] = None
    process_name: Optional[str] = None
    command_line: Optional[str] = None
    message: str


class NormalizedEvent(BaseModel):
    timestamp: str
    source: str
    event_id: int
    event_type: str
    severity: str
    hostname: str
    user: str
    source_ip: str
    destination_ip: Optional[str] = "N/A"
    process_name: Optional[str] = "N/A"
    command_line: Optional[str] = "N/A"
    description: str
    mitre_technique: str
    mitre_tactic: Optional[str] = "Unknown"
    recommendation: Optional[str] = "N/A"
    risk_score: int = 0


class Alert(BaseModel):
    alert_id: str
    alert_name: str
    severity: str
    confidence: int
    mitre_technique: str
    event: Dict[str, Any]


class ThreatIntelData(BaseModel):
    ip: str
    status: str
    reputation: str
    risk_score: int
    threat_category: str
    threat_feed_sources: List[str]


class Incident(BaseModel):
    incident_id: str
    incident_name: str
    severity: str
    confidence: int
    alert_count: int
    affected_host: str
    affected_user: str
    alerts: List[Dict[str, Any]]
    created_at: str


class ResponsePlan(BaseModel):
    incident_id: str
    incident_name: str
    priority: str
    containment_actions: List[str]
    eradication_actions: List[str]
    recovery_actions: List[str]


class SOCReport(BaseModel):
    report_id: str
    incident_id: str
    incident_name: str
    severity: str
    confidence: int
    host: str
    user: str
    source_ip: str
    mitre_technique: str
    mitre_tactic: str
    executive_summary: str
    technical_analysis: str
    threat_intel_status: str
    risk_score: int
    recommended_actions: List[str]
    timestamp: str


class AnalystFeedback(BaseModel):
    feedback_id: str
    incident_id: str
    alert_name: str
    analyst_verdict: str  # 'True Positive', 'False Positive', 'Inconclusive'
    override_severity: Optional[str] = None
    adjusted_confidence: int
    notes: str
    timestamp: str
