import os
import sys
import time
from typing import Dict, Any

# Ensure project root is in sys.path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config.settings import LOG_FILE_PATH
from analysis.parser import parse_log_file
from analysis.normalize import normalize_events
from analysis.deduplicate import deduplicate_events
from analysis.enrich import enrich_events

from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent
from agents.threat_intelligence_agent import ThreatIntelligenceAgent
from agents.explainability_agent import ExplainabilityAgent
from agents.response_planning_agent import ResponsePlanningAgent
from agents.reporting_agent import ReportingAgent
from agents.feedback_agent import FeedbackAgent
from utils.generate_logs import generate_synthetic_attack_logs


def main(include_nxlog: bool = True, nxlog_incremental: bool = False) -> Dict[str, Any]:
    """
    Main Multi-Agent SOC Pipeline Orchestrator with High-Precision Agent Performance Timing.
    """
    total_start_time = time.perf_counter()
    agent_performance = {}

    # 0. NXLog Real Telemetry Network Sync
    t_start = time.perf_counter()
    nxlog_logs = []
    if include_nxlog:
        try:
            from analysis.parser import NXLogReader
            nx_reader = NXLogReader()
            nxlog_logs = nx_reader.read_events(incremental=nxlog_incremental)
        except Exception as e:
            print(f"[!] NXLog ingestion note: {e}")
    t_end = time.perf_counter()
    agent_performance["NXLog Telemetry Sync"] = {
        "agent": "NXLog Network Telemetry Sync",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": f"Ingested {len(nxlog_logs)} live events from C:\\AdaptiveSentinel\\windows-events.log (Harsha -> Sujith TCP 2514)"
    }

    # 1. Ingestion & Parsing
    t_start = time.perf_counter()
    raw_logs = parse_log_file(LOG_FILE_PATH)
    if nxlog_logs:
        raw_logs.extend(nxlog_logs)
    t_end = time.perf_counter()
    agent_performance["Log Ingestion & Parsing"] = {
        "agent": "Ingestion Parser",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": f"Parsed {len(raw_logs)} multi-format JSON/NXLog raw logs into memory"
    }

    # 2. Normalization & Deduplication
    t_start = time.perf_counter()
    normalized = normalize_events(raw_logs)
    deduped = deduplicate_events(normalized)
    enriched = enrich_events(deduped)
    t_end = time.perf_counter()
    agent_performance["Normalization & Deduplication"] = {
        "agent": "Normalization Engine",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Mapped raw events to OCSF schema & deduplicated sliding window"
    }

    # 3. Detection Agent
    t_start = time.perf_counter()
    detection_agent = DetectionAgent()
    alerts = detection_agent.detect(enriched)
    t_end = time.perf_counter()
    agent_performance["Detection Agent"] = {
        "agent": "Detection Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Scanned events against MITRE rules & command-line heuristics"
    }

    # 4. Correlation Agent
    t_start = time.perf_counter()
    correlation_agent = CorrelationAgent()
    incidents = correlation_agent.correlate(alerts)
    t_end = time.perf_counter()
    agent_performance["Correlation Agent"] = {
        "agent": "Correlation Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Grouped atomic alerts into multi-stage attack chains"
    }

    # 5. Threat Intelligence Agent
    t_start = time.perf_counter()
    threat_intel_agent = ThreatIntelligenceAgent()
    incidents = threat_intel_agent.analyze(incidents)
    t_end = time.perf_counter()
    agent_performance["Threat Intelligence Agent"] = {
        "agent": "Threat Intelligence Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Queried SQLite IOC table & assigned IP reputation risk scores"
    }

    # 6. Explainability Agent
    t_start = time.perf_counter()
    explainability_agent = ExplainabilityAgent()
    explanations = explainability_agent.explain(incidents)
    t_end = time.perf_counter()
    agent_performance["Explainability Agent"] = {
        "agent": "Explainability Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Generated plain-English root-cause rationale using LLM reasoning"
    }

    # 7. Response Planning Agent (SOAR Playbooks)
    t_start = time.perf_counter()
    response_agent = ResponsePlanningAgent()
    response_plans = response_agent.plan(incidents)
    t_end = time.perf_counter()
    agent_performance["Response Planning Agent"] = {
        "agent": "Response Planning Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Compiled Containment, Eradication, & Recovery SOAR playbooks"
    }

    # 8. Reporting Agent
    t_start = time.perf_counter()
    reporting_agent = ReportingAgent()
    reports = reporting_agent.generate(incidents)
    t_end = time.perf_counter()
    agent_performance["Reporting Agent"] = {
        "agent": "Reporting Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Formatted Executive & Technical Incident Reports"
    }

    # 9. Feedback Agent
    t_start = time.perf_counter()
    feedback_agent = FeedbackAgent()
    feedback_history = feedback_agent.get_feedback_history()
    t_end = time.perf_counter()
    agent_performance["Feedback Agent"] = {
        "agent": "Feedback Agent",
        "time_ms": round((t_end - t_start) * 1000, 3),
        "task": "Queried & updated Human-in-the-Loop records in SQLite DB"
    }

    total_end_time = time.perf_counter()
    agent_performance["Total Pipeline Execution"] = {
        "agent": "Pipeline Orchestrator",
        "time_ms": round((total_end_time - total_start_time) * 1000, 3),
        "task": "Complete end-to-end multi-agent execution cycle"
    }

    return {
        "logs": enriched,
        "alerts": alerts,
        "incidents": incidents,
        "explanations": explanations,
        "response_plans": response_plans,
        "reports": reports,
        "feedback_history": feedback_history,
        "agent_performance": agent_performance
    }


if __name__ == "__main__":
    res = main()
    print("[+] AdaptiveSentinelGPT Pipeline Executed Successfully!")
    print(f"[+] Total Logs Processed : {len(res['logs'])}")
    print(f"[+] Incidents Correlated : {len(res['incidents'])}")
    print("\n--- Agent Execution Time Breakdown ---")
    for task_name, perf in res["agent_performance"].items():
        print(f" - {perf['agent']:<30}: {perf['time_ms']:>8.3f} ms | Task: {perf['task']}")