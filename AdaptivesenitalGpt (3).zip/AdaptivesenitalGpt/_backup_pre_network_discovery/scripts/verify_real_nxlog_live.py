import sys
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from streamlit.testing.v1 import AppTest

def verify_real_nxlog_live():
    print("\n========================================================")
    print("[*] VERIFYING REAL NXLOG LIVE TELEMETRY & CORRELATION")
    print("========================================================")

    app = AppTest.from_file("dashboard/app.py", default_timeout=30)
    app.run()
    assert not app.exception, f"Initial load exception: {app.exception}"

    print(f"[+] Initial load succeeded without crash.")
    print(f"    Total session live NXLog events: {len(app.session_state.nxlog_live_events)}")
    print(f"    Total session NXLog alerts: {len(app.session_state.nxlog_alerts)}")
    print(f"    Total session NXLog incidents: {len(app.session_state.nxlog_incidents)}")

    # 1. Switch Telemetry Source Filter to REAL NXLOG WINDOWS
    print("\n--- STEP 1: Select 'REAL NXLOG WINDOWS (real_nxlog_windows)' ---")
    select_box = app.sidebar.selectbox[0]
    select_box.select("REAL NXLOG WINDOWS (real_nxlog_windows)")
    app.run()
    assert not app.exception, f"Filter selection exception: {app.exception}"

    # Extract metrics from the top metric cards
    # k1: Total Logs Analyzed, k2: Live NXLog Stream, k3: Correlated Incidents, k4: High/Critical Threats
    k1_val = app.metric[0].value
    k2_val = app.metric[1].value
    k3_val = app.metric[2].value
    k4_val = app.metric[3].value

    print(f"    Top Metric 1 (Total Logs Analyzed): {k1_val}")
    print(f"    Top Metric 2 (Live NXLog Stream): {k2_val}")
    print(f"    Top Metric 3 (Correlated Incidents): {k3_val}")
    print(f"    Top Metric 4 (High/Critical Threats): {k4_val}")

    assert int(k1_val) > 0, "Total Logs Analyzed should be > 0"
    assert int(k2_val) > 0, "Live NXLog Stream should be > 0"
    assert int(k3_val) > 0, f"Correlated Incidents should be > 0, got {k3_val}"
    assert int(k4_val) > 0, f"High/Critical Threats should be > 0, got {k4_val}"
    print("✅ [1/3] Top KPI metrics show real correlated incidents and high/critical threats!")

    # 2. Verify Tab 1 Correlated Incidents display
    print("\n--- STEP 2: Verify Correlated Incidents in Tab 1 ---")
    incidents = app.session_state.nxlog_incidents
    print(f"    Generated {len(incidents)} correlated incident(s) from real NXLog telemetry:")
    for inc in incidents:
        print(f"    🔥 {inc['incident_name']} | Severity: {inc['severity']} | Conf: {inc['confidence']}% | Host: {inc['affected_host']} | Alerts: {inc['alert_count']}")
    
    assert len(incidents) > 0, "Should have correlated incidents"
    has_high_or_crit = any(inc["severity"] in ["High", "Critical"] for inc in incidents)
    assert has_high_or_crit, "Should have High or Critical incident"
    print("✅ [2/3] Correlated incident cards verified with High/Critical severities!")

    # 3. Verify Attack Graph rendering in Sector 7
    print("\n--- STEP 3: Verify Dynamic Attack Graph Rendering ---")
    from analysis.graph_visualizer import generate_attack_graph_figure
    fig = generate_attack_graph_figure(incidents=incidents, logs=app.session_state.nxlog_live_events)
    assert fig is not None, "Attack graph figure should be generated"
    assert len(fig.data) > 0, "Attack graph should have Plotly traces"
    print(f"    Attack graph generated successfully with {len(fig.data)} traces (no scipy error)!")
    print("✅ [3/3] Dynamic attack graph verified without errors!")

    print("\n========================================================")
    print("🎉 ALL REAL NXLOG TELEMETRY & CORRELATION TESTS PASSED!")
    print("========================================================")

if __name__ == "__main__":
    verify_real_nxlog_live()
