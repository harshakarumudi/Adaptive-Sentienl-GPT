import os
import sys
import sqlite3
from pathlib import Path

# Ensure UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from streamlit.testing.v1 import AppTest

project_root = Path(__file__).resolve().parent.parent
db_path = str(project_root / "data" / "soar_audit.db")

print("=== VERIFYING ALL 4 SOAR BUTTONS (Approve, Reject, Simulation, Rollback) ===")
print(f"Resolved DB Absolute Path: {os.path.abspath(db_path)}")

# Reset DB for test
with sqlite3.connect(db_path) as conn:
    conn.execute("DELETE FROM soar_audit_log")
    conn.commit()

# Start App
at = AppTest.from_file(str(project_root / "dashboard" / "app.py"), default_timeout=60)
at.run()

# 1. Test APPROVE
approve_btns = [b for b in at.button if "Approve Action" in b.label]
print(f"\n--- Testing APPROVE ACTION (Key: {approve_btns[0].key}) ---")
approve_btns[0].click().run()

with sqlite3.connect(db_path) as conn:
    count_1 = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
    row_1 = conn.execute("SELECT action_id, analyst_approval, action_status, rollback_status FROM soar_audit_log ORDER BY requested_timestamp DESC LIMIT 1").fetchone()
print(f"Rows in DB: {count_1} | Action: {row_1[0]} | Approval: {row_1[1]} | Status: {row_1[2]}")

metrics_1 = {m.label: m.value for m in at.metric}
print(f"Approved Actions Metric: {metrics_1.get('Approved Actions')}")

# 2. Test REJECT
reject_btns = [b for b in at.button if "Reject Action" in b.label]
print(f"\n--- Testing REJECT ACTION (Key: {reject_btns[0].key}) ---")
reject_btns[0].click().run()

with sqlite3.connect(db_path) as conn:
    count_2 = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
    row_2 = conn.execute("SELECT action_id, analyst_approval, action_status, error_message FROM soar_audit_log ORDER BY requested_timestamp DESC LIMIT 1").fetchone()
print(f"Rows in DB: {count_2} | Action: {row_2[0]} | Approval: {row_2[1]} | Status: {row_2[2]} | Error: {row_2[3]}")

metrics_2 = {m.label: m.value for m in at.metric}
print(f"Failed / Rejected Metric: {metrics_2.get('Failed / Rejected')}")

# 3. Test EXECUTE SIMULATION
sim_btns = [b for b in at.button if "Execute Simulation" in b.label]
print(f"\n--- Testing EXECUTE SIMULATION (Key: {sim_btns[0].key}) ---")
sim_btns[0].click().run()

with sqlite3.connect(db_path) as conn:
    count_3 = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
    row_3 = conn.execute("SELECT action_id, action_status, verification_result, dry_run FROM soar_audit_log ORDER BY requested_timestamp DESC LIMIT 1").fetchone()
print(f"Rows in DB: {count_3} | Action: {row_3[0]} | Status: {row_3[1]} | Verification: {row_3[2]} | DryRun: {row_3[3]}")

metrics_3 = {m.label: m.value for m in at.metric}
print(f"Executed Actions Metric: {metrics_3.get('Executed Actions')}")

# 4. Test TRIGGER ROLLBACK
rb_btns = [b for b in at.button if "Trigger Rollback" in b.label]
print(f"\n--- Testing TRIGGER ROLLBACK (Key: {rb_btns[0].key}) ---")
rb_btns[0].click().run()

with sqlite3.connect(db_path) as conn:
    count_4 = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
    row_4 = conn.execute("SELECT action_id, action_status, rollback_status, dry_run FROM soar_audit_log ORDER BY requested_timestamp DESC LIMIT 1").fetchone()
print(f"Rows in DB: {count_4} | Action: {row_4[0]} | Status: {row_4[1]} | Rollback: {row_4[2]} | DryRun: {row_4[3]}")

metrics_4 = {m.label: m.value for m in at.metric}
print(f"Rollbacks Triggered Metric: {metrics_4.get('Rollbacks Triggered')}")

# Final assertions
assert count_1 == 1, "Approve failed to write exactly 1 row"
assert count_2 == 2, "Reject failed to write exactly 2 rows"
assert count_3 == 3, "Simulation failed to write exactly 3 rows"
assert count_4 == 4, "Rollback failed to write exactly 4 rows"

print("\n=== ALL 4 SOAR BUTTONS TESTED AND VERIFIED END-TO-END! ===")
