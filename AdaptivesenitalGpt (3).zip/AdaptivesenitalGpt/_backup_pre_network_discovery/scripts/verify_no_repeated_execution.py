import sys
from pathlib import Path
from unittest.mock import patch

# Ensure project root in sys.path
project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from streamlit.testing.v1 import AppTest

def verify_no_repeated_execution():
    print("\n========================================================")
    print("[*] VERIFYING IDEMPOTENT EXECUTION & NO REPEATED RUNS")
    print("========================================================")

    # We will patch generate functions and main.main to count calls
    import utils.generate_apt_logs
    import utils.generate_logs
    import main as main_module

    with patch.object(utils.generate_apt_logs, "generate_apt_attack_logs", wraps=utils.generate_apt_logs.generate_apt_attack_logs) as mock_apt_gen, \
         patch.object(utils.generate_logs, "generate_synthetic_attack_logs", wraps=utils.generate_logs.generate_synthetic_attack_logs) as mock_synth_gen, \
         patch.object(main_module, "main", wraps=main_module.main) as mock_main:

        # 1. INITIAL LOAD
        print("\n--- STEP 1: Initial Dashboard Load ---")
        app = AppTest.from_file("dashboard/app.py", default_timeout=30)
        app.run()
        assert not app.exception, f"Initial load exception: {app.exception}"

        print(f"   main() calls: {mock_main.call_count} (Expected: 1)")
        print(f"   APT generator calls: {mock_apt_gen.call_count} (Expected: 0)")
        print(f"   Synthetic generator calls: {mock_synth_gen.call_count} (Expected: 0)")
        assert mock_main.call_count == 1, f"Expected 1 main() call, got {mock_main.call_count}"
        assert mock_apt_gen.call_count == 0, "APT generator should not run on initial load"
        assert mock_synth_gen.call_count == 0, "Synthetic generator should not run on initial load"
        print("✅ [1/5] Initial load executed pipeline once without generating attacks.")

        # 2. SIMULATE 3 CONSECUTIVE RERUNS (Auto-refresh / Tab switches / Expander clicks)
        print("\n--- STEP 2: Consecutive Reruns (Auto-Refresh / Tab Switching Simulation) ---")
        for i in range(3):
            app.run()
            assert not app.exception, f"Rerun {i+1} exception: {app.exception}"

        print(f"   main() calls after 3 reruns: {mock_main.call_count} (Expected: still 1)")
        print(f"   APT generator calls: {mock_apt_gen.call_count} (Expected: still 0)")
        print(f"   Synthetic generator calls: {mock_synth_gen.call_count} (Expected: still 0)")
        assert mock_main.call_count == 1, f"Pipeline re-ran during normal rerun! Count: {mock_main.call_count}"
        assert mock_apt_gen.call_count == 0, "APT generator re-ran during normal rerun!"
        assert mock_synth_gen.call_count == 0, "Synthetic generator re-ran during normal rerun!"
        print("✅ [2/5] Verified: Reruns do NOT re-run pipeline or generators.")

        # 3. CLICK APT ATTACK SCENARIO BUTTON
        print("\n--- STEP 3: Click APT Attack Scenario Button ---")
        apt_btn = next((b for b in app.sidebar.button if "APT Attack Scenario" in b.label), None)
        assert apt_btn is not None, "APT button not found"
        apt_btn.click()
        app.run()
        assert not app.exception, f"APT click exception: {app.exception}"

        print(f"   main() calls after APT click: {mock_main.call_count} (Expected: 2)")
        print(f"   APT generator calls: {mock_apt_gen.call_count} (Expected: 1)")
        assert mock_apt_gen.call_count == 1, f"Expected exactly 1 APT call, got {mock_apt_gen.call_count}"
        assert mock_main.call_count == 2, f"Expected exactly 2 main() calls, got {mock_main.call_count}"

        # Now simulate auto-refresh after APT
        print("   Simulating 2 auto-refreshes after APT scenario...")
        for i in range(2):
            app.run()
            assert not app.exception

        print(f"   main() calls after auto-refreshes: {mock_main.call_count} (Expected: still 2)")
        print(f"   APT generator calls: {mock_apt_gen.call_count} (Expected: still 1)")
        assert mock_main.call_count == 2, "Pipeline re-ran during auto-refresh after APT!"
        assert mock_apt_gen.call_count == 1, "APT generator re-ran during auto-refresh!"
        print("✅ [3/5] Verified: APT generated exactly once; auto-refresh did NOT regenerate.")

        # 4. CLICK SYNTHETIC ATTACK BUTTON
        print("\n--- STEP 4: Click Synthetic Attack Button ---")
        synth_btn = next((b for b in app.sidebar.button if "Synthetic Attack" in b.label), None)
        assert synth_btn is not None, "Synthetic button not found"
        synth_btn.click()
        app.run()
        assert not app.exception, f"Synthetic click exception: {app.exception}"

        print(f"   Synthetic generator calls: {mock_synth_gen.call_count} (Expected: 1)")
        print(f"   APT generator calls: {mock_apt_gen.call_count} (Expected: still 1)")
        print(f"   main() calls: {mock_main.call_count} (Expected: 3)")
        assert mock_synth_gen.call_count == 1, f"Expected 1 Synthetic call, got {mock_synth_gen.call_count}"
        assert mock_apt_gen.call_count == 1, "APT generator should not run on Synthetic click"
        assert mock_main.call_count == 3, f"Expected 3 main() calls, got {mock_main.call_count}"

        # Simulate auto-refresh after Synthetic
        print("   Simulating 2 auto-refreshes after Synthetic scenario...")
        for i in range(2):
            app.run()
            assert not app.exception

        assert mock_synth_gen.call_count == 1, "Synthetic generator re-ran during auto-refresh!"
        assert mock_main.call_count == 3, "Pipeline re-ran during auto-refresh after Synthetic!"
        print("✅ [4/5] Verified: Synthetic generated exactly once; auto-refresh did NOT regenerate.")

        # 5. RESET DASHBOARD TO 0 LOGS
        print("\n--- STEP 5: Click Reset Dashboard to 0 Logs Button ---")
        reset_btn = next((b for b in app.sidebar.button if "Reset Dashboard to 0 Logs" in b.label), None)
        assert reset_btn is not None, "Reset button not found"
        reset_btn.click()
        app.run()
        assert not app.exception, f"Reset click exception: {app.exception}"

        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        live_stream_m = next(m for m in app.metric if "Live NXLog Stream" in m.label)
        incidents_m = next(m for m in app.metric if "Correlated Incidents" in m.label)
        high_crit_m = next(m for m in app.metric if "High/Critical Threats" in m.label)

        print(f"   Total Logs: {total_logs_m.value}")
        print(f"   Live Stream: {live_stream_m.value}")
        print(f"   Incidents: {incidents_m.value}")
        print(f"   High/Critical: {high_crit_m.value}")

        assert int(total_logs_m.value) == 0, f"Expected Total Logs 0, got {total_logs_m.value}"
        assert int(live_stream_m.value) == 0, f"Expected Live Stream 0, got {live_stream_m.value}"
        assert int(incidents_m.value) == 0, f"Expected Incidents 0, got {incidents_m.value}"
        assert int(high_crit_m.value) == 0, f"Expected High/Critical 0, got {high_crit_m.value}"

        # Simulate auto-refresh after reset
        for i in range(2):
            app.run()
            assert not app.exception

        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        assert int(total_logs_m.value) == 0, "Total Logs should remain 0 across auto-refreshes after reset"
        assert mock_apt_gen.call_count == 1, "APT generator should not run after reset"
        assert mock_synth_gen.call_count == 1, "Synthetic generator should not run after reset"

        print("✅ [5/5] Verified: Reset zeroes all metrics; auto-refresh preserves 0 without regenerating.")

    print("\n========================================================")
    print("🎉 ALL IDEMPOTENCE AND NO-REPEATED-EXECUTION TESTS PASSED!")
    print("========================================================")

if __name__ == "__main__":
    verify_no_repeated_execution()
