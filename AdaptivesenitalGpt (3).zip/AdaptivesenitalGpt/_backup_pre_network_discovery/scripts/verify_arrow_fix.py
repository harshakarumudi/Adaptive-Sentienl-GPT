import sys
from pathlib import Path

# Ensure project root in sys.path
sys.path.append(str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from streamlit.testing.v1 import AppTest

def verify_arrow_fix():
    print("\n========================================================")
    print("[*] VERIFYING STREAMLIT ARROW SERIALIZATION & DATAFRAMES")
    print("========================================================")

    app = AppTest.from_file("dashboard/app.py", default_timeout=30)
    app.run()
    assert not app.exception, f"App execution raised exception: {app.exception}"

    print(f"[*] Total dataframes rendered: {len(app.dataframe)}")
    for idx, df_comp in enumerate(app.dataframe):
        # Extract the underlying pandas DataFrame from the component
        df = df_comp.value
        if "Event ID" in df.columns:
            # Verify Event ID is purely string typed
            types = set(type(x) for x in df["Event ID"])
            print(f"   [+] Dataframe #{idx} has 'Event ID' column. Value types: {types}")
            assert all(isinstance(x, str) for x in df["Event ID"]), f"Mixed types in Event ID: {types}"

    # Verify expanding incident details in Sector 1
    apt_btn = next((b for b in app.sidebar.button if "APT Attack Scenario" in b.label), None)
    if apt_btn:
        apt_btn.click()
        app.run()
        assert not app.exception, f"APT scenario exception: {app.exception}"
        print(f"[*] Dataframes after APT run: {len(app.dataframe)}")
        for idx, df_comp in enumerate(app.dataframe):
            df = df_comp.value
            if "Event ID" in df.columns:
                types = set(type(x) for x in df["Event ID"])
                print(f"   [+] Dataframe #{idx} after APT run has 'Event ID'. Value types: {types}")
                assert all(isinstance(x, str) for x in df["Event ID"]), f"Mixed types in Event ID: {types}"

    print("\n[SUCCESS] No ArrowTypeError encountered across any rendered dataframes!")

if __name__ == "__main__":
    verify_arrow_fix()
