import sys
import os
from pathlib import Path
import json

# Ensure project root in sys.path
sys.path.append(str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from streamlit.testing.v1 import AppTest
from analysis.parser import NXLogReader
from config.settings import LOG_FILE_PATH, NXLOG_FILE_PATH

def test_scenario_metrics_and_reset():
    print("\n========================================================")
    print("[*] AUTOMATED VERIFICATION: SCENARIO METRICS & RESET TO 0")
    print("========================================================")

    # Backup current raw logs to restore after test
    raw_backup = []
    if LOG_FILE_PATH.exists():
        with open(LOG_FILE_PATH, "r", encoding="utf-8") as f:
            try:
                raw_backup = json.load(f)
            except Exception:
                raw_backup = []

    try:
        app = AppTest.from_file("dashboard/app.py", default_timeout=30)
        app.run()
        assert not app.exception, f"Initial run exception: {app.exception}"
        print("✅ [1/5] Initial dashboard load successful.")

        # --- STEP 1: Test APT Attack Scenario ---
        print("\n--- Testing APT Attack Scenario Button ---")
        apt_btn = next((b for b in app.sidebar.button if "APT Attack Scenario" in b.label), None)
        assert apt_btn is not None, "APT button not found in sidebar"
        apt_btn.click()
        app.run()
        assert not app.exception, f"APT run exception: {app.exception}"

        # Find metrics
        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        live_stream_m = next(m for m in app.metric if "Live NXLog Stream" in m.label)
        incidents_m = next(m for m in app.metric if "Correlated Incidents" in m.label)
        high_crit_m = next(m for m in app.metric if "High/Critical Threats" in m.label)

        apt_total = int(total_logs_m.value)
        apt_incidents = int(incidents_m.value)
        apt_high_crit = int(high_crit_m.value)

        print(f"   APT Total Logs Analyzed: {apt_total}")
        print(f"   APT Correlated Incidents: {apt_incidents}")
        print(f"   APT High/Critical Threats: {apt_high_crit}")
        print(f"   APT Live NXLog Stream: {live_stream_m.value}")

        assert apt_total > 0, f"Expected APT logs > 0, got {apt_total}"
        assert apt_incidents > 0, f"Expected APT incidents > 0, got {apt_incidents}"
        print("✅ [2/5] APT Scenario successfully isolated with positive metrics.")

        # --- STEP 2: Test Synthetic Attack Scenario Isolation ---
        print("\n--- Testing Synthetic Attack Scenario Isolation ---")
        synth_btn = next((b for b in app.sidebar.button if "Synthetic Attack" in b.label), None)
        assert synth_btn is not None, "Synthetic button not found in sidebar"
        synth_btn.click()
        app.run()
        assert not app.exception, f"Synthetic run exception: {app.exception}"

        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        incidents_m = next(m for m in app.metric if "Correlated Incidents" in m.label)
        synth_total = int(total_logs_m.value)
        synth_incidents = int(incidents_m.value)

        print(f"   Synthetic Total Logs Analyzed: {synth_total}")
        print(f"   Synthetic Correlated Incidents: {synth_incidents}")

        # Verification: Scenarios must NOT bleed into each other
        assert synth_total != apt_total + synth_total, "Metrics should not accumulate across scenarios!"
        assert synth_total > 0, f"Expected Synthetic logs > 0, got {synth_total}"
        print("✅ [3/5] Scenario isolation verified: Synthetic metrics did NOT accumulate APT logs.")

        # --- STEP 3: Test Reset Dashboard to 0 Logs ---
        print("\n--- Testing Reset Dashboard to 0 Logs Button ---")
        reset_btn = next((b for b in app.sidebar.button if "Reset Dashboard to 0 Logs" in b.label), None)
        assert reset_btn is not None, "Reset button not found in sidebar"
        reset_btn.click()
        app.run()
        assert not app.exception, f"Reset run exception: {app.exception}"

        # Re-fetch metric cards
        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        live_stream_m = next(m for m in app.metric if "Live NXLog Stream" in m.label)
        incidents_m = next(m for m in app.metric if "Correlated Incidents" in m.label)
        high_crit_m = next(m for m in app.metric if "High/Critical Threats" in m.label)

        reset_total = int(total_logs_m.value)
        reset_live = int(live_stream_m.value)
        reset_incidents = int(incidents_m.value)
        reset_high_crit = int(high_crit_m.value)

        print(f"   Reset Total Logs Analyzed: {reset_total}")
        print(f"   Reset Live NXLog Stream: {reset_live}")
        print(f"   Reset Correlated Incidents: {reset_incidents}")
        print(f"   Reset High/Critical Threats: {reset_high_crit}")

        assert reset_total == 0, f"Expected Total Logs 0, got {reset_total}"
        assert reset_live == 0, f"Expected Live Stream 0, got {reset_live}"
        assert reset_incidents == 0, f"Expected Incidents 0, got {reset_incidents}"
        assert reset_high_crit == 0, f"Expected High/Critical 0, got {reset_high_crit}"

        # Check severity breakdown text in app markdown and caption
        full_md = " ".join(m.value for m in app.markdown)
        full_cap = " ".join(c.value for c in app.caption)
        assert "LOW SEVERITY" in full_md and "MEDIUM SEVERITY" in full_md and "HIGH SEVERITY" in full_md and "CRITICAL SEVERITY" in full_md
        assert "Severity Classified Total: 0 / 0 logs (100% accounted)" in full_cap or "0 / 0 logs" in full_cap
        print("   Severity Breakdown: Low: 0, Medium: 0, High: 0, Critical: 0 (100% accounted)")
        print("✅ [4/5] Full Reset to 0 Logs verified across all KPI metrics and severity counts.")

        # --- STEP 4: Test NXLog Live Stream Incremental Counter from Reset Baseline ---
        print("\n--- Testing NXLog Live Stream Incremental Ingestion from Baseline ---")
        # Ingest 1 simulated live event into session state via sync
        app.session_state.nxlog_live_events.append({
            "timestamp": "2026-10-06T01:45:00Z",
            "source": "real_nxlog_windows",
            "event_id": 4624,
            "event_type": "Successful Authentication",
            "severity": "Low",
            "hostname": "Harsha",
            "user": "harsha_admin",
            "source_ip": "10.184.216.159",
            "destination_ip": "10.184.216.57",
            "process_name": "explorer.exe",
            "description": "Live incremental test event over TCP 2514"
        })
        app.run()
        assert not app.exception, f"Incremental NXLog run exception: {app.exception}"

        live_stream_m = next(m for m in app.metric if "Live NXLog Stream" in m.label)
        print(f"   Live NXLog Stream after 1 arriving event: {live_stream_m.value}")
        assert int(live_stream_m.value) == 1, f"Expected Live NXLog Stream to be 1, got {live_stream_m.value}"

        total_logs_m = next(m for m in app.metric if "Total Logs Analyzed" in m.label)
        print(f"   Total Logs Analyzed in reset state: {total_logs_m.value}")
        print("✅ [5/5] Incremental Live NXLog Stream baseline tracking verified.")

        print("\n========================================================")
        print("🎉 ALL 5 VERIFICATION SUITES PASSED SUCCESSFULLY!")
        print("========================================================")

    finally:
        # Restore raw logs
        with open(LOG_FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(raw_backup, f, indent=2)

if __name__ == "__main__":
    test_scenario_metrics_and_reset()
