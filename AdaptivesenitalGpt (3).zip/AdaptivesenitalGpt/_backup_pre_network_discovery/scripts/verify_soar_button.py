import os
import sys
import sqlite3
from pathlib import Path

# Ensure UTF-8 output on Windows
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from streamlit.testing.v1 import AppTest

project_root = Path(__file__).resolve().parent.parent
db_path = str(project_root / "data" / "soar_audit.db")

print("=== SOAR BUTTON EXECUTION PATH VERIFICATION ===")
print(f"Resolved DB Absolute Path: {os.path.abspath(db_path)}")

# 1. Check Row Count Before
with sqlite3.connect(db_path) as conn:
    count_before = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
print(f"Before Test - Rows in soar_audit_log: {count_before}")

# 2. Initialize and Run App via Streamlit AppTest framework
print("\n[Step 1] Initializing Streamlit AppTest with dashboard/app.py...")
at = AppTest.from_file(str(project_root / "dashboard" / "app.py"), default_timeout=60)
at.run()

if at.exception:
    print("ERROR: App encountered exception on startup:")
    for exc in at.exception:
        print(exc.value)
    sys.exit(1)

print(f"[Step 2] App loaded successfully. Total buttons detected: {len(at.button)}")

# 3. Locate the 'Approve Action' button
approve_buttons = [b for b in at.button if "Approve Action" in b.label]
print(f"Found {len(approve_buttons)} 'Approve Action' button(s).")
if not approve_buttons:
    print("ERROR: No 'Approve Action' buttons found!")
    sys.exit(1)

target_btn = approve_buttons[0]
print(f"Target Button Key: {target_btn.key}")

# 4. Click the 'Approve Action' button
print("\n[Step 3] Simulating user click on 'Approve Action' button...")
target_btn.click().run()

if at.exception:
    print("ERROR: App encountered exception after click:")
    for exc in at.exception:
        print(exc.value)
    sys.exit(1)

# 5. Check Row Count After
with sqlite3.connect(db_path) as conn:
    count_after = conn.execute("SELECT COUNT(*) FROM soar_audit_log").fetchone()[0]
print(f"\n[Step 4] Database Verification:")
print(f"Before Test Count : {count_before}")
print(f"After Test Count  : {count_after}")
print(f"Row Delta         : +{count_after - count_before}")

# 6. Fetch the Latest Record
with sqlite3.connect(db_path) as conn:
    conn.row_factory = sqlite3.Row
    row = conn.execute("""
        SELECT
            audit_id,
            incident_id,
            action_id,
            analyst_approval,
            analyst_user,
            target,
            action_status,
            dry_run,
            requested_timestamp
        FROM soar_audit_log
        ORDER BY requested_timestamp DESC
        LIMIT 1
    """).fetchone()

if row:
    print("\n[Step 5] Latest Persisted Audit Log Row:")
    for k in row.keys():
        print(f"  {k:<20}: {row[k]}")

# 7. Check Streamlit UI Metrics & Alerts
print("\n[Step 6] UI State Verification:")
metrics_dict = {m.label: m.value for m in at.metric}
print(f"Approved Actions KPI Metric : {metrics_dict.get('Approved Actions', 'NOT_FOUND')}")

success_alerts = [s.value for s in at.success]
print(f"Success Alerts on Screen    : {success_alerts}")

assert count_after == count_before + 1, "Count did not increase by 1!"
assert row["analyst_approval"] == "APPROVED", "analyst_approval is not APPROVED!"
assert row["action_status"] == "APPROVED", "action_status is not APPROVED!"
print("\n=== EMPIRICAL TEST RESULT: 100% SUCCESSFUL ===")
