r"""
AdaptiveSentinelGPT — Demonstration Event Generator Script
Use this script during live presentations to generate test events into C:\AdaptiveSentinel\windows-events.log
and demonstrate the end-to-end detection, correlation, and SOAR lifecycle.
"""

import sys
import json
import argparse
from datetime import datetime, timezone
from pathlib import Path

NXLOG_FILE_PATH = Path("C:/AdaptiveSentinel/windows-events.log")

DEMO_SCENARIOS = {
    "1": {
        "name": "Normal Application Event",
        "event_id": 1000,
        "event_type": "Application Informational",
        "severity": "Low",
        "hostname": "Harsha",
        "user": "HarshaUser",
        "source_ip": "10.184.216.159",
        "destination_ip": "10.184.216.57",
        "process_name": "explorer.exe",
        "command_line": "explorer.exe",
        "description": "NXLog DEMO 1: Normal user activity event from Harsha Windows 11 endpoint."
    },
    "2": {
        "name": "Failed Authentication Attempt (Brute Force Indicator)",
        "event_id": 4625,
        "event_type": "Failed Authentication",
        "severity": "Medium",
        "hostname": "Harsha",
        "user": "Administrator",
        "source_ip": "10.184.216.159",
        "destination_ip": "10.184.216.57",
        "process_name": "winlogon.exe",
        "command_line": "N/A",
        "description": "NXLog DEMO 2: Failed logon attempt for user Administrator from Harsha Windows endpoint."
    },
    "3": {
        "name": "Suspicious Process Creation (Mimikatz Execution)",
        "event_id": 4688,
        "event_type": "Windows Process Creation",
        "severity": "High",
        "hostname": "Harsha",
        "user": "SYSTEM",
        "source_ip": "10.184.216.159",
        "destination_ip": "10.184.216.57",
        "process_name": "mimikatz.exe",
        "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords exit",
        "description": "NXLog DEMO 3: Suspicious process mimikatz.exe spawned on Harsha Windows endpoint."
    },
    "4": {
        "name": "Audit Log Clearance (Indicator Removal - T1070)",
        "event_id": 1102,
        "event_type": "Audit Log Cleared",
        "severity": "Critical",
        "hostname": "Harsha",
        "user": "HarshaAdmin",
        "source_ip": "10.184.216.159",
        "destination_ip": "10.184.216.57",
        "process_name": "wevtutil.exe",
        "command_line": "wevtutil.exe cl Security",
        "description": "NXLog DEMO 4: Security audit log cleared by HarshaAdmin on Harsha Windows endpoint."
    }
}


def append_demo_event(scenario_key: str):
    scenario = DEMO_SCENARIOS.get(scenario_key)
    if not scenario:
        print(f"[!] Invalid scenario key: '{scenario_key}'. Choose 1, 2, 3, or 4.")
        return

    payload = {
        "EventTime": datetime.now(timezone.utc).isoformat(),
        "EventID": scenario["event_id"],
        "event_type": scenario["event_type"],
        "severity": scenario["severity"],
        "Hostname": scenario["hostname"],
        "TargetUserName": scenario["user"],
        "IpAddress": scenario["source_ip"],
        "destination_ip": scenario["destination_ip"],
        "NewProcessName": scenario["process_name"],
        "CommandLine": scenario["command_line"],
        "Message": scenario["description"]
    }

    try:
        NXLOG_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(NXLOG_FILE_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload) + "\n")
        print(f"[+] Successfully appended DEMO #{scenario_key} ({scenario['name']}) to {NXLOG_FILE_PATH}")
    except Exception as e:
        print(f"[!] Failed to append demo event: {e}")


def main():
    parser = argparse.ArgumentParser(description="AdaptiveSentinelGPT Demonstration Event Generator")
    parser.add_argument("--demo", choices=["1", "2", "3", "4", "all"], default="1", help="Demo scenario to generate")
    args = parser.parse_args()

    if args.demo == "all":
        for k in ["1", "2", "3", "4"]:
            append_demo_event(k)
    else:
        append_demo_event(args.demo)


if __name__ == "__main__":
    main()
