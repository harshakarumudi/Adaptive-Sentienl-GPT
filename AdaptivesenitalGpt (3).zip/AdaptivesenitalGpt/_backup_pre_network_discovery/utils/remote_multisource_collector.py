import socket
import json
import time
from datetime import datetime


def generate_and_send_all_7_log_types(soc_server_ip: str, port: int = 5000):
    """
    RUN THIS SCRIPT ON LAPTOP A (THE SECOND LAPTOP).
    Generates & transmits ALL 7 log types from the architecture diagram:
    1. Windows Logs
    2. Linux Logs
    3. Sysmon Logs
    4. Suricata NIDS Logs
    5. Zeek Network Logs
    6. Threat Feeds
    7. Cloud Logs (AWS/Azure)
    """
    hostname = socket.gethostname()
    laptop_a_ip = socket.gethostbyname(hostname)

    print("==================================================================")
    print("🌐 Multi-Source Log Generator & Transmitter (Laptop A -> Laptop B)")
    print(f"💻 Remote Host: {hostname} ({laptop_a_ip})")
    print(f"🎯 Target SOC Server IP: {soc_server_ip}:{port}")
    print("==================================================================")

    now = datetime.now().isoformat()

    all_7_logs = [
        # 1. Windows Logs
        {
            "timestamp": now,
            "source": "Windows Security",
            "event_id": 4624,
            "hostname": f"REMOTE-{hostname}",
            "user": "corp\\jdoe",
            "source_ip": laptop_a_ip,
            "destination_ip": soc_server_ip,
            "process_name": "svchost.exe",
            "command_line": "C:\\Windows\\System32\\svchost.exe -k netsvcs",
            "message": "1. Windows Log: Successful domain user logon."
        },
        # 2. Linux Logs
        {
            "timestamp": now,
            "source": "Linux Auth",
            "event_id": 1001,
            "hostname": f"REMOTE-LINUX-{hostname}",
            "user": "root",
            "source_ip": "45.33.32.156",
            "destination_ip": laptop_a_ip,
            "process_name": "sshd",
            "command_line": "N/A",
            "message": "2. Linux Log: Failed SSH password attempt for user root from 45.33.32.156."
        },
        # 3. Sysmon Logs
        {
            "timestamp": now,
            "source": "Sysmon",
            "event_id": 10,
            "hostname": f"REMOTE-{hostname}",
            "user": "corp\\jdoe",
            "source_ip": laptop_a_ip,
            "destination_ip": "N/A",
            "process_name": "mimikatz.exe",
            "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords exit",
            "message": "3. Sysmon Log: LSASS process memory dump for credential theft."
        },
        # 4. Suricata Logs
        {
            "timestamp": now,
            "source": "Suricata IDS",
            "event_id": 2000001,
            "hostname": f"REMOTE-{hostname}",
            "user": "corp\\Administrator",
            "source_ip": laptop_a_ip,
            "destination_ip": "10.0.0.1",
            "process_name": "wmic.exe",
            "command_line": "wmic.exe /node:10.0.0.1 process call create 'powershell.exe ...'",
            "message": "4. Suricata IDS Alert: Remote WMI Lateral Movement detected."
        },
        # 5. Zeek Logs
        {
            "timestamp": now,
            "source": "Zeek Network",
            "event_id": 3000001,
            "hostname": f"REMOTE-{hostname}",
            "user": "N/A",
            "source_ip": laptop_a_ip,
            "destination_ip": "185.220.101.5",
            "process_name": "zeek_conn",
            "command_line": "N/A",
            "message": "5. Zeek Network Log: High-frequency outbound TCP connection to unverified IP."
        },
        # 6. Threat Feeds
        {
            "timestamp": now,
            "source": "Threat Feeds",
            "event_id": 4000001,
            "hostname": f"REMOTE-{hostname}",
            "user": "N/A",
            "source_ip": "185.220.101.5",
            "destination_ip": laptop_a_ip,
            "process_name": "threat_feed_sync",
            "command_line": "N/A",
            "message": "6. Threat Intelligence Feed: IP 185.220.101.5 flagged as active C2 server (Risk Score: 95/100)."
        },
        # 7. Cloud Logs
        {
            "timestamp": now,
            "source": "Cloud AWS",
            "event_id": 5000001,
            "hostname": "AWS-CLOUD-TENANT",
            "user": "aws_admin_user",
            "source_ip": laptop_a_ip,
            "destination_ip": "172.31.0.1",
            "process_name": "aws_cli",
            "command_line": "aws iam create-access-key --user-name admin",
            "message": "7. Cloud Log: AWS CloudTrail CreateAccessKey IAM privilege escalation."
        }
    ]

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    payload_bytes = json.dumps(all_7_logs).encode('utf-8')
    sock.sendto(payload_bytes, (soc_server_ip, port))

    print(f"✅ Transmitted ALL 7 Log Types from {hostname} to SOC Server at {soc_server_ip}:{port}!")
    print(f"📊 Transmitted Log Sources: Windows, Linux, Sysmon, Suricata, Zeek, Threat Feeds, Cloud Logs.")


if __name__ == "__main__":
    ip_target = input("\n👉 Enter your laptop's (Laptop B) local IP address (e.g. 192.168.1.50): ").strip()
    if not ip_target:
        ip_target = "127.0.0.1"
    generate_and_send_all_7_log_types(ip_target)
