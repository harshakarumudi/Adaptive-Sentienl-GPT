import socket
import json
import sys
import os
import hashlib
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

# Add project root to path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import config.settings as settings

LOG_FILE_PATH = getattr(settings, "LOG_FILE_PATH", Path(project_root) / "data" / "raw_logs" / "windows_logs.json")
RAW_LOGS_DIR = getattr(settings, "RAW_LOGS_DIR", Path(project_root) / "data" / "raw_logs")
RECEIVER_HOST = getattr(settings, "RECEIVER_HOST", "0.0.0.0")
RECEIVER_PORT = getattr(settings, "RECEIVER_PORT", 5000)
DEFAULT_ENDPOINT_ID = getattr(settings, "DEFAULT_ENDPOINT_ID", "EP-REMOTE-01")
COLLECTOR_VERSION = getattr(settings, "COLLECTOR_VERSION", "1.0.0")
PROJECT_TOKEN = getattr(settings, "PROJECT_TOKEN", "SENTINEL_SECRET_TOKEN_2026")
ENDPOINT_STATUS_FILE_PATH = getattr(settings, "ENDPOINT_STATUS_FILE_PATH", Path(project_root) / "data" / "endpoint_status.json")
HEARTBEAT_TIMEOUT_SECONDS = getattr(settings, "HEARTBEAT_TIMEOUT_SECONDS", 30)


class EndpointTracker:
    """
    Tracks remote Windows endpoint connections, heartbeats, and telemetry statistics.
    Persists state to endpoint_status.json for dashboard visibility.
    """

    def __init__(self, status_file=ENDPOINT_STATUS_FILE_PATH, timeout_seconds=HEARTBEAT_TIMEOUT_SECONDS):
        self.status_file = Path(status_file)
        self.timeout_seconds = timeout_seconds
        self.endpoints: Dict[str, Dict[str, Any]] = {}
        self.load_status()

    def load_status(self):
        if self.status_file.exists():
            try:
                with open(self.status_file, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        data = json.loads(content)
                        if isinstance(data, dict):
                            self.endpoints = data
            except Exception:
                self.endpoints = {}

    def save_status(self):
        try:
            self.status_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.status_file, "w", encoding="utf-8") as f:
                json.dump(self.endpoints, f, indent=2)
        except Exception as e:
            print(f"[!] Failed to save endpoint status: {e}")

    def record_packet(
        self,
        endpoint_id: str,
        hostname: str,
        source_ip: str,
        event_count: int = 0,
        is_malformed: bool = False,
        is_error: bool = False,
        collector_version: str = COLLECTOR_VERSION,
        transport: str = "udp"
    ):
        now_iso = datetime.now().isoformat()
        ep_key = endpoint_id or f"EP-{source_ip.replace('.', '_')}"

        if ep_key not in self.endpoints:
            self.endpoints[ep_key] = {
                "endpoint_id": ep_key,
                "hostname": hostname or f"HOST-{source_ip}",
                "source_ip": source_ip,
                "status": "connected",
                "last_seen": now_iso,
                "events_received": 0,
                "packets_received": 0,
                "malformed_events": 0,
                "connection_errors": 0,
                "collector_version": collector_version,
                "transport": transport
            }

        ep = self.endpoints[ep_key]
        ep["status"] = "connected"
        ep["last_seen"] = now_iso
        if hostname:
            ep["hostname"] = hostname
        if source_ip:
            ep["source_ip"] = source_ip
        if collector_version:
            ep["collector_version"] = collector_version
        ep["transport"] = transport
        ep["packets_received"] += 1

        if is_malformed:
            ep["malformed_events"] += 1
        if is_error:
            ep["connection_errors"] += 1
        if event_count > 0:
            ep["events_received"] += event_count

        self.save_status()

    def get_statuses(self) -> List[Dict[str, Any]]:
        self.load_status()
        now = datetime.now()
        result = []
        for ep_key, ep in self.endpoints.items():
            ep_copy = ep.copy()
            last_seen_str = ep_copy.get("last_seen")
            if last_seen_str:
                try:
                    last_seen_dt = datetime.fromisoformat(last_seen_str)
                    if (now - last_seen_dt).total_seconds() > self.timeout_seconds:
                        ep_copy["status"] = "disconnected"
                except Exception:
                    pass
            result.append(ep_copy)
        return result


def compute_event_fingerprint(evt: dict) -> str:
    """Computes a SHA-256 fingerprint for deduplication."""
    raw_str = (
        f"{evt.get('timestamp')}_"
        f"{evt.get('hostname')}_"
        f"{evt.get('event_id')}_"
        f"{evt.get('message')}_"
        f"{evt.get('command_line')}"
    )
    return hashlib.sha256(raw_str.encode('utf-8')).hexdigest()


def process_incoming_packet(
    data_bytes: bytes,
    addr: tuple,
    tracker: Optional[EndpointTracker] = None,
    project_token: str = PROJECT_TOKEN,
    log_file_path: Path = LOG_FILE_PATH
) -> Dict[str, Any]:
    """
    Validates, fingerprints, enriches, and ingests incoming UDP log packets.
    Rejects malformed JSON and duplicates safely while tracking endpoint metrics.
    """
    if tracker is None:
        tracker = EndpointTracker()

    source_ip = addr[0] if (addr and len(addr) > 0) else "127.0.0.1"
    now_iso = datetime.now().isoformat()

    # 1. Parse JSON safely
    try:
        raw_text = data_bytes.decode('utf-8', errors='ignore')
        payload = json.loads(raw_text)
    except Exception as e:
        ep_id = f"EP-{source_ip.replace('.', '_')}"
        tracker.record_packet(ep_id, f"HOST-{source_ip}", source_ip, is_malformed=True, is_error=True)
        return {"success": False, "reason": f"Invalid JSON format: {e}", "events_added": 0}

    # 2. Validate payload structure
    if not isinstance(payload, (dict, list)):
        ep_id = f"EP-{source_ip.replace('.', '_')}"
        tracker.record_packet(ep_id, f"HOST-{source_ip}", source_ip, is_malformed=True)
        return {"success": False, "reason": "Payload must be JSON object or array", "events_added": 0}

    raw_events = payload if isinstance(payload, list) else [payload]

    if not raw_events:
        ep_id = f"EP-{source_ip.replace('.', '_')}"
        tracker.record_packet(ep_id, f"HOST-{source_ip}", source_ip, is_malformed=True)
        return {"success": False, "reason": "Empty event payload", "events_added": 0}

    # 3. Optional Authentication / Project Token Validation
    for evt in raw_events:
        if isinstance(evt, dict) and "project_token" in evt:
            if evt["project_token"] != project_token:
                ep_id = evt.get("endpoint_id") or f"EP-{source_ip.replace('.', '_')}"
                tracker.record_packet(ep_id, evt.get("hostname", source_ip), source_ip, is_error=True)
                return {"success": False, "reason": "Unauthorized project token", "events_added": 0}

    # 4. Load existing logs & fingerprints to prevent duplicate writes
    existing_logs = []
    seen_fingerprints = set()
    if log_file_path.exists():
        try:
            with open(log_file_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    existing_logs = json.loads(content)
                    if isinstance(existing_logs, list):
                        for e in existing_logs:
                            if isinstance(e, dict):
                                fp = e.get("fingerprint") or compute_event_fingerprint(e)
                                seen_fingerprints.add(fp)
        except Exception:
            existing_logs = []

    valid_events_to_add = []
    malformed_count = 0
    ep_id = None
    ep_hostname = None
    collector_ver = COLLECTOR_VERSION

    for raw_evt in raw_events:
        if not isinstance(raw_evt, dict):
            malformed_count += 1
            continue

        # Extract hostname & endpoint ID
        hostname = raw_evt.get("hostname") or f"REMOTE-{source_ip}"
        ep_id = raw_evt.get("endpoint_id") or f"EP-{hostname.upper().replace(' ', '_')}"
        ep_hostname = hostname
        collector_ver = raw_evt.get("collector_version") or COLLECTOR_VERSION
        evt_timestamp = raw_evt.get("timestamp") or now_iso

        fp = compute_event_fingerprint(raw_evt)
        if fp in seen_fingerprints:
            # Duplicate event fingerprint - skip writing but allow packet tracking
            continue

        seen_fingerprints.add(fp)

        # Build enriched remote event structure
        enriched_remote_event = {
            "timestamp": evt_timestamp,
            "source": "remote_windows",
            "event_id": raw_evt.get("event_id", 4624),
            "hostname": hostname,
            "user": raw_evt.get("user", "SYSTEM"),
            "source_ip": raw_evt.get("source_ip", source_ip),
            "destination_ip": raw_evt.get("destination_ip", "127.0.0.1"),
            "process_name": raw_evt.get("process_name", "svchost.exe"),
            "command_line": raw_evt.get("command_line", "N/A"),
            "message": raw_evt.get("message", "Remote Windows Security Event"),
            "endpoint_id": ep_id,
            "collector_version": collector_ver,
            "event_timestamp": evt_timestamp,
            "received_timestamp": now_iso,
            "transport": "udp",
            "fingerprint": fp,
            "raw_event": raw_evt.copy()
        }

        valid_events_to_add.append(enriched_remote_event)

    if not ep_id:
        ep_id = f"EP-{source_ip.replace('.', '_')}"
        ep_hostname = f"HOST-{source_ip}"

    # 5. Record packet statistics in endpoint tracker
    tracker.record_packet(
        endpoint_id=ep_id,
        hostname=ep_hostname,
        source_ip=source_ip,
        event_count=len(valid_events_to_add),
        is_malformed=(malformed_count > 0),
        collector_version=collector_ver,
        transport="udp"
    )

    # 6. Save newly ingested remote events to windows_logs.json
    if valid_events_to_add:
        existing_logs.extend(valid_events_to_add)
        log_file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_file_path, "w", encoding="utf-8") as f:
            json.dump(existing_logs, f, indent=2)

    return {
        "success": True,
        "events_added": len(valid_events_to_add),
        "malformed": malformed_count,
        "endpoint_id": ep_id
    }


def start_network_log_server(host: str = RECEIVER_HOST, port: int = RECEIVER_PORT):
    """
    Listens for incoming remote Windows security log UDP packets.
    Performs validation, fingerprinting, metadata enrichment, and endpoint status tracking.
    """
    tracker = EndpointTracker()

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    except Exception:
        pass

    try:
        server_socket.bind((host, port))
    except Exception as e:
        print(f"[!] Port {port} is busy ({e}). Attempting socket reuse...")
        server_socket.close()
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        except Exception:
            pass
        server_socket.bind((host, port))

    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    print("============================================================")
    print(f"[+] AdaptiveSentinelGPT Remote Log Receiver Active!")
    print(f"[+] Listening on Host: {host} | Port: {port} (Transport: UDP)")
    print(f"[+] Endpoint Status Tracking -> {ENDPOINT_STATUS_FILE_PATH}")
    print("============================================================")

    while True:
        try:
            data, addr = server_socket.recvfrom(65535)
            result = process_incoming_packet(data, addr, tracker=tracker)
            if result["success"]:
                print(f"[+] [{addr[0]}:{addr[1]}] Ingested {result['events_added']} valid remote event(s) for Endpoint '{result['endpoint_id']}'.")
            else:
                print(f"[!] [{addr[0]}:{addr[1]}] Rejected packet: {result['reason']}")

        except KeyboardInterrupt:
            print("\n[!] Shutting down Remote Log Receiver Server.")
            break
        except Exception as e:
            print(f"[!] Error processing UDP packet: {e}")


if __name__ == "__main__":
    start_network_log_server()
