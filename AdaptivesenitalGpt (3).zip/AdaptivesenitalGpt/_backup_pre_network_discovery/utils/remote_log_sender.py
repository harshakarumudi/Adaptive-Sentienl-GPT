import socket
import json
import time
from datetime import datetime


def send_remote_logs(server_ip: str, port: int = 5000):
    """
    Run this script on Laptop A (the remote machine / victim laptop).
    Sends Windows / Sysmon / Attack logs over the local Wi-Fi/LAN network
    to Laptop B (running AdaptiveSentinelGPT SOC Server).
    """
    print(f"============================================================")
    print(f"📡 Remote Log Sender (Laptop A -> Laptop B SOC Server)")
    print(f"🎯 Target SOC Server IP: {server_ip} | Port: {port}")
    print(f"============================================================")

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # Sample Remote Security Attack Logs generated on Laptop A
    remote_attack_events = [
        {
            "timestamp": datetime.now().isoformat(),
            "source": "Windows Security",
            "event_id": 4625,
            "hostname": "REMOTE-LAPTOP-A",
            "user": "Administrator",
            "source_ip": "192.168.1.105",
            "destination_ip": "192.168.1.50",
            "process_name": "sshd",
            "command_line": "N/A",
            "message": "Remote Laptop A: Failed Logon Attempt detected for user Administrator (Brute Force)."
        },
        {
            "timestamp": datetime.now().isoformat(),
            "source": "Sysmon",
            "event_id": 1,
            "hostname": "REMOTE-LAPTOP-A",
            "user": "corp\\jdoe",
            "source_ip": "192.168.1.105",
            "destination_ip": "192.168.1.50",
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -ExecutionPolicy Bypass -NoP -Enc QnkgUGFzcyBPdMVy...",
            "message": "Remote Laptop A: Obfuscated PowerShell execution detected."
        },
        {
            "timestamp": datetime.now().isoformat(),
            "source": "Sysmon",
            "event_id": 10,
            "hostname": "REMOTE-LAPTOP-A",
            "user": "corp\\jdoe",
            "source_ip": "192.168.1.105",
            "destination_ip": "N/A",
            "process_name": "mimikatz.exe",
            "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords exit",
            "message": "Remote Laptop A: Process memory access to LSASS.exe detected."
        }
    ]

    for event in remote_attack_events:
        payload = json.dumps(event).encode('utf-8')
        sock.sendto(payload, (server_ip, port))
        print(f"[+] Transmitted Log Event ({event['process_name']}) from Remote Laptop A to {server_ip}:{port}")
        time.sleep(0.5)

    print(f"\n✅ All remote log events transmitted successfully to SOC Server!")


if __name__ == "__main__":
    ip_input = input("Enter your main laptop (Laptop B) local IP address (e.g. 192.168.1.50): ").strip()
    if not ip_input:
        ip_input = "127.0.0.1"
    send_remote_logs(ip_input)
