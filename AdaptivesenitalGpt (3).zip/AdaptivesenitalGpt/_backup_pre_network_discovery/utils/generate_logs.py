import json
import random
from datetime import datetime, timedelta
from pathlib import Path
import sys

# Add project root to sys.path
sys.path.append(str(Path(__file__).resolve().parent.parent))
from config.settings import RAW_LOGS_DIR


def generate_synthetic_attack_logs(num_background_logs=None):
    """
    Generates a dynamic multi-source log dataset with randomized attack scenarios.
    """
    if num_background_logs is None:
        num_background_logs = random.randint(200, 800)

    logs = []
    now = datetime.now()

    # --- Pool of Available Attack Scenarios ---
    all_attack_scenarios = []

    # Scenario A: Ransomware & Shadow Copy Deletion (T1486, T1059)
    t1 = now - timedelta(minutes=25)
    scenario_a = [
        {
            "timestamp": (t1 + timedelta(seconds=1)).isoformat(),
            "source": "Sysmon",
            "event_id": 1,
            "hostname": "FINANCE-WORKSTATION",
            "user": "corp\\jdoe",
            "source_ip": "10.0.4.15",
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -ExecutionPolicy Bypass -Enc QnkgUGFzcyBPdmVy",
            "message": "Process Creation: Unsigned PowerShell executed with hidden bypass flag."
        },
        {
            "timestamp": (t1 + timedelta(seconds=5)).isoformat(),
            "source": "Windows",
            "event_id": 4688,
            "hostname": "FINANCE-WORKSTATION",
            "user": "corp\\jdoe",
            "source_ip": "10.0.4.15",
            "process_name": "vssadmin.exe",
            "command_line": "vssadmin.exe delete shadows /all /quiet",
            "message": "Process Creation: Volume Shadow Copies deletion requested."
        }
    ]
    all_attack_scenarios.append(scenario_a)

    # Scenario B: Brute Force & LSASS Dumping
    t2 = now - timedelta(minutes=20)
    attacker_ip = f"185.220.{random.randint(100, 200)}.{random.randint(2, 250)}"
    scenario_b = []
    for i in range(random.randint(3, 7)):
        scenario_b.append({
            "timestamp": (t2 + timedelta(seconds=i * 2)).isoformat(),
            "source": "Windows",
            "event_id": 4625,
            "hostname": "DC-PRIMARY",
            "user": "Administrator",
            "source_ip": attacker_ip,
            "process_name": "winlogon.exe",
            "command_line": "N/A",
            "message": "An account failed to log on. Reason: Unknown user name or bad password."
        })
    scenario_b.append({
        "timestamp": (t2 + timedelta(seconds=20)).isoformat(),
        "source": "Sysmon",
        "event_id": 10,
        "hostname": "DC-PRIMARY",
        "user": "SYSTEM",
        "source_ip": attacker_ip,
        "process_name": "mimikatz.exe",
        "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords exit",
        "message": "Process accessed LSASS memory space (Target: lsass.exe, GrantedAccess: 0x1010)."
    })
    all_attack_scenarios.append(scenario_b)

    # Scenario C: Defense Evasion (Event Log Clearing)
    t3 = now - timedelta(minutes=15)
    scenario_c = [
        {
            "timestamp": (t3 + timedelta(seconds=2)).isoformat(),
            "source": "Windows",
            "event_id": 1102,
            "hostname": f"SRV-FILE-0{random.randint(1, 4)}",
            "user": "corp\\admin_malicious",
            "source_ip": "10.0.1.50",
            "process_name": "wevtutil.exe",
            "command_line": "wevtutil cl Security",
            "message": "The audit log was cleared."
        }
    ]
    all_attack_scenarios.append(scenario_c)

    # Scenario D: Persistence (Account Creation)
    t4 = now - timedelta(minutes=10)
    scenario_d = [
        {
            "timestamp": (t4 + timedelta(seconds=1)).isoformat(),
            "source": "Windows",
            "event_id": 4720,
            "hostname": "DC-PRIMARY",
            "user": "Administrator",
            "source_ip": "10.0.1.50",
            "process_name": "net.exe",
            "command_line": "net user backdoor_user P@ssword123! /add",
            "message": "A user account was created."
        }
    ]
    all_attack_scenarios.append(scenario_d)

    # Scenario E: Suricata IDS Alert
    t5 = now - timedelta(minutes=5)
    scenario_e = [
        {
            "timestamp": (t5 + timedelta(seconds=1)).isoformat(),
            "source": "Suricata",
            "event_id": 2000001,
            "hostname": f"EDGE-GATEWAY-0{random.randint(1,3)}",
            "user": "N/A",
            "source_ip": f"45.33.{random.randint(10,90)}.{random.randint(2,200)}",
            "destination_ip": "10.0.2.10",
            "process_name": "suricata",
            "command_line": "N/A",
            "message": "ET EXPLOIT Possible Lateral Movement via WMI Remote Command Execution"
        }
    ]
    all_attack_scenarios.append(scenario_e)

    # Scenario F: Linux SSH Intrusion
    t6 = now - timedelta(minutes=3)
    scenario_f = [
        {
            "timestamp": (t6 + timedelta(seconds=5)).isoformat(),
            "source": "Linux",
            "event_id": 1001,
            "hostname": "WEB-SRV-LINUX",
            "user": "root",
            "source_ip": "45.33.32.156",
            "process_name": "sshd",
            "command_line": "sshd: root@pts/0",
            "message": "Failed password for root from 45.33.32.156 port 48920 ssh2"
        }
    ]
    all_attack_scenarios.append(scenario_f)

    # --- Randomly Select 2 to 6 Attack Scenarios on Each Run ---
    chosen_scenarios = random.sample(all_attack_scenarios, random.randint(2, len(all_attack_scenarios)))

    for sc in chosen_scenarios:
        logs.extend(sc)

    # --- Background Benign Logs ---
    hosts = ["DESKTOP-01", "DESKTOP-02", "SERVER-APP-01", "WORKSTATION-99", "HR-LAPTOP-04"]
    users = ["alice", "bob", "carol", "david", "eve", "frank"]

    for i in range(num_background_logs):
        b_time = now - timedelta(minutes=random.randint(1, 120))
        logs.append({
            "timestamp": b_time.isoformat(),
            "source": "Windows",
            "event_id": 4624,
            "hostname": random.choice(hosts),
            "user": random.choice(users),
            "source_ip": f"192.168.1.{random.randint(10, 250)}",
            "process_name": "explorer.exe",
            "command_line": "C:\\Windows\\explorer.exe",
            "message": "An account was successfully logged on."
        })

    # Tag all generated events with source = synthetic
    for item in logs:
        item["source"] = "synthetic"

    # Sort logs chronologically
    logs.sort(key=lambda x: x["timestamp"])

    output_path = RAW_LOGS_DIR / "windows_logs.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(logs, f, indent=4)

    print(f"[INFO] Synthetic Attack Log Generator created {len(logs)} log events across {len(chosen_scenarios)} attack scenario(s) at {output_path}")
    return output_path


if __name__ == "__main__":
    generate_synthetic_attack_logs()