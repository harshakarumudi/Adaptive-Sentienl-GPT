import sys
import os
import subprocess
import json
import re
from datetime import datetime
from typing import List, Dict, Any
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.settings import LOG_FILE_PATH, RAW_LOGS_DIR


class RealWindowsLogCollector:
    """
    Real Windows Event Log & Sysmon Collector.
    Queries native Windows Event Viewer logs directly from the local OS
    using PowerShell Get-WinEvent API and normalizes them for AdaptiveSentinelGPT.
    """

    def __init__(self):
        self.output_file = LOG_FILE_PATH

    def collect_live_os_logs(self, max_events: int = 50) -> List[Dict[str, Any]]:
        """
        Executes native PowerShell query to harvest real local Windows Security Event Logs.
        """
        print(f"[INFO] Harvesting real native Windows Event Logs from local OS Event Viewer...")

        # PowerShell command to fetch recent Security, System & Application log events
        ps_script = f"Get-WinEvent -LogName Security, System, Application -MaxEvents {max_events} -ErrorAction SilentlyContinue | Select-Object TimeCreated, Id, MachineName, Message | ConvertTo-Json -Compress"

        try:
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)

            if result.returncode != 0 or not result.stdout.strip():
                print("[!] PowerShell Event Viewer query returned no security events or requires Admin rights.")
                return self._fallback_real_system_logs()

            raw_json = result.stdout.strip()
            # Handle single object vs list in JSON
            if raw_json.startswith("{"):
                parsed_events = [json.loads(raw_json)]
            else:
                parsed_events = json.loads(raw_json)

            logs = []
            for evt in parsed_events:
                msg = evt.get("Message") or ""
                
                # Extract User if present in message
                user_match = re.search(r"Account Name:\s*([^\r\n]+)", msg)
                user = user_match.group(1).strip() if user_match else "SYSTEM"

                # Extract Process Name if present
                proc_match = re.search(r"New Process Name:\s*([^\r\n]+)", msg)
                process_name = proc_match.group(1).strip() if proc_match else "svchost.exe"

                t_raw = evt.get("TimeCreated")
                t_iso = datetime.now().isoformat()
                if isinstance(t_raw, str) and "Date(" in t_raw:
                    try:
                        ms = int(re.search(r"\d+", t_raw).group(0))
                        t_iso = datetime.fromtimestamp(ms / 1000.0).isoformat()
                    except Exception:
                        pass
                elif t_raw:
                    t_iso = str(t_raw)

                logs.append({
                    "timestamp": t_iso,
                    "source": "local_windows",
                    "event_id": evt.get("Id", 4624),
                    "hostname": evt.get("MachineName", "LOCAL-WINDOWS-PC"),
                    "user": user,
                    "source_ip": "127.0.0.1",
                    "destination_ip": "127.0.0.1",
                    "process_name": process_name,
                    "command_line": process_name,
                    "message": msg[:200] if msg else "Native Windows OS Security Event"
                })

            # Save real logs to windows_logs.json
            with open(self.output_file, "w", encoding="utf-8") as f:
                json.dump(logs, f, indent=2)

            try:
                sys.stdout.reconfigure(encoding='utf-8')
            except Exception:
                pass
            print(f"[+] Harvested {len(logs)} real Windows OS security logs from Event Viewer!")
            return logs

        except Exception as e:
            print(f"[!] Error fetching Windows Event Logs: {e}")
            return self._fallback_real_system_logs()

    def _fallback_real_system_logs(self) -> List[Dict[str, Any]]:
        """Zero fallback logs - returns empty list if no real network logs exist."""
        logs = []
        with open(self.output_file, "w", encoding="utf-8") as f:
            json.dump(logs, f, indent=2)
        return logs


def collect_real_windows_logs() -> List[Dict[str, Any]]:
    collector = RealWindowsLogCollector()
    return collector.collect_live_os_logs()


if __name__ == "__main__":
    collect_real_windows_logs()
