import os
import socket
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_LOGS_DIR = DATA_DIR / "raw_logs"
PROCESSED_LOGS_DIR = DATA_DIR / "processed_logs"
REPORTS_DIR = DATA_DIR / "reports"
DB_PATH = BASE_DIR / "knowledge_base" / "sentinel_kb.db"

LOG_FILE_PATH = RAW_LOGS_DIR / "windows_logs.json"

# Ensure directories exist
RAW_LOGS_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_LOGS_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# LLM Configurations
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "fallback")  # Options: 'ollama', 'gemini', 'openai', 'fallback'
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Detection & Correlation Thresholds
CORRELATION_TIME_WINDOW_MINUTES = 15
BRUTE_FORCE_THRESHOLD = 3
SUSPICIOUS_PROCESS_NAMES = [
    "powershell.exe", "cmd.exe", "wmic.exe", "vssadmin.exe",
    "mimikatz.exe", "whoami.exe", "net.exe", "reg.exe"
]

# Threat Intelligence Configs
THREAT_INTEL_SIMULATED_REPUTATION_THRESHOLD = 70

# Remote Endpoint Ingestion Configs
RECEIVER_HOST = os.getenv("RECEIVER_HOST", "0.0.0.0")
RECEIVER_PORT = int(os.getenv("RECEIVER_PORT", "5000"))
DEFAULT_ENDPOINT_ID = os.getenv("DEFAULT_ENDPOINT_ID", "EP-REMOTE-01")
COLLECTOR_VERSION = os.getenv("COLLECTOR_VERSION", "1.0.0")
PROJECT_TOKEN = os.getenv("PROJECT_TOKEN", "SENTINEL_SECRET_TOKEN_2026")
ENDPOINT_STATUS_FILE_PATH = DATA_DIR / "endpoint_status.json"
HEARTBEAT_TIMEOUT_SECONDS = int(os.getenv("HEARTBEAT_TIMEOUT_SECONDS", "30"))

# NXLog Ingestion & Centralized Network Configs
NXLOG_FILE_PATH = Path(os.getenv("NXLOG_FILE_PATH", r"C:\AdaptiveSentinel\windows-events.log"))
NXLOG_CURSOR_FILE_PATH = DATA_DIR / "nxlog_cursor.json"
NXLOG_PORT = int(os.getenv("NXLOG_PORT", "2514"))
ENDPOINT_HOSTNAME = os.getenv("ENDPOINT_HOSTNAME", "N/A")
RECEIVER_HOSTNAME = os.getenv("RECEIVER_HOSTNAME", "Sujith")


def detect_local_ip() -> str:
    """
    Detects the active non-loopback local IPv4 address via a non-transmitting
    UDP socket route lookup. Avoids hardcoding transient Wi-Fi IPs.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0.1)
            s.connect(("10.255.255.255", 1))
            local_ip = s.getsockname()[0]
            if local_ip and not local_ip.startswith("127.") and local_ip != "0.0.0.0":
                return local_ip
    except Exception:
        pass
    return "127.0.0.1"


def get_receiver_ip() -> str:
    """
    Returns the configured receiver IP address (honoring RECEIVER_ADVERTISED_IP,
    RECEIVER_IP, or SUJITH_IP environment overrides first), falling back to
    dynamic active interface detection.
    """
    for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
        val = os.getenv(env_key, "").strip()
        if val and val.upper() not in ("N/A", "NONE", "AUTO"):
            return val
    return detect_local_ip()


def get_endpoint_ip(observed_ip: str = None, receiver_ip: str = None) -> str:
    """
    Resolves the sender/endpoint IP from observed telemetry or explicit environment
    configuration (ENDPOINT_IP / HARSHA_IP).
    Never labels the receiver IP as the sender IP, and returns 'N/A' when unknown.
    """
    active_receiver = (receiver_ip or get_receiver_ip()).strip()
    invalid_tokens = {"", "-", "N/A", "NONE", "UNKNOWN", "127.0.0.1", "::1", "0.0.0.0"}

    if observed_ip is not None:
        candidate = str(observed_ip).strip()
        if candidate.upper() not in invalid_tokens and candidate != active_receiver:
            return candidate

    for env_key in ("ENDPOINT_IP", "HARSHA_IP"):
        val = os.getenv(env_key, "").strip()
        if val.upper() not in invalid_tokens and val != active_receiver:
            return val

    return "N/A"


SUJITH_IP = get_receiver_ip()
RECEIVER_ADVERTISED_IP = SUJITH_IP
HARSHA_IP = get_endpoint_ip(receiver_ip=SUJITH_IP)



