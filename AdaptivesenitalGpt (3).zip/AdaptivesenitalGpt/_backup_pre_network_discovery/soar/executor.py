from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, Optional
from soar.action_registry import SOARActionRegistry


class BaseSOARExecutor(ABC):
    """Abstract Base Class for SOAR Execution Abstraction Layer."""

    @abstractmethod
    def execute_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    def rollback_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        pass


class MockSOARExecutor(BaseSOARExecutor):
    """
    Safe Mock / Simulated SOAR Executor.
    Executes allowlisted SOAR actions in Dry-Run or Simulated Sandbox mode.
    Prohibits real destructive OS modifications.
    """

    def __init__(self, registry: Optional[SOARActionRegistry] = None):
        self.registry = registry or SOARActionRegistry()

    def execute_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        Simulates execution of allowlisted SOAR action.
        """
        parameters = parameters or {}
        now_str = datetime.now().isoformat()

        # Validate request against allowlist & target rules
        is_valid, err_msg = self.registry.validate_action_request(action_id, target, parameters)
        if not is_valid:
            return {
                "execution_id": f"EXEC-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": err_msg,
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {"reason": err_msg}
            }

        action_meta = self.registry.get_action(action_id)
        is_reversible = action_meta.get("is_reversible", False)
        rollback_status = "AVAILABLE" if is_reversible else "NON_REVERSIBLE"

        if dry_run:
            preview_msg = (
                f"DRY RUN — NO SYSTEM CHANGE: Would execute '{action_id}' on target '{target}' "
                f"with parameters {parameters} via agent policy."
            )
            return {
                "execution_id": f"EXEC-DRYRUN-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "DRY_RUN",
                "verification_status": "VERIFIED_SUCCESS",
                "error_message": "",
                "rollback_status": rollback_status,
                "dry_run": True,
                "timestamp": now_str,
                "details": {
                    "preview": preview_msg,
                    "simulated": True,
                    "mode": "DRY RUN MODE — NO SYSTEM CHANGE"
                }
            }

        # Simulated Execution Mode (dry_run = False)
        sim_details = self._simulate_action_logic(action_id, target, parameters)
        return {
            "execution_id": f"EXEC-SIM-{datetime.now().strftime('%M%S%f')}",
            "action_id": action_id,
            "target": target,
            "status": "EXECUTED",
            "verification_status": "VERIFIED_SUCCESS",
            "error_message": "",
            "rollback_status": rollback_status,
            "dry_run": False,
            "timestamp": now_str,
            "details": sim_details
        }

    def rollback_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        Simulates rollback execution for reversible SOAR actions.
        """
        parameters = parameters or {}
        now_str = datetime.now().isoformat()

        action_meta = self.registry.get_action(action_id)
        if not action_meta:
            return {
                "execution_id": f"ROLLBACK-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": f"Action '{action_id}' is unknown.",
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {}
            }

        if not action_meta.get("is_reversible", False):
            return {
                "execution_id": f"ROLLBACK-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": f"Action '{action_id}' is explicitly NON-REVERSIBLE and cannot be rolled back.",
                "rollback_status": "NON_REVERSIBLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {"reason": "Non-reversible action"}
            }

        rollback_action_id = action_meta.get("rollback_action_id")
        if dry_run:
            preview_msg = (
                f"DRY RUN — NO SYSTEM CHANGE: Would execute rollback '{rollback_action_id}' "
                f"for target '{target}'."
            )
            return {
                "execution_id": f"ROLLBACK-DRYRUN-{datetime.now().strftime('%M%S%f')}",
                "action_id": rollback_action_id,
                "target": target,
                "status": "DRY_RUN",
                "verification_status": "VERIFIED_SUCCESS",
                "error_message": "",
                "rollback_status": "ROLLED_BACK",
                "dry_run": True,
                "timestamp": now_str,
                "details": {"preview": preview_msg, "simulated": True}
            }

        sim_details = {
            "summary": f"SIMULATED ROLLBACK SUCCESS: Reverted '{action_id}' via '{rollback_action_id}' on target '{target}'.",
            "previous_state": f"Modified by {action_id}",
            "restored_state": "Baseline Operational State"
        }
        return {
            "execution_id": f"ROLLBACK-SIM-{datetime.now().strftime('%M%S%f')}",
            "action_id": rollback_action_id,
            "target": target,
            "status": "ROLLED_BACK",
            "verification_status": "VERIFIED_SUCCESS",
            "error_message": "",
            "rollback_status": "ROLLED_BACK",
            "dry_run": False,
            "timestamp": now_str,
            "details": sim_details
        }

    def _simulate_action_logic(self, action_id: str, target: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Internal helper generating detailed simulation logs for each allowlisted action."""
        if action_id == "ISOLATE_HOST":
            return {
                "summary": f"SIMULATED HOST ISOLATION: Applied firewall rule isolating host '{target}'.",
                "sandbox_ip_rule": f"DENY ALL EXCEPT SOC ENGINE ON HOST {target}",
                "agent_channel": "SOAR Active Response Protocol (Simulated)"
            }
        elif action_id == "BLOCK_IP":
            return {
                "summary": f"SIMULATED IP BLOCK: Added IP '{target}' to edge firewall drop table.",
                "rule_id": f"FW-BLOCK-{target.replace('.', '_')}",
                "perimeter": "Inbound & Outbound Traffic Filtered"
            }
        elif action_id == "LOCK_USER":
            return {
                "summary": f"SIMULATED ACCOUNT LOCKOUT: Set accountDisabled=TRUE for user '{target}'.",
                "active_directory_sam": f"Account '{target}' disabled in SAM/AD database.",
                "active_sessions": "Terminated 2 active Kerberos tickets for account."
            }
        elif action_id == "COLLECT_FORENSIC_ARTIFACTS":
            art_type = parameters.get("artifact_type", "triage_package")
            return {
                "summary": f"SIMULATED FORENSIC COLLECTION: Captured artifact package '{art_type}' for host '{target}'.",
                "artifact_type": art_type,
                "storage_location": f"data/forensics/triage_{target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
                "integrity_hash_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
            }
        return {"summary": f"Simulated execution for action '{action_id}' on target '{target}'."}
