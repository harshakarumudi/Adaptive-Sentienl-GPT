import ipaddress
import re
from typing import Dict, Any, List, Tuple, Optional


class SOARActionRegistry:
    """
    Deterministic Action Registry enforcing a strict allowlist of predefined SOAR actions.
    Prohibits arbitrary LLM shell code execution.
    """

    ALLOWED_ARTIFACT_TYPES = {
        "memory_dump",
        "event_logs",
        "triage_package",
        "volatile_data",
        "network_pcap"
    }

    def __init__(self):
        self._actions: Dict[str, Dict[str, Any]] = {
            "ISOLATE_HOST": {
                "action_id": "ISOLATE_HOST",
                "name": "Isolate Endpoint Host",
                "description": "Network-level isolation of compromised host endpoint via agent firewall rule",
                "target_type": "hostname",
                "required_parameters": ["hostname"],
                "is_reversible": True,
                "rollback_action_id": "UNISOLATE_HOST",
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "BLOCK_IP": {
                "action_id": "BLOCK_IP",
                "name": "Block Malicious IP Address",
                "description": "Add IP address to perimeter firewall / host blocklist",
                "target_type": "ip_address",
                "required_parameters": ["ip_address"],
                "is_reversible": True,
                "rollback_action_id": "UNBLOCK_IP",
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "LOCK_USER": {
                "action_id": "LOCK_USER",
                "name": "Lock Monitored User Account",
                "description": "Disable user account in Active Directory / Local SAM to prevent lateral movement",
                "target_type": "username",
                "required_parameters": ["username"],
                "is_reversible": True,
                "rollback_action_id": "UNLOCK_USER",
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "COLLECT_FORENSIC_ARTIFACTS": {
                "action_id": "COLLECT_FORENSIC_ARTIFACTS",
                "name": "Collect Forensic Artifact Package",
                "description": "Trigger automated forensic artifact collection (memory dump, event logs, volatile data)",
                "target_type": "artifact",
                "required_parameters": ["hostname", "artifact_type"],
                "is_reversible": False,
                "rollback_action_id": None,
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "UNISOLATE_HOST": {
                "action_id": "UNISOLATE_HOST",
                "name": "Restore Endpoint Host Network",
                "description": "Rollback isolation and restore network connectivity to host",
                "target_type": "hostname",
                "required_parameters": ["hostname"],
                "is_reversible": False,
                "rollback_action_id": None,
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "UNBLOCK_IP": {
                "action_id": "UNBLOCK_IP",
                "name": "Unblock IP Address",
                "description": "Remove IP address from perimeter firewall blocklist",
                "target_type": "ip_address",
                "required_parameters": ["ip_address"],
                "is_reversible": False,
                "rollback_action_id": None,
                "requires_analyst_approval": True,
                "dry_run_supported": True
            },
            "UNLOCK_USER": {
                "action_id": "UNLOCK_USER",
                "name": "Unlock User Account",
                "description": "Re-enable user account in Active Directory / Local SAM",
                "target_type": "username",
                "required_parameters": ["username"],
                "is_reversible": False,
                "rollback_action_id": None,
                "requires_analyst_approval": True,
                "dry_run_supported": True
            }
        }

    def get_action(self, action_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves registered action details by action ID."""
        return self._actions.get(action_id)

    def is_action_allowed(self, action_id: str) -> bool:
        """Checks if action_id exists in allowlisted registry."""
        return action_id in self._actions

    def list_allowlisted_actions(self) -> List[Dict[str, Any]]:
        """Returns list of all allowlisted actions."""
        return list(self._actions.values())

    def validate_action_request(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, str]:
        """
        Validates SOAR action request against allowlist and strict target rules.
        Returns: (is_valid: bool, error_message: str)
        """
        parameters = parameters or {}

        # 1. Allowlist Validation
        if not self.is_action_allowed(action_id):
            return False, f"ACTION REJECTED: '{action_id}' is not in the allowlisted SOAR action registry."

        action_meta = self.get_action(action_id)
        target_type = action_meta["target_type"]

        # 2. Target Non-Empty Validation
        if not target or not isinstance(target, str) or not target.strip():
            return False, f"TARGET INVALID: Target string cannot be empty for action '{action_id}'."

        target_str = target.strip()

        # Reject wildcard / illegal broad targets
        if target_str in ("*", "ALL", "UNKNOWN", "N/A", "127.0.0.1", "0.0.0.0"):
            if action_id == "BLOCK_IP" and target_str in ("127.0.0.1", "0.0.0.0"):
                return False, f"TARGET REJECTED: Block action cannot target loopback/unspecified IP '{target_str}'."
            if action_id in ("ISOLATE_HOST", "LOCK_USER") and target_str in ("*", "ALL"):
                return False, f"TARGET REJECTED: Action '{action_id}' cannot target wildcard '{target_str}'."

        # 3. Action-Specific Parameter & Target Validation
        if action_id in ("ISOLATE_HOST", "UNISOLATE_HOST"):
            if not re.match(r"^[A-Za-z0-9_\-\.]+$", target_str):
                return False, f"HOSTNAME INVALID: '{target_str}' contains invalid hostname characters."

        elif action_id in ("BLOCK_IP", "UNBLOCK_IP"):
            try:
                ip_obj = ipaddress.ip_address(target_str)
                if ip_obj.is_loopback:
                    return False, f"IP INVALID: Cannot block loopback IP '{target_str}'."
                if ip_obj.is_multicast:
                    return False, f"IP INVALID: Cannot block multicast IP '{target_str}'."
            except ValueError:
                return False, f"IP INVALID: '{target_str}' is not a valid IPv4 or IPv6 address."

        elif action_id in ("LOCK_USER", "UNLOCK_USER"):
            if not re.match(r"^[A-Za-z0-9_\-\.\@\\]+$", target_str):
                return False, f"USERNAME INVALID: '{target_str}' contains invalid username characters."

        elif action_id == "COLLECT_FORENSIC_ARTIFACTS":
            artifact_type = parameters.get("artifact_type", target_str)
            if artifact_type not in self.ALLOWED_ARTIFACT_TYPES:
                return False, (
                    f"ARTIFACT TYPE INVALID: '{artifact_type}' is not supported. "
                    f"Allowed types: {sorted(list(self.ALLOWED_ARTIFACT_TYPES))}"
                )

        return True, "VALID"
