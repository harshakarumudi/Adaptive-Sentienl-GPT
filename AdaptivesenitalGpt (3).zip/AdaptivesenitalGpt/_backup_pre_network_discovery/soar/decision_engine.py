from typing import Dict, Any, List, Optional
from soar.action_registry import SOARActionRegistry


class SOARDecisionEngine:
    """
    Deterministic Decision Engine evaluating security incidents and GNN risk scores
    to output structured response recommendations using strictly allowlisted SOAR actions.
    Prohibits arbitrary AI shell command generation.
    """

    def __init__(self, registry: Optional[SOARActionRegistry] = None):
        self.registry = registry or SOARActionRegistry()

    def evaluate_incident(self, incident: Dict[str, Any], gnn_risk_score: float = 0.0) -> List[Dict[str, Any]]:
        """
        Evaluates an incident and returns list of structured response recommendations.
        """
        recommendations = []
        inc_id = incident.get("incident_id", "INC-UNK")
        host = incident.get("affected_host", "UNKNOWN-HOST")
        user = incident.get("affected_user", "SYSTEM")
        severity = incident.get("severity", "Medium")

        # Extract alerts & metadata
        alerts = incident.get("alerts", [])
        source_ips = set()
        mitre_techs = set()
        detected_rules = set()

        for alt in alerts:
            evt = alt.get("event", {}) if isinstance(alt, dict) else {}
            if evt.get("source_ip"):
                source_ips.add(evt["source_ip"])
            rule_id = evt.get("rule_id")
            if rule_id:
                detected_rules.add(str(rule_id))
            techs = evt.get("mitre_techniques", [])
            if isinstance(techs, str):
                techs = [techs]
            mitre_techs.update(techs)

        primary_ip = list(source_ips)[0] if source_ips else "127.0.0.1"
        primary_rule = list(detected_rules)[0] if detected_rules else "N/A"
        primary_tech = list(mitre_techs)[0] if mitre_techs else "N/A"

        # 1. Recommendation Rule: Host Isolation (ISOLATE_HOST)
        # Recommended if Critical/High severity OR GNN risk score >= 0.70 OR Critical techniques present
        critical_tech_match = any(t in mitre_techs for t in ("T1003", "T1490", "T1055", "T1059.001", "T1505.003", "T1558.001"))
        if severity in ("Critical", "High") or gnn_risk_score >= 0.70 or critical_tech_match:
            is_valid, _ = self.registry.validate_action_request("ISOLATE_HOST", host)
            if is_valid:
                why_msg = (
                    f"Recommended network isolation for endpoint '{host}' because incident '{inc_id}' "
                    f"has {severity} severity (GNN Risk Score: {gnn_risk_score:.4f}) and detected "
                    f"technique(s) {sorted(list(mitre_techs))}."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "ISOLATE_HOST",
                    "action_name": "Isolate Endpoint Host",
                    "target": host,
                    "parameters": {"hostname": host},
                    "why_recommended": why_msg,
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute ISOLATE_HOST on target '{host}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 2. Recommendation Rule: Forensic Artifact Collection (COLLECT_FORENSIC_ARTIFACTS)
        # Recommended for all High/Critical incidents or elevated GNN risk score
        if severity in ("Critical", "High") or gnn_risk_score >= 0.50:
            is_valid, _ = self.registry.validate_action_request("COLLECT_FORENSIC_ARTIFACTS", host, {"artifact_type": "triage_package"})
            if is_valid:
                why_msg = (
                    f"Recommended automated forensic triage collection for host '{host}' to capture "
                    f"volatile memory, process tree, and event logs for post-incident analysis."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "COLLECT_FORENSIC_ARTIFACTS",
                    "action_name": "Collect Forensic Artifact Package",
                    "target": host,
                    "parameters": {"hostname": host, "artifact_type": "triage_package"},
                    "why_recommended": why_msg,
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute COLLECT_FORENSIC_ARTIFACTS (triage_package) on target '{host}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 3. Recommendation Rule: Block IP (BLOCK_IP)
        # Recommended if external non-loopback IP is present and involved in brute force / unauthorized access
        if primary_ip and primary_ip not in ("127.0.0.1", "0.0.0.0", "localhost"):
            is_valid, _ = self.registry.validate_action_request("BLOCK_IP", primary_ip)
            if is_valid:
                why_msg = (
                    f"Recommended perimeter IP block for source IP '{primary_ip}' due to suspicious "
                    f"authentication failures or network activity targeting '{host}'."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "BLOCK_IP",
                    "action_name": "Block Malicious IP Address",
                    "target": primary_ip,
                    "parameters": {"ip_address": primary_ip},
                    "why_recommended": why_msg,
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute BLOCK_IP on target '{primary_ip}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 4. Recommendation Rule: Lock User Account (LOCK_USER)
        # Recommended if credential theft, brute force, or golden ticket is detected
        cred_tech_match = any(t in mitre_techs for t in ("T1003", "T1110", "T1110.003", "T1558", "T1558.001", "T1558.003"))
        if user and user not in ("SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "IUSR") and (cred_tech_match or severity == "Critical"):
            is_valid, _ = self.registry.validate_action_request("LOCK_USER", user)
            if is_valid:
                why_msg = (
                    f"Recommended account lockout for monitored user '{user}' to prevent credential misuse "
                    f"and lateral movement across domain infrastructure."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "LOCK_USER",
                    "action_name": "Lock Monitored User Account",
                    "target": user,
                    "parameters": {"username": user},
                    "why_recommended": why_msg,
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute LOCK_USER on target '{user}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        return recommendations
