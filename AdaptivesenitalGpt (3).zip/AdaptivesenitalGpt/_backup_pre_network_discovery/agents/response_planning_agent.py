from typing import List, Dict, Any
from llm.llm_client import LLMClient
from soar.decision_engine import SOARDecisionEngine


class ResponsePlanningAgent:
    """
    Response Planning Agent generating structured SOAR recommendations
    and high-level playbooks for Incident Containment, Eradication, and Recovery.
    Enforces allowlisted SOAR action recommendations via SOARDecisionEngine.
    """

    def __init__(self):
        self.llm = LLMClient()
        self.decision_engine = SOARDecisionEngine()

    def plan(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        plans = []

        for incident in incidents:
            plan = self.llm.generate_response_plan(incident)
            
            # Generate structured allowlisted SOAR recommendations
            gnn_score = float(incident.get("gnn_risk_score", 0.0))
            recommendations = self.decision_engine.evaluate_incident(incident, gnn_risk_score=gnn_score)
            
            plan["recommendations"] = recommendations
            plan["incident_id"] = incident.get("incident_id", "INC-UNK")
            plan["affected_host"] = incident.get("affected_host", "UNKNOWN-HOST")
            plan["affected_user"] = incident.get("affected_user", "SYSTEM")
            plan["severity"] = incident.get("severity", "Medium")
            plans.append(plan)

        print(f"[INFO] Response Planning Agent compiled {len(plans)} SOAR Response Playbook(s).")
        return plans