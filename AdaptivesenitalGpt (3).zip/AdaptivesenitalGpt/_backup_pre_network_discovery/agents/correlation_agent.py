import hashlib
import uuid
from typing import List, Dict, Any
from datetime import datetime


class CorrelationAgent:
    """
    Correlation Agent correlating atomic alerts into unified multi-stage Incidents
    based on host, user, IP, and temporal attack chain analysis.
    """

    def correlate(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        incidents = []

        # Group alerts by Host and Source IP
        host_groups = {}
        for alert in alerts:
            event = alert["event"]
            host = event.get("hostname", "UNKNOWN_HOST")
            user = event.get("user", "SYSTEM")
            key = f"{host}::{user}"

            if key not in host_groups:
                host_groups[key] = []
            host_groups[key].append(alert)

        # Correlate grouped alerts
        for key, alert_list in host_groups.items():
            host, user = key.split("::")

            # Separate diagnostic probes from genuine security alerts
            diag_alerts = [a for a in alert_list if a.get("is_diagnostic") or "Diagnostic" in a.get("alert_name", "")]
            security_alerts = [a for a in alert_list if not (a.get("is_diagnostic") or "Diagnostic" in a.get("alert_name", ""))]

            if diag_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:diagnostic".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-DIAG-{inc_hash}",
                    "incident_name": f"Diagnostic Telemetry Verification Probe ({host})",
                    "severity": "Low",
                    "confidence": 100,
                    "is_diagnostic": True,
                    "alert_count": len(diag_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": diag_alerts,
                    "created_at": datetime.now().isoformat()
                })

            if not security_alerts:
                continue

            failed_logins = [a for a in security_alerts if "Failed Logon" in a["alert_name"]]
            lsass_alerts = [a for a in security_alerts if "LSASS" in a["alert_name"] or "Mimikatz" in a["alert_name"]]
            cred_manager_alerts = [a for a in security_alerts if "Credential Manager" in a["alert_name"]]
            discovery_alerts = [a for a in security_alerts if "Account Discovery" in a["alert_name"] or "Group Membership" in a["alert_name"]]
            ps_alerts = [a for a in security_alerts if "PowerShell" in a["alert_name"]]
            vss_alerts = [a for a in security_alerts if "Shadow Copies" in a["alert_name"] or "Ransomware" in a["alert_name"]]
            log_cleared = [a for a in security_alerts if "Log Cleared" in a["alert_name"]]

            # Ransomware Attack Sequence Correlation (PowerShell + VSSAdmin Deletion)
            if vss_alerts or (ps_alerts and len(ps_alerts) >= 1):
                combined_alerts = vss_alerts + ps_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:ransomware".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Ransomware Pre-Encryption Staging Activity",
                    "severity": "Critical",
                    "confidence": 98,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Brute Force & Credential Harvesting Chain (Failed Logins + Mimikatz LSASS)
            elif len(failed_logins) >= 3 or (failed_logins and lsass_alerts):
                combined_alerts = failed_logins + lsass_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:bruteforce".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Automated Brute Force & Credential Dumping Attack Chain",
                    "severity": "Critical" if lsass_alerts else "High",
                    "confidence": 96 if lsass_alerts else 90,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Account Discovery & Credential Vault Harvesting Attack Chain
            elif cred_manager_alerts and discovery_alerts:
                combined_alerts = cred_manager_alerts + discovery_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:recon_cred_theft".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Account Discovery & Credential Vault Harvesting Attack Chain",
                    "severity": "Critical",
                    "confidence": 96,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Windows Credential Manager Access Activity (Event 5379)
            elif cred_manager_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:cred_vault".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Windows Credential Manager Password Vault Access Activity",
                    "severity": "Critical" if len(cred_manager_alerts) >= 2 else "High",
                    "confidence": 95 if len(cred_manager_alerts) >= 2 else 90,
                    "alert_count": len(cred_manager_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": cred_manager_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Local Account Group Discovery Campaign (Event 4798 / 4799)
            elif discovery_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:discovery".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Local Account Group Discovery Campaign ({user})",
                    "severity": "High" if len(discovery_alerts) >= 2 else "Medium",
                    "confidence": 92 if len(discovery_alerts) >= 2 else 85,
                    "alert_count": len(discovery_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": discovery_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Defense Evasion & Anti-Forensics Correlation
            elif log_cleared:
                inc_hash = hashlib.md5(f"{host}:{user}:evasion".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Host Defense Evasion & Security Log Tampering",
                    "severity": "High",
                    "confidence": 95,
                    "alert_count": len(log_cleared),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": log_cleared,
                    "created_at": datetime.now().isoformat()
                })

            # Fallback for remaining single alerts
            elif security_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:{security_alerts[0].get('alert_name', 'suspicious')}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Suspicious Activity on {host}",
                    "severity": security_alerts[0].get("severity", "Medium"),
                    "confidence": security_alerts[0].get("confidence", 80),
                    "alert_count": len(security_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": security_alerts,
                    "created_at": datetime.now().isoformat()
                })

        for inc in incidents:
            src_ips = []
            for alt in inc.get("alerts", []):
                sip = str(alt.get("event", {}).get("source_ip") or "N/A").strip()
                if sip and sip not in ("N/A", "-", "127.0.0.1", "::1") and sip not in src_ips:
                    src_ips.append(sip)
            inc["observed_source_ips"] = src_ips if src_ips else ["N/A"]

        print(f"[INFO] Correlation Agent synthesized {len(incidents)} correlated Incident(s).")
        return incidents