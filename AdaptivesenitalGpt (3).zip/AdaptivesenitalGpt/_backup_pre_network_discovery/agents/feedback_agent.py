import uuid
from datetime import datetime
from typing import Dict, Any
from knowledge_base.database import KnowledgeBaseDB


class FeedbackAgent:
    """
    Feedback Agent managing Human-in-the-Loop analyst interactions.
    Persists analyst verdicts, severity overrides, and confidence adjustments
    into the SQLite Adaptive Knowledge Base for continuous model alignment.
    """

    def __init__(self):
        self.db = KnowledgeBaseDB()

    def process_feedback(
        self,
        incident_id: str,
        alert_name: str,
        analyst_verdict: str,
        override_severity: str = None,
        adjusted_confidence: int = 90,
        notes: str = ""
    ) -> Dict[str, Any]:
        """
        Receives analyst review from the SOC Dashboard, stores feedback record,
        and dynamically updates detection rule weights.
        """
        feedback_entry = {
            "feedback_id": f"FDB-{uuid.uuid4().hex[:6].upper()}",
            "incident_id": incident_id,
            "alert_name": alert_name,
            "analyst_verdict": analyst_verdict,  # 'True Positive', 'False Positive', 'Inconclusive'
            "override_severity": override_severity,
            "adjusted_confidence": adjusted_confidence,
            "notes": notes,
            "timestamp": datetime.now().isoformat()
        }

        # Save into SQLite Adaptive Knowledge Base
        self.db.save_feedback(feedback_entry)

        print(
            f"[INFO] Feedback Agent recorded analyst review for {incident_id}: "
            f"Verdict={analyst_verdict}, Adjusted Confidence={adjusted_confidence}%"
        )
        return feedback_entry

    def get_feedback_history(self):
        return self.db.get_all_feedback()
