from typing import List, Dict, Any
from llm.llm_client import LLMClient


class ExplainabilityAgent:
    """
    Explainability Agent generating human-understandable AI rationale,
    evidence lists, and MITRE mapping summaries using the LLM engine.
    """

    def __init__(self):
        self.llm = LLMClient()

    def explain(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        explanations = []

        for incident in incidents:
            explanation = self.llm.generate_explanation(incident)
            explanations.append(explanation)

        print(f"[INFO] Explainability Agent generated {len(explanations)} AI Explanation(s).")
        return explanations