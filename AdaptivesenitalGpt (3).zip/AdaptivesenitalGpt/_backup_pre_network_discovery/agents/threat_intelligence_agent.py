from typing import List, Dict, Any
from knowledge_base.database import KnowledgeBaseDB


class ThreatIntelligenceAgent:
    """
    Threat Intelligence Agent enriching incidents with Threat Feeds,
    IP Reputation scores, and SQLite Knowledge Base IOC matching.
    """

    def __init__(self):
        self.db = KnowledgeBaseDB()

    def analyze(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        for incident in incidents:
            for alert in incident.get("alerts", []):
                event = alert.get("event", {})
                ip = event.get("source_ip", "127.0.0.1")

                # Lookup IP in SQLite Threat Intel KB
                kb_record = self.db.lookup_ioc(ip)

                if kb_record:
                    alert["threat_intel"] = {
                        "ip": ip,
                        "status": kb_record["status"],
                        "reputation": kb_record["reputation"],
                        "risk_score": kb_record["risk_score"],
                        "category": kb_record["threat_category"]
                    }
                else:
                    # Dynamic classification for unknown IPs
                    if ip.startswith("192.168.") or ip.startswith("10.") or ip.startswith("172."):
                        alert["threat_intel"] = {
                            "ip": ip,
                            "status": "Internal Intranet",
                            "reputation": "Trusted",
                            "risk_score": 10,
                            "category": "LAN Traffic"
                        }
                    elif ip == "127.0.0.1":
                        alert["threat_intel"] = {
                            "ip": ip,
                            "status": "Local Machine Loopback",
                            "reputation": "Trusted",
                            "risk_score": 0,
                            "category": "Loopback"
                        }
                    else:
                        alert["threat_intel"] = {
                            "ip": ip,
                            "status": "External Suspicious IP",
                            "reputation": "Untrusted / High Risk",
                            "risk_score": 85,
                            "category": "External Threat Actor"
                        }

        print(f"[INFO] Threat Intelligence Agent processed {len(incidents)} Incident(s).")
        return incidents