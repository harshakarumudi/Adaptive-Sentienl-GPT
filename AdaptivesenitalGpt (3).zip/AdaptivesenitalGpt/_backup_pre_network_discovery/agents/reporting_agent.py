from typing import List, Dict, Any
from datetime import datetime


class ReportingAgent:
    """
    Reporting Agent synthesizing technical incident data, threat intel,
    and response playbooks into formal SOC Incident Reports.
    """

    def generate(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        reports = []

        for incident in incidents:
            alerts = incident.get("alerts", [])
            first_alert = alerts[0] if alerts else {}
            event = first_alert.get("event", {})
            threat = first_alert.get("threat_intel", {})

            report = {
                "report_id": f"REP-{incident.get('incident_id', '000')}",
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": incident.get("incident_name", "Security Incident"),
                "severity": incident.get("severity", "High"),
                "confidence": incident.get("confidence", 90),
                "host": incident.get("affected_host", "UNKNOWN"),
                "user": incident.get("affected_user", "SYSTEM"),
                "source_ip": event.get("source_ip", "127.0.0.1"),
                "mitre_technique": event.get("mitre_technique", "T1059"),
                "mitre_tactic": event.get("mitre_tactic", "Execution"),
                "executive_summary": (
                    f"A {incident.get('severity')} severity security incident '{incident.get('incident_name')}' "
                    f"was identified on endpoint '{incident.get('affected_host')}' involving account '{incident.get('affected_user')}'. "
                    f"The multi-agent detection engine correlated {len(alerts)} related event alert(s) with {incident.get('confidence')}% confidence."
                ),
                "technical_analysis": (
                    f"Initial trigger event ID {event.get('event_id', 'N/A')} ({event.get('event_type', 'Process Creation')}) "
                    f"was registered at {event.get('timestamp', 'N/A')}. "
                    f"Process Name: {event.get('process_name', 'N/A')}. "
                    f"Command Line string: '{event.get('command_line', 'N/A')}'."
                ),
                "status": threat.get("status", "Suspicious"),
                "reputation": threat.get("reputation", "Untrusted"),
                "risk_score": threat.get("risk_score", 75),
                "recommendation": event.get("recommendation", "Execute containment playbook and isolate host."),
                "timestamp": datetime.now().isoformat()
            }

            reports.append(report)

        print(f"[INFO] Reporting Agent generated {len(reports)} formal SOC Incident Report(s).")
        return reports