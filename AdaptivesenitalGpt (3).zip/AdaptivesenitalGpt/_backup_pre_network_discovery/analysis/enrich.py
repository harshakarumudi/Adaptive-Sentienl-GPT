from typing import List, Dict, Any


class LogEnricher:
    """
    Enriches normalized events with MITRE Tactics, Risk Scores, and Asset Criticality.
    """

    TACTIC_MAP = {
        "T1110": "Credential Access",
        "T1110.001": "Credential Access",
        "T1059": "Execution",
        "T1059.001": "Execution",
        "T1136": "Persistence",
        "T1070": "Defense Evasion",
        "T1003.001": "Credential Access",
        "T1021": "Lateral Movement",
        "T1486": "Impact"
    }

    CRITICAL_ASSETS = ["DC-PRIMARY", "SRV-FILE-01", "EDGE-GATEWAY"]

    def enrich(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        enriched_logs = []

        for log in logs:
            technique = log.get("mitre_technique", "N/A")
            log["mitre_tactic"] = self.TACTIC_MAP.get(technique, "Unknown Tactic")

            # Asset criticality scoring
            hostname = log.get("hostname", "")
            if hostname in self.CRITICAL_ASSETS:
                log["asset_criticality"] = "High"
                log["risk_score"] = min(100, log.get("risk_score", 50) + 25)
            else:
                log["asset_criticality"] = "Standard"
                log["risk_score"] = log.get("risk_score", 20)

            enriched_logs.append(log)

        print(f"[INFO] LogEnricher enriched {len(enriched_logs)} events with tactics & asset criticality.")
        return enriched_logs


def enrich_events(logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return LogEnricher().enrich(logs)