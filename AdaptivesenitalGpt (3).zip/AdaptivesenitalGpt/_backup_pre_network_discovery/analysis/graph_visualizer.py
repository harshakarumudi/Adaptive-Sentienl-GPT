import networkx as nx
import plotly.graph_objects as go
import pandas as pd
from typing import List, Dict, Any, Tuple, Optional


class AttackGraphBuilder:
    """
    NetworkX-driven Graph Construction Engine for Security Incident Telemetry.
    Constructs GNN-ready directed graphs mapping real event evidence, endpoint metadata,
    detection rules, and MITRE ATT&CK techniques into multi-stage attack chains.
    """

    NODE_COLOR_MAP = {
        "Incident": "#dc2626",          # Bright Red
        "Endpoint": "#0284c7",          # Sky Blue
        "User": "#8b5cf6",              # Purple
        "Source IP": "#f59e0b",         # Amber
        "Process": "#10b981",           # Emerald
        "Event": "#38bdf8",             # Cyan
        "Detection Rule": "#06b6d4",     # Cyan
        "Detection Rule": "#06b6d4",    # Cyan
        "MITRE Technique": "#ef4444",   # Crimson
        "MITRE Tactic": "#34d399",      # Mint
    }

    SEVERITY_WEIGHTS = {
        "Critical": 4.0,
        "High": 3.0,
        "Medium": 2.0,
        "Low": 1.0,
        "Informational": 0.5
    }

    def __init__(self):
        self.graph = nx.DiGraph()

    def build_graph(
        self,
        incidents: Optional[List[Dict[str, Any]]] = None,
        logs: Optional[List[Dict[str, Any]]] = None,
        alerts: Optional[List[Dict[str, Any]]] = None
    ) -> nx.DiGraph:
        """
        Builds directed evidence graph from actual pipeline incidents, logs, and alerts.
        Preserves complete node & edge metadata.
        """
        self.graph.clear()

        # 1. Process Incident Data
        if incidents:
            for inc in incidents:
                inc_id = inc.get("incident_id", "INC-UNK")
                inc_name = inc.get("incident_name", "Security Incident")
                inc_sev = inc.get("severity", "Medium")
                inc_host = inc.get("affected_host", "UNKNOWN-HOST")
                inc_user = inc.get("affected_user", "SYSTEM")

                inc_node_id = f"INC:{inc_id}"
                self.graph.add_node(
                    inc_node_id,
                    id=inc_node_id,
                    type="Incident",
                    label=f"Incident: {inc_name}",
                    severity=inc_sev,
                    hostname=inc_host,
                    incident_id=inc_id,
                    confidence=inc.get("confidence", 80),
                    alert_count=inc.get("alert_count", 0)
                )

                # Endpoint Node
                host_node_id = f"HOST:{inc_host}"
                if not self.graph.has_node(host_node_id):
                    self.graph.add_node(
                        host_node_id,
                        id=host_node_id,
                        type="Endpoint",
                        label=f"Endpoint: {inc_host}",
                        hostname=inc_host,
                        severity=inc_sev
                    )

                # Edge: Incident -> Endpoint
                self.graph.add_edge(inc_node_id, host_node_id, relationship="associated_with", weight=2.0)

                # Process Alerts inside Incident
                inc_alerts = inc.get("alerts", [])
                prev_evt_node_id = None

                for alt_idx, alt in enumerate(inc_alerts):
                    evt = alt.get("event", {})
                    if not isinstance(evt, dict):
                        continue

                    evt_id = evt.get("event_id", 4624)
                    evt_type = evt.get("event_type", "Security Event")
                    evt_sev = evt.get("severity", inc_sev)
                    evt_source = evt.get("source", "unknown")
                    evt_ts = evt.get("timestamp", "N/A")
                    evt_user = evt.get("user") or inc_user
                    evt_src_ip = evt.get("source_ip", "127.0.0.1")
                    evt_proc = evt.get("process_name", "svchost.exe")
                    rule_id = evt.get("rule_id", "N/A")
                    rule_lvl = evt.get("rule_level", "N/A")
                    mitre_techs = evt.get("mitre_techniques", [])
                    if isinstance(mitre_techs, str):
                        mitre_techs = [mitre_techs]

                    evt_node_id = f"EVT:{inc_id}_{alt_idx}_{evt_id}"
                    self.graph.add_node(
                        evt_node_id,
                        id=evt_node_id,
                        type="Event",
                        label=f"Event {evt_id}: {evt_type}",
                        event_id=evt_id,
                        event_type=evt_type,
                        severity=evt_sev,
                        timestamp=evt_ts,
                        source=evt_source,
                        hostname=inc_host,
                        user=evt_user,
                        source_ip=evt_src_ip,
                        process_name=evt_proc,
                        rule_id=rule_id,
                        incident_id=inc_id
                    )

                    # Edge: Event -> Incident
                    self.graph.add_edge(evt_node_id, inc_node_id, relationship="correlated_into", weight=1.5)

                    # Edge: Host -> Event
                    self.graph.add_edge(host_node_id, evt_node_id, relationship="generated", weight=1.0)

                    # User Node & Edge
                    if evt_user:
                        user_node_id = f"USER:{evt_user}"
                        if not self.graph.has_node(user_node_id):
                            self.graph.add_node(user_node_id, id=user_node_id, type="User", label=f"User: {evt_user}", hostname=inc_host)
                        self.graph.add_edge(user_node_id, evt_node_id, relationship="triggered", weight=1.0)

                    # Source IP Node & Edge
                    if evt_src_ip and evt_src_ip != "127.0.0.1":
                        ip_node_id = f"IP:{evt_src_ip}"
                        if not self.graph.has_node(ip_node_id):
                            self.graph.add_node(ip_node_id, id=ip_node_id, type="Source IP", label=f"IP: {evt_src_ip}")
                        self.graph.add_edge(ip_node_id, evt_node_id, relationship="originating_from", weight=1.0)

                    # Process Node & Edge
                    if evt_proc:
                        proc_node_id = f"PROC:{evt_proc}"
                        if not self.graph.has_node(proc_node_id):
                            self.graph.add_node(proc_node_id, id=proc_node_id, type="Process", label=f"Process: {evt_proc}")
                        self.graph.add_edge(evt_node_id, proc_node_id, relationship="spawned", weight=1.0)

                    # Detection Rule Node & Edge
                    if rule_id:
                        rule_node_id = f"RULE:{rule_id}"
                        if not self.graph.has_node(rule_node_id):
                            self.graph.add_node(
                                rule_node_id,
                                id=rule_node_id,
                                type="Detection Rule",
                                label=f"Rule {rule_id}",
                                rule_id=rule_id,
                                rule_level=rule_lvl
                            )
                        self.graph.add_edge(evt_node_id, rule_node_id, relationship="matched", weight=1.2)

                    # MITRE Technique Nodes & Edges
                    tactic_name = evt.get("mitre_tactic", alt.get("mitre_tactic", "Execution"))
                    for tech in mitre_techs:
                        if tech and tech != "N/A":
                            tech_node_id = f"TECH:{tech}"
                            if not self.graph.has_node(tech_node_id):
                                self.graph.add_node(tech_node_id, id=tech_node_id, type="MITRE Technique", label=f"MITRE: {tech}", mitre_technique=tech)
                            self.graph.add_edge(evt_node_id, tech_node_id, relationship="mapped_to", weight=1.5)

                            # MITRE Tactic Node & Edge
                            if tactic_name:
                                tactic_node_id = f"TACTIC:{tactic_name}"
                                if not self.graph.has_node(tactic_node_id):
                                    self.graph.add_node(tactic_node_id, id=tactic_node_id, type="MITRE Tactic", label=f"Tactic: {tactic_name}")
                                self.graph.add_edge(tech_node_id, tactic_node_id, relationship="belongs_to", weight=1.0)

                    # Sequential Attack Chain Edge
                    if prev_evt_node_id:
                        self.graph.add_edge(prev_evt_node_id, evt_node_id, relationship="followed_by", weight=2.0)
                    prev_evt_node_id = evt_node_id

        # 2. Process Uncorrelated Standalone Logs if Provided
        elif logs:
            for idx, log in enumerate(logs):
                if not isinstance(log, dict):
                    continue
                host = log.get("hostname", "UNKNOWN-HOST")
                evt_id = log.get("event_id", 4624)
                evt_type = log.get("event_type", "Log Event")
                sev = log.get("severity", "Low")
                src = log.get("source", "unknown")
                ts = log.get("timestamp", "N/A")

                evt_node_id = f"EVT_STANDALONE_{idx}_{evt_id}"
                self.graph.add_node(
                    evt_node_id,
                    id=evt_node_id,
                    type="Event",
                    label=f"Event {evt_id}: {evt_type}",
                    event_id=evt_id,
                    severity=sev,
                    source=src,
                    timestamp=ts,
                    hostname=host
                )

                host_node_id = f"HOST:{host}"
                if not self.graph.has_node(host_node_id):
                    self.graph.add_node(host_node_id, id=host_node_id, type="Endpoint", label=f"Endpoint: {host}", hostname=host)
                self.graph.add_edge(host_node_id, evt_node_id, relationship="generated", weight=1.0)

        return self.graph

    def get_graph_stats(self) -> Dict[str, int]:
        """Calculates evidence metrics and node category counts from current graph."""
        if not self.graph or self.graph.number_of_nodes() == 0:
            return {
                "total_nodes": 0,
                "total_edges": 0,
                "endpoints_count": 0,
                "users_count": 0,
                "events_count": 0,
                "incidents_count": 0,
                "mitre_techniques_count": 0,
                "high_critical_nodes_count": 0
            }

        counts = {
            "total_nodes": self.graph.number_of_nodes(),
            "total_edges": self.graph.number_of_edges(),
            "endpoints_count": 0,
            "users_count": 0,
            "events_count": 0,
            "incidents_count": 0,
            "mitre_techniques_count": 0,
            "high_critical_nodes_count": 0
        }

        for n, data in self.graph.nodes(data=True):
            ntype = data.get("type")
            if ntype == "Endpoint":
                counts["endpoints_count"] += 1
            elif ntype == "User":
                counts["users_count"] += 1
            elif ntype == "Event":
                counts["events_count"] += 1
            elif ntype == "Incident":
                counts["incidents_count"] += 1
            elif ntype == "MITRE Technique":
                counts["mitre_techniques_count"] += 1

            if data.get("severity") in ("High", "Critical", "HIGH", "CRITICAL"):
                counts["high_critical_nodes_count"] += 1

        return counts

    def export_gnn_features(self) -> Dict[str, Any]:
        """
        Extracts GNN-ready node feature matrices, COO edge index, and relation features
        for downstream Graph Neural Network (GNN) model integration.
        Does NOT execute GNN inference directly.
        """
        if not self.graph or self.graph.number_of_nodes() == 0:
            return {
                "node_features": [],
                "edge_index": ([], []),
                "edge_features": [],
                "node_mapping": {},
                "num_nodes": 0,
                "num_edges": 0
            }

        node_types = list(self.NODE_COLOR_MAP.keys())
        type_to_code = {t: i for i, t in enumerate(node_types)}

        node_list = list(self.graph.nodes())
        node_mapping = {node_id: idx for idx, node_id in enumerate(node_list)}

        node_features = []
        for node_id in node_list:
            data = self.graph.nodes[node_id]
            ntype = data.get("type", "Event")
            type_code = type_to_code.get(ntype, 0)
            sev_code = self.SEVERITY_WEIGHTS.get(data.get("severity", "Low"), 1.0)
            in_deg = self.graph.in_degree(node_id)
            out_deg = self.graph.out_degree(node_id)

            node_features.append({
                "node_id": node_id,
                "node_index": node_mapping[node_id],
                "type_code": type_code,
                "severity_weight": sev_code,
                "in_degree": in_deg,
                "out_degree": out_deg,
                "total_degree": in_deg + out_deg
            })

        src_indices = []
        dst_indices = []
        edge_features = []

        rel_type_map = {
            "generated": 0,
            "triggered": 1,
            "originating_from": 2,
            "spawned": 3,
            "matched": 4,
            "mapped_to": 5,
            "belongs_to": 6,
            "correlated_into": 7,
            "associated_with": 8,
            "followed_by": 9
        }

        for u, v, edata in self.graph.edges(data=True):
            src_indices.append(node_mapping[u])
            dst_indices.append(node_mapping[v])
            rel = edata.get("relationship", "associated_with")
            edge_features.append({
                "source_index": node_mapping[u],
                "target_index": node_mapping[v],
                "relationship": rel,
                "relationship_code": rel_type_map.get(rel, 0),
                "weight": edata.get("weight", 1.0)
            })

        return {
            "node_features": node_features,
            "edge_index": (src_indices, dst_indices),
            "edge_features": edge_features,
            "node_mapping": node_mapping,
            "num_nodes": len(node_list),
            "num_edges": len(src_indices)
        }

    def filter_subgraph(
        self,
        endpoint: Optional[str] = None,
        severity: Optional[str] = None,
        source: Optional[str] = None,
        incident_id: Optional[str] = None
    ) -> nx.DiGraph:
        """Filters network graph by endpoint, severity, source, or incident ID."""
        if not self.graph:
            return nx.DiGraph()

        sub_nodes = set()
        for n, data in self.graph.nodes(data=True):
            keep = True
            if endpoint and endpoint != "ALL" and data.get("hostname") and data.get("hostname") != endpoint:
                keep = False
            if severity and severity != "ALL" and data.get("severity") and data.get("severity") != severity:
                keep = False
            if source and source != "ALL" and data.get("source") and data.get("source") != source:
                keep = False
            if incident_id and incident_id != "ALL" and data.get("incident_id") and data.get("incident_id") != incident_id:
                keep = False

            if keep:
                sub_nodes.add(n)

        # Include 1-hop neighbors of matched nodes to preserve context
        expanded_nodes = set(sub_nodes)
        for n in sub_nodes:
            expanded_nodes.update(self.graph.predecessors(n))
            expanded_nodes.update(self.graph.successors(n))

        return self.graph.subgraph(expanded_nodes).copy()


def generate_attack_graph_figure(
    incidents: Optional[List[Dict[str, Any]]] = None,
    logs: Optional[List[Dict[str, Any]]] = None,
    source_filter: Optional[str] = None,
    severity_filter: Optional[str] = None
) -> go.Figure:
    """
    Generates dynamic interactive Plotly Attack Graph / GNN-Ready Topology from real evidence.
    Supports zoom, pan, hover node inspection, and severity color coding.
    """
    builder = AttackGraphBuilder()
    G = builder.build_graph(incidents=incidents, logs=logs)

    if source_filter or severity_filter:
        G = builder.filter_subgraph(source=source_filter, severity=severity_filter)

    if G.number_of_nodes() == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="<b>No attack graph evidence available</b><br>No matching security incident telemetry found under active filter.",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16, color="#94a3b8")
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#f8fafc")
        )
        return fig

    # 2D Layout Calculation using NetworkX Spring Layout with robust fallback
    try:
        pos = nx.spring_layout(G, k=1.2, seed=42)
    except Exception:
        try:
            pos = nx.circular_layout(G)
        except Exception:
            pos = {node: (float(i % 5), float(i // 5)) for i, node in enumerate(G.nodes())}

    # Edge Traces
    edge_x = []
    edge_y = []
    edge_texts = []

    for u, v, data in G.edges(data=True):
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
        edge_texts.append(f"{u} → {v} ({data.get('relationship', 'rel')})")

    edge_trace = go.Scatter(
        x=edge_x,
        y=edge_y,
        line=dict(width=2, color='#475569'),
        hoverinfo='none',
        mode='lines'
    )

    # Node Traces
    node_x = []
    node_y = []
    node_colors = []
    node_labels = []
    node_hovers = []
    node_sizes = []

    for node_id, data in G.nodes(data=True):
        x, y = pos[node_id]
        node_x.append(x)
        node_y.append(y)
        ntype = data.get("type", "Event")
        node_colors.append(builder.NODE_COLOR_MAP.get(ntype, "#38bdf8"))
        node_labels.append(data.get("label", node_id))

        hover_str = (
            f"<b>{data.get('label', node_id)}</b><br>"
            f"Type: {ntype}<br>"
            f"Severity: {data.get('severity', 'N/A')}<br>"
            f"Host: {data.get('hostname', 'N/A')}<br>"
            f"Timestamp: {data.get('timestamp', 'N/A')}<br>"
            f"Source: {data.get('source', 'N/A')}"
        )
        node_hovers.append(hover_str)

        # Size scaling by node type/importance
        if ntype == "Incident":
            node_sizes.append(34)
        elif ntype == "Endpoint":
            node_sizes.append(28)
        elif ntype in ("MITRE Technique", "Detection Rule"):
            node_sizes.append(24)
        else:
            node_sizes.append(18)

    node_trace = go.Scatter(
        x=node_x,
        y=node_y,
        mode='markers+text',
        hoverinfo='text',
        text=node_labels,
        textposition="top center",
        hovertext=node_hovers,
        marker=dict(
            showscale=False,
            color=node_colors,
            size=node_sizes,
            line=dict(width=2, color='#ffffff')
        )
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        title=dict(text="<b>🕸️ Interactive Attack Graph & GNN-Ready Evidence Topology</b>", font=dict(size=16)),
        showlegend=False,
        hovermode='closest',
        margin=dict(b=20, l=20, r=20, t=50),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#f8fafc")
    )

    return fig


def generate_attack_timeline(
    incidents: Optional[List[Dict[str, Any]]] = None,
    logs: Optional[List[Dict[str, Any]]] = None
) -> List[Dict[str, Any]]:
    """
    Generates chronologically ordered attack timeline events extracted from actual telemetry.
    """
    timeline_entries = []

    if incidents:
        for inc in incidents:
            inc_name = inc.get("incident_name", "Incident")
            inc_host = inc.get("affected_host", "N/A")
            inc_sev = inc.get("severity", "Medium")

            for alt in inc.get("alerts", []):
                evt = alt.get("event", {})
                if isinstance(evt, dict):
                    ts = evt.get("timestamp") or evt.get("timeCreated") or "N/A"
                    evt_id = evt.get("event_id", 4624)
                    evt_type = evt.get("event_type", "Security Event")
                    tech = alt.get("mitre_technique") or evt.get("mitre_techniques")
                    if isinstance(tech, list):
                        tech = ", ".join(tech)

                    evt_sev = evt.get("severity") or inc_sev

                    timeline_entries.append({
                        "timestamp": str(ts),
                        "event": f"Event {evt_id} ({evt_type})",
                        "technique": str(tech or "N/A"),
                        "incident": inc_name,
                        "hostname": inc_host,
                        "severity": evt_sev,
                        "source": evt.get("source", "unknown")
                    })

    elif logs:
        for log in logs:
            if isinstance(log, dict):
                ts = log.get("timestamp", "N/A")
                evt_id = log.get("event_id", 4624)
                evt_type = log.get("event_type", "Log Event")
                tech = log.get("mitre_techniques", "N/A")
                if isinstance(tech, list):
                    tech = ", ".join(tech)

                timeline_entries.append({
                    "timestamp": str(ts),
                    "event": f"Event {evt_id} ({evt_type})",
                    "technique": str(tech),
                    "incident": "Standalone Telemetry",
                    "hostname": log.get("hostname", "N/A"),
                    "severity": log.get("severity", "Low"),
                    "source": log.get("source", "unknown")
                })

    # Sort chronologically
    timeline_entries.sort(key=lambda x: x["timestamp"])
    return timeline_entries
