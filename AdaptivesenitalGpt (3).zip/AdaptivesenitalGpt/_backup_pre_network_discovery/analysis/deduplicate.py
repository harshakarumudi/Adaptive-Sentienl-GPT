from typing import List, Dict, Any, Tuple


def get_event_identity_key(log: Dict[str, Any]) -> Tuple[Any, ...]:
    """
    Computes a safe deduplication identity key for an event.
    Includes record_offset and record_id when available so separate legitimate
    records in the log stream are never discarded solely because their raw text
    or second-precision timestamp matches.
    """
    return (
        log.get("source"),
        log.get("timestamp"),
        log.get("event_id"),
        log.get("hostname"),
        log.get("user"),
        log.get("source_ip"),
        log.get("remote_peer_ip"),
        log.get("command_line"),
        log.get("description") or log.get("message"),
        log.get("record_id"),
        log.get("record_offset"),
    )


class LogDeduplicator:
    """
    Deduplicates high-frequency noise logs while preserving threat attack sequences
    and distinct endpoint records.
    """

    def remove_duplicates(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        unique_logs = []
        seen = set()

        for log in logs:
            key = get_event_identity_key(log)
            if key not in seen:
                seen.add(key)
                unique_logs.append(log)

        removed_count = len(logs) - len(unique_logs)
        print(f"[INFO] LogDeduplicator removed {removed_count} duplicate event(s). {len(unique_logs)} unique events remain.")
        return unique_logs


def deduplicate_events(logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return LogDeduplicator().remove_duplicates(logs)