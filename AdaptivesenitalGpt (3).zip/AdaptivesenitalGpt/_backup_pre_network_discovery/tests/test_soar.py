import unittest
from pathlib import Path
import tempfile
import shutil

from soar.action_registry import SOARActionRegistry
from soar.audit_logger import SOARAuditLogger
from soar.executor import MockSOARExecutor
from soar.decision_engine import SOARDecisionEngine


class TestSOARModule(unittest.TestCase):

    def setUp(self):
        self.registry = SOARActionRegistry()
        self.engine = SOARDecisionEngine(registry=self.registry)
        self.executor = MockSOARExecutor(registry=self.registry)
        self.temp_dir = tempfile.mkdtemp()
        self.audit_db_path = str(Path(self.temp_dir) / "test_soar_audit.db")
        self.audit_logger = SOARAuditLogger(db_path=self.audit_db_path)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_action_registry_allowlist(self):
        """Test action registry allows only registered actions and rejects arbitrary commands."""
        self.assertTrue(self.registry.is_action_allowed("ISOLATE_HOST"))
        self.assertTrue(self.registry.is_action_allowed("BLOCK_IP"))
        self.assertTrue(self.registry.is_action_allowed("LOCK_USER"))
        self.assertTrue(self.registry.is_action_allowed("COLLECT_FORENSIC_ARTIFACTS"))
        self.assertFalse(self.registry.is_action_allowed("EXECUTE_RCE"))
        self.assertFalse(self.registry.is_action_allowed("RUN_SHELL_SCRIPT"))
        self.assertFalse(self.registry.is_action_allowed("rm -rf /"))
        self.assertFalse(self.registry.is_action_allowed("cmd.exe /c del system32"))

    def test_target_validation_isolate_host(self):
        """Test target validation for host isolation."""
        valid, msg = self.registry.validate_action_request("ISOLATE_HOST", "WORKSTATION-01")
        self.assertTrue(valid)

        invalid_empty, msg = self.registry.validate_action_request("ISOLATE_HOST", "")
        self.assertFalse(invalid_empty)

        invalid_wildcard, msg = self.registry.validate_action_request("ISOLATE_HOST", "*")
        self.assertFalse(invalid_wildcard)

    def test_target_validation_block_ip(self):
        """Test target validation for IP blocking."""
        valid_ipv4, msg = self.registry.validate_action_request("BLOCK_IP", "198.51.100.45")
        self.assertTrue(valid_ipv4)

        valid_ipv6, msg = self.registry.validate_action_request("BLOCK_IP", "2001:db8::1")
        self.assertTrue(valid_ipv6)

        invalid_ip, msg = self.registry.validate_action_request("BLOCK_IP", "999.999.999.999")
        self.assertFalse(invalid_ip)

        loopback_ip, msg = self.registry.validate_action_request("BLOCK_IP", "127.0.0.1")
        self.assertFalse(loopback_ip)

    def test_target_validation_lock_user(self):
        """Test target validation for user account locking."""
        valid, msg = self.registry.validate_action_request("LOCK_USER", "harsha_admin")
        self.assertTrue(valid)

        invalid_empty, msg = self.registry.validate_action_request("LOCK_USER", "   ")
        self.assertFalse(invalid_empty)

    def test_target_validation_forensics(self):
        """Test target validation for forensic artifact collection."""
        valid, msg = self.registry.validate_action_request("COLLECT_FORENSIC_ARTIFACTS", "WORKSTATION-01", {"artifact_type": "triage_package"})
        self.assertTrue(valid)

        invalid_type, msg = self.registry.validate_action_request("COLLECT_FORENSIC_ARTIFACTS", "WORKSTATION-01", {"artifact_type": "malicious_script"})
        self.assertFalse(invalid_type)

    def test_decision_engine_recommendations(self):
        """Test SOAR decision engine generates allowlisted recommendations for incidents."""
        incident = {
            "incident_id": "INC-TEST-SOAR",
            "incident_name": "LSASS Credential Access",
            "severity": "Critical",
            "affected_host": "WORKSTATION-01",
            "affected_user": "admin_user",
            "alerts": [
                {
                    "event": {
                        "event_id": 10,
                        "source_ip": "198.51.100.77",
                        "rule_id": "60800",
                        "mitre_techniques": ["T1003"]
                    }
                }
            ]
        }

        recs = self.engine.evaluate_incident(incident, gnn_risk_score=0.92)
        self.assertGreater(len(recs), 0)

        action_ids = [r["action_id"] for r in recs]
        self.assertIn("ISOLATE_HOST", action_ids)
        self.assertIn("COLLECT_FORENSIC_ARTIFACTS", action_ids)
        self.assertIn("BLOCK_IP", action_ids)
        self.assertIn("LOCK_USER", action_ids)

        for r in recs:
            self.assertTrue(self.registry.is_action_allowed(r["action_id"]))
            self.assertTrue(r["dry_run"])
            self.assertIn("DRY RUN", r["dry_run_preview"])

    def test_executor_dry_run_mode(self):
        """Test mock executor dry run mode generates preview without changes."""
        res = self.executor.execute_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=True)
        self.assertEqual(res["status"], "DRY_RUN")
        self.assertEqual(res["verification_status"], "VERIFIED_SUCCESS")
        self.assertTrue(res["dry_run"])
        self.assertIn("DRY RUN — NO SYSTEM CHANGE", res["details"]["preview"])

    def test_executor_simulated_execution(self):
        """Test mock executor simulated execution mode."""
        res = self.executor.execute_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=False)
        self.assertEqual(res["status"], "EXECUTED")
        self.assertEqual(res["verification_status"], "VERIFIED_SUCCESS")
        self.assertFalse(res["dry_run"])
        self.assertIn("SIMULATED HOST ISOLATION", res["details"]["summary"])

    def test_executor_rollback_reversible_action(self):
        """Test rollback of reversible action (ISOLATE_HOST -> UNISOLATE_HOST)."""
        res = self.executor.rollback_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=False)
        self.assertEqual(res["status"], "ROLLED_BACK")
        self.assertEqual(res["action_id"], "UNISOLATE_HOST")
        self.assertEqual(res["verification_status"], "VERIFIED_SUCCESS")

    def test_executor_rollback_non_reversible_action(self):
        """Test rollback rejection for non-reversible action (COLLECT_FORENSIC_ARTIFACTS)."""
        res = self.executor.rollback_action("COLLECT_FORENSIC_ARTIFACTS", "WORKSTATION-01", dry_run=False)
        self.assertEqual(res["status"], "REJECTED")
        self.assertEqual(res["rollback_status"], "NON_REVERSIBLE")
        self.assertIn("NON-REVERSIBLE", res["error_message"])

    def test_audit_logger_recording_and_retrieval(self):
        """Test SOAR audit logger stores and queries audit events."""
        record = {
            "incident_id": "INC-AUDIT-01",
            "action_id": "BLOCK_IP",
            "analyst_approval": "APPROVED",
            "analyst_user": "soc_analyst_1",
            "target": "198.51.100.99",
            "action_status": "EXECUTED",
            "verification_result": "VERIFIED_SUCCESS",
            "rollback_status": "AVAILABLE",
            "gnn_score": 0.88,
            "rule_id": "60106",
            "mitre_technique": "T1110",
            "dry_run": False
        }

        audit_id = self.audit_logger.log_event(record)
        self.assertTrue(audit_id.startswith("AUDIT-"))

        records = self.audit_logger.get_audit_records(incident_id="INC-AUDIT-01")
        self.assertEqual(len(records), 1)
        rec = records[0]
        self.assertEqual(rec["action_id"], "BLOCK_IP")
        self.assertEqual(rec["target"], "198.51.100.99")
        self.assertEqual(rec["analyst_approval"], "APPROVED")
        self.assertFalse(rec["dry_run"])

    def test_rejected_unknown_action_execution(self):
        """Test executor rejects unregistered arbitrary action ID."""
        res = self.executor.execute_action("UNREGISTERED_ACTION", "TARGET-01", dry_run=True)
        self.assertEqual(res["status"], "REJECTED")
        self.assertEqual(res["verification_status"], "VERIFIED_FAILURE")
        self.assertIn("ACTION REJECTED", res["error_message"])

    def test_full_e2e_soar_lifecycle_verification(self):
        """
        Phase 7.1 End-to-End SOAR Lifecycle Verification.
        Verifies complete path: Incident -> GNN score -> Decision Engine -> Validation -> Analyst Approval -> Dry Run -> Simulation -> Verification -> Audit DB -> Rollback.
        """
        # 1. Input Incident Metadata
        incident = {
            "incident_id": "INC-HARSHA-E2E-VERIFY",
            "incident_name": "Harsha Endpoint LSASS Dumping",
            "severity": "Critical",
            "affected_host": "Harsha",
            "affected_user": "HarshaAdmin",
            "alerts": [
                {
                    "event": {
                        "event_id": 10,
                        "source_ip": "198.51.100.22",
                        "rule_id": "60800",
                        "mitre_techniques": ["T1003"]
                    }
                }
            ]
        }
        gnn_score = 0.9450

        # 2. Decision Engine Recommendation Generation
        recs = self.engine.evaluate_incident(incident, gnn_risk_score=gnn_score)
        self.assertGreater(len(recs), 0)

        iso_rec = next(r for r in recs if r["action_id"] == "ISOLATE_HOST")
        self.assertEqual(iso_rec["incident_id"], "INC-HARSHA-E2E-VERIFY")
        self.assertEqual(iso_rec["action_id"], "ISOLATE_HOST")
        self.assertEqual(iso_rec["target"], "Harsha")
        self.assertEqual(iso_rec["gnn_risk_score"], 0.9450)
        self.assertTrue("rule_id" in iso_rec)
        self.assertEqual(iso_rec["mitre_technique"], "T1003")
        self.assertIn("Recommended network isolation", iso_rec["why_recommended"])

        # 3. Action Registry Pass-Through Validation
        valid, msg = self.registry.validate_action_request(iso_rec["action_id"], iso_rec["target"])
        self.assertTrue(valid)
        self.assertEqual(msg, "VALID")

        # 4. Unapproved Action Prevention
        audit_pending = {
            "incident_id": incident["incident_id"],
            "action_id": iso_rec["action_id"],
            "analyst_approval": "PENDING",
            "target": iso_rec["target"],
            "action_status": "PENDING",
            "verification_result": "UNVERIFIED",
            "rollback_status": "NOT_APPLICABLE",
            "gnn_score": gnn_score,
            "dry_run": True
        }
        self.audit_logger.log_event(audit_pending)
        recs_db = self.audit_logger.get_audit_records(incident_id=incident["incident_id"])
        self.assertEqual(recs_db[0]["analyst_approval"], "PENDING")
        self.assertEqual(recs_db[0]["action_status"], "PENDING")

        # 5. Reject Action Workflow
        audit_reject = dict(audit_pending, analyst_approval="REJECTED", action_status="REJECTED", error_message="Rejected by analyst")
        self.audit_logger.log_event(audit_reject)
        recs_db = self.audit_logger.get_audit_records(incident_id=incident["incident_id"])
        self.assertEqual(recs_db[0]["analyst_approval"], "REJECTED")
        self.assertEqual(recs_db[0]["action_status"], "REJECTED")

        # 6. Approve Action Workflow
        audit_approve = dict(audit_pending, analyst_approval="APPROVED", action_status="APPROVED")
        self.audit_logger.log_event(audit_approve)

        # 7. Dry-Run Execution
        dry_res = self.executor.execute_action(iso_rec["action_id"], iso_rec["target"], dry_run=True)
        self.assertEqual(dry_res["status"], "DRY_RUN")
        self.assertIn("DRY RUN — NO SYSTEM CHANGE", dry_res["details"]["preview"])

        # 8. Simulated Execution
        sim_res = self.executor.execute_action(iso_rec["action_id"], iso_rec["target"], dry_run=False)
        self.assertEqual(sim_res["status"], "EXECUTED")
        self.assertIn("SIMULATED HOST ISOLATION", sim_res["details"]["summary"])

        # 9. Verification Engine
        self.assertEqual(sim_res["verification_status"], "VERIFIED_SUCCESS")

        # 10. Database Persistence Verification
        audit_final = {
            "incident_id": incident["incident_id"],
            "action_id": iso_rec["action_id"],
            "analyst_approval": "APPROVED",
            "target": iso_rec["target"],
            "action_status": sim_res["status"],
            "verification_result": sim_res["verification_status"],
            "rollback_status": sim_res["rollback_status"],
            "gnn_score": gnn_score,
            "rule_id": "60800",
            "mitre_technique": "T1003",
            "dry_run": False,
            "details": sim_res["details"]
        }
        self.audit_logger.log_event(audit_final)
        db_check = self.audit_logger.get_audit_records(incident_id=incident["incident_id"])
        self.assertEqual(len(db_check), 4) # Pending -> Rejected -> Approved -> Executed
        self.assertEqual(db_check[0]["action_status"], "EXECUTED")
        self.assertEqual(db_check[0]["verification_result"], "VERIFIED_SUCCESS")

        # 11. Rollback Execution for Reversible Actions
        for act_id, target in [("ISOLATE_HOST", "Harsha"), ("BLOCK_IP", "198.51.100.22"), ("LOCK_USER", "HarshaAdmin")]:
            rb_res = self.executor.rollback_action(act_id, target, dry_run=False)
            self.assertEqual(rb_res["status"], "ROLLED_BACK")
            self.assertEqual(rb_res["verification_status"], "VERIFIED_SUCCESS")

        # 12. Non-Reversible Action Rollback Rejection
        rb_non_rev = self.executor.rollback_action("COLLECT_FORENSIC_ARTIFACTS", "Harsha", dry_run=False)
        self.assertEqual(rb_non_rev["status"], "REJECTED")
        self.assertEqual(rb_non_rev["rollback_status"], "NON_REVERSIBLE")

        # 13. Invalid Targets Rejections
        self.assertFalse(self.registry.validate_action_request("BLOCK_IP", "999.999.999.999")[0])
        self.assertFalse(self.registry.validate_action_request("BLOCK_IP", "127.0.0.1")[0])
        self.assertFalse(self.registry.validate_action_request("ISOLATE_HOST", "*")[0])
        self.assertFalse(self.registry.validate_action_request("ISOLATE_HOST", "")[0])

        # 14. Arbitrary Shell Command Prohibition
        self.assertFalse(self.registry.validate_action_request("rm -rf /", "Harsha")[0])
        self.assertFalse(self.registry.validate_action_request("cmd.exe /c del system32", "Harsha")[0])


if __name__ == "__main__":
    unittest.main()
