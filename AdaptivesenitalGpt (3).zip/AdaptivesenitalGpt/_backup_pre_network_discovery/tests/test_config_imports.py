import unittest


class TestConfigImports(unittest.TestCase):

    def test_settings_imports(self):
        from config.settings import (
            RECEIVER_HOST,
            RECEIVER_PORT,
            DEFAULT_ENDPOINT_ID,
            COLLECTOR_VERSION,
            PROJECT_TOKEN,
            ENDPOINT_STATUS_FILE_PATH,
            HEARTBEAT_TIMEOUT_SECONDS,
        )

        self.assertIsNotNone(RECEIVER_HOST)
        self.assertEqual(RECEIVER_HOST, "0.0.0.0")
        self.assertIsInstance(RECEIVER_PORT, int)
        self.assertEqual(RECEIVER_PORT, 5000)
        self.assertIsNotNone(DEFAULT_ENDPOINT_ID)
        self.assertIsNotNone(COLLECTOR_VERSION)
        self.assertIsNotNone(PROJECT_TOKEN)
        self.assertIsNotNone(ENDPOINT_STATUS_FILE_PATH)
        self.assertIsInstance(HEARTBEAT_TIMEOUT_SECONDS, int)
        self.assertEqual(HEARTBEAT_TIMEOUT_SECONDS, 30)


if __name__ == "__main__":
    unittest.main()
