import unittest
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent
from agents.feedback_agent import FeedbackAgent


class TestAgentsLayer(unittest.TestCase):

    def test_detection_agent(self):
        logs = [{
            "timestamp": "2026-07-29T12:00:00",
            "source": "Windows",
            "event_id": 4625,
            "hostname": "HOST-1",
            "user": "user1",
            "source_ip": "1.1.1.1",
            "process_name": "N/A",
            "command_line": "N/A",
            "mitre_technique": "T1110"
        }]

        detector = DetectionAgent()
        alerts = detector.detect(logs)

        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0]["alert_name"], "Failed Logon Attempt")

    def test_correlation_agent(self):
        alerts = [
            {"alert_name": "Failed Logon Attempt", "severity": "Medium", "confidence": 85, "event": {"hostname": "HOST-1", "user": "user1", "source_ip": "1.1.1.1"}},
            {"alert_name": "Failed Logon Attempt", "severity": "Medium", "confidence": 85, "event": {"hostname": "HOST-1", "user": "user1", "source_ip": "1.1.1.1"}},
            {"alert_name": "Failed Logon Attempt", "severity": "Medium", "confidence": 85, "event": {"hostname": "HOST-1", "user": "user1", "source_ip": "1.1.1.1"}}
        ]

        correlator = CorrelationAgent()
        incidents = correlator.correlate(alerts)

        self.assertGreaterEqual(len(incidents), 1)
        self.assertIn("Brute Force", incidents[0]["incident_name"])

    def test_feedback_agent(self):
        fb_agent = FeedbackAgent()
        entry = fb_agent.process_feedback(
            incident_id="INC-TEST",
            alert_name="Test Alert",
            analyst_verdict="True Positive",
            override_severity="Critical",
            adjusted_confidence=99,
            notes="Verified malware execution"
        )

        self.assertEqual(entry["incident_id"], "INC-TEST")
        self.assertEqual(entry["analyst_verdict"], "True Positive")


if __name__ == "__main__":
    unittest.main()
