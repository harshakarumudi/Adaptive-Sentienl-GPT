import unittest
import time
import uuid
import tempfile
import shutil
from pathlib import Path

from analysis.parser import NXLogReader
from analysis.normalize import LogNormalizer, normalize_events
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent
from config.settings import NXLOG_FILE_PATH, SUJITH_IP, HARSHA_IP


class TestPhase1NXLogIngestion(unittest.TestCase):
    """
    Automated verification suite for Phase 1: Real NXLog Ingestion & Diagnostic Probes.
    1. Extraction and end-to-end trace of historical marker SECTOR1_RECEIVER_TEST_002.
    2. Ingestion and flow of newly injected unique marker PHASE1_VERIFIED_TEST_<timestamp>.
    3. Non-advancement of cursor during replay (no cursor stranding).
    4. Clean handling of incomplete trailing records at EOF.
    5. Exact parsing of hostname, event ID, timestamp, and unforced source IP.
    """

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.temp_log = self.temp_dir / "windows-events.log"
        self.temp_cursor = self.temp_dir / "nxlog_cursor.json"
        self.reader = NXLogReader(log_file=self.temp_log, cursor_file=self.temp_cursor)
        self.detector = DetectionAgent()
        self.correlator = CorrelationAgent()

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_01_extract_and_trace_sector1_receiver_test_002(self):
        """
        Trace SECTOR1_RECEIVER_TEST_002:
        Receiver file -> Parser -> Detection Agent -> Correlation Agent -> Low Severity Diagnostic Probe.
        """
        raw_line = r"2026-10-10 02:49:50 Harsha INFO 1000 HARSHA\Harsha SECTOR1_RECEIVER_TEST_002"

        # 1. Parsing
        event = self.reader.parse_line(raw_line)
        self.assertIsNotNone(event)
        self.assertEqual(event["hostname"], "Harsha")
        self.assertEqual(event["user"], "Harsha")
        self.assertEqual(event["event_id"], 1000)
        self.assertEqual(event["source_ip"], "N/A", "Should not force endpoint IP when no source IP is in event")
        self.assertEqual(event["severity"], "Low")
        self.assertTrue(event.get("is_diagnostic"), "Diagnostic marker must be identified")
        self.assertEqual(event["event_type"], "Diagnostic Telemetry Probe")

        # 2. Normalization
        norm_events = normalize_events([event])
        self.assertEqual(len(norm_events), 1)
        norm_evt = norm_events[0]
        self.assertEqual(norm_evt["severity"], "Low")
        self.assertEqual(norm_evt["mitre_technique"], "N/A")
        self.assertTrue(norm_evt.get("is_diagnostic"))

        # 3. Detection Agent
        alerts = self.detector.detect(norm_events)
        self.assertEqual(len(alerts), 1)
        alert = alerts[0]
        self.assertEqual(alert["alert_name"], "Diagnostic Telemetry Verification Probe")
        self.assertEqual(alert["severity"], "Low")
        self.assertTrue(alert.get("is_diagnostic"))
        self.assertEqual(alert["confidence"], 100)

        # 4. Correlation Agent
        incidents = self.correlator.correlate(alerts)
        self.assertEqual(len(incidents), 1)
        inc = incidents[0]
        self.assertTrue(inc["incident_id"].startswith("INC-DIAG-"))
        self.assertEqual(inc["incident_name"], "Diagnostic Telemetry Verification Probe (Harsha)")
        self.assertEqual(inc["severity"], "Low", "Diagnostic probe must NOT be classified as High/Critical")
        self.assertTrue(inc.get("is_diagnostic"))
        self.assertEqual(inc["affected_host"], "Harsha")
        self.assertEqual(inc["affected_user"], "Harsha")

    def test_02_newly_injected_marker_incremental_flow(self):
        """
        Inject a unique diagnostic marker and verify incremental ingestion through the full pipeline.
        """
        unique_marker = f"PHASE1_VERIFIED_TEST_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        log_line = f"2026-10-10 10:30:00 Harsha INFO 1000 HARSHA\\Harsha {unique_marker}\n"

        with open(self.temp_log, "w", encoding="utf-8") as f:
            f.write(log_line)

        # Read incrementally
        events = self.reader.read_events(incremental=True)
        self.assertEqual(len(events), 1)
        evt = events[0]
        self.assertIn(unique_marker, evt["description"])
        self.assertTrue(evt["is_diagnostic"])

        # Detection & Correlation
        alerts = self.detector.detect([evt])
        self.assertEqual(len(alerts), 1)
        self.assertTrue(alerts[0]["is_diagnostic"])

        incidents = self.correlator.correlate(alerts)
        self.assertEqual(len(incidents), 1)
        self.assertEqual(incidents[0]["severity"], "Low")

        # Second incremental read should yield 0 new events
        events_again = self.reader.read_events(incremental=True)
        self.assertEqual(len(events_again), 0, "Incremental cursor must prevent duplicate reads")

    def test_03_non_advancement_of_cursor_during_replay(self):
        """
        Verify that replay_events does not modify or advance the incremental cursor.
        """
        line1 = "2026-10-10 10:00:00 Harsha INFO 4624 Event 4624 Logon\n"
        line2 = "2026-10-10 10:01:00 Harsha INFO 4688 Event 4688 Process\n"

        with open(self.temp_log, "w", encoding="utf-8") as f:
            f.write(line1)

        # Read first line incrementally
        self.reader.read_events(incremental=True)
        initial_cursor = self.reader.load_cursor()
        self.assertGreater(initial_cursor, 0)

        # Replay events
        replayed = self.reader.replay_events(from_offset=0)
        self.assertEqual(len(replayed), 1)

        # Cursor must remain strictly unchanged after replay
        cursor_after_replay = self.reader.load_cursor()
        self.assertEqual(cursor_after_replay, initial_cursor, "Replay must NOT advance or modify the cursor")

        # Now append second line and verify normal incremental ingestion still works
        with open(self.temp_log, "a", encoding="utf-8") as f:
            f.write(line2)

        new_events = self.reader.read_events(incremental=True)
        self.assertEqual(len(new_events), 1)
        self.assertEqual(new_events[0]["event_id"], 4688)

    def test_04_incomplete_trailing_record_at_eof_handling(self):
        """
        Verify that incomplete records at EOF (e.g. written mid-packet) are not consumed
        partially or causing cursor corruption.
        """
        complete_line = "2026-10-10 10:00:00 Harsha INFO 4624 Logon Success\n"
        partial_line = "2026-10-10 10:01:00 Harsha INFO 4688 Partial Command Line with no new"

        with open(self.temp_log, "wb") as f:
            f.write(complete_line.encode("utf-8") + partial_line.encode("utf-8"))

        # Read incrementally: should only consume the complete first line
        events = self.reader.read_events(incremental=True)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_id"], 4624)

        # Cursor should be at the end of the first complete line, NOT at the end of partial_line
        expected_offset = len(complete_line.encode("utf-8"))
        self.assertEqual(self.reader.load_cursor(), expected_offset)

        # Complete the partial line
        with open(self.temp_log, "ab") as f:
            f.write(b"line here\n")

        # Next read should now cleanly pick up the full second line
        events_next = self.reader.read_events(incremental=True)
        self.assertEqual(len(events_next), 1)
        self.assertEqual(events_next[0]["event_id"], 4688)
        self.assertIn("Partial Command Line with no newline here", events_next[0]["description"])

    def test_05_exact_ip_and_hostname_parsing_without_forcing(self):
        """
        Verify exact parsing of hostname and source IP:
        1. No IP in event -> source_ip == 'N/A' (not hardcoded HARSHA_IP).
        2. Explicit IP in event -> source_ip preserves actual address.
        3. Custom hostname from remote machine -> preserves remote hostname.
        """
        # Event with no IP from an arbitrary machine
        line_no_ip = "2026-10-10 10:05:00 LAPTOP-REMOTE INFO 4624 Remote User Logon"
        evt1 = self.reader.parse_line(line_no_ip)
        self.assertEqual(evt1["hostname"], "LAPTOP-REMOTE")
        self.assertEqual(evt1["source_ip"], "N/A")

        # Event with explicit IP
        line_with_ip = "2026-10-10 10:06:00 WS-CLIENT INFO 4625 Failed Logon Source Network Address: 172.16.5.99"
        evt2 = self.reader.parse_line(line_with_ip)
        self.assertEqual(evt2["hostname"], "WS-CLIENT")
        self.assertEqual(evt2["source_ip"], "172.16.5.99")
        self.assertEqual(evt2["event_id"], 4625)

        # JSON Event with custom fields
        import json
        json_line = json.dumps({
            "EventID": 4688,
            "Hostname": "DESKTOP-HARSHA2",
            "TargetUserName": "Analyst1",
            "IpAddress": "192.168.10.45",
            "CommandLine": "powershell.exe -NoProfile"
        })
        evt3 = self.reader.parse_line(json_line)
        self.assertEqual(evt3["hostname"], "DESKTOP-HARSHA2")
        self.assertEqual(evt3["user"], "Analyst1")
        self.assertEqual(evt3["source_ip"], "192.168.10.45")
        self.assertEqual(evt3["command_line"], "powershell.exe -NoProfile")

    def test_06_event_id_1000_alone_does_not_create_incident(self):
        """
        Verify that ordinary Event ID 1000 without a diagnostic marker does NOT
        become a security incident or a diagnostic probe.
        """
        ordinary_line = "2026-10-10 12:00:00 Harsha INFO 1000 Ordinary Windows Application Informational Event"
        evt = self.reader.parse_line(ordinary_line)
        self.assertIsNotNone(evt)
        self.assertEqual(evt["event_id"], 1000)
        self.assertFalse(evt.get("is_diagnostic"), "Ordinary Event ID 1000 alone must not be flagged as diagnostic")
        self.assertEqual(evt["severity"], "Low")

        norm_evts = normalize_events([evt])
        self.assertFalse(norm_evts[0].get("is_diagnostic"))

        alerts = self.detector.detect(norm_evts)
        self.assertEqual(len(alerts), 0, "Ordinary Event ID 1000 alone must not trigger any alert")

        incidents = self.correlator.correlate(alerts)
        self.assertEqual(len(incidents), 0, "Ordinary Event ID 1000 alone must not become an incident")

    def test_07_incomplete_multiline_record_at_eof(self):
        """
        Verify that a multiline Windows Security event cut off after Subject:
        is held back until its remaining sections arrive.
        """
        event1 = "2026-10-10 10:00:00 Harsha INFO 1000 HARSHA\\Harsha PHASE1_COMPLETE_LINE\r\n"
        event2_part1 = (
            "2026-10-10 10:01:00 Harsha AUDIT_SUCCESS 4798 A user's local group membership was enumerated.\r\n"
            "\r\n"
            "Subject:\r\n"
            "\tSecurity ID:\t\tS-1-5-18\r\n"
            "\tAccount Name:\t\tHARSHA$\r\n"
        )
        event2_part2 = (
            "\r\n"
            "User:\r\n"
            "\tSecurity ID:\t\tS-1-5-21-1005\r\n"
            "\tAccount Name:\t\tHarsha\r\n"
            "\r\n"
            "Process Information:\r\n"
            "\tProcess ID:\t\t0x4278\r\n"
            "\tProcess Name:\t\tC:\\Windows\\System32\\svchost.exe\r\n"
        )

        with open(self.temp_log, "wb") as f:
            f.write(event1.encode("utf-8") + event2_part1.encode("utf-8"))

        # First read: should ingest event1 and hold back incomplete multiline event2_part1
        ingested1 = self.reader.read_events(incremental=True)
        self.assertEqual(len(ingested1), 1)
        self.assertEqual(ingested1[0]["event_id"], 1000)
        self.assertEqual(self.reader.load_cursor(), len(event1.encode("utf-8")))

        # Now append the rest of event2
        with open(self.temp_log, "ab") as f:
            f.write(event2_part2.encode("utf-8"))

        # Second read: should now ingest the complete event2 with user='Harsha' and process='C:\Windows\System32\svchost.exe'
        ingested2 = self.reader.read_events(incremental=True)
        self.assertEqual(len(ingested2), 1)
        self.assertEqual(ingested2[0]["event_id"], 4798)
        self.assertEqual(ingested2[0]["user"], "Harsha")
        self.assertEqual(ingested2[0]["process_name"], r"C:\Windows\System32\svchost.exe")

    def test_08_real_receiver_file_sector1_receiver_test_002_trace(self):
        """
        Verify against the actual C:\\AdaptiveSentinel\\windows-events.log file (if present)
        that SECTOR1_RECEIVER_TEST_002 is retrieved by get_recent_events and replay_events
        without modifying the live cursor, and traces through the pipeline.
        """
        if not NXLOG_FILE_PATH.exists():
            self.skipTest(f"Live receiver file {NXLOG_FILE_PATH} not present on this machine")

        live_reader = NXLogReader()
        cursor_before = live_reader.load_cursor()

        recent = live_reader.get_recent_events(max_events=300)
        cursor_after = live_reader.load_cursor()
        self.assertEqual(cursor_before, cursor_after, "get_recent_events must not modify live cursor")

        matches = [
            e for e in recent
            if "SECTOR1_RECEIVER_TEST_002" in str(e.get("description", ""))
        ]
        self.assertGreaterEqual(len(matches), 1, "SECTOR1_RECEIVER_TEST_002 must be found in recent events")
        target = matches[0]
        self.assertEqual(target["hostname"], "Harsha")
        self.assertEqual(target["user"], "Harsha")
        self.assertEqual(target["event_id"], 1000)
        self.assertTrue(target["is_diagnostic"])
        self.assertEqual(target["source_ip"], "N/A")

        # Trace through normalization, detection, and correlation
        norm_evts = normalize_events([target])
        alerts = self.detector.detect(norm_evts)
        self.assertEqual(len(alerts), 1)
        self.assertTrue(alerts[0]["is_diagnostic"])

        incidents = self.correlator.correlate(alerts)
        self.assertEqual(len(incidents), 1)
        self.assertTrue(incidents[0]["is_diagnostic"])
        self.assertEqual(incidents[0]["severity"], "Low")


if __name__ == "__main__":
    unittest.main()

