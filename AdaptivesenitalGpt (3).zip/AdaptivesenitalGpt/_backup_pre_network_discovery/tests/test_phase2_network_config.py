import importlib
import os
import unittest
from pathlib import Path
from unittest.mock import patch

import config.settings as settings
from analysis.normalize import LogNormalizer
from analysis.parser import NXLogReader


class TestPhase2NetworkConfig(unittest.TestCase):
    """
    Phase 2 verification suite:
    - Active code & dashboard do not contain stale hardcoded Wi-Fi IP literals
    - Centralized receiver and endpoint IP helpers support environment overrides
    - Dynamic local interface fallback works without hardcoding today's Wi-Fi IP
    - Receiver IP is never labeled as sender IP
    - Events without a source IP display 'N/A'
    """

    def setUp(self):
        self.project_root = Path(__file__).resolve().parent.parent
        self.env_keys = [
            "RECEIVER_ADVERTISED_IP",
            "RECEIVER_IP",
            "SUJITH_IP",
            "ENDPOINT_IP",
            "HARSHA_IP",
            "NXLOG_PORT",
            "ENDPOINT_HOSTNAME",
            "RECEIVER_HOSTNAME",
        ]
        self.saved_env = {k: os.environ.get(k) for k in self.env_keys}
        for k in self.env_keys:
            os.environ.pop(k, None)
        importlib.reload(settings)

    def tearDown(self):
        for k, v in self.saved_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        importlib.reload(settings)

    def test_no_stale_hardcoded_ips_in_active_files(self):
        """Ensure active configuration, parser, normalizer, evaluation, and dashboard contain no stale Wi-Fi IPs."""
        active_files = [
            self.project_root / "config" / "settings.py",
            self.project_root / "dashboard" / "app.py",
            self.project_root / "analysis" / "parser.py",
            self.project_root / "analysis" / "normalize.py",
            self.project_root / "utils" / "run_final_evaluation.py",
        ]
        forbidden_literals = ("10.184.216.159", "10.184.216.57", "11.12.7.72")

        for file_path in active_files:
            content = file_path.read_text(encoding="utf-8")
            for literal in forbidden_literals:
                self.assertNotIn(
                    literal,
                    content,
                    f"Stale hardcoded IP literal {literal} found in active file {file_path.name}",
                )

    def test_receiver_ip_overrides_and_fallback(self):
        """Verify get_receiver_ip() honors explicit overrides and falls back to detect_local_ip()."""
        with patch.object(settings, "detect_local_ip", return_value="198.51.100.25"):
            self.assertEqual(settings.get_receiver_ip(), "198.51.100.25")

            os.environ["SUJITH_IP"] = "198.51.100.30"
            self.assertEqual(settings.get_receiver_ip(), "198.51.100.30")

            os.environ["RECEIVER_IP"] = "198.51.100.40"
            self.assertEqual(settings.get_receiver_ip(), "198.51.100.40")

            os.environ["RECEIVER_ADVERTISED_IP"] = "198.51.100.50"
            self.assertEqual(settings.get_receiver_ip(), "198.51.100.50")

    def test_settings_reload_with_env_overrides(self):
        """Verify reloading config.settings picks up SUJITH_IP, HARSHA_IP, and NXLOG_PORT overrides."""
        os.environ["SUJITH_IP"] = "192.0.2.50"
        os.environ["HARSHA_IP"] = "192.0.2.100"
        os.environ["NXLOG_PORT"] = "12514"
        importlib.reload(settings)

        self.assertEqual(settings.SUJITH_IP, "192.0.2.50")
        self.assertEqual(settings.HARSHA_IP, "192.0.2.100")
        self.assertEqual(settings.NXLOG_PORT, 12514)

    def test_endpoint_ip_defaults_to_na_when_unknown(self):
        """Verify get_endpoint_ip() and HARSHA_IP default to 'N/A' when not configured or observed."""
        self.assertEqual(settings.HARSHA_IP, "N/A")
        self.assertEqual(settings.get_endpoint_ip(None), "N/A")
        self.assertEqual(settings.get_endpoint_ip("N/A"), "N/A")
        self.assertEqual(settings.get_endpoint_ip("-"), "N/A")
        self.assertEqual(settings.get_endpoint_ip("127.0.0.1"), "N/A")

    def test_receiver_ip_never_labeled_as_sender_ip(self):
        """Verify receiver IP is rejected if passed as observed sender IP or configured HARSHA_IP."""
        os.environ["SUJITH_IP"] = "192.0.2.55"
        os.environ["HARSHA_IP"] = "192.0.2.55"  # Misconfigured same as receiver
        importlib.reload(settings)

        self.assertEqual(settings.SUJITH_IP, "192.0.2.55")
        self.assertEqual(settings.HARSHA_IP, "N/A")
        self.assertEqual(
            settings.get_endpoint_ip(observed_ip="192.0.2.55", receiver_ip="192.0.2.55"),
            "N/A",
        )
        self.assertEqual(
            settings.get_endpoint_ip(observed_ip="192.0.2.88", receiver_ip="192.0.2.55"),
            "192.0.2.88",
        )

    def test_normalizer_preserves_na_and_rejects_receiver_as_source_ip(self):
        """Verify LogNormalizer sets source_ip='N/A' when missing or equal to receiver IP."""
        os.environ["SUJITH_IP"] = "192.0.2.77"
        importlib.reload(settings)

        reader = NXLogReader()
        evt_no_ip = reader.parse_line(
            "2026-10-10 14:00:00 Harsha AUDIT_SUCCESS 4798 A user's local group membership was enumerated."
        )
        self.assertEqual(evt_no_ip["source_ip"], "N/A")

        normalizer = LogNormalizer()
        norm_list = normalizer.normalize([
            evt_no_ip,
            {
                "source": "real_nxlog_windows",
                "event_id": 4624,
                "hostname": "Harsha",
                "source_ip": "192.0.2.77",  # Receiver IP should not be labeled as sender IP
            },
            {
                "source": "real_nxlog_windows",
                "event_id": 4624,
                "hostname": "Harsha",
                "source_ip": "192.0.2.99",  # Distinct sender IP preserved
            },
        ])
        self.assertEqual(norm_list[0]["source_ip"], "N/A")
        self.assertEqual(norm_list[0]["destination_ip"], "N/A")
        self.assertEqual(norm_list[1]["source_ip"], "N/A")
        self.assertEqual(norm_list[1]["destination_ip"], "192.0.2.77")
        self.assertEqual(norm_list[2]["source_ip"], "192.0.2.99")
        self.assertEqual(norm_list[2]["destination_ip"], "192.0.2.77")


if __name__ == "__main__":
    unittest.main()
