import unittest
import json
import tempfile
import shutil
from pathlib import Path

from analysis.parser import NXLogReader
from analysis.normalize import LogNormalizer
from config.settings import HARSHA_IP, SUJITH_IP, NXLOG_PORT


class TestNXLogIngestion(unittest.TestCase):

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.log_file = self.temp_dir / "windows-events.log"
        self.cursor_file = self.temp_dir / "nxlog_cursor.json"
        self.reader = NXLogReader(log_file=self.log_file, cursor_file=self.cursor_file)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_parse_json_nxlog_line(self):
        """Test parsing line-delimited JSON Windows Event log from NXLog."""
        raw_json = json.dumps({
            "EventID": 4624,
            "Hostname": "Harsha",
            "TargetUserName": "HarshaUser",
            "IpAddress": "10.184.216.159",
            "Message": "An account was successfully logged on."
        })
        event = self.reader.parse_line(raw_json)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_id"], 4624)
        self.assertEqual(event["hostname"], "Harsha")
        self.assertEqual(event["user"], "HarshaUser")
        self.assertEqual(event["source_ip"], "10.184.216.159")
        self.assertEqual(event["source"], "real_nxlog_windows")

    def test_parse_text_syslog_line(self):
        """Test parsing plain text / test syslog line from NXLog without forcing IP."""
        raw_line = "2026-10-04 21:00:00 [INFO] NXLog TEST EVENT from Harsha"
        event = self.reader.parse_line(raw_line)
        self.assertIsNotNone(event)
        self.assertEqual(event["hostname"], "Harsha")
        self.assertEqual(event["source_ip"], "N/A")
        self.assertIn("TEST EVENT", event["description"])

        # Also test line with explicit source IP
        test_ip = HARSHA_IP if HARSHA_IP != "N/A" else "192.0.2.10"
        raw_line_ip = f"2026-10-04 21:00:00 [INFO] NXLog TEST EVENT from Harsha IpAddress: {test_ip}"
        event_ip = self.reader.parse_line(raw_line_ip)
        self.assertEqual(event_ip["source_ip"], test_ip)

    def test_incremental_cursor_reading(self):
        """Test that NXLogReader only reads newly appended log lines on subsequent calls."""
        line1 = json.dumps({"EventID": 4688, "Hostname": "Harsha", "ProcessName": "cmd.exe"}) + "\n"
        line2 = json.dumps({"EventID": 1102, "Hostname": "Harsha", "Message": "Audit Log Cleared"}) + "\n"

        # Write first line
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write(line1)

        # First read: should yield 1 event and save cursor
        events1 = self.reader.read_events(incremental=True)
        self.assertEqual(len(events1), 1)
        self.assertEqual(events1[0]["event_id"], 4688)

        # Append second line
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(line2)

        # Second read: should yield only the new second event
        events2 = self.reader.read_events(incremental=True)
        self.assertEqual(len(events2), 1)
        self.assertEqual(events2[0]["event_id"], 1102)

    def test_normalization_with_nxlog_defaults(self):
        """Test that LogNormalizer correctly processes NXLog events with proper defaults."""
        raw_events = [{
            "source": "real_nxlog_windows",
            "event_id": 4624,
            "hostname": "Harsha",
            "source_ip": "10.184.216.159"
        }]

        normalizer = LogNormalizer()
        normalized = normalizer.normalize(raw_events)
        self.assertEqual(len(normalized), 1)
        evt = normalized[0]
        self.assertEqual(evt["source"], "real_nxlog_windows")
        self.assertEqual(evt["event_type"], "Successful Authentication")
        self.assertEqual(evt["destination_ip"], SUJITH_IP)


    def test_event_id_extraction_variations(self):
        """Test Event ID extraction across XML tags, KV labels, and syslog strings."""
        lines_and_expected = [
            ("<EventID>1000</EventID> AdaptiveSentinel Test Event", 1000),
            ("EventID: 4672 Special Privileges Assigned", 4672),
            ("ID=5379 Credential Read", 5379),
            ("Windows Event 7040 Service Change", 7040),
            ("Event 4799 Local Group Enumeration", 4799),
        ]
        for line, expected_id in lines_and_expected:
            evt = self.reader.parse_line(line)
            self.assertIsNotNone(evt, f"Failed for line: {line}")
            self.assertEqual(evt["event_id"], expected_id, f"Expected {expected_id} for line '{line}', got {evt['event_id']}")

    def test_ingestion_timestamp_presence(self):
        """Test that ingested events contain both event timestamp and ingestion timestamp."""
        raw_json = json.dumps({
            "EventID": 4688,
            "EventTime": "2026-10-04 20:50:00",
            "Hostname": "Harsha"
        })
        evt = self.reader.parse_line(raw_json)
        self.assertIsNotNone(evt)
        self.assertEqual(evt["timestamp"], "2026-10-04 20:50:00")
        self.assertIn("ingestion_timestamp", evt)
        self.assertTrue(len(evt["ingestion_timestamp"]) > 0)


if __name__ == "__main__":
    unittest.main()
