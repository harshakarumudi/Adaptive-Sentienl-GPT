import unittest
import torch
import json
import shutil
import tempfile
from pathlib import Path

from models.gnn.gnn_model import AdaptiveSentinelGNN
from models.gnn.train import train_gnn_model, generate_multi_graph_dataset, compute_class_balance, evaluate_non_gnn_baseline
from models.gnn.inference import run_gnn_inference


class TestGNNModule(unittest.TestCase):

    def setUp(self):
        self.model = AdaptiveSentinelGNN(in_channels=5, hidden_channels=16, num_layers=2)

    def test_gnn_model_instantiation_and_forward_pass(self):
        """Test GNN model forward pass tensor output shapes and score bounds."""
        num_nodes = 10
        num_edges = 8
        x = torch.randn(num_nodes, 5)
        edge_index = torch.randint(0, num_nodes, (2, num_edges), dtype=torch.long)

        self.model.eval()
        with torch.no_grad():
            embeddings, scores = self.model(x, edge_index)

        self.assertEqual(embeddings.shape, (num_nodes, 16))
        self.assertEqual(scores.shape, (num_nodes,))
        self.assertTrue(torch.all(scores >= 0.0) and torch.all(scores <= 1.0))

    def test_multi_graph_dataset_and_class_balance(self):
        """Test generation of multi-graph benchmark dataset and class balance stats."""
        dataset = generate_multi_graph_dataset()
        self.assertEqual(len(dataset), 30)

        cb = compute_class_balance(dataset)
        self.assertGreater(cb["total_nodes"], 100)
        self.assertGreater(cb["anomalous_nodes"], 0)
        self.assertGreater(cb["benign_nodes"], 0)
        self.assertGreater(cb["anomalous_percentage"], 0)

    def test_non_gnn_baseline_evaluation(self):
        """Test evaluation of Non-GNN feature-only linear baseline."""
        dataset = generate_multi_graph_dataset()
        train_graphs = dataset[:21]
        test_graphs = dataset[21:]

        cb_train = compute_class_balance(train_graphs)
        pos_weight = float(cb_train["benign_nodes"]) / max(1.0, float(cb_train["anomalous_nodes"]))

        res = evaluate_non_gnn_baseline(train_graphs, test_graphs, pos_weight)
        self.assertIn("accuracy", res)
        self.assertIn("precision", res)
        self.assertIn("recall", res)
        self.assertIn("f1", res)

    def test_gnn_training_and_checkpoint_export(self):
        """Test model training run, graph-level split, and checkpoint metadata generation."""
        metadata = train_gnn_model(epochs=10, lr=0.01)

        self.assertIn("metrics", metadata)
        self.assertIn("test_accuracy", metadata["metrics"])
        self.assertIn("test_f1", metadata["metrics"])
        self.assertIn("confusion_matrix", metadata["metrics"])
        self.assertIn("total_graphs", metadata)
        self.assertEqual(metadata["total_graphs"], 30)
        self.assertIn("class_balance", metadata)
        self.assertIn("baseline_comparison", metadata)
        self.assertEqual(metadata["in_channels"], 5)

        model_dir = Path(__file__).resolve().parent.parent / "models" / "gnn"
        ckpt_path = model_dir / "adaptivesentinel_gnn.pt"
        meta_path = model_dir / "gnn_metadata.json"

        self.assertTrue(ckpt_path.exists())
        self.assertTrue(meta_path.exists())

    def test_gnn_inference_execution(self):
        """Test GNN inference mapping model risk scores to graph nodes."""
        incidents = [
            {
                "incident_id": "INC-TEST-GNN",
                "incident_name": "Credential Access Campaign",
                "severity": "High",
                "affected_host": "Harsha",
                "affected_user": "HarshaAdmin",
                "alerts": [
                    {
                        "alert_name": "Failed Authentication",
                        "mitre_technique": "T1110",
                        "event": {
                            "event_id": 4625,
                            "event_type": "Failed Authentication",
                            "severity": "High",
                            "source": "real_nxlog_windows",
                            "user": "HarshaAdmin",
                            "rule_id": "60106",
                            "mitre_techniques": ["T1110"]
                        }
                    }
                ]
            }
        ]

        res = run_gnn_inference(incidents=incidents)

        self.assertEqual(res["status"], "TRAINED")
        self.assertEqual(res["inference_status"], "ACTIVE")
        self.assertGreater(res["analyzed_nodes"], 0)
        self.assertIn("highest_risk_score", res)
        self.assertIn("top_risk_nodes", res)
        self.assertGreater(len(res["top_risk_nodes"]), 0)

        top_node = res["top_risk_nodes"][0]
        self.assertIn("gnn_risk_score", top_node)
        self.assertIn("associated_graph_evidence", top_node)

    def test_gnn_inference_empty_graph(self):
        """Test GNN inference handling empty graph inputs cleanly."""
        res = run_gnn_inference(incidents=[], logs=[])
        self.assertEqual(res["status"], "TRAINED")
        self.assertEqual(res["analyzed_nodes"], 0)


if __name__ == "__main__":
    unittest.main()
