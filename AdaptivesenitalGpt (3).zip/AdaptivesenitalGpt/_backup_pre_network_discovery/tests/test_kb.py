import unittest
from knowledge_base.mitre import MitreKnowledgeBase
from knowledge_base.database import KnowledgeBaseDB


class TestKnowledgeBase(unittest.TestCase):

    def test_mitre_knowledge_base(self):
        kb = MitreKnowledgeBase()
        info = kb.get_mitre(4625)

        self.assertEqual(info["technique"], "T1110")
        self.assertEqual(info["tactic"], "Credential Access")
        self.assertEqual(info["name"], "Brute Force")

    def test_sqlite_database_ioc(self):
        db = KnowledgeBaseDB()

        record = db.lookup_ioc("185.220.101.5")
        self.assertIsNotNone(record)
        self.assertEqual(record["risk_score"], 95)


if __name__ == "__main__":
    unittest.main()
