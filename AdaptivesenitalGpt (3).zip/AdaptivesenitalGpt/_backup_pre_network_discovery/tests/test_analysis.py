import unittest
from analysis.normalize import LogNormalizer
from analysis.deduplicate import LogDeduplicator
from analysis.enrich import LogEnricher


class TestAnalysisLayer(unittest.TestCase):

    def test_log_normalization(self):
        raw_logs = [{
            "timestamp": "2026-07-29T12:00:00",
            "source": "Windows",
            "event_id": 4625,
            "hostname": "TEST-HOST",
            "user": "admin",
            "source_ip": "192.168.1.50",
            "message": "Failed logon"
        }]

        normalizer = LogNormalizer()
        normalized = normalizer.normalize(raw_logs)

        self.assertEqual(len(normalized), 1)
        self.assertEqual(normalized[0]["event_type"], "Failed Authentication")
        self.assertEqual(normalized[0]["severity"], "Medium")
        self.assertEqual(normalized[0]["mitre_technique"], "T1110")

    def test_log_deduplication(self):
        raw_logs = [
            {"timestamp": "2026-07-29T12:00:00", "event_id": 4625, "hostname": "HOST-1", "user": "user1", "source_ip": "1.1.1.1", "command_line": "N/A"},
            {"timestamp": "2026-07-29T12:00:00", "event_id": 4625, "hostname": "HOST-1", "user": "user1", "source_ip": "1.1.1.1", "command_line": "N/A"}
        ]

        deduplicator = LogDeduplicator()
        unique = deduplicator.remove_duplicates(raw_logs)

        self.assertEqual(len(unique), 1)

    def test_log_enrichment(self):
        logs = [{
            "mitre_technique": "T1110",
            "hostname": "DC-PRIMARY",
            "event_id": 4625
        }]

        enricher = LogEnricher()
        enriched = enricher.enrich(logs)

        self.assertEqual(len(enriched), 1)
        self.assertEqual(enriched[0]["mitre_tactic"], "Credential Access")
        self.assertEqual(enriched[0]["asset_criticality"], "High")

    def test_incident_card_html_rendering(self):
        test_incidents = [
            {"incident_name": "Ransomware Pre-Encryption", "severity": "Critical", "affected_host": "Harsha", "affected_user": "Harsha", "confidence": 98, "alert_count": 1, "alerts": [{"event": {"source": "real_nxlog_windows"}}]},
            {"incident_name": "Privilege Escalation", "severity": "High", "affected_host": "Finance-WS", "affected_user": "Admin", "confidence": 92, "alert_count": 3, "alerts": []},
            {"incident_name": "Suspicious Script", "severity": "Medium", "affected_host": "HR-Laptop", "affected_user": "Bob", "confidence": 75, "alert_count": 2, "alerts": []},
            {"incident_name": "Failed Logon", "severity": "Low", "affected_host": "Domain-Ctrl", "affected_user": "Guest", "confidence": 40, "alert_count": 1, "alerts": []},
        ]

        for inc in test_incidents:
            sev_str = str(inc.get("severity", "Medium")).strip()
            sev_lower = sev_str.lower()
            if sev_lower == "critical":
                severity_class = "badge-critical"
            elif sev_lower == "high":
                severity_class = "badge-high"
            elif sev_lower == "medium":
                severity_class = "badge-medium"
            else:
                severity_class = "badge-low"

            has_nxlog = any(alt.get("event", {}).get("source") == "real_nxlog_windows" for alt in inc.get("alerts", []))
            nxlog_badge = '<span class="badge-telemetry" style="margin-right: 8px;">📡 REAL NXLOG INCIDENT</span>' if has_nxlog else ''
            severity_badge = f'<span class="{severity_class}">{sev_str.upper()} SEVERITY</span>'
            badges_html = f'{nxlog_badge}{severity_badge}'

            inc_name = inc.get("incident_name", "Incident")
            inc_host = inc.get("affected_host", "Unknown")
            inc_user = inc.get("affected_user", "Unknown")
            inc_conf = inc.get("confidence", 0)
            inc_alerts = inc.get("alert_count", 0)

            card_html = (
                f'<div class="soc-card">'
                f'<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">'
                f'<h3 style="margin: 0; color: #0f172a; font-weight: 700;">🔥 {inc_name}</h3>'
                f'<div>{badges_html}</div>'
                f'</div>'
                f'<div style="display: flex; gap: 24px; color: #64748b; font-size: 0.92rem; flex-wrap: wrap;">'
                f'<span>📍 <strong>Target Host:</strong> <code style="color: #2563eb; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">{inc_host}</code></span>'
                f'<span>👤 <strong>User Account:</strong> <code style="color: #2563eb; background: #f1f5f9; padding: 2px 6px; border-radius: 4px;">{inc_user}</code></span>'
                f'<span>📊 <strong>Confidence:</strong> <strong style="color: #0f172a;">{inc_conf}%</strong></span>'
                f'<span>🚨 <strong>Alert Count:</strong> <strong style="color: #0f172a;">{inc_alerts}</strong></span>'
                f'</div>'
                f'</div>'
            )

            # Ensure valid HTML structure
            self.assertTrue(card_html.startswith('<div class="soc-card">'))
            self.assertTrue(card_html.endswith('</div>'))
            self.assertIn(severity_class, card_html)
            self.assertIn(f'{sev_str.upper()} SEVERITY', card_html)
            if has_nxlog:
                self.assertIn('REAL NXLOG INCIDENT', card_html)
            else:
                self.assertNotIn('REAL NXLOG INCIDENT', card_html)

            # Ensure no line is indented with 4+ spaces which could trigger Markdown code block
            for line in card_html.split('\n'):
                self.assertFalse(line.startswith('    '), 'Line indented with 4+ spaces!')


if __name__ == "__main__":
    unittest.main()
