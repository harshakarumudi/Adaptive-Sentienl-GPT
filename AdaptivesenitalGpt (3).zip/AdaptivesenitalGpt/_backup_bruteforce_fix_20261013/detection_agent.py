import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional, Set
from analysis.normalize import resolve_canonical_hostname


class DetectionAgent:
    """
    Detection Agent evaluating normalized events against MITRE ATT&CK rules,
    heuristic thresholds, and signature checks.
    """

    _BENIGN_PRIVILEGE_ACCOUNTS = (
        "SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "ANONYMOUS LOGON", "-", ""
    )
    _SENSITIVE_PRIVILEGES = {
        "sedebugprivilege",
        "setakeownershipprivilege",
        "seloaddriverprivilege",
        "seimpersonateprivilege",
        "setcbprivilege",
        "seassignprimarytokenprivilege",
        "secreatetokenprivilege",
        "serelabelprivilege",
    }
    _BENIGN_LSASS_EVENT_IDS = (12, 225)
    _BENIGN_LSASS_BINARY_PATHS = (
        "lsass.exe",
        "lsass",
        r"c:\windows\system32\lsass.exe",
        r"%systemroot%\system32\lsass.exe",
        r"\systemroot\system32\lsass.exe",
    )
    _LSASS_DUMP_INDICATORS = (
        "mimikatz",
        "sekurlsa",
        "lsadump",
        "procdump",
        "comsvcs",
        "minidump",
        "lsass.dmp",
        ".dmp",
        "-ma",
        "rundll32",
        "nanodump",
        "pypykatz",
        "sqldumper",
        "createdump",
        "outflank",
        "dumpert",
        "handlekatz",
        "lazagne",
        "0x1010",
        "0x1fffff",
        "0x1410",
        "dump",
    )

    @classmethod
    def _is_lsass_credential_dumping(
        cls,
        event_id: Any,
        process_name: str,
        cmd_line: str,
        desc_lower: str,
    ) -> bool:
        """
        Determines whether an event represents genuine LSASS credential dumping or
        suspicious LSASS memory access (RULE-CRED-LSASS-10).
        Never triggers on benign Windows startup Event ID 12, Kernel-PnP Event ID 225,
        or a bare reference to the legitimate Windows C:\\Windows\\System32\\lsass.exe
        executable path without credential-dumping telemetry.
        """
        if (
            "mimikatz" in process_name
            or "mimikatz" in cmd_line
            or "mimikatz" in desc_lower
            or "sekurlsa" in cmd_line
            or "sekurlsa" in desc_lower
            or "lsadump" in cmd_line
            or "lsadump" in desc_lower
            or "procdump" in process_name
            or "procdump" in cmd_line
            or "comsvcs" in cmd_line
            or "minidump" in cmd_line
            or "lsass.dmp" in cmd_line
            or "lsass.dmp" in desc_lower
            or "process accessed lsass" in desc_lower
            or "memory access to lsass" in desc_lower
            or "lsass memory dump" in desc_lower
            or "lsass process memory dump" in desc_lower
            or "lsass process credential" in desc_lower
        ):
            return True

        if event_id in cls._BENIGN_LSASS_EVENT_IDS:
            return False

        if event_id == 10 and (
            "lsass" in process_name
            or "lsass" in cmd_line
            or "lsass" in desc_lower
            or "process accessed" in desc_lower
        ):
            return True

        if "lsass" in cmd_line:
            cmd_norm = cmd_line.strip(" \"'").replace("/", "\\")
            is_benign_lsass_binary = (
                cmd_norm in cls._BENIGN_LSASS_BINARY_PATHS
                or (
                    cmd_norm.endswith(r"\windows\system32\lsass.exe")
                    and " " not in cmd_norm
                )
            )
            if not is_benign_lsass_binary and any(
                ind in cmd_line or ind in process_name or ind in desc_lower
                for ind in cls._LSASS_DUMP_INDICATORS
            ):
                return True

        return False

    @staticmethod
    def _parse_event_timestamp(ts_val: Any) -> Optional[datetime]:
        if not ts_val:
            return None
        s = str(ts_val).strip().replace("T", " ")
        if s.endswith("Z"):
            s = s[:-1]
        if len(s) >= 19 and s[4:5] == "-" and s[7:8] == "-":
            try:
                return datetime.strptime(s[:19], "%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
        return None

    @classmethod
    def _find_privesc_corroboration(
        cls,
        target_log: Dict[str, Any],
        all_logs: List[Dict[str, Any]],
        window_seconds: int = 300,
    ) -> Optional[Dict[str, Any]]:
        """
        Finds meaningful corroborating evidence within a bounded time window
        (<= window_seconds) on the same host for privilege escalation.
        Never alerts on routine standalone events or merely opening an elevated console.
        """
        target_host = resolve_canonical_hostname(target_log.get("hostname", "UNKNOWN_HOST")).lower()
        target_ts = cls._parse_event_timestamp(target_log.get("timestamp"))

        for other in all_logs:
            if other is target_log:
                continue
            other_host = resolve_canonical_hostname(other.get("hostname", "UNKNOWN_HOST")).lower()
            if other_host != target_host:
                continue

            other_ts = cls._parse_event_timestamp(other.get("timestamp"))
            if target_ts and other_ts:
                if abs((target_ts - other_ts).total_seconds()) > window_seconds:
                    continue

            other_id = other.get("event_id")
            proc = str(other.get("process_name", "")).lower()
            cmd = str(other.get("command_line", "")).lower()
            desc = str(other.get("description", "")).lower()
            full_text = f"{proc} {cmd} {desc}"

            # 1. Administrative Security Group Modification (4732, 4728, 4756)
            if other_id in (4732, 4728, 4756) or any(
                m in desc for m in (
                    "member was added to a security-enabled",
                    "a member was added to a security",
                    "security group member added",
                    "administrators",
                )
            ):
                return {
                    "corroborating_event": other,
                    "reason": f"Administrative security group modification (Event ID {other_id})",
                }

            # 2. New Service Installation (7045, 4697)
            if other_id in (7045, 4697) or "service was installed" in desc or "new service" in desc:
                return {
                    "corroborating_event": other,
                    "reason": f"New service installation (Event ID {other_id})",
                }

            # 3. Explicit Credentials Logon (4648) from non-system / untrusted process
            if other_id == 4648 or "explicit credentials" in desc:
                trusted_system_procs = ("svchost.exe", "lsass.exe", "services.exe", "winlogon.exe", "dwm.exe")
                if not any(proc.endswith(p) for p in trusted_system_procs):
                    return {
                        "corroborating_event": other,
                        "reason": f"Logon using explicit credentials ({proc or 'Event ID 4648'})",
                    }

            # 4. User Account Created (4720)
            if other_id == 4720 or "user account was created" in desc:
                return {
                    "corroborating_event": other,
                    "reason": "User account created in privilege escalation window (Event ID 4720)",
                }

            # 5. Process Creation (4688, 1) with token elevation or recon/privilege commands
            if other_id in (4688, 1) or "process" in desc:
                if (
                    "%%1937" in full_text
                    or "tokenelevationtypefull" in full_text
                    or "elevation" in full_text
                    or "full privileges" in full_text
                ):
                    return {
                        "corroborating_event": other,
                        "reason": f"Process created with full token elevation ({proc or '4688'})",
                    }

                recon_priv_tools = (
                    "whoami", "net.exe", "net1.exe", "cmd.exe", "powershell.exe",
                    "pwsh.exe", "reg.exe", "rundll32.exe", "wmic.exe", "sc.exe", "nltest.exe"
                )
                if any(t in proc or t in cmd for t in recon_priv_tools):
                    if any(k in full_text for k in (
                        "/priv", "/groups", "/all", "localgroup", "administrators",
                        "admin", "elevat", "privilege", "reg add", "reg query",
                        "sc create", "sc config", "bypass", "-enc"
                    )):
                        return {
                            "corroborating_event": other,
                            "reason": f"Elevated command execution ({proc or cmd})",
                        }
                    if any(tool in proc or tool in cmd for tool in ("whoami", "net.exe", "net1.exe", "nltest.exe")):
                        return {
                            "corroborating_event": other,
                            "reason": f"Privilege reconnaissance tool execution ({proc or cmd})",
                        }

        return None

    def detect(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        alerts = []
        privesc_alerted_hosts: Set[str] = set()

        for log in logs:
            event_id = log.get("event_id")
            process_name = str(log.get("process_name", "")).lower()
            cmd_line = str(log.get("command_line", "")).lower()
            desc = str(log.get("description", ""))
            canonical_host_key = resolve_canonical_hostname(log.get("hostname", "UNKNOWN_HOST")).lower()

            alert = None

            # Diagnostic Telemetry Verification Probe (explicit diagnostic markers; Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in desc.upper() or marker in cmd_line.upper() for marker in [
                    "SECTOR1_RECEIVER_TEST",
                    "SECTOR1_E2E",
                    "DIAGNOSTIC_TEST",
                    "PHASE1_",
                    "PHASE2_",
                    "PHASE3_",
                    "MULTI_ENDPOINT_",
                    "RECEIVER_TEST",
                    "SENTINEL_TEST",
                    "ADAPTIVE SENTINEL CONNECTION TEST",
                    "ADAPTIVESENTINEL_LIVE_TEST",
                    "ADAPTIVESENTINELGPT TEST EVENT",
                    "LIVE_TEST_",
                    "NXLOG TEST EVENT",
                    "LIVE TEST FROM",
                ])
            )

            if is_diagnostic:
                alert = {
                    "alert_id": f"ALT-DIAG-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Diagnostic Telemetry Verification Probe",
                    "rule_id": "RULE-DIAG-001",
                    "severity": "Low",
                    "confidence": 100,
                    "mitre_technique": "N/A",
                    "is_diagnostic": True,
                    "event": log
                }

            # Context-Aware Privilege Escalation (RULE-PRIVESC-CONTEXT-01)
            # Never alert on Event ID 4672 alone or for routine SYSTEM, LOCAL SERVICE, NETWORK SERVICE, DWM-*, UMFD-*
            # Requires non-service user assigned sensitive privileges corroborated by elevated process creation,
            # administrative security group modification (4732/4728/4756), new service installation (7045), etc.
            elif event_id == 4672:
                target_user = str(log.get("user", "SYSTEM")).strip()
                is_service = (
                    target_user.upper() in self._BENIGN_PRIVILEGE_ACCOUNTS
                    or target_user.endswith("$")
                    or target_user.upper().startswith(("DWM-", "UMFD-"))
                )
                if not is_service:
                    privs = [str(p).lower() for p in (log.get("privileges") or [])]
                    desc_lower = desc.lower()
                    has_sensitive_priv = any(
                        sp in privs or sp in desc_lower
                        for sp in self._SENSITIVE_PRIVILEGES
                    )
                    if has_sensitive_priv:
                        corr = self._find_privesc_corroboration(log, logs, window_seconds=300)
                        if corr:
                            corroborating_ev = corr["corroborating_event"]
                            alert = {
                                "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                                "alert_name": "Context-Aware Privilege Escalation: Sensitive Privileges Corroborated",
                                "rule_id": "RULE-PRIVESC-CONTEXT-01",
                                "severity": "High",
                                "confidence": 88,
                                "mitre_technique": "T1548.002",
                                "corroborating_event_id": corroborating_ev.get("event_id"),
                                "corroboration_detail": corr["reason"],
                                "corroborating_events": [corroborating_ev],
                                "event": log,
                            }
                            privesc_alerted_hosts.add(canonical_host_key)

            elif event_id in (4732, 4728, 4756):
                if canonical_host_key not in privesc_alerted_hosts:
                    corr = self._find_privesc_corroboration(log, logs, window_seconds=300)
                    if corr:
                        corroborating_ev = corr["corroborating_event"]
                        alert = {
                            "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                            "alert_name": "Context-Aware Privilege Escalation: Unauthorized Security Group Modification",
                            "rule_id": "RULE-PRIVESC-CONTEXT-01",
                            "severity": "High",
                            "confidence": 88,
                            "mitre_technique": "T1548.002",
                            "corroborating_event_id": corroborating_ev.get("event_id"),
                            "corroboration_detail": corr["reason"],
                            "corroborating_events": [corroborating_ev],
                            "event": log,
                        }
                        privesc_alerted_hosts.add(canonical_host_key)

            # Failed Logon Attempt (Windows 4625 or SSH/auth 1001; exclude Windows Error Reporting Fault bucket 1001)
            elif event_id == 4625 or (
                event_id == 1001
                and "fault bucket" not in desc.lower()
                and (
                    "ssh" in process_name
                    or "ssh" in desc.lower()
                    or "ssh" in str(log.get("event_type", "")).lower()
                    or "failed" in desc.lower()
                    or "login" in desc.lower()
                    or "logon" in desc.lower()
                )
            ):
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Failed Logon Attempt",
                    "rule_id": "RULE-AUTH-4625",
                    "severity": "Medium",
                    "confidence": 85,
                    "mitre_technique": log.get("mitre_technique") if log.get("mitre_technique") not in (None, "", "N/A") else "T1110",
                    "event": log
                }

            # Unsigned/Bypass PowerShell Execution (require PowerShell/pwsh evidence; do not flag benign Event ID 1 low-power state)
            elif (
                "powershell" in process_name
                or "pwsh" in process_name
                or "powershell" in cmd_line
                or "pwsh" in cmd_line
                or (
                    event_id in (1, 4104, 4688)
                    and (
                        "powershell" in desc.lower()
                        or "pwsh" in desc.lower()
                        or "-encodedcommand" in desc.lower()
                        or "executionpolicy bypass" in desc.lower()
                    )
                )
            ):
                desc_lower = desc.lower()
                if (
                    "bypass" in cmd_line
                    or "enc" in cmd_line
                    or "executionpolicy" in cmd_line
                    or "bypass" in desc_lower
                    or "-encodedcommand" in desc_lower
                    or " -enc " in desc_lower
                ):
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "Suspicious Obfuscated PowerShell Execution",
                        "rule_id": "RULE-EXEC-PS-01",
                        "severity": "High",
                        "confidence": 92,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }
                else:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "PowerShell Script Execution",
                        "rule_id": "RULE-EXEC-PS-02",
                        "severity": "Low",
                        "confidence": 75,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }

            # Shadow Copy Deletion (Ransomware Prep)
            elif "vssadmin" in process_name or "delete shadows" in cmd_line or "delete shadows" in desc.lower():
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Volume Shadow Copies Deletion (Ransomware Activity)",
                    "rule_id": "RULE-IMPACT-VSS-01",
                    "severity": "Critical",
                    "confidence": 98,
                    "mitre_technique": "T1486",
                    "event": log
                }

            # Mimikatz LSASS Memory Access (require Sysmon Event ID 10 or explicit credential-dumping indicators;
            # never trigger on benign Windows startup Event ID 12, Kernel-PnP Event ID 225, or bare C:\Windows\System32\lsass.exe paths)
            elif self._is_lsass_credential_dumping(event_id, process_name, cmd_line, desc.lower()):
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "OS Credential Dumping via LSASS Access",
                    "rule_id": "RULE-CRED-LSASS-10",
                    "severity": "Critical",
                    "confidence": 96,
                    "mitre_technique": "T1003.001",
                    "event": log
                }

            # Audit Log Clearing
            elif event_id == 1102 or "wevtutil cl" in cmd_line:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Security Audit Log Cleared",
                    "rule_id": "RULE-EVASION-1102",
                    "severity": "High",
                    "confidence": 95,
                    "mitre_technique": "T1070",
                    "event": log
                }

            # New Account Created
            elif event_id == 4720:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "New Account Created",
                    "rule_id": "RULE-PERSIST-4720",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1136",
                    "event": log
                }

            # Network IDS Alert (Suricata)
            elif event_id == 2000001:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Suricata IDS: Lateral Movement via Remote WMI Execution",
                    "rule_id": "RULE-LATERAL-2000001",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1021",
                    "event": log
                }

            # Windows Credential Manager Read / Vault Access (distinguish routine OS read from credential harvesting tools;
            # ignore machine accounts ending in '$' and built-in service accounts when no credential tool is present)
            elif event_id == 5379 or "credential manager" in str(log.get("description", "")).lower():
                target_user = str(log.get("user", "SYSTEM")).strip()
                cred_vault_tools = (
                    "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe",
                    "rundll32", "mimikatz", "lazagne", "seatbelt", "sharphound",
                    "bloodhound", "procdump", "wscript", "cscript", "mshta", "python",
                )
                has_cred_tool = any(
                    t in process_name or t in cmd_line or t in desc.lower()
                    for t in cred_vault_tools
                )
                is_machine_or_service = (
                    target_user.endswith("$")
                    or target_user.upper() in ("LOCAL SERVICE", "NETWORK SERVICE")
                )
                if has_cred_tool or not is_machine_or_service:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": (
                            "Windows Credential Manager Access & Harvesting"
                            if has_cred_tool
                            else "Windows Credential Manager Read Activity"
                        ),
                        "rule_id": "RULE-CRED-5379",
                        "severity": "High" if has_cred_tool else "Low",
                        "confidence": 90 if has_cred_tool else 68,
                        "mitre_technique": "T1555.004",
                        "event": log
                    }

            # Local Account & Group Enumeration / Reconnaissance Discovery (ignore computer accounts ending in '$' and built-in service accounts)
            elif event_id in [4798, 4799] or "group membership was enumerated" in str(log.get("description", "")).lower():
                target_user = str(log.get("user", "SYSTEM")).strip()
                recon_binaries = (
                    "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
                    "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
                    "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
                )
                has_recon_tool = any(
                    b in process_name or b in cmd_line or b in desc.lower()
                    for b in recon_binaries
                )
                is_machine_or_service = (
                    target_user.endswith("$")
                    or target_user.upper() in ("LOCAL SERVICE", "NETWORK SERVICE")
                )
                if has_recon_tool or not is_machine_or_service:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": f"Account Discovery: Group Membership Enumeration ({target_user})" if target_user not in ["SYSTEM", "N/A"] else "Account Discovery: Group Membership Enumeration",
                        "rule_id": "RULE-DISC-4798",
                        "severity": "Medium" if has_recon_tool else "Low",
                        "confidence": 85 if has_recon_tool else 65,
                        "mitre_technique": "T1087.001" if event_id == 4798 else "T1087",
                        "event": log
                    }

            if alert:
                alert.setdefault("is_diagnostic", False)
                alert.setdefault("rule_id", "RULE-GEN-001")
                alert["hostname"] = log.get("hostname", "UNKNOWN_HOST")
                alert["source_ip"] = log.get("source_ip", "N/A")
                if not log.get("rule_id") or log.get("rule_id") == "N/A":
                    log["rule_id"] = alert["rule_id"]
                if alert.get("mitre_technique") not in (None, "", "N/A") and log.get("mitre_technique") in (None, "", "N/A"):
                    log["mitre_technique"] = alert["mitre_technique"]
                alerts.append(alert)

        print(f"[INFO] Detection Agent flagged {len(alerts)} suspicious alert(s).")
        return alerts