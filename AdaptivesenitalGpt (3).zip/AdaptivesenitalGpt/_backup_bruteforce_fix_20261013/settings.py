import os
import socket
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import utils.network_discovery as _net_disc
from utils.network_discovery import (
    CentralNetworkStateService,
    INTERFACE_CACHE_TTL_SEC,
    clear_interface_detection_cache,
    detect_active_interface_and_ip,
    ensure_udp_discovery_responder,
    format_network_display,
    inspect_tcp_port_connections,
    is_valid_unicast_ipv4,
)

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_LOGS_DIR = DATA_DIR / "raw_logs"
PROCESSED_LOGS_DIR = DATA_DIR / "processed_logs"
REPORTS_DIR = DATA_DIR / "reports"
DB_PATH = BASE_DIR / "knowledge_base" / "sentinel_kb.db"

LOG_FILE_PATH = RAW_LOGS_DIR / "windows_logs.json"

# Ensure directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
RAW_LOGS_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_LOGS_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# LLM Configurations
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "fallback")  # Options: 'ollama', 'gemini', 'openai', 'fallback'
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Detection & Correlation Thresholds
CORRELATION_TIME_WINDOW_MINUTES = 15
BRUTE_FORCE_THRESHOLD = 3
SUSPICIOUS_PROCESS_NAMES = [
    "powershell.exe", "cmd.exe", "wmic.exe", "vssadmin.exe",
    "mimikatz.exe", "whoami.exe", "net.exe", "reg.exe"
]

# Threat Intelligence Configs
THREAT_INTEL_SIMULATED_REPUTATION_THRESHOLD = 70

# SOAR Simulation & Execution Mode Configs (Fail-Closed Backend Isolation)
SOAR_EXECUTION_MODE = os.getenv("SOAR_EXECUTION_MODE", "DRY_RUN").strip().upper()
SOAR_DRY_RUN = True  # Hardcoded default safety invariant: real endpoint actions strictly disabled
SOAR_ALLOW_REAL_ENDPOINT_ACTIONS = False  # Explicit killswitch: Real endpoint modification permanently prohibited


def get_soar_execution_mode() -> str:
    """
    Returns the configured SOAR execution mode.
    Defaults to 'DRY_RUN'. Only authorized modes ('DRY_RUN', 'SIMULATION', 'ADVISORY')
    are permitted by the backend isolation guard.
    """
    mode = os.getenv("SOAR_EXECUTION_MODE", "DRY_RUN").strip().upper()
    return mode if mode else "DRY_RUN"


# Remote Endpoint Ingestion Configs
RECEIVER_HOST = os.getenv("RECEIVER_HOST", "0.0.0.0")
RECEIVER_PORT = int(os.getenv("RECEIVER_PORT", "5000"))
DEFAULT_ENDPOINT_ID = os.getenv("DEFAULT_ENDPOINT_ID", "EP-REMOTE-01")
COLLECTOR_VERSION = os.getenv("COLLECTOR_VERSION", "1.0.0")
PROJECT_TOKEN = os.getenv("PROJECT_TOKEN", "SENTINEL_SECRET_TOKEN_2026")
ENDPOINT_STATUS_FILE_PATH = DATA_DIR / "endpoint_status.json"
NETWORK_STATE_FILE_PATH = DATA_DIR / "network_state.json"
HEARTBEAT_TIMEOUT_SECONDS = int(os.getenv("HEARTBEAT_TIMEOUT_SECONDS", "30"))

# NXLog Ingestion & Centralized Network Configs
NXLOG_FILE_PATH = Path(os.getenv("NXLOG_FILE_PATH", r"C:\AdaptiveSentinel\windows-events.log"))
NXLOG_CURSOR_FILE_PATH = DATA_DIR / "nxlog_cursor.json"
DEMO_BASELINE_FILE_PATH = DATA_DIR / "nxlog_demo_baseline.json"
DASHBOARD_FILTER_STATE_FILE_PATH = DATA_DIR / "dashboard_filter_state.json"
NXLOG_PORT = int(os.getenv("NXLOG_PORT", "2514"))
ENDPOINT_HOSTNAME = os.getenv("ENDPOINT_HOSTNAME", "N/A")
RECEIVER_HOSTNAME = os.getenv("RECEIVER_HOSTNAME", "Sujith")

RECEIVER_IP_CACHE_TTL_SEC = float(INTERFACE_CACHE_TTL_SEC)
_RECEIVER_IP_CACHE: Dict[str, Any] = {
    "timestamp": 0.0,
    "key": None,
    "ip": None,
}


def clear_receiver_ip_cache() -> None:
    """Clears the cached receiver IP and underlying active-interface detection cache."""
    _RECEIVER_IP_CACHE["timestamp"] = 0.0
    _RECEIVER_IP_CACHE["key"] = None
    _RECEIVER_IP_CACHE["ip"] = None
    clear_interface_detection_cache()


def detect_local_ip(
    use_cache: bool = True,
    cache_ttl_sec: float = RECEIVER_IP_CACHE_TTL_SEC,
) -> str:
    """
    Detects the active non-loopback, non-virtual local IPv4 address using
    physical-first adapter inspection and UDP route probing.
    """
    _, ip_addr = detect_active_interface_and_ip(
        use_cache=use_cache,
        cache_ttl_sec=cache_ttl_sec,
    )
    if ip_addr and not ip_addr.startswith("127.") and ip_addr != "0.0.0.0":
        return ip_addr
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(0.1)
            s.connect(("10.255.255.255", 1))
            local_ip = s.getsockname()[0]
            if local_ip and not local_ip.startswith("127.") and local_ip != "0.0.0.0":
                return local_ip
    except Exception:
        pass
    return "127.0.0.1"


_DEFAULT_DETECT_LOCAL_IP = detect_local_ip


def get_receiver_ip(
    use_cache: bool = True,
    cache_ttl_sec: float = RECEIVER_IP_CACHE_TTL_SEC,
) -> str:
    """
    Returns the configured receiver IP address (honoring RECEIVER_ADVERTISED_IP,
    RECEIVER_IP, or SUJITH_IP environment overrides first), falling back to
    dynamic active interface detection with a 5-10s TTL cache.
    """
    for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
        val = os.getenv(env_key, "").strip()
        if val and val.upper() not in ("N/A", "NONE", "AUTO"):
            return val

    if detect_local_ip is not _DEFAULT_DETECT_LOCAL_IP:
        return detect_local_ip()

    cache_key = (
        id(detect_active_interface_and_ip),
        id(_net_disc.enumerate_windows_ipv4_interfaces),
        id(_net_disc.probe_os_route_ip),
    )
    now = time.monotonic()
    if use_cache and cache_ttl_sec > 0:
        cached_ip = _RECEIVER_IP_CACHE.get("ip")
        cached_ts = float(_RECEIVER_IP_CACHE.get("timestamp") or 0.0)
        if (
            cached_ip is not None
            and _RECEIVER_IP_CACHE.get("key") == cache_key
            and (now - cached_ts) < float(cache_ttl_sec)
        ):
            return str(cached_ip)

    resolved_ip = detect_local_ip(use_cache=use_cache, cache_ttl_sec=cache_ttl_sec)
    if use_cache and cache_ttl_sec > 0:
        _RECEIVER_IP_CACHE["timestamp"] = time.monotonic()
        _RECEIVER_IP_CACHE["key"] = cache_key
        _RECEIVER_IP_CACHE["ip"] = resolved_ip
    return resolved_ip



def get_endpoint_ip(observed_ip: str = None, receiver_ip: str = None) -> str:
    """
    Resolves the sender/endpoint IP from observed telemetry or explicit environment
    configuration (ENDPOINT_IP / HARSHA_IP).
    Never labels the receiver IP as the sender IP, and returns 'N/A' when unknown.
    """
    active_receiver = (receiver_ip or get_receiver_ip()).strip()
    invalid_tokens = {"", "-", "N/A", "NONE", "UNKNOWN", "127.0.0.1", "::1", "0.0.0.0"}

    if observed_ip is not None:
        candidate = str(observed_ip).strip()
        if candidate.upper() not in invalid_tokens and candidate != active_receiver:
            return candidate

    for env_key in ("ENDPOINT_IP", "HARSHA_IP"):
        val = os.getenv(env_key, "").strip()
        if val.upper() not in invalid_tokens and val != active_receiver:
            return val

    return "N/A"


def get_active_tcp_peer_ip(receiver_ip: Optional[str] = None) -> str:
    """
    Returns the primary active remote peer IP connected to TCP port NXLOG_PORT (2514),
    or 'N/A' if no established remote peer connection is currently present.
    Never returns the receiver's own IP.
    """
    active_receiver = (receiver_ip or get_receiver_ip()).strip()
    tcp_info = inspect_tcp_port_connections(port=NXLOG_PORT, receiver_ip=active_receiver)
    peers = tcp_info.get("remote_peer_ips", [])
    for p in peers:
        if is_valid_unicast_ipv4(p) and p != active_receiver:
            return p
    return "N/A"


_NETWORK_STATE_SERVICE = CentralNetworkStateService(
    state_file_path=NETWORK_STATE_FILE_PATH,
    endpoint_status_file_path=ENDPOINT_STATUS_FILE_PATH,
    receiver_port=NXLOG_PORT,
    default_receiver_hostname=RECEIVER_HOSTNAME,
    secret_token=PROJECT_TOKEN,
)


def get_central_network_state(
    observed_events: Optional[List[Dict[str, Any]]] = None,
    start_udp_responder: bool = False,
) -> Dict[str, Any]:
    """
    Refreshes and returns the authoritative CentralNetworkState dictionary
    used across all 9 dashboard sectors and pipeline reports.
    """
    if start_udp_responder:
        ensure_udp_discovery_responder(
            state_service=_NETWORK_STATE_SERVICE,
            port=NXLOG_PORT,
            secret_token=PROJECT_TOKEN,
        )
    return _NETWORK_STATE_SERVICE.refresh_state(observed_events=observed_events)


SUJITH_IP = get_receiver_ip()
RECEIVER_ADVERTISED_IP = SUJITH_IP
HARSHA_IP = get_endpoint_ip(receiver_ip=SUJITH_IP)
