import unittest
import json
import tempfile
import shutil
from pathlib import Path
from datetime import datetime, timedelta

from utils.network_log_server import (
    EndpointTracker,
    process_incoming_packet,
)


class TestRemoteWindowsIngestion(unittest.TestCase):

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.log_file = self.temp_dir / "windows_logs.json"
        self.status_file = self.temp_dir / "endpoint_status.json"
        self.tracker = EndpointTracker(status_file=self.status_file, timeout_seconds=2)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_valid_remote_event(self):
        """Test valid remote Windows event packet ingestion and metadata enrichment."""
        packet_data = json.dumps({
            "timestamp": "2026-10-02T12:00:00.000Z",
            "event_id": 4625,
            "hostname": "REMOTE-DESKTOP-01",
            "user": "harsha",
            "source_ip": "11.12.10.200",
            "process_name": "cmd.exe",
            "command_line": "cmd.exe /c whoami",
            "message": "Failed Remote Login Attempt",
            "endpoint_id": "EP-HARSHA-01",
            "collector_version": "1.2.0"
        }).encode('utf-8')

        result = process_incoming_packet(
            data_bytes=packet_data,
            addr=("11.12.10.200", 5000),
            tracker=self.tracker,
            log_file_path=self.log_file
        )

        self.assertTrue(result["success"])
        self.assertEqual(result["events_added"], 1)

        # Check stored event metadata
        with open(self.log_file, "r", encoding="utf-8") as f:
            logs = json.load(f)

        self.assertEqual(len(logs), 1)
        event = logs[0]
        self.assertEqual(event["source"], "remote_windows")
        self.assertEqual(event["endpoint_id"], "EP-HARSHA-01")
        self.assertEqual(event["hostname"], "REMOTE-DESKTOP-01")
        self.assertEqual(event["collector_version"], "1.2.0")
        self.assertEqual(event["transport"], "udp")
        self.assertIn("received_timestamp", event)
        self.assertIn("raw_event", event)
        self.assertEqual(event["raw_event"]["message"], "Failed Remote Login Attempt")

    def test_malformed_event(self):
        """Test rejection of malformed non-JSON data and non-dict payload items."""
        bad_json = b"THIS_IS_NOT_VALID_JSON{{"
        result = process_incoming_packet(
            data_bytes=bad_json,
            addr=("11.12.10.200", 5000),
            tracker=self.tracker,
            log_file_path=self.log_file
        )

        self.assertFalse(result["success"])
        self.assertEqual(result["events_added"], 0)

        # Verify tracker recorded malformed event error
        statuses = self.tracker.get_statuses()
        self.assertEqual(len(statuses), 1)
        self.assertGreaterEqual(statuses[0]["malformed_events"], 1)

    def test_duplicate_event(self):
        """Test fingerprint deduplication prevents duplicate writing."""
        packet_dict = {
            "timestamp": "2026-10-02T12:00:00.000Z",
            "event_id": 4688,
            "hostname": "REMOTE-DESKTOP-01",
            "user": "admin",
            "source_ip": "11.12.10.200",
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -Enc QnkgUGFzcz...",
            "message": "Duplicate Test Event"
        }
        packet_bytes = json.dumps(packet_dict).encode('utf-8')

        # First send
        res1 = process_incoming_packet(packet_bytes, ("11.12.10.200", 5000), tracker=self.tracker, log_file_path=self.log_file)
        self.assertEqual(res1["events_added"], 1)

        # Second send (Duplicate)
        res2 = process_incoming_packet(packet_bytes, ("11.12.10.200", 5000), tracker=self.tracker, log_file_path=self.log_file)
        self.assertEqual(res2["events_added"], 0)

        # Verify only 1 log stored on disk
        with open(self.log_file, "r", encoding="utf-8") as f:
            logs = json.load(f)
        self.assertEqual(len(logs), 1)

    def test_disconnected_endpoint(self):
        """Test endpoint transitions to disconnected status when heartbeat timeout expires."""
        self.tracker.record_packet(
            endpoint_id="EP-TIMEOUT-01",
            hostname="HOST-TIMEOUT",
            source_ip="10.0.0.99",
            event_count=1
        )

        # Override last_seen to 10 seconds in the past
        old_time = (datetime.now() - timedelta(seconds=10)).isoformat()
        self.tracker.endpoints["EP-TIMEOUT-01"]["last_seen"] = old_time
        self.tracker.save_status()

        statuses = self.tracker.get_statuses()
        self.assertEqual(len(statuses), 1)
        self.assertEqual(statuses[0]["status"], "disconnected")

    def test_reconnecting_endpoint(self):
        """Test disconnected endpoint status transitions back to connected upon receiving new telemetry."""
        # 1. Register as disconnected
        self.tracker.record_packet(
            endpoint_id="EP-RECONNECT-01",
            hostname="HOST-RECONNECT",
            source_ip="10.0.0.88"
        )
        old_time = (datetime.now() - timedelta(seconds=10)).isoformat()
        self.tracker.endpoints["EP-RECONNECT-01"]["last_seen"] = old_time
        self.tracker.save_status()

        self.assertEqual(self.tracker.get_statuses()[0]["status"], "disconnected")

        # 2. Receive new packet from endpoint
        packet_bytes = json.dumps({
            "endpoint_id": "EP-RECONNECT-01",
            "hostname": "HOST-RECONNECT",
            "event_id": 4624,
            "message": "Reconnecting Event"
        }).encode('utf-8')

        process_incoming_packet(packet_bytes, ("10.0.0.88", 5000), tracker=self.tracker, log_file_path=self.log_file)

        # 3. Status should now be connected
        statuses = self.tracker.get_statuses()
        self.assertEqual(statuses[0]["status"], "connected")

    def test_multiple_remote_events(self):
        """Test processing batch of multiple remote events in a single array payload."""
        batch_payload = [
            {"event_id": 4624, "hostname": "HOST-BATCH", "message": "Event 1", "timestamp": "2026-10-02T12:01:00"},
            {"event_id": 4625, "hostname": "HOST-BATCH", "message": "Event 2", "timestamp": "2026-10-02T12:02:00"},
            {"event_id": 1102, "hostname": "HOST-BATCH", "message": "Event 3", "timestamp": "2026-10-02T12:03:00"}
        ]
        packet_bytes = json.dumps(batch_payload).encode('utf-8')

        result = process_incoming_packet(packet_bytes, ("10.0.0.50", 5000), tracker=self.tracker, log_file_path=self.log_file)
        self.assertEqual(result["events_added"], 3)

        with open(self.log_file, "r", encoding="utf-8") as f:
            logs = json.load(f)
        self.assertEqual(len(logs), 3)

    def test_multiple_endpoints(self):
        """Test telemetry from distinct endpoints tracked independently."""
        ep1_bytes = json.dumps({"endpoint_id": "EP-01", "hostname": "HARSHA-LAPTOP", "event_id": 4624, "message": "EP1 Event"}).encode('utf-8')
        ep2_bytes = json.dumps({"endpoint_id": "EP-02", "hostname": "SUJITH-LAPTOP", "event_id": 4624, "message": "EP2 Event"}).encode('utf-8')

        process_incoming_packet(ep1_bytes, ("192.168.1.101", 5000), tracker=self.tracker, log_file_path=self.log_file)
        process_incoming_packet(ep2_bytes, ("192.168.1.102", 5000), tracker=self.tracker, log_file_path=self.log_file)

        statuses = self.tracker.get_statuses()
        self.assertEqual(len(statuses), 2)
        ep_ids = {ep["endpoint_id"] for ep in statuses}
        self.assertIn("EP-01", ep_ids)
        self.assertIn("EP-02", ep_ids)


if __name__ == "__main__":
    unittest.main()
