import unittest
import networkx as nx
from analysis.graph_visualizer import AttackGraphBuilder, generate_attack_graph_figure, generate_attack_timeline


class TestAttackGraphBuilder(unittest.TestCase):

    def setUp(self):
        self.sample_incidents = [
            {
                "incident_id": "INC-101",
                "incident_name": "Credential Access Campaign",
                "severity": "High",
                "affected_host": "Harsha",
                "affected_user": "HarshaAdmin",
                "confidence": 92,
                "alert_count": 2,
                "alerts": [
                    {
                        "alert_name": "Failed Authentication",
                        "mitre_technique": "T1110",
                        "mitre_tactic": "Credential Access",
                        "event": {
                            "event_id": 4625,
                            "event_type": "Failed Authentication",
                            "severity": "High",
                            "source": "real_nxlog_windows",
                            "timestamp": "2026-10-03T22:58:00Z",
                            "user": "HarshaAdmin",
                            "source_ip": "10.184.216.159",
                            "process_name": "svchost.exe",
                            "rule_id": "60106",
                            "rule_level": 10,
                            "mitre_techniques": ["T1110", "T1110.001"]
                        }
                    },
                    {
                        "alert_name": "Mimikatz LSASS Access",
                        "mitre_technique": "T1003",
                        "mitre_tactic": "Credential Access",
                        "event": {
                            "event_id": 10,
                            "event_type": "Sysmon Process Access",
                            "severity": "Critical",
                            "source": "real_nxlog_windows",
                            "timestamp": "2026-10-03T22:59:00Z",
                            "user": "SYSTEM",
                            "source_ip": "10.184.216.159",
                            "process_name": "mimikatz.exe",
                            "rule_id": "60800",
                            "rule_level": 12,
                            "mitre_techniques": ["T1003"]
                        }
                    }
                ]
            }
        ]

    def test_graph_construction_and_nodes(self):
        """Test NetworkX graph construction from real incident telemetry."""
        builder = AttackGraphBuilder()
        G = builder.build_graph(incidents=self.sample_incidents)

        self.assertGreater(G.number_of_nodes(), 0)
        self.assertGreater(G.number_of_edges(), 0)

        # Check Node Types
        node_types = set(nx.get_node_attributes(G, "type").values())
        self.assertIn("Incident", node_types)
        self.assertIn("Endpoint", node_types)
        self.assertIn("Event", node_types)
        self.assertIn("User", node_types)
        self.assertIn("Detection Rule", node_types)
        self.assertIn("MITRE Technique", node_types)

    def test_edge_relationships(self):
        """Test evidence edge relationships in graph."""
        builder = AttackGraphBuilder()
        G = builder.build_graph(incidents=self.sample_incidents)

        relationships = set(nx.get_edge_attributes(G, "relationship").values())
        self.assertIn("associated_with", relationships)
        self.assertIn("correlated_into", relationships)
        self.assertIn("generated", relationships)
        self.assertIn("triggered", relationships)
        self.assertIn("matched", relationships)
        self.assertIn("mapped_to", relationships)
        self.assertIn("followed_by", relationships)

    def test_graph_statistics(self):
        """Test calculation of graph node and edge statistics."""
        builder = AttackGraphBuilder()
        builder.build_graph(incidents=self.sample_incidents)
        stats = builder.get_graph_stats()

        self.assertGreater(stats["total_nodes"], 0)
        self.assertGreater(stats["total_edges"], 0)
        self.assertEqual(stats["endpoints_count"], 1)
        self.assertEqual(stats["incidents_count"], 1)
        self.assertGreaterEqual(stats["events_count"], 2)
        self.assertGreaterEqual(stats["mitre_techniques_count"], 2)

    def test_gnn_feature_export(self):
        """Test GNN-ready feature matrix extraction."""
        builder = AttackGraphBuilder()
        builder.build_graph(incidents=self.sample_incidents)
        gnn_data = builder.export_gnn_features()

        self.assertIn("node_features", gnn_data)
        self.assertIn("edge_index", gnn_data)
        self.assertIn("edge_features", gnn_data)
        self.assertIn("node_mapping", gnn_data)

        self.assertEqual(len(gnn_data["node_features"]), gnn_data["num_nodes"])
        self.assertEqual(len(gnn_data["edge_features"]), gnn_data["num_edges"])
        src_idx, _dst_idx = gnn_data["edge_index"]
        self.assertEqual(len(src_idx), gnn_data["num_edges"])

    def test_empty_graph_handling(self):
        """Test handling empty incidents/logs cleanly without error."""
        builder = AttackGraphBuilder()
        G = builder.build_graph(incidents=[])
        self.assertEqual(G.number_of_nodes(), 0)

        stats = builder.get_graph_stats()
        self.assertEqual(stats["total_nodes"], 0)

        fig = generate_attack_graph_figure(incidents=[])
        self.assertIsNotNone(fig)

    def test_attack_timeline_generation(self):
        """Test attack timeline extraction and chronological sorting."""
        timeline = generate_attack_timeline(incidents=self.sample_incidents)
        self.assertEqual(len(timeline), 2)
        self.assertEqual(timeline[0]["event"], "Event 4625 (Failed Authentication)")
        self.assertEqual(timeline[1]["event"], "Event 10 (Sysmon Process Access)")


if __name__ == "__main__":
    unittest.main()
