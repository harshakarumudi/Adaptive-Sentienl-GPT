import unittest
from pathlib import Path
import sys

# Ensure project root is in sys.path
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from analysis.parser import NXLogReader
from analysis.normalize import normalize_events
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent
from config.settings import NXLOG_FILE_PATH


class TestSector1Metrics(unittest.TestCase):
    """
    Regression test suite for Sector 1 Dashboard Metrics verification:
    1. Metric calculation accuracy (Total Logs, Live NXLog Stream, Correlated Incidents, High/Critical Incidents).
    2. Incident ID uniqueness (no duplicate IDs or hash collisions).
    3. Structural distinction between Incidents (attack chains) and Alerts (atomic detections).
    4. Supporting evidence and provenance for each correlated incident.
    5. Live NXLog telemetry pipeline execution (Reader -> Normalizer -> Detection -> Correlation).
    6. Severity distribution totality and rerun idempotency (no count inflation).
    7. Telemetry source filtering isolation and reset baseline (0 logs).
    """

    def setUp(self):
        self.detector = DetectionAgent()
        self.correlator = CorrelationAgent()

    def test_incident_uniqueness_and_structure(self):
        """
        Verify that correlated incidents are unique multi-alert structures with distinct IDs,
        not simple alert counts or duplicate objects.
        """
        test_alerts = [
            # Group 1: Harsha :: Administrator (Enumeration)
            {
                "alert_name": "Account Discovery: Group Membership Enumeration (Administrator)",
                "severity": "Medium",
                "confidence": 85,
                "event": {
                    "event_id": 4798,
                    "hostname": "Harsha",
                    "user": "Administrator",
                    "source": "real_nxlog_windows",
                    "source_ip": "10.184.216.159"
                }
            },
            {
                "alert_name": "Account Discovery: Group Membership Enumeration (Administrator)",
                "severity": "Medium",
                "confidence": 85,
                "event": {
                    "event_id": 4798,
                    "hostname": "Harsha",
                    "user": "Administrator",
                    "source": "real_nxlog_windows",
                    "source_ip": "10.184.216.159"
                }
            },
            # Group 2: Harsha :: Harsha (Credential Vault Access + Discovery)
            {
                "alert_name": "Windows Credential Manager Access & Harvesting",
                "severity": "High",
                "confidence": 90,
                "event": {
                    "event_id": 5379,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "source": "real_nxlog_windows",
                    "source_ip": "10.184.216.159"
                }
            },
            {
                "alert_name": "Account Discovery: Group Membership Enumeration (Harsha)",
                "severity": "Medium",
                "confidence": 85,
                "event": {
                    "event_id": 4798,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "source": "real_nxlog_windows",
                    "source_ip": "10.184.216.159"
                }
            },
            # Group 3: FINANCE-WORKSTATION :: corp\\jdoe (Ransomware)
            {
                "alert_name": "Volume Shadow Copies Deletion (Ransomware Activity)",
                "severity": "Critical",
                "confidence": 98,
                "event": {
                    "event_id": 4688,
                    "hostname": "FINANCE-WORKSTATION",
                    "user": "corp\\jdoe",
                    "source": "synthetic",
                    "command_line": "vssadmin.exe delete shadows /all /quiet"
                }
            }
        ]

        incidents = self.correlator.correlate(test_alerts)

        # 5 alerts should be grouped into exactly 3 incidents
        self.assertEqual(len(incidents), 3, "Alerts must be aggregated into unique host::user incidents")
        
        # Verify unique Incident IDs
        incident_ids = [inc["incident_id"] for inc in incidents]
        self.assertEqual(len(incident_ids), len(set(incident_ids)), "Every incident must have a unique ID")

        # Verify each incident contains alert count and underlying alerts array
        for inc in incidents:
            self.assertIn("incident_id", inc)
            self.assertIn("incident_name", inc)
            self.assertIn("severity", inc)
            self.assertIn("alerts", inc)
            self.assertGreaterEqual(inc["alert_count"], 1)
            self.assertEqual(len(inc["alerts"]), inc["alert_count"])
            # Verify evidence presence in each alert
            for alt in inc["alerts"]:
                self.assertIn("event", alt)
                self.assertIn("event_id", alt["event"])
                self.assertIn("hostname", alt["event"])

    def test_high_critical_incident_calculation_rule(self):
        """
        Verify that High/Critical metric counts INCIDENTS (not raw events or alerts),
        and that High/Critical count equals total incident count when all incidents are High/Critical.
        """
        mock_incidents = [
            {"incident_id": "INC-001", "severity": "Critical", "affected_host": "H1", "alerts": [{}]},
            {"incident_id": "INC-002", "severity": "High", "affected_host": "H2", "alerts": [{}]},
            {"incident_id": "INC-003", "severity": "High", "affected_host": "H3", "alerts": [{}]},
            {"incident_id": "INC-004", "severity": "Critical", "affected_host": "H4", "alerts": [{}]},
            {"incident_id": "INC-005", "severity": "High", "affected_host": "H5", "alerts": [{}]},
            {"incident_id": "INC-006", "severity": "Critical", "affected_host": "H6", "alerts": [{}]},
        ]

        incidents_count = len(mock_incidents)
        high_crit_count = sum(1 for inc in mock_incidents if inc.get("severity") in ("Critical", "High"))

        self.assertEqual(incidents_count, 6)
        self.assertEqual(high_crit_count, 6)
        self.assertEqual(incidents_count, high_crit_count, 
                         "When all 6 incidents are High or Critical, Correlated Incidents and High/Critical Incidents must both equal 6")

        # Now introduce a Medium incident: counts must diverge
        mock_incidents.append({"incident_id": "INC-007", "severity": "Medium", "affected_host": "H7", "alerts": [{}]})
        incidents_count_2 = len(mock_incidents)
        high_crit_count_2 = sum(1 for inc in mock_incidents if inc.get("severity") in ("Critical", "High"))
        self.assertEqual(incidents_count_2, 7)
        self.assertEqual(high_crit_count_2, 6, "Medium incident should not increment High/Critical Incidents")

    def test_severity_distribution_totality(self):
        """
        Verify that Low + Medium + High + Critical strictly equals 100% of analyzed logs.
        """
        test_logs = [
            {"severity": "Critical"},
            {"severity": "High"},
            {"severity": "HIGH"},
            {"severity": "Medium"},
            {"severity": "medium"},
            {"severity": "Low"},
            {"severity": "Informational"},
            {"severity": ""},        # unclassified -> fallback to Low
            {"severity": "unknown"}   # unclassified -> fallback to Low
        ]

        crit_logs = sum(1 for l in test_logs if str(l.get("severity", "")).strip().title() == "Critical")
        high_logs = sum(1 for l in test_logs if str(l.get("severity", "")).strip().title() == "High")
        med_logs  = sum(1 for l in test_logs if str(l.get("severity", "")).strip().title() == "Medium")
        low_logs  = max(0, len(test_logs) - (crit_logs + high_logs + med_logs))

        self.assertEqual(crit_logs, 1)
        self.assertEqual(high_logs, 2)
        self.assertEqual(med_logs, 2)
        self.assertEqual(low_logs, 4)
        self.assertEqual(crit_logs + high_logs + med_logs + low_logs, len(test_logs), 
                         "Severity totals must account for exactly 100% of logs")

    def test_real_nxlog_pipeline_execution(self):
        """
        Verify that live NXLog logs pass completely through the detection and correlation pipeline.
        """
        if not NXLOG_FILE_PATH.exists():
            self.skipTest(f"NXLog file not present at {NXLOG_FILE_PATH}")

        reader = NXLogReader()
        raw_events = reader.get_recent_events(max_events=300)
        self.assertGreater(len(raw_events), 0, "NXLog file should contain live events")

        normalized = normalize_events(raw_events)
        self.assertEqual(len(normalized), len(raw_events), "All raw events must be normalized")
        for evt in normalized:
            self.assertEqual(evt.get("source"), "real_nxlog_windows")

        alerts = self.detector.detect(normalized)
        self.assertGreaterEqual(len(alerts), 0)

        incidents = self.correlator.correlate(alerts)
        self.assertGreaterEqual(len(incidents), 0)

        # Verify all incidents are distinct and contain alerts
        incident_ids = [inc["incident_id"] for inc in incidents]
        self.assertEqual(len(incident_ids), len(set(incident_ids)), "Real NXLog incidents must all have distinct IDs")

        for inc in incidents:
            self.assertTrue(inc["severity"] in ("Critical", "High", "Medium", "Low"))
            self.assertGreaterEqual(inc["alert_count"], 1)
            # Verify provenance: alerts come from real_nxlog_windows
            sources = [a.get("event", {}).get("source") for a in inc.get("alerts", [])]
            self.assertTrue(all(s == "real_nxlog_windows" for s in sources))

    def test_rerun_idempotency_no_inflation(self):
        """
        Verify that multiple reruns on the same logs do not duplicate logs or inflate counts.
        """
        base_logs = [{"event_id": 4625, "user": f"u{i}", "severity": "Low"} for i in range(50)]
        nxlog_logs = [{"event_id": 4798, "user": f"nx_{i}", "severity": "High"} for i in range(20)]

        # Run 1: merge ALL SOURCES
        display_logs_1 = list(base_logs) + [l for l in nxlog_logs if l not in base_logs]
        count_1 = len(display_logs_1)
        self.assertEqual(count_1, 70)

        # Run 2: simulate Streamlit rerun without new ingest
        display_logs_2 = list(base_logs) + [l for l in nxlog_logs if l not in base_logs]
        count_2 = len(display_logs_2)
        self.assertEqual(count_2, count_1, "Reruns without new data must produce invariant log counts")

        # Severity counts must remain invariant
        high_1 = sum(1 for l in display_logs_1 if str(l.get("severity", "")).strip().title() == "High")
        high_2 = sum(1 for l in display_logs_2 if str(l.get("severity", "")).strip().title() == "High")
        self.assertEqual(high_1, high_2)


if __name__ == "__main__":
    unittest.main()
