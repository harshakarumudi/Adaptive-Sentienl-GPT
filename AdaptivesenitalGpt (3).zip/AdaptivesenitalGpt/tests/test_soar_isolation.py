import os
import unittest
import tempfile
import shutil
from pathlib import Path
from unittest.mock import MagicMock

from config.settings import (
    SOAR_EXECUTION_MODE,
    SOAR_DRY_RUN,
    SOAR_ALLOW_REAL_ENDPOINT_ACTIONS,
    get_soar_execution_mode,
)
from soar.guard import SOARExecutionGuard
from soar.action_registry import SOARActionRegistry
from soar.executor import BaseSOARExecutor, MockSOARExecutor
from soar.audit_logger import SOARAuditLogger
from soar.decision_engine import SOARDecisionEngine
from agents.response_planning_agent import ResponsePlanningAgent
from llm.llm_client import LLMClient


class TestSOARSimulationIsolation(unittest.TestCase):
    """
    Comprehensive verification of SOAR simulation-only isolation, fail-closed guards,
    and prohibition of real endpoint containment/remediation actions.
    """

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.temp_db_path = str(Path(self.temp_dir) / "test_isolated_audit.db")
        self.audit_logger = SOARAuditLogger(db_path=self.temp_db_path)
        self.registry = SOARActionRegistry()
        self.guard = SOARExecutionGuard(mode="DRY_RUN")
        self.executor = MockSOARExecutor(registry=self.registry, guard=self.guard)

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_01_default_configuration_is_dry_run(self):
        """Proves default configuration is DRY_RUN and killswitches are permanently active."""
        self.assertEqual(SOAR_EXECUTION_MODE, "DRY_RUN")
        self.assertTrue(SOAR_DRY_RUN)
        self.assertFalse(SOAR_ALLOW_REAL_ENDPOINT_ACTIONS)
        self.assertEqual(get_soar_execution_mode(), "DRY_RUN")

        default_guard = SOARExecutionGuard()
        self.assertEqual(default_guard.get_effective_mode(), "DRY_RUN")
        is_valid, active_mode, msg = default_guard.validate_mode()
        self.assertTrue(is_valid)
        self.assertEqual(active_mode, "DRY_RUN")

    def test_02_simulated_action_never_invokes_real_action_handler(self):
        """Proves a simulated action never invokes real actions and execute_real_action fails closed."""
        # 1. Simulated execution
        res_dry = self.executor.execute_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=True)
        self.assertFalse(res_dry["real_endpoint_action_taken"])
        self.assertFalse(res_dry["details"]["real_endpoint_action_taken"])
        self.assertEqual(res_dry["status"], "DRY_RUN")

        res_sim = self.executor.execute_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=False)
        self.assertFalse(res_sim["real_endpoint_action_taken"])
        self.assertFalse(res_sim["details"]["real_endpoint_action_taken"])
        self.assertEqual(res_sim["status"], "EXECUTED")
        self.assertEqual(res_sim["lifecycle_state"], "COMPLETED_IN_SIMULATION")

        # 2. Direct attempt to invoke real execution fails closed
        res_real = self.executor.execute_real_action("ISOLATE_HOST", "WORKSTATION-01")
        self.assertEqual(res_real["status"], "REFUSED")
        self.assertEqual(res_real["lifecycle_state"], "REFUSED_FAIL_CLOSED")
        self.assertFalse(res_real["real_endpoint_action_taken"])
        self.assertIn("REFUSED FAIL-CLOSED", res_real["error_message"])

    def test_03_ui_approval_cannot_bypass_backend_guard(self):
        """Proves analyst approval click cannot bypass simulation isolation or trigger real actions."""
        # Analyst approval passed into parameters
        params_approved = {"analyst_approval": "APPROVED", "username": "harsha_admin"}
        res = self.executor.execute_action(
            "LOCK_USER",
            "harsha_admin",
            parameters=params_approved,
            dry_run=False
        )
        self.assertEqual(res["status"], "EXECUTED")
        self.assertEqual(res["lifecycle_state"], "COMPLETED_IN_SIMULATION")
        self.assertFalse(res["real_endpoint_action_taken"])
        self.assertFalse(res["details"]["real_endpoint_action_taken"])
        self.assertEqual(res["simulation_banner"], "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN")

        # Even with approval, if mode is unknown, execution is strictly refused
        invalid_guard_executor = MockSOARExecutor(registry=self.registry, execution_mode="PRODUCTION")
        refused_res = invalid_guard_executor.execute_action(
            "LOCK_USER",
            "harsha_admin",
            parameters=params_approved,
            dry_run=False
        )
        self.assertEqual(refused_res["status"], "REFUSED")
        self.assertEqual(refused_res["lifecycle_state"], "REFUSED_FAIL_CLOSED")
        self.assertFalse(refused_res["real_endpoint_action_taken"])

    def test_04_unknown_or_missing_mode_fails_closed(self):
        """Proves unknown, missing, empty, or unverified modes fail closed."""
        for invalid_mode in ["UNKNOWN", "", "PRODUCTION", "LIVE", "DANGEROUS_REMEDIATION", "INVALID", "NULL"]:
            exec_fail_closed = MockSOARExecutor(registry=self.registry, execution_mode=invalid_mode)
            res = exec_fail_closed.execute_action("BLOCK_IP", "198.51.100.99", dry_run=False)
            self.assertEqual(res["status"], "REFUSED")
            self.assertEqual(res["lifecycle_state"], "REFUSED_FAIL_CLOSED")
            self.assertFalse(res["real_endpoint_action_taken"])
            self.assertIn("FAIL-CLOSED", res["error_message"])

            # Rollback also fails closed under invalid mode
            rb_res = exec_fail_closed.rollback_action("BLOCK_IP", "198.51.100.99", dry_run=False)
            self.assertEqual(rb_res["status"], "REFUSED")
            self.assertEqual(rb_res["lifecycle_state"], "REFUSED_FAIL_CLOSED")
            self.assertFalse(rb_res["real_endpoint_action_taken"])

        # Test completely missing / empty mode configuration
        guard_missing = SOARExecutionGuard(mode="")
        is_val, active_m, msg = guard_missing.validate_mode()
        self.assertFalse(is_val)
        self.assertEqual(active_m, "MISSING_MODE")
        self.assertIn("FAIL-CLOSED", msg)

        exec_missing = MockSOARExecutor(registry=self.registry, guard=guard_missing)
        res_missing = exec_missing.execute_action("ISOLATE_HOST", "WORKSTATION-01", dry_run=False)
        self.assertEqual(res_missing["status"], "REFUSED")
        self.assertEqual(res_missing["lifecycle_state"], "REFUSED_FAIL_CLOSED")
        self.assertFalse(res_missing["real_endpoint_action_taken"])

    def test_05_every_available_soar_action_follows_same_guard(self):
        """Proves every allowlisted SOAR action enforces the isolation guard and real_endpoint_action_taken=False."""
        all_actions = self.registry.list_allowlisted_actions()
        self.assertGreaterEqual(len(all_actions), 8)

        sample_targets = {
            "ISOLATE_HOST": ("WORKSTATION-01", {"hostname": "WORKSTATION-01"}),
            "BLOCK_IP": ("198.51.100.55", {"ip_address": "198.51.100.55"}),
            "LOCK_USER": ("suspicious_user", {"username": "suspicious_user"}),
            "COLLECT_FORENSIC_ARTIFACTS": ("WORKSTATION-01", {"hostname": "WORKSTATION-01", "artifact_type": "triage_package"}),
            "UNISOLATE_HOST": ("WORKSTATION-01", {"hostname": "WORKSTATION-01"}),
            "UNBLOCK_IP": ("198.51.100.55", {"ip_address": "198.51.100.55"}),
            "UNLOCK_USER": ("suspicious_user", {"username": "suspicious_user"}),
            "TERMINATE_PROCESS": ("powershell.exe", {"hostname": "WORKSTATION-01", "process_name": "powershell.exe"}),
        }

        for action_meta in all_actions:
            act_id = action_meta["action_id"]
            target, params = sample_targets.get(act_id, ("WORKSTATION-01", {}))

            # Dry-run
            dry_res = self.executor.execute_action(act_id, target, parameters=params, dry_run=True)
            self.assertEqual(dry_res["status"], "DRY_RUN")
            self.assertFalse(dry_res["real_endpoint_action_taken"])

            # Simulation
            sim_res = self.executor.execute_action(act_id, target, parameters=params, dry_run=False)
            self.assertEqual(sim_res["status"], "EXECUTED")
            self.assertEqual(sim_res["lifecycle_state"], "COMPLETED_IN_SIMULATION")
            self.assertFalse(sim_res["real_endpoint_action_taken"])
            self.assertFalse(sim_res["details"]["real_endpoint_action_taken"])

            # Fail-closed check under invalid mode
            fail_executor = MockSOARExecutor(registry=self.registry, execution_mode="INVALID")
            fail_res = fail_executor.execute_action(act_id, target, parameters=params, dry_run=False)
            self.assertEqual(fail_res["status"], "REFUSED")
            self.assertFalse(fail_res["real_endpoint_action_taken"])

    def test_06_advisory_playbooks_render_correctly(self):
        """Proves advisory playbooks remain fully functional with advisory-only recommendations."""
        incident = {
            "incident_id": "INC-85D28A",
            "incident_name": "Context-Aware Privilege Escalation Activity",
            "severity": "High",
            "affected_host": "Harsha",
            "affected_user": "HarshaAdmin",
            "alerts": [
                {
                    "event": {
                        "event_id": 4672,
                        "hostname": "Harsha",
                        "user": "HarshaAdmin",
                        "rule_id": "RULE-PRIVESC-CONTEXT-01",
                        "mitre_technique": "T1548.002",
                    }
                }
            ],
        }

        agent = ResponsePlanningAgent()
        plans = agent.plan([incident])
        self.assertEqual(len(plans), 1)
        plan = plans[0]

        self.assertEqual(plan["incident_id"], "INC-85D28A")
        self.assertEqual(plan["advisory_status"], "Advisory Recommendation — Not Executed")
        for step in plan["containment_actions"]:
            self.assertIn("Advisory Recommendation — Not Executed", step)
        for step in plan["eradication_actions"]:
            self.assertIn("Advisory Recommendation — Not Executed", step)
        for step in plan["recovery_actions"]:
            self.assertIn("Advisory Recommendation — Not Executed", step)

    def test_07_existing_incident_history_and_audit_data_remain_intact(self):
        """Proves audit logger records real_endpoint_action_taken=False and existing live database remains untouched."""
        live_db_path = Path(__file__).resolve().parent.parent / "data" / "soar_audit.db"
        self.assertTrue(live_db_path.exists(), "Live soar_audit.db must exist.")
        self.assertGreater(live_db_path.stat().st_size, 0, "Live soar_audit.db must not be empty or truncated.")

        # Test in isolated temp DB
        audit_record = {
            "incident_id": "INC-TEST-ISOLATION",
            "action_id": "ISOLATE_HOST",
            "analyst_approval": "APPROVED",
            "analyst_user": "soc_analyst",
            "target": "Harsha",
            "action_status": "EXECUTED",
            "verification_result": "VERIFIED_SUCCESS",
            "rollback_status": "AVAILABLE",
            "gnn_score": 0.85,
            "rule_id": "RULE-PRIVESC-CONTEXT-01",
            "mitre_technique": "T1548.002",
            "dry_run": False,
            "details": {
                "real_endpoint_action_taken": False,
                "guard_status": "ISOLATION_ENFORCED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"
            }
        }
        audit_id = self.audit_logger.log_event(audit_record)
        self.assertTrue(audit_id.startswith("AUDIT-"))

        records = self.audit_logger.get_audit_records(incident_id="INC-TEST-ISOLATION")
        self.assertEqual(len(records), 1)
        retrieved_details = records[0]["details"]
        self.assertFalse(retrieved_details["real_endpoint_action_taken"])
        self.assertEqual(retrieved_details["guard_status"], "ISOLATION_ENFORCED")


if __name__ == "__main__":
    unittest.main()
