import os
import sys
import json

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config.settings import get_receiver_ip, ENDPOINT_HOSTNAME
from analysis.parser import NXLogReader
from analysis.normalize import (
    LogNormalizer,
    build_endpoint_inventory,
    filter_telemetry_by_endpoint,
)
from analysis.deduplicate import LogDeduplicator, get_event_identity_key
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent

RECEIVER_IP = get_receiver_ip()


def test_settings_default_endpoint_hostname_is_not_harsha():
    """Verify unconfigured ENDPOINT_HOSTNAME defaults to N/A rather than assuming Harsha."""
    if "ENDPOINT_HOSTNAME" not in os.environ:
        assert ENDPOINT_HOSTNAME == "N/A"


def test_multi_endpoint_parsing_preserves_hostnames_and_separate_ip_fields(tmp_path):
    """
    Requirements 1, 2, 3, 4:
    - Support events from multiple distinct Windows endpoint hostnames (e.g., Harsha, LAPTOP-2, UNKNOWN_HOST).
    - Never default an unknown host to Harsha.
    - Keep hostname, source_ip, receiver_ip, and remote_peer_ip as separate fields.
    - Never infer source_ip from receiver_ip.
    """
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        # 1. Harsha 4-field header without source IP
        "2026-10-10 15:00:01 Harsha INFO 4688 A new process has been created. Creator Process Name: C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        # 2. LAPTOP-2 4-field header with explicit Source Network Address
        "2026-10-10 15:00:05 LAPTOP-2 WARNING 4625 An account failed to log on. Account Name: admin Source Network Address: 192.168.1.55",
        # 3. JSON event from WIN-SEC-03 with RemoteAddress (TCP peer) but no event Source IP
        json.dumps({
            "EventTime": "2026-10-10 15:00:10",
            "Hostname": "WIN-SEC-03",
            "EventID": 4672,
            "Severity": "INFO",
            "AccountName": "sec_op",
            "MessageSourceAddress": "11.12.7.105",
            "Message": "Special privileges assigned to new logon.",
            "RecordNumber": 9001,
        }),
        # 4. Raw line with no hostname and no IP -> must become UNKNOWN_HOST and N/A, never Harsha or RECEIVER_IP
        "4624 An account was successfully logged on without header metadata",
    ]
    log_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    raw_events = reader.read_events()
    assert len(raw_events) == 4

    normalizer = LogNormalizer()
    norm_events = normalizer.normalize(raw_events)
    assert len(norm_events) == 4

    # Event 1: Harsha, no source IP, no remote peer IP
    e1 = norm_events[0]
    assert e1["hostname"] == "Harsha"
    assert e1["source_ip"] == "N/A"
    assert e1["remote_peer_ip"] == "N/A"
    assert e1["receiver_ip"] == RECEIVER_IP
    assert e1["source_ip"] != RECEIVER_IP

    # Event 2: LAPTOP-2, explicit source IP 192.168.1.55, no remote peer IP
    e2 = norm_events[1]
    assert e2["hostname"] == "LAPTOP-2"
    assert e2["source_ip"] == "192.168.1.55"
    assert e2["remote_peer_ip"] == "N/A"
    assert e2["receiver_ip"] == RECEIVER_IP

    # Event 3: WIN-SEC-03, no event source IP (must stay N/A), remote_peer_ip = 11.12.7.105
    e3 = norm_events[2]
    assert e3["hostname"] == "WIN-SEC-03"
    assert e3["source_ip"] == "N/A"
    assert e3["remote_peer_ip"] == "11.12.7.105"
    assert e3["receiver_ip"] == RECEIVER_IP
    assert e3["record_id"] == 9001

    # Event 4: Missing hostname -> UNKNOWN_HOST (never Harsha), missing IP -> N/A
    e4 = norm_events[3]
    assert e4["hostname"] == "UNKNOWN_HOST"
    assert e4["hostname"] != "Harsha"
    assert e4["source_ip"] == "N/A"
    assert e4["remote_peer_ip"] == "N/A"


def test_duplicate_looking_but_distinct_events_preserved(tmp_path):
    """
    Requirement 8:
    Make deduplication safe for repeated legitimate events; do not discard separate
    events solely because their raw text matches.
    """
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    # Two identical raw lines written sequentially to the receiver log file
    identical_line = (
        "2026-10-10 15:10:00 Harsha INFO 4688 A new process has been created. "
        "Creator Process Name: C:\\Windows\\System32\\whoami.exe"
    )
    log_file.write_text(identical_line + "\n" + identical_line + "\n", encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    parsed = reader.read_events()
    assert len(parsed) == 2

    # Distinct byte offsets must be recorded for the two separate file lines
    assert parsed[0]["record_offset"] != parsed[1]["record_offset"]
    assert get_event_identity_key(parsed[0]) != get_event_identity_key(parsed[1])

    normalizer = LogNormalizer()
    normalized = normalizer.normalize(parsed)
    assert len(normalized) == 2

    deduplicator = LogDeduplicator()
    deduped = deduplicator.remove_duplicates(normalized)
    assert len(deduped) == 2, "Separate legitimate records in the log file must not be discarded when raw text matches"

    # Conversely, replaying the exact same file offsets produces matching identity keys
    replayed = reader.replay_events()
    assert len(replayed) == 2
    assert get_event_identity_key(replayed[0]) == get_event_identity_key(parsed[0])
    assert get_event_identity_key(replayed[1]) == get_event_identity_key(parsed[1])


def test_multi_endpoint_attribution_through_detection_and_correlation(tmp_path):
    """
    Requirements 7 & 9:
    Ensure events from different hosts remain correctly attributed through parsing,
    detection, and correlation, and diagnostic probes stay separated from genuine incidents.
    """
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        # Host 1 (Harsha): encoded PowerShell security alert
        "2026-10-10 15:20:01 Harsha CRITICAL 4688 A new process has been created. New Process Name: C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe Process Command Line: powershell.exe -EncodedCommand JABzAD0ATgBlAHcALQBPAGIAagBlAGMAdAA=",
        # Host 2 (LAPTOP-2): failed logon with explicit source IP
        "2026-10-10 15:20:02 LAPTOP-2 HIGH 4625 An account failed to log on. Account Name: finance_admin Source Network Address: 10.20.30.40",
        # Host 2 (LAPTOP-2): PHASE3 diagnostic probe
        "2026-10-10 15:20:03 LAPTOP-2 INFO 4688 PHASE3_MULTI_ENDPOINT_PROBE_LAPTOP2 process creation test",
    ]
    log_file.write_text("\n".join(lines) + "\n", encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    normalizer = LogNormalizer()
    deduplicator = LogDeduplicator()
    detector = DetectionAgent()
    correlator = CorrelationAgent()

    norm_events = deduplicator.remove_duplicates(normalizer.normalize(reader.read_events()))
    assert len(norm_events) == 3

    alerts = detector.detect(norm_events)
    assert len(alerts) == 3

    # Verify alert attribution
    harsha_alerts = [a for a in alerts if a["hostname"] == "Harsha"]
    laptop2_alerts = [a for a in alerts if a["hostname"] == "LAPTOP-2"]
    assert len(harsha_alerts) == 1
    assert harsha_alerts[0]["source_ip"] == "N/A"
    assert not harsha_alerts[0]["is_diagnostic"]

    assert len(laptop2_alerts) == 2
    sec_laptop2 = [a for a in laptop2_alerts if not a["is_diagnostic"]]
    diag_laptop2 = [a for a in laptop2_alerts if a["is_diagnostic"]]
    assert len(sec_laptop2) == 1
    assert sec_laptop2[0]["source_ip"] == "10.20.30.40"
    assert len(diag_laptop2) == 1
    assert "PHASE3_MULTI_ENDPOINT_PROBE_LAPTOP2" in diag_laptop2[0]["event"]["description"]

    # Correlate into incidents and verify hosts are not merged together
    incidents = correlator.correlate(alerts)
    security_incidents = [i for i in incidents if not i.get("is_diagnostic")]
    diagnostic_incidents = [i for i in incidents if i.get("is_diagnostic")]

    assert len(security_incidents) == 2
    assert len(diagnostic_incidents) == 1
    assert diagnostic_incidents[0]["affected_host"] == "LAPTOP-2"

    inc_hosts = {inc["affected_host"]: inc for inc in security_incidents}
    assert "Harsha" in inc_hosts
    assert "LAPTOP-2" in inc_hosts
    assert inc_hosts["Harsha"]["observed_source_ips"] == ["N/A"]
    assert inc_hosts["LAPTOP-2"]["observed_source_ips"] == ["10.20.30.40"]


def test_endpoint_inventory_and_endpoint_filtering(tmp_path):
    """
    Requirements 5 & 6:
    - Endpoint inventory in Sector 1 uses observed telemetry: hostname, latest_timestamp,
      event_count, observed_source_ip (N/A when unknown), and observed_remote_peer_ip.
    - Filtering by endpoint works cleanly without breaking source isolation.
    """
    events = [
        {
            "timestamp": "2026-10-10 15:01:00",
            "hostname": "Harsha",
            "source_ip": "N/A",
            "remote_peer_ip": "N/A",
            "source": "real_nxlog_windows",
            "severity": "Low",
        },
        {
            "timestamp": "2026-10-10 15:05:00",
            "hostname": "Harsha",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.7.88",
            "source": "real_nxlog_windows",
            "severity": "High",
        },
        {
            "timestamp": "2026-10-10 15:03:00",
            "hostname": "LAPTOP-2",
            "source_ip": "192.168.10.25",
            "remote_peer_ip": "11.12.7.99",
            "source": "real_nxlog_windows",
            "severity": "Medium",
        },
    ]

    inventory = build_endpoint_inventory(events)
    assert len(inventory) == 2
    by_host = {item["hostname"]: item for item in inventory}

    assert by_host["Harsha"]["event_count"] == 2
    assert by_host["Harsha"]["latest_timestamp"] == "2026-10-10 15:05:00"
    assert by_host["Harsha"]["observed_source_ip"] == "N/A"
    assert by_host["Harsha"]["observed_remote_peer_ip"] == "11.12.7.88"

    assert by_host["LAPTOP-2"]["event_count"] == 1
    assert by_host["LAPTOP-2"]["latest_timestamp"] == "2026-10-10 15:03:00"
    assert by_host["LAPTOP-2"]["observed_source_ip"] == "192.168.10.25"
    assert by_host["LAPTOP-2"]["observed_remote_peer_ip"] == "11.12.7.99"

    incidents = [
        {"incident_name": "Harsha Incident", "affected_host": "Harsha", "alerts": [{"hostname": "Harsha", "event": events[1]}]},
        {"incident_name": "Laptop2 Incident", "affected_host": "LAPTOP-2", "alerts": [{"hostname": "LAPTOP-2", "event": events[2]}]},
    ]

    # Filter by Harsha
    f_logs, f_inc = filter_telemetry_by_endpoint(events, incidents, "Harsha")
    assert len(f_logs) == 2
    assert all(l["hostname"] == "Harsha" for l in f_logs)
    assert len(f_inc) == 1
    assert f_inc[0]["affected_host"] == "Harsha"

    # Filter by LAPTOP-2
    f_logs_2, f_inc_2 = filter_telemetry_by_endpoint(events, incidents, "LAPTOP-2")
    assert len(f_logs_2) == 1
    assert f_logs_2[0]["hostname"] == "LAPTOP-2"
    assert len(f_inc_2) == 1
    assert f_inc_2[0]["affected_host"] == "LAPTOP-2"

    # ALL ENDPOINTS returns full list
    f_logs_all, f_inc_all = filter_telemetry_by_endpoint(events, incidents, "ALL ENDPOINTS")
    assert len(f_logs_all) == 3
    assert len(f_inc_all) == 2


def test_regression_phase3_windows_event_marker_and_multiline_guid_handling(tmp_path):
    """
    Tasks 4 & 5 Regression Test:
    - Uses a temporary receiver-log file and temporary cursor file.
    - Includes a multiline Event 10016 containing Windows GUID lines ({...}) and 'from address LocalHost',
      an uppercase 'HARSHA' probe, and a trailing Event 5379 Credential Manager block.
    - Appends the exact marker '2026-10-10 16:08:33 Harsha INFO 1000 HARSHA\\Harsha PHASE3_WINDOWS_EVENT_20261010_160833'.
    - Invokes the same reader paths used by the dashboard (get_recent_events and read_events(incremental=True))
      and verifies the exact marker is returned with hostname='Harsha', is_diagnostic=True, no bogus 'address'
      or 'UNKNOWN_HOST' fragments, and case-insensitive endpoint filtering ('Harsha' vs 'HARSHA').
    """
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    initial_content = (
        "2026-10-10 15:42:47 Harsha WARNING 10016 HARSHA\\Harsha The application-specific permission settings do not grant Local Activation permission for the COM Server application with CLSID \r\n"
        "{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}\r\n"
        " and APPID \r\n"
        "{15C20B67-12E7-4BB6-92BB-7AFF07997402}\r\n"
        " to the user HARSHA\\Harsha SID (S-1-5-21-1251900359-2259549607-1534340609-1005) from address LocalHost (Using LRPC) running in the application container Unavailable SID (Unavailable).\r\n"
        "2026-10-10 15:54:31 HARSHA INFO 1000 AdaptiveSentinelTest PHASE3_MULTI_ENDPOINT_LIVE_HARSHA_20261010_155431\r\n"
    )
    log_file.write_bytes(initial_content.encode("utf-8"))

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    normalizer = LogNormalizer()

    # Step 1: Initial incremental read
    batch1 = normalizer.normalize(reader.read_events(incremental=True))
    assert len(batch1) == 2
    assert reader.load_cursor() == log_file.stat().st_size

    # Verify Event 10016 was NOT split into bogus UNKNOWN_HOST or 'address' hosts
    hosts_batch1 = {e["hostname"] for e in batch1}
    assert "UNKNOWN_HOST" not in hosts_batch1
    assert "address" not in hosts_batch1

    # Step 2: Append the exact live Windows Application event marker and a trailing Event 5379
    appended_content = (
        "2026-10-10 16:08:33 Harsha INFO 1000 HARSHA\\Harsha PHASE3_WINDOWS_EVENT_20261010_160833\r\n"
        "2026-10-10 16:09:29 Harsha AUDIT_SUCCESS 5379 Credential Manager credentials were read.\r\n"
        "\r\n"
        "Subject:\r\n"
        "\tSecurity ID:\t\tS-1-5-21-1251900359-2259549607-1534340609-1005\r\n"
        "\tAccount Name:\t\tHarsha\r\n"
        "\tAccount Domain:\t\tHARSHA\r\n"
        "\tLogon ID:\t\t0xCC809894\r\n"
        "\tRead Operation:\t\tEnumerate Credentials\r\n"
        "\r\n"
        "This event occurs when a user performs a read operation on stored credentials in Credential Manager.\r\n"
    )
    with open(log_file, "ab") as f:
        f.write(appended_content.encode("utf-8"))

    # Step 3: Verify both incremental read_events() and tail get_recent_events() return the marker
    batch2 = normalizer.normalize(reader.read_events(incremental=True))
    assert len(batch2) == 2
    assert reader.load_cursor() == log_file.stat().st_size

    marker_events = [e for e in batch2 if "PHASE3_WINDOWS_EVENT_20261010_160833" in e["description"]]
    assert len(marker_events) == 1
    marker_evt = marker_events[0]
    assert marker_evt["hostname"] == "Harsha"
    assert marker_evt["event_id"] == 1000
    assert marker_evt["is_diagnostic"] is True
    assert marker_evt["event_type"] == "Diagnostic Telemetry Probe"

    # Also verify get_recent_events(max_events=300) returns all 4 events including the marker
    recent_all = normalizer.normalize(reader.get_recent_events(max_events=300))
    assert len(recent_all) == 4
    recent_markers = [e for e in recent_all if "PHASE3_WINDOWS_EVENT_20261010_160833" in e["description"]]
    assert len(recent_markers) == 1

    # Verify case-insensitive inventory unification ('HARSHA' and 'Harsha' unified into 'Harsha')
    inv = build_endpoint_inventory(recent_all)
    assert len(inv) == 1
    assert inv[0]["hostname"] == "Harsha"
    assert inv[0]["event_count"] == 4

    # Verify filtering by either 'Harsha' or 'HARSHA' retains the marker event
    filtered_mixed, _ = filter_telemetry_by_endpoint(recent_all, [], "Harsha")
    filtered_upper, _ = filter_telemetry_by_endpoint(recent_all, [], "HARSHA")
    assert len(filtered_mixed) == 4
    assert len(filtered_upper) == 4
    assert any("PHASE3_WINDOWS_EVENT_20261010_160833" in e["description"] for e in filtered_upper)


def test_failed_parse_does_not_advance_cursor_past_unprocessed_records(tmp_path, monkeypatch):
    """
    Task 5:
    Ensure a failed parse cannot silently advance the cursor past unprocessed records.
    Preserve correct byte offsets and idempotent rereading.
    """
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    rec1 = "2026-10-10 16:01:00 Harsha INFO 4688 First valid event\n"
    rec2 = "2026-10-10 16:02:00 Harsha INFO 1000 Second event that will fail once\n"
    rec3 = "2026-10-10 16:03:00 Harsha INFO 4624 Third valid event\n"
    log_file.write_bytes((rec1 + rec2 + rec3).encode("utf-8"))

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    orig_parse_line = reader.parse_line

    def flaky_parse_line(raw_line: str):
        if "fail once" in raw_line:
            return None
        return orig_parse_line(raw_line)

    monkeypatch.setattr(reader, "parse_line", flaky_parse_line)

    # First read: rec1 succeeds, rec2 fails -> cursor must stop at start of rec2
    evts_first = reader.read_events(incremental=True)
    assert len(evts_first) == 1
    assert evts_first[0]["record_offset"] == 0
    expected_rec2_offset = len(rec1.encode("utf-8"))
    assert reader.load_cursor() == expected_rec2_offset

    # Restore parser: second read must pick up rec2 and rec3 from expected_rec2_offset
    monkeypatch.setattr(reader, "parse_line", orig_parse_line)
    evts_second = reader.read_events(incremental=True)
    assert len(evts_second) == 2
    assert evts_second[0]["record_offset"] == expected_rec2_offset
    assert "fail once" in evts_second[0]["description"]
    assert evts_second[1]["record_offset"] == expected_rec2_offset + len(rec2.encode("utf-8"))
    assert reader.load_cursor() == log_file.stat().st_size

    # Third read: idempotent at EOF
    assert reader.read_events(incremental=True) == []

