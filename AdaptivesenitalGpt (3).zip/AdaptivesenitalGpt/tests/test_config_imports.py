import unittest


class TestConfigImports(unittest.TestCase):

    def test_settings_imports(self):
        from config.settings import (
            BASE_DIR,
            DATA_DIR,
            RECEIVER_HOST,
            RECEIVER_PORT,
            DEFAULT_ENDPOINT_ID,
            COLLECTOR_VERSION,
            PROJECT_TOKEN,
            ENDPOINT_STATUS_FILE_PATH,
            DEMO_BASELINE_FILE_PATH,
            DASHBOARD_FILTER_STATE_FILE_PATH,
            HEARTBEAT_TIMEOUT_SECONDS,
        )

        self.assertIsNotNone(RECEIVER_HOST)
        self.assertEqual(RECEIVER_HOST, "0.0.0.0")
        self.assertIsInstance(RECEIVER_PORT, int)
        self.assertEqual(RECEIVER_PORT, 5000)
        self.assertIsNotNone(DEFAULT_ENDPOINT_ID)
        self.assertIsNotNone(COLLECTOR_VERSION)
        self.assertIsNotNone(PROJECT_TOKEN)
        self.assertIsNotNone(ENDPOINT_STATUS_FILE_PATH)
        self.assertEqual(DEMO_BASELINE_FILE_PATH, BASE_DIR / "data" / "nxlog_demo_baseline.json")
        self.assertEqual(DASHBOARD_FILTER_STATE_FILE_PATH, BASE_DIR / "data" / "dashboard_filter_state.json")
        self.assertTrue(DATA_DIR.exists())
        self.assertIsInstance(HEARTBEAT_TIMEOUT_SECONDS, int)
        self.assertEqual(HEARTBEAT_TIMEOUT_SECONDS, 30)

    def test_stale_settings_module_hot_reload_on_dashboard_startup(self):
        import config.settings as cfg_mod
        import analysis.parser as parser_mod
        from streamlit.testing.v1 import AppTest

        # Simulate a long-running Streamlit server process with stale in-memory modules
        delattr(cfg_mod, "DEMO_BASELINE_FILE_PATH")
        delattr(cfg_mod, "DASHBOARD_FILTER_STATE_FILE_PATH")
        delattr(parser_mod.NXLogReader, "load_demo_baseline")

        at = AppTest.from_file("dashboard/app.py", default_timeout=30).run(timeout=30)
        self.assertFalse(at.exception, f"Unexpected exception during startup: {at.exception}")
        self.assertTrue(hasattr(cfg_mod, "DEMO_BASELINE_FILE_PATH"))
        self.assertTrue(hasattr(cfg_mod, "DASHBOARD_FILTER_STATE_FILE_PATH"))
        self.assertTrue(hasattr(parser_mod.NXLogReader, "load_demo_baseline"))


if __name__ == "__main__":
    unittest.main()
