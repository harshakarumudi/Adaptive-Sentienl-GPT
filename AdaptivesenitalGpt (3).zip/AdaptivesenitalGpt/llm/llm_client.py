import requests
import re
from typing import Dict, Any, Optional
from config.settings import LLM_PROVIDER, OLLAMA_MODEL, OLLAMA_URL, GEMINI_API_KEY, OPENAI_API_KEY


class LLMClient:
    """
    Universal LLM Abstraction Layer.
    Supports Ollama (Llama 3 / Qwen 2.5), Google Gemini, OpenAI,
    and a robust Heuristic AI Reasoning Engine fallback.
    """

    def __init__(self, provider: str = LLM_PROVIDER):
        self.provider = provider.lower()

    def generate_explanation(self, incident: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generates explainable AI rationale for a detected security incident.
        """
        prompt = self._build_explainability_prompt(incident)

        if self.provider == "ollama":
            response = self._call_ollama(prompt)
            if response:
                return self._parse_ai_response(response, incident)

        elif self.provider == "gemini" and GEMINI_API_KEY:
            response = self._call_gemini(prompt)
            if response:
                return self._parse_ai_response(response, incident)

        elif self.provider == "openai" and OPENAI_API_KEY:
            response = self._call_openai(prompt)
            if response:
                return self._parse_ai_response(response, incident)

        # Fallback to Heuristic AI Engine if external LLMs are unavailable
        return self._heuristic_explainability_engine(incident)

    def generate_response_plan(self, incident: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generates advisory SOAR response playbooks grounded in actual incident evidence.
        All steps are advisory recommendations (not executed automatically).
        """
        name = incident.get("incident_name", "")
        sev = str(incident.get("severity", "Low"))

        if "Privilege Escalation" in name or "Privilege" in name:
            return {
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": name,
                "priority": incident.get("severity", "High"),
                "advisory_status": "Advisory Recommendation — Not Executed",
                "containment_actions": [
                    "Advisory Recommendation — Not Executed: Audit assigned privileges and verify authorization of elevated execution.",
                    "Advisory Recommendation — Not Executed: Restrict non-administrative user permissions and verify group membership changes."
                ],
                "eradication_actions": [
                    "Advisory Recommendation — Not Executed: Revoke unauthorized privileges and revert unapproved security group modifications.",
                    "Advisory Recommendation — Not Executed: Terminate suspicious child processes spawned under elevated tokens."
                ],
                "recovery_actions": [
                    "Advisory Recommendation — Not Executed: Monitor endpoint for subsequent credential access or lateral movement attempts."
                ]
            }

        elif "Brute Force" in name or "LSASS" in name or "Mimikatz" in name:
            return {
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": name,
                "priority": incident.get("severity", "High"),
                "advisory_status": "Advisory Recommendation — Not Executed",
                "containment_actions": [
                    "Advisory Recommendation — Not Executed: Lock target user account if unauthorized authentication attempts are confirmed.",
                    "Advisory Recommendation — Not Executed: Block verified external source IP address on perimeter firewalls if applicable.",
                    "Advisory Recommendation — Not Executed: Terminate unauthorized active sessions across domain controllers."
                ],
                "eradication_actions": [
                    "Advisory Recommendation — Not Executed: Perform identity audit to ensure no secondary persistent credentials were breached.",
                    "Advisory Recommendation — Not Executed: Enforce Multi-Factor Authentication (MFA) reset for affected account.",
                    "Advisory Recommendation — Not Executed: Inspect endpoint process memory if credential dumping indicators are present."
                ],
                "recovery_actions": [
                    "Advisory Recommendation — Not Executed: Restore user account access with rotated credentials after verification.",
                    "Advisory Recommendation — Not Executed: Resume normal monitoring with elevated alert sensitivity on host."
                ]
            }
        elif "Credential Manager" in name or "Credential Vault" in name or "Discovery" in name:
            if sev in ("Low", "Informational"):
                return {
                    "incident_id": incident.get("incident_id", "INC-000"),
                    "incident_name": name,
                    "priority": sev,
                    "advisory_status": "Advisory Recommendation — Not Executed",
                    "containment_actions": [
                        "Advisory Recommendation — Not Executed: No host isolation, account lockout, or firewall IP block is warranted for routine local Windows Credential Manager (5379) or Account Discovery (4798) telemetry.",
                        "Advisory Recommendation — Not Executed: Verify the caller process ID and user session context in Windows Security Event Logs before taking any containment action."
                    ],
                    "eradication_actions": [
                        "Advisory Recommendation — Not Executed: Correlate event timestamps with Process Creation logs (Event ID 4688 / Sysmon Event ID 1) to confirm routine OS or service activity.",
                        "Advisory Recommendation — Not Executed: Audit stored Credential Manager entries and local group memberships only if an unexpected caller process is identified."
                    ],
                    "recovery_actions": [
                        "Advisory Recommendation — Not Executed: Maintain standard endpoint monitoring and baseline routine background enumeration."
                    ]
                }
            return {
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": name,
                "priority": sev,
                "advisory_status": "Advisory Recommendation — Not Executed",
                "containment_actions": [
                    "Advisory Recommendation — Not Executed: Inspect and terminate unauthorized caller processes enumerating local groups or reading Windows Credential Manager vaults.",
                    "Advisory Recommendation — Not Executed: Restrict or rotate credentials stored in Windows Vault for the affected account pending analyst verification."
                ],
                "eradication_actions": [
                    "Advisory Recommendation — Not Executed: Audit process creation lineages and command-line arguments on the affected host for reconnaissance or credential harvesting utilities.",
                    "Advisory Recommendation — Not Executed: Review scheduled tasks, startup entries, and user session logs for unauthorized persistence."
                ],
                "recovery_actions": [
                    "Advisory Recommendation — Not Executed: Rotate affected Windows Credential Manager entries and resume normal monitoring after analyst sign-off."
                ]
            }
        elif "Ransomware" in name or "PowerShell" in name:
            return {
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": name,
                "priority": incident.get("severity", "Critical"),
                "advisory_status": "Advisory Recommendation — Not Executed",
                "containment_actions": [
                    "Advisory Recommendation — Not Executed: Isolate infected endpoint from internal LAN and VLAN segment after analyst approval.",
                    "Advisory Recommendation — Not Executed: Terminate suspicious PowerShell and vssadmin process trees.",
                    "Advisory Recommendation — Not Executed: Block verified command-and-control (C2) IP addresses and domain hashes."
                ],
                "eradication_actions": [
                    "Advisory Recommendation — Not Executed: Execute forensic memory capture and disk image acquisition.",
                    "Advisory Recommendation — Not Executed: Purge malicious script payload from temp directory and scheduled tasks.",
                    "Advisory Recommendation — Not Executed: Verify integrity of Volume Shadow Copies and system restore points."
                ],
                "recovery_actions": [
                    "Advisory Recommendation — Not Executed: Re-image impacted workstation using gold-standard corporate image.",
                    "Advisory Recommendation — Not Executed: Restore encrypted file shares from verified offline immutable backups."
                ]
            }
        else:
            return {
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": name,
                "priority": incident.get("severity", "Medium"),
                "advisory_status": "Advisory Recommendation — Not Executed",
                "containment_actions": [
                    "Advisory Recommendation — Not Executed: Review host activity and place on restricted investigation VLAN if malicious indicators are confirmed.",
                    "Advisory Recommendation — Not Executed: Audit active access tokens and Kerberos tickets for the affected user."
                ],
                "eradication_actions": [
                    "Advisory Recommendation — Not Executed: Run endpoint detection and response (EDR) scan if suspicious binaries are identified.",
                    "Advisory Recommendation — Not Executed: Review audit log event streams for corroborating indicators."
                ],
                "recovery_actions": [
                    "Advisory Recommendation — Not Executed: Close investigation or resume normal monitoring following analyst review."
                ]
            }

    def query_chatbot(self, query: str, context: Dict[str, Any]) -> str:
        """
        Universal Interactive SOC Assistant Chatbot.
        Answers live SOC telemetry questions AND all general cybersecurity questions,
        terms, concepts, and definitions.
        """
        query_clean = query.strip()
        query_lower = query_clean.lower()
        incidents = context.get("incidents", [])
        alerts = context.get("alerts", [])
        logs = context.get("logs", [])

        # 1. Try Live Ollama / Gemini / OpenAI LLM APIs if connected
        prompt = f"""
You are SentinelGPT AI Security Assistant, an expert SOC AI analyst.
Context:
- Ingested Logs: {len(logs)}
- Correlated Incidents: {len(incidents)}
- Incidents Summary: {[inc['incident_name'] for inc in incidents]}

User Question: {query}
Answer concisely, accurately, and professionally in simple plain English.
"""
        if self.provider == "ollama":
            res = self._call_ollama(prompt)
            if res:
                return res
        elif self.provider == "gemini" and GEMINI_API_KEY:
            res = self._call_gemini(prompt)
            if res:
                return res

        # 2. Universal Heuristic Conversational AI Engine (Strictly Grounded in Active Context)
        active_sec_incidents = [inc for inc in incidents if not inc.get("is_diagnostic")]

        # Helper: find a referenced incident in context or fall back to top active incident
        matched_inc = None
        for inc in active_sec_incidents:
            inc_id_str = str(inc.get("incident_id") or "").lower()
            inc_name_str = str(inc.get("incident_name") or "").lower()
            if (inc_id_str and inc_id_str in query_lower) or (inc_name_str and inc_name_str in query_lower):
                matched_inc = inc
                break
        if matched_inc is None and active_sec_incidents:
            matched_inc = active_sec_incidents[0]

        # Quick Action 1 / Incident Root Cause & Evidence Explanation
        if (
            "root cause" in query_lower
            or "severity rationale" in query_lower
            or "explain active incident" in query_lower
            or ("explain" in query_lower and matched_inc and str(matched_inc.get("incident_id", "")).lower() in query_lower)
        ):
            if matched_inc:
                exp = self.generate_explanation(matched_inc)
                win_cnt = matched_inc.get("window_alert_count", matched_inc.get("alert_count", len(matched_inc.get("alerts") or [])))
                cum_cnt = matched_inc.get("cumulative_alert_count", win_cnt)
                return (
                    f"🔎 **Active Incident Analysis — `{matched_inc.get('incident_id')}` ({matched_inc.get('incident_name')})**:\n\n"
                    f"- **Target Host**: `{matched_inc.get('affected_host', 'UNKNOWN_HOST')}` | **User**: `{matched_inc.get('affected_user', 'SYSTEM')}`\n"
                    f"- **Severity**: `{matched_inc.get('severity', 'Low')}` (Confidence: `{matched_inc.get('confidence', 0)}%`)\n"
                    f"- **Alert Scope**: `{win_cnt}` current-window alert(s) | `{cum_cnt}` cumulative alert(s)\n"
                    f"- **Root Cause & Narrative**: {exp.get('explanation')}\n"
                    f"- **MITRE Mapping**: {exp.get('mitre')}\n"
                    f"- **Key Evidence**: {exp.get('evidence')}\n"
                    f"- **Advisory Recommendation**: {exp.get('recommendation')}"
                )
            return (
                "🟢 **No Active Security Incident in Current View**:\n\n"
                f"The current filtered view contains **{len(logs)}** normalized event(s) and **0** correlated security incidents."
            )

        # Quick Action 4 / Mitigation & Containment Options
        if "mitigation" in query_lower or "containment" in query_lower or "remediation" in query_lower:
            if matched_inc:
                plan = self.generate_response_plan(matched_inc)
                cont_str = "\n".join(f"  - {c}" for c in plan.get("containment_actions", []))
                erad_str = "\n".join(f"  - {c}" for c in plan.get("eradication_actions", []))
                rec_str = "\n".join(f"  - {c}" for c in plan.get("recovery_actions", []))
                return (
                    f"🛠️ **Advisory Mitigation & Containment Plan — `{matched_inc.get('incident_id')}` ({matched_inc.get('incident_name')})**:\n\n"
                    f"- **Target Host**: `{matched_inc.get('affected_host', 'UNKNOWN_HOST')}` | **Severity**: `{matched_inc.get('severity', 'Low')}`\n"
                    f"- **Execution Mode**: `Advisory / Simulation Only (Dry-Run Mode — No Real Endpoint Changes)`\n\n"
                    f"**Containment Options**:\n{cont_str}\n\n"
                    f"**Eradication / Verification Steps**:\n{erad_str}\n\n"
                    f"**Recovery Steps**:\n{rec_str}"
                )
            return (
                "🛠️ **Advisory Mitigation Options**:\n\n"
                "No active security incidents require containment in the current view. Keep continuous NXLog telemetry monitoring active and SOAR in dry-run simulation mode."
            )

        # Quick Action 2 / Supporting Logs & Pipeline Statistics
        if (
            "supporting logs" in query_lower
            or "summarize the supporting logs" in query_lower
            or "supporting windows event" in query_lower
            or "event ids, hosts, users" in query_lower
        ):
            target_evts = (
                [a.get("event", {}) for a in (matched_inc.get("alerts") or []) if isinstance(a.get("event"), dict)]
                if matched_inc and matched_inc.get("alerts")
                else logs
            )
            if not target_evts:
                return "📋 **Supporting Logs Summary**:\n\nNo supporting events are present in the current filtered scope."
            eid_counts: Dict[Any, int] = {}
            hosts_seen = []
            users_seen = []
            procs_seen = []
            ts_vals = []
            for ev in target_evts:
                eid = ev.get("event_id", 0)
                eid_counts[eid] = eid_counts.get(eid, 0) + 1
                h = str(ev.get("hostname") or "UNKNOWN_HOST")
                u = str(ev.get("user") or "SYSTEM")
                p = str(ev.get("process_name") or "N/A")
                ts = str(ev.get("timestamp") or "")[:19].replace("T", " ")
                if h not in hosts_seen:
                    hosts_seen.append(h)
                if u not in users_seen:
                    users_seen.append(u)
                if p not in procs_seen and p != "N/A":
                    procs_seen.append(p)
                if ts and ts != "N/A":
                    ts_vals.append(ts)
            eid_summary = ", ".join(f"Event ID `{k}` ({v})" for k, v in sorted(eid_counts.items(), key=lambda x: -x[1])[:6])
            ts_range = f"`{min(ts_vals)}` → `{max(ts_vals)}`" if ts_vals else "`N/A`"
            scope_title = f"Incident `{matched_inc.get('incident_id')}`" if matched_inc else "Active Telemetry Stream"
            return (
                f"📋 **Supporting Logs Summary ({scope_title})**:\n\n"
                f"- **Supporting Events Analyzed**: `{len(target_evts)}` event(s)\n"
                f"- **Event ID Breakdown**: {eid_summary}\n"
                f"- **Observed Host(s)**: {', '.join(f'`{h}`' for h in hosts_seen[:5])}\n"
                f"- **Observed Account(s)**: {', '.join(f'`{u}`' for u in users_seen[:5])}\n"
                f"- **Processes Observed**: {', '.join(f'`{p}`' for p in procs_seen[:5]) if procs_seen else '`N/A (OS-level audit records)`'}\n"
                f"- **Timestamp Span**: {ts_range}"
            )

        # A. Cybersecurity / Security
        if "cybersecurity" in query_lower or "cyber security" in query_lower:
            return (
                "🛡️ **Cybersecurity**:\n\n"
                "**Cybersecurity** is the practice of protecting computer systems, networks, servers, devices, and data from digital attacks, unauthorized access, espionage, or damage.\n\n"
                "Key domains of cybersecurity include:\n"
                "1. **Network Security**: Securing computer networks from intruders.\n"
                "2. **Application & Endpoint Security**: Keeping software and devices free of vulnerabilities.\n"
                "3. **Security Operations (SOC)**: Continuous monitoring, threat detection, and incident response (which is what **AdaptiveSentinelGPT** automates!)."
            )

        # B. SOC / Security Operations Center
        elif "soc" in query_lower and "log" not in query_lower and "stat" not in query_lower:
            return (
                "🛡️ **SOC (Security Operations Center)**:\n\n"
                "**SOC** stands for **Security Operations Center**. It is a centralized unit within an organization where security teams continuously monitor, detect, analyze, and respond to cybersecurity threats across networks, endpoints, and servers in real time."
            )

        # C. SIEM
        elif "siem" in query_lower:
            return (
                "📊 **SIEM (Security Information and Event Management)**:\n\n"
                "**SIEM** is a security software category that aggregates, normalizes, and analyzes log telemetry from firewalls, operating systems, and applications to detect security threats and provide compliance reporting."
            )

        # D. SOAR
        elif "soar" in query_lower:
            return (
                "⚡ **SOAR (Security Orchestration, Automation, and Response)**:\n\n"
                "**SOAR** refers to solutions that automate security response playbooks (such as isolating compromised hosts, revoking breached tokens, or blocking malicious IPs on firewalls) in controlled dry-run or analyst-approved workflows."
            )

        # E. MITRE ATT&CK (grounded with active triggered techniques when present)
        elif "mitre" in query_lower:
            active_techs = []
            for inc in active_sec_incidents:
                for mt in (inc.get("mitre_techniques") or []):
                    if mt and mt != "N/A" and mt not in active_techs:
                        active_techs.append(mt)
            if not active_techs:
                for alt in alerts:
                    mt = str(alt.get("mitre_technique") or "").strip()
                    if mt and mt != "N/A" and mt not in active_techs:
                        active_techs.append(mt)
            tech_descriptions = {
                "T1555.004": "`T1555.004` (Credentials from Password Stores: Windows Credential Manager) — tracks read/enumerate operations against the local Windows Credential Vault (Event ID `5379`).",
                "T1087.001": "`T1087.001` (Account Discovery: Local Account) — tracks enumeration of local user accounts and group memberships (Event ID `4798`).",
                "T1087": "`T1087` (Account Discovery) — tracks enumeration of security-enabled local groups (Event ID `4799`).",
                "T1110": "`T1110` (Brute Force) — tracks repeated failed authentication attempts (Event ID `4625`).",
                "T1059.001": "`T1059.001` (Command and Scripting Interpreter: PowerShell) — tracks suspicious or encoded PowerShell execution.",
                "T1003.001": "`T1003.001` (OS Credential Dumping: LSASS Memory) — tracks unauthorized process access or memory dumping of `lsass.exe`.",
                "T1486": "`T1486` (Data Encrypted for Impact) — tracks ransomware staging such as Volume Shadow Copy deletion.",
            }
            if active_techs:
                lines = [f"- {tech_descriptions.get(t, f'`{t}` — active technique observed in current telemetry scope.')}" for t in active_techs]
                return (
                    "🎯 **MITRE ATT&CK Techniques in Active Scope**:\n\n"
                    "**MITRE ATT&CK** (Adversarial Tactics, Techniques, and Common Knowledge) maps observed telemetry to standardized adversary behaviors.\n\n"
                    "**Triggered Techniques in Current View**:\n"
                    + "\n".join(lines)
                )
            return (
                "🎯 **MITRE ATT&CK Framework**:\n\n"
                "**MITRE ATT&CK** (Adversarial Tactics, Techniques, and Common Knowledge) is a curated knowledge base tracking real-world cyber adversary attack behavior and techniques. Currently, no suspicious MITRE ATT&CK techniques are triggered in the active view."
            )

        # F. Sysmon
        elif "sysmon" in query_lower:
            return (
                "💻 **Sysmon (System Monitor)**:\n\n"
                "**Sysmon** is a Windows system service and driver that logs granular system activity (process creations, network sockets, raw disk access) to help security analysts investigate attacks."
            )

        # G. OCSF
        elif "ocsf" in query_lower:
            return (
                "📋 **OCSF (Open Cybersecurity Schema Framework)**:\n\n"
                "**OCSF** is an open-source schema that standardizes security logs from multiple different vendors (Windows, Linux, Suricata IDS, Sysmon) into a unified JSON format."
            )

        # H. Malware / Virus / Trojan / EDR
        elif "malware" in query_lower or "virus" in query_lower or "trojan" in query_lower or "edr" in query_lower or "endpoint" in query_lower:
            return (
                "🦠 **Malware & Endpoint Security**:\n\n"
                "**Malware** (Malicious Software) includes viruses, ransomware, trojans, and spyware designed to compromise computers.\n\n"
                "**Endpoint Detection and Response (EDR)** monitors endpoints to detect malware execution, isolate infected hosts, and eliminate malicious processes."
            )

        # I. Phishing
        elif "phishing" in query_lower:
            return (
                "🎣 **Phishing**:\n\n"
                "**Phishing** is a social engineering attack where malicious actors trick users into revealing sensitive credentials, clicking malicious links, or downloading malware payloads."
            )

        # J. Incident Response / Playbook
        elif "incident response" in query_lower or "playbook" in query_lower:
            return (
                "📋 **Incident Response & SOAR Playbooks**:\n\n"
                "Incident response follows 4 critical phases:\n"
                "1. **Preparation & Detection**: Logging and identifying security alerts.\n"
                "2. **Containment**: Isolating infected systems and blocking attacker IPs.\n"
                "3. **Eradication**: Deleting malware files and resetting breached accounts.\n"
                "4. **Recovery**: Restoring clean operations and conducting post-incident reviews."
            )

        # K. Ransomware / Vssadmin (strictly grounded in active incidents)
        elif "ransomware" in query_lower or "vssadmin" in query_lower or "shadow" in query_lower:
            ransom_incs = [
                inc for inc in active_sec_incidents
                if "ransomware" in str(inc.get("incident_name", "")).lower()
                or "T1486" in (inc.get("mitre_techniques") or [])
            ]
            if ransom_incs:
                r_inc = ransom_incs[0]
                return (
                    f"☣️ **Active Ransomware Threat Analysis (`{r_inc.get('incident_id')}`)**:\n\n"
                    f"- **Target Host**: `{r_inc.get('affected_host')}`\n"
                    f"- **Target User**: `{r_inc.get('affected_user')}`\n"
                    f"- **Severity**: `{r_inc.get('severity')}` (Source: `{r_inc.get('primary_source', 'telemetry')}`)\n"
                    f"- **Advisory Action**: Review host isolation and process termination options in SOAR dry-run mode."
                )
            return (
                "☣️ **Ransomware & Shadow Copy Deletion (`T1486`)**:\n\n"
                "- **Active Telemetry Status**: **0** ransomware or `vssadmin.exe delete shadows` events are present in the current active telemetry view.\n"
                "- **Detection Coverage**: `RULE-IMPACT-VSS-01` continuously monitors for Volume Shadow Copy deletion and escalates matching events to `Critical`."
            )

        # L. Brute Force / Mimikatz / Credential Access (strictly grounded in active incidents)
        elif "brute" in query_lower or "force" in query_lower or "mimikatz" in query_lower or "lsass" in query_lower or "password" in query_lower or "credential" in query_lower:
            cred_incs = [
                inc for inc in active_sec_incidents
                if any(
                    k in str(inc.get("incident_name", "")).lower()
                    for k in ("credential", "brute", "password", "lsass", "discovery")
                )
            ]
            if cred_incs:
                c_inc = cred_incs[0]
                exp = self.generate_explanation(c_inc)
                win_cnt = c_inc.get("window_alert_count", c_inc.get("alert_count", len(c_inc.get("alerts") or [])))
                cum_cnt = c_inc.get("cumulative_alert_count", win_cnt)
                return (
                    f"🔑 **Credential & Authentication Activity Analysis (`{c_inc.get('incident_id')}`)**:\n\n"
                    f"- **Incident Name**: `{c_inc.get('incident_name')}`\n"
                    f"- **Target Host**: `{c_inc.get('affected_host')}` | **Account**: `{c_inc.get('affected_user')}`\n"
                    f"- **Severity**: `{c_inc.get('severity')}` | **Confidence**: `{c_inc.get('confidence')}%`\n"
                    f"- **Alert Counts**: `{win_cnt}` current-window alert(s) | `{cum_cnt}` cumulative alert(s)\n"
                    f"- **Assessment**: {exp.get('explanation')}\n"
                    f"- **Advisory Recommendation**: {exp.get('recommendation')}"
                )
            return (
                "🔑 **Credential Access & Brute Force Monitoring**:\n\n"
                f"- **Active Telemetry Status**: **0** credential dumping (`T1003.001`), brute-force (`T1110`), or Credential Manager (`T1555.004`) incidents are active in the current view ({len(logs)} logs analyzed)."
            )

        # M. IP Addresses / Firewall Blocking
        elif re.search(r"\b(ip|ips|block|firewall)\b", query_lower):
            net_st = context.get("network_state", {}) if isinstance(context, dict) else {}
            local_known_ips = {
                str(net_st.get("receiver_ip_current") or "").strip(),
                str(net_st.get("sender_ip_current") or "").strip(),
                str(net_st.get("raw_remote_peer_ip") or "").strip(),
                "N/A", "NA", "-", "", "127.0.0.1", "::1", "0.0.0.0", "NONE", "UNKNOWN"
            }
            external_ips = []
            for alt in alerts:
                ev = alt.get("event", {})
                sip = str(ev.get("source_ip") or "").strip()
                ti = alt.get("threat_intel", {})
                if (
                    sip
                    and sip.upper() not in local_known_ips
                    and sip not in local_known_ips
                    and not sip.startswith(("192.168.", "10.", "127.", "169.254."))
                    and (ti.get("is_malicious") or int(ti.get("risk_score", 0) or 0) >= 70 or ev.get("source") in ("api_simulation", "synthetic"))
                ):
                    if sip not in external_ips:
                        external_ips.append(sip)
            if external_ips:
                ip_list = ", ".join([f"`{ip}`" for ip in external_ips])
                return (
                    f"🛡️ **Advisory Firewall Block Candidates ({len(external_ips)})**:\n\n"
                    f"The Threat Intelligence Agent flagged the following external untrusted IP(s) in the active view:\n"
                    f"- {ip_list}\n\n"
                    f"**Advisory Recommendation — Not Executed**: Verify external IOC provenance before applying any perimeter firewall block (SOAR remains in Dry-Run mode)."
                )
            return (
                "🟢 **No External Malicious IP Addresses Identified in Active View**:\n\n"
                "All events in the active filtered view are local Windows endpoint or internal LAN telemetry "
                "(`External IP Reputation Not Applicable — Baseline Risk Score: 10 / 100`).\n\n"
                "**Advisory Status**: Do not block internal endpoint or collector LAN IP addresses."
            )

        # N. Critical Threats
        elif "critical" in query_lower or "threat" in query_lower or "incident" in query_lower or "high risk" in query_lower:
            criticals = [inc for inc in active_sec_incidents if inc.get("severity") in ("Critical", "High")]
            if criticals:
                inc_lines = "\n".join(
                    f"- **{inc.get('incident_name')}** on `{inc.get('affected_host')}` (User: `{inc.get('affected_user')}`, Source: `{inc.get('primary_source', 'telemetry')}`, Severity: `{inc.get('severity')}`)"
                    for inc in criticals
                )
                hosts_str = ", ".join(dict.fromkeys(f"`{inc.get('affected_host')}`" for inc in criticals if inc.get("affected_host")))
                return (
                    f"🚨 **Critical & High-Severity Threats Detected ({len(criticals)})**:\n\n"
                    f"Active high-priority incidents in current view:\n"
                    f"{inc_lines}\n\n"
                    f"**Advisory Recommendation**: Review SOAR containment actions for impacted hosts ({hosts_str}) and verify affected user accounts."
                )
            if active_sec_incidents:
                inc_lines = "\n".join(
                    f"- **{inc.get('incident_name')}** on `{inc.get('affected_host')}` (User: `{inc.get('affected_user')}`, Source: `{inc.get('primary_source', 'telemetry')}`, Severity: `{inc.get('severity')}`)"
                    for inc in active_sec_incidents
                )
                return (
                    "🟢 **No Critical Threats Active**:\n\n"
                    f"There are currently **0** Critical or High-severity incidents in the active filtered view ({len(logs)} logs analyzed).\n\n"
                    f"**Active Monitored Lower-Severity Incidents ({len(active_sec_incidents)})**:\n"
                    f"{inc_lines}\n\n"
                    "**Advisory Status**: Routine or lower-severity activity under observation — no disruptive host containment required."
                )
            return (
                "🟢 **No Critical Threats Active**:\n\n"
                f"There are currently **0** Critical or High-severity incidents in the active filtered view ({len(logs)} logs analyzed)."
            )

        # O. Log Statistics / Pipeline Numbers
        elif "log" in query_lower or "stat" in query_lower or "count" in query_lower or "number" in query_lower or "how many" in query_lower:
            perf = context.get("agent_performance", {}) if isinstance(context, dict) else {}
            lat_ms = perf.get("pipeline_latency_ms")
            lat_scope = perf.get("latency_scope") or "End-to-End Batch"
            lat_str = f"{float(lat_ms):.2f} ms ({lat_scope})" if isinstance(lat_ms, (int, float)) and lat_ms >= 0 else "N/A (no batch measured yet)"
            return (
                f"📊 **SOC Pipeline Telemetry Stats**:\n\n"
                f"- 📥 **Logs Ingested (Active Window)**: {len(logs)} unique security events\n"
                f"- 🚨 **Detection Alerts**: {len(alerts)} alert(s)\n"
                f"- 🔗 **Correlated Incidents**: {len(active_sec_incidents)} active incident(s)\n"
                f"- 🤖 **Active Sub-Agents**: 7 Specialized AI Agents\n"
                f"- ⚡ **Measured Pipeline Latency**: {lat_str}"
            )

        # P. Multi-Agent Framework / How it Works
        elif "how" in query_lower or "agent" in query_lower or "work" in query_lower or "framework" in query_lower:
            return (
                "🤖 **AdaptiveSentinelGPT Multi-Agent Architecture**:\n\n"
                "1. **Ingestion & Normalization**: Converts Windows, Linux, Sysmon, and Suricata logs into OCSF schema.\n"
                "2. **7 Autonomous Agents**: Detection, Correlation, Threat Intel, Explainability, Response Planning, Reporting, and Feedback Agents.\n"
                "3. **Explainable AI**: Generates plain-English root-cause diagnostics and SOAR playbooks.\n"
                "4. **Human-in-the-Loop**: Persists analyst feedback into SQLite database (`sentinel_kb.db`)."
            )

        # Q. Who Are You / Greetings
        elif "hi" in query_lower or "hello" in query_lower or "who" in query_lower or "sentinel" in query_lower:
            return (
                "👋 **Hello! I am your SentinelGPT AI Security Assistant.**\n\n"
                "I am designed to assist SOC analysts and project reviewers by explaining security logs, attack incidents, MITRE ATT&CK techniques, and recommended remedies in simple plain English.\n\n"
                "Feel free to ask me any question about cybersecurity terms, concepts, or active threats!"
            )

        # R. Universal General Concept Explainer for any "what is X" or "explain X" query!
        elif "what is" in query_lower or "explain" in query_lower or "define" in query_lower or "meaning of" in query_lower:
            subject = re.sub(r'^(what is|explain|define|meaning of)\s+', '', query_lower, flags=re.IGNORECASE).strip(' ?.')
            return (
                f"🧠 **Explanation for '{subject.title()}'**:\n\n"
                f"**{subject.title()}** is an important concept in cybersecurity and Security Operations (SOC).\n\n"
                f"- **Definition**: It refers to security mechanisms, protocols, or threat vectors involved in monitoring, defending, and mitigating risks within an enterprise computing environment.\n"
                f"- **Role in AdaptiveSentinelGPT**: Our multi-agent framework continuously monitors computer event logs to identify threats associated with **{subject.title()}**, generate explainable AI rationales, and automate response playbooks.\n\n"
                f"Currently, the AI pipeline has analyzed **{len(logs)} ingested logs** and identified **{len(active_sec_incidents)} active security incident(s)** related to your SOC telemetry."
            )

        # S. Universal Intelligent Fallback
        else:
            return (
                f"🤖 **SentinelGPT AI Assistant Response**: *\"{query_clean}\"*\n\n"
                f"Regarding **\"{query_clean}\"**:\n\n"
                f"In the context of **AdaptiveSentinelGPT** and enterprise cybersecurity:\n"
                f"- **SOC Ingestion**: Our pipeline has analyzed **{len(logs)} logs** and correlated **{len(active_sec_incidents)} security incident(s)** in the active view.\n"
                f"- **AI Analysis**: 7 autonomous sub-agents analyze threat telemetry, generate MITRE ATT&CK mappings, and provide actionable remedies.\n\n"
                f"Ask me about any active incident, supporting logs, MITRE ATT&CK technique, or mitigation option to get a grounded breakdown!"
            )

    def _build_explainability_prompt(self, incident: Dict[str, Any]) -> str:
        return f"""
You are an expert SOC AI Security Analyst. Explain the following incident:
Incident Name: {incident.get('incident_name')}
Severity: {incident.get('severity')}
Alert Count: {incident.get('alert_count')}
Affected Host: {incident.get('affected_host')}
Affected User: {incident.get('affected_user')}

Provide concise explanation, MITRE attack mapping, key evidence, and recommendation.
"""

    def _call_ollama(self, prompt: str) -> Optional[str]:
        try:
            res = requests.post(
                OLLAMA_URL,
                json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
                timeout=5
            )
            if res.status_code == 200:
                return res.json().get("response")
        except Exception:
            pass
        return None

    def _call_gemini(self, prompt: str) -> Optional[str]:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
            res = requests.post(url, json={"contents": [{"parts": [{"text": prompt}]}]}, timeout=5)
            if res.status_code == 200:
                return res.json()["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            pass
        return None

    def _call_openai(self, prompt: str) -> Optional[str]:
        try:
            headers = {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}
            payload = {"model": "gpt-3.5-turbo", "messages": [{"role": "user", "content": prompt}]}
            res = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload, timeout=5)
            if res.status_code == 200:
                return res.json()["choices"][0]["message"]["content"]
        except Exception:
            pass
        return None

    def _parse_ai_response(self, text: str, incident: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "incident_id": incident.get("incident_id", "INC-000"),
            "incident_name": incident.get("incident_name"),
            "reason": text,
            "mitre": incident.get("alerts", [{}])[0].get("mitre_technique", "T1059"),
            "tactic": incident.get("alerts", [{}])[0].get("mitre_tactic", "Execution"),
            "severity": incident.get("severity"),
            "confidence": incident.get("confidence"),
            "evidence": [f"AI Rationale: {text[:200]}..."],
            "recommendation": "Advisory Recommendation — Not Executed: Review AI response and verify telemetry before executing any containment steps."
        }

    def _heuristic_explainability_engine(self, incident: Dict[str, Any]) -> Dict[str, Any]:
        name = incident.get("incident_name", "")
        sev = str(incident.get("severity", "Low"))
        alerts = incident.get("alerts", [])
        first_alert = alerts[0] if alerts else {}
        event = first_alert.get("event", {})

        # Collect all MITRE techniques from the incident and its alerts
        mitre_list = []
        for t in incident.get("mitre_techniques", []) or []:
            ts = str(t).strip()
            if ts and ts.upper() not in ("N/A", "NA", "NONE") and ts not in mitre_list:
                mitre_list.append(ts)
        for alt in alerts:
            for t in (alt.get("mitre_technique"), alt.get("event", {}).get("mitre_technique")):
                ts = str(t or "").strip()
                if ts and ts.upper() not in ("N/A", "NA", "NONE") and ts not in mitre_list:
                    mitre_list.append(ts)
        mitre_tech = ", ".join(mitre_list) if mitre_list else (first_alert.get("mitre_technique") or event.get("mitre_technique") or "T1059")
        primary_tech = mitre_list[0] if mitre_list else mitre_tech

        event_ids = []
        for alt in alerts:
            eid = str(alt.get("event", {}).get("event_id", "")).strip()
            if eid and eid not in event_ids:
                event_ids.append(eid)
        event_ids_str = ", ".join(event_ids) if event_ids else str(event.get("event_id", "N/A"))

        from analysis.enrich import LogEnricher
        tactic = (
            incident.get("mitre_tactic")
            if incident.get("mitre_tactic") not in (None, "", "Unknown Tactic")
            else (
                event.get("mitre_tactic")
                if event.get("mitre_tactic") not in (None, "", "Unknown Tactic")
                else LogEnricher.TACTIC_MAP.get(primary_tech, "Execution")
            )
        )

        if "Brute Force" in name or "LSASS" in name:
            reason = (
                f"The AI Correlation Engine detected multiple failed authentication attempts on host '{incident.get('affected_host')}' "
                f"originating from source IP '{event.get('source_ip', 'External')}', followed by credential access activity. "
                "This behavior exhibits classic indicators of automated Password Spraying and Credential Harvesting."
            )
            recommendation = "Advisory Recommendation — Not Executed: Lock account, block verified external source IP on firewall, and inspect LSASS memory dumps."
        elif "Ransomware" in name or "PowerShell" in name:
            reason = (
                f"Anomalous execution of PowerShell process with bypass flags combined with Volume Shadow Copy deletion (vssadmin.exe) "
                f"was observed on endpoint '{incident.get('affected_host')}'. This pattern is strongly correlated with Ransomware pre-encryption staging."
            )
            recommendation = "Advisory Recommendation — Not Executed: Isolate endpoint after analyst approval, terminate parent processes, and verify offline backups."
        elif "Credential Vault" in name or "Credential Manager" in name or "Discovery" in name:
            if sev in ("Low", "Informational"):
                reason = (
                    f"Live endpoint telemetry on host '{incident.get('affected_host')}' recorded {incident.get('alert_count', len(alerts))} "
                    f"event(s) for account '{incident.get('affected_user')}' ({name}; Event ID(s): {event_ids_str}; MITRE: {mitre_tech}). "
                    "No suspicious command-line recon utilities (e.g., vaultcmd, mimikatz, whoami, net.exe) or malicious external IOCs were observed; "
                    "this pattern is consistent with routine Windows Credential Manager reads and background local group enumeration."
                )
                recommendation = (
                    "Advisory Recommendation — Not Executed: Verify whether the credential read or local group enumeration matches "
                    "expected OS/application activity; no host isolation or account lockout is warranted without corroborating indicators."
                )
            else:
                reason = (
                    f"Endpoint telemetry on host '{incident.get('affected_host')}' captured {incident.get('alert_count', len(alerts))} "
                    f"correlated security event(s) involving account '{incident.get('affected_user')}' ({name}; Event ID(s): {event_ids_str}; MITRE: {mitre_tech}) "
                    "supported by suspicious process/command-line or threat-intelligence indicators."
                )
                recommendation = (
                    "Advisory Recommendation — Not Executed: Inspect the caller process tree, verify whether the enumeration/credential "
                    "vault access was authorized, and rotate stored credentials if unauthorized activity is confirmed."
                )
        elif "Privilege Escalation" in name or "Privilege" in name:
            reason = (
                f"Context-aware privilege escalation activity detected on host '{incident.get('affected_host')}' "
                f"for account '{incident.get('affected_user')}'. Sensitive privileges assignment was corroborated by "
                f"elevated execution or administrative security group modification within a bounded temporal window (MITRE: {mitre_tech})."
            )
            recommendation = (
                "Advisory Recommendation — Not Executed: Verify whether the privilege elevation and administrative activity "
                "were authorized; inspect process execution lineage and review account group memberships."
            )
        else:
            reason = (
                f"Suspicious activity pattern matching {name} observed on host {incident.get('affected_host')} "
                f"involving user account {incident.get('affected_user')} ({incident.get('alert_count', len(alerts))} supporting alert(s))."
            )
            recommendation = "Advisory Recommendation — Not Executed: Investigate event logs and check asset criticality."

        return {
            "incident_id": incident.get("incident_id", "INC-000"),
            "incident_name": name,
            "reason": reason,
            "mitre": mitre_tech,
            "tactic": tactic,
            "severity": incident.get("severity"),
            "confidence": incident.get("confidence"),
            "evidence": [
                f"Event ID : {event_ids_str}",
                f"Target Host : {incident.get('affected_host')}",
                f"User Account : {incident.get('affected_user')}",
                f"Source IP : {event.get('source_ip', 'N/A')}",
                f"Command Line : {event.get('command_line', 'N/A')}"
            ],
            "threat_status": first_alert.get("threat_intel", {}).get("status", "Local Endpoint Telemetry (No External IP)"),
            "risk_score": first_alert.get("threat_intel", {}).get("risk_score", 10),
            "recommendation": recommendation
        }
