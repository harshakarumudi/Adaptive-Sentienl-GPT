from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, Any, Optional
from soar.action_registry import SOARActionRegistry
from soar.guard import SOARExecutionGuard


class BaseSOARExecutor(ABC):
    """Abstract Base Class for SOAR Execution Abstraction Layer with Fail-Closed Isolation."""

    def __init__(self, guard: Optional[SOARExecutionGuard] = None):
        self.guard = guard or SOARExecutionGuard()

    @abstractmethod
    def execute_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    def rollback_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        pass

    def execute_real_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Strictly prohibits real endpoint actions across all SOAR execution paths.
        Always fails closed and refuses execution.
        """
        now_str = datetime.now().isoformat()
        refusal_msg = (
            f"REFUSED FAIL-CLOSED: Real endpoint action '{action_id}' on target '{target}' is strictly "
            f"prohibited. SOAR is locked in simulation-only isolation mode."
        )
        return {
            "execution_id": f"EXEC-REAL-BLOCKED-{datetime.now().strftime('%M%S%f')}",
            "action_id": action_id,
            "target": target,
            "status": "REFUSED",
            "lifecycle_state": "REFUSED_FAIL_CLOSED",
            "simulation_banner": "EXECUTION REFUSED — REAL ENDPOINT ACTIONS PROHIBITED",
            "verification_status": "VERIFIED_FAILURE",
            "error_message": refusal_msg,
            "real_endpoint_action_taken": False,
            "rollback_status": "NOT_APPLICABLE",
            "dry_run": True,
            "timestamp": now_str,
            "details": {
                "reason": refusal_msg,
                "real_endpoint_action_taken": False,
                "guard_status": "REFUSED_FAIL_CLOSED",
            }
        }


class MockSOARExecutor(BaseSOARExecutor):
    """
    Safe Mock / Simulated SOAR Executor.
    Executes allowlisted SOAR actions in Dry-Run or Simulated Sandbox mode.
    Prohibits real destructive OS modifications via fail-closed SOARExecutionGuard.
    """

    def __init__(
        self,
        registry: Optional[SOARActionRegistry] = None,
        guard: Optional[SOARExecutionGuard] = None,
        execution_mode: Optional[str] = None
    ):
        self.guard = guard or SOARExecutionGuard(mode=execution_mode)
        super().__init__(guard=self.guard)
        self.registry = registry or SOARActionRegistry()
        self.execution_mode = execution_mode

    def execute_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        Simulates execution of allowlisted SOAR action under fail-closed isolation guard.
        """
        parameters = parameters or {}
        now_str = datetime.now().isoformat()

        # 1. FAIL-CLOSED GUARD VERIFICATION: Execution Mode and Isolation Check
        permitted, guard_reason, guard_meta = self.guard.verify_safety_before_execution(
            action_id=action_id,
            target=target,
            mode=self.execution_mode,
            analyst_approval=parameters.get("analyst_approval"),
            parameters=parameters,
        )
        if not permitted:
            return {
                "execution_id": f"EXEC-REFUSED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REFUSED",
                "lifecycle_state": "REFUSED_FAIL_CLOSED",
                "simulation_banner": "EXECUTION REFUSED — FAIL-CLOSED SAFETY GUARD TRIGGERED",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": guard_reason,
                "real_endpoint_action_taken": False,
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": True,
                "timestamp": now_str,
                "details": {
                    "reason": guard_reason,
                    "guard_status": "REFUSED_FAIL_CLOSED",
                    "real_endpoint_action_taken": False,
                    "mode": guard_meta.get("execution_mode", "UNKNOWN"),
                }
            }

        # 2. Validate request against allowlist & target rules
        is_valid, err_msg = self.registry.validate_action_request(action_id, target, parameters)
        if not is_valid:
            return {
                "execution_id": f"EXEC-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "lifecycle_state": "REJECTED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": err_msg,
                "real_endpoint_action_taken": False,
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {
                    "reason": err_msg,
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                }
            }

        action_meta = self.registry.get_action(action_id)
        is_reversible = action_meta.get("is_reversible", False)
        rollback_status = "AVAILABLE" if is_reversible else "NON_REVERSIBLE"

        if dry_run:
            preview_msg = (
                f"DRY RUN — NO SYSTEM CHANGE: Would execute '{action_id}' on target '{target}' "
                f"with parameters {parameters} via agent policy."
            )
            return {
                "execution_id": f"EXEC-DRYRUN-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "DRY_RUN",
                "lifecycle_state": "SIMULATED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                "verification_status": "VERIFIED_SUCCESS",
                "error_message": "",
                "real_endpoint_action_taken": False,
                "rollback_status": rollback_status,
                "dry_run": True,
                "timestamp": now_str,
                "details": {
                    "preview": preview_msg,
                    "simulated": True,
                    "lifecycle_state": "SIMULATED",
                    "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                    "mode": "DRY RUN MODE — NO SYSTEM CHANGE",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                }
            }

        # Simulated Execution Mode (dry_run = False)
        sim_details = self._simulate_action_logic(action_id, target, parameters)
        sim_details["lifecycle_state"] = "COMPLETED_IN_SIMULATION"
        sim_details["simulation_banner"] = "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"
        sim_details["real_endpoint_action_taken"] = False
        sim_details["guard_status"] = "ISOLATION_ENFORCED"
        return {
            "execution_id": f"EXEC-SIM-{datetime.now().strftime('%M%S%f')}",
            "action_id": action_id,
            "target": target,
            "status": "EXECUTED",
            "lifecycle_state": "COMPLETED_IN_SIMULATION",
            "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
            "verification_status": "VERIFIED_SUCCESS",
            "error_message": "",
            "real_endpoint_action_taken": False,
            "rollback_status": rollback_status,
            "dry_run": False,
            "timestamp": now_str,
            "details": sim_details
        }

    def rollback_action(
        self,
        action_id: str,
        target: str,
        parameters: Optional[Dict[str, Any]] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        Simulates rollback execution for reversible SOAR actions under fail-closed isolation guard.
        """
        parameters = parameters or {}
        now_str = datetime.now().isoformat()

        # 1. FAIL-CLOSED GUARD VERIFICATION: Execution Mode and Isolation Check
        permitted, guard_reason, guard_meta = self.guard.verify_safety_before_execution(
            action_id=action_id,
            target=target,
            mode=self.execution_mode,
            analyst_approval=parameters.get("analyst_approval"),
            parameters=parameters,
        )
        if not permitted:
            return {
                "execution_id": f"ROLLBACK-REFUSED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REFUSED",
                "lifecycle_state": "REFUSED_FAIL_CLOSED",
                "simulation_banner": "EXECUTION REFUSED — FAIL-CLOSED SAFETY GUARD TRIGGERED",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": guard_reason,
                "real_endpoint_action_taken": False,
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": True,
                "timestamp": now_str,
                "details": {
                    "reason": guard_reason,
                    "guard_status": "REFUSED_FAIL_CLOSED",
                    "real_endpoint_action_taken": False,
                    "mode": guard_meta.get("execution_mode", "UNKNOWN"),
                }
            }

        action_meta = self.registry.get_action(action_id)
        if not action_meta:
            return {
                "execution_id": f"ROLLBACK-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "lifecycle_state": "REJECTED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": f"Action '{action_id}' is unknown.",
                "real_endpoint_action_taken": False,
                "rollback_status": "NOT_APPLICABLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {
                    "reason": f"Action '{action_id}' is unknown.",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                }
            }

        if not action_meta.get("is_reversible", False):
            return {
                "execution_id": f"ROLLBACK-REJECTED-{datetime.now().strftime('%M%S%f')}",
                "action_id": action_id,
                "target": target,
                "status": "REJECTED",
                "lifecycle_state": "REJECTED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                "verification_status": "VERIFIED_FAILURE",
                "error_message": f"Action '{action_id}' is explicitly NON-REVERSIBLE and cannot be rolled back.",
                "real_endpoint_action_taken": False,
                "rollback_status": "NON_REVERSIBLE",
                "dry_run": dry_run,
                "timestamp": now_str,
                "details": {
                    "reason": "Non-reversible action",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                }
            }

        rollback_action_id = action_meta.get("rollback_action_id")
        if dry_run:
            preview_msg = (
                f"DRY RUN — NO SYSTEM CHANGE: Would execute rollback '{rollback_action_id}' "
                f"for target '{target}'."
            )
            return {
                "execution_id": f"ROLLBACK-DRYRUN-{datetime.now().strftime('%M%S%f')}",
                "action_id": rollback_action_id,
                "target": target,
                "status": "DRY_RUN",
                "lifecycle_state": "SIMULATED",
                "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                "verification_status": "VERIFIED_SUCCESS",
                "error_message": "",
                "real_endpoint_action_taken": False,
                "rollback_status": "ROLLED_BACK",
                "dry_run": True,
                "timestamp": now_str,
                "details": {
                    "preview": preview_msg,
                    "simulated": True,
                    "lifecycle_state": "SIMULATED",
                    "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
                    "real_endpoint_action_taken": False,
                    "guard_status": "ISOLATION_ENFORCED",
                }
            }

        sim_details = {
            "summary": f"SIMULATED ROLLBACK SUCCESS: Reverted '{action_id}' via '{rollback_action_id}' on target '{target}'.",
            "previous_state": f"Modified by {action_id}",
            "restored_state": "Baseline Operational State",
            "lifecycle_state": "ROLLED_BACK",
            "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
            "real_endpoint_action_taken": False,
            "guard_status": "ISOLATION_ENFORCED",
        }
        return {
            "execution_id": f"ROLLBACK-SIM-{datetime.now().strftime('%M%S%f')}",
            "action_id": rollback_action_id,
            "target": target,
            "status": "ROLLED_BACK",
            "lifecycle_state": "ROLLED_BACK",
            "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
            "verification_status": "VERIFIED_SUCCESS",
            "error_message": "",
            "real_endpoint_action_taken": False,
            "rollback_status": "ROLLED_BACK",
            "dry_run": False,
            "timestamp": now_str,
            "details": sim_details
        }

    def _simulate_action_logic(self, action_id: str, target: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Internal helper generating detailed simulation logs for each allowlisted action."""
        if action_id == "ISOLATE_HOST":
            return {
                "summary": f"SIMULATED HOST ISOLATION: Applied firewall rule isolating host '{target}'.",
                "sandbox_ip_rule": f"DENY ALL EXCEPT SOC ENGINE ON HOST {target}",
                "agent_channel": "SOAR Active Response Protocol (Simulated)"
            }
        elif action_id == "BLOCK_IP":
            return {
                "summary": f"SIMULATED IP BLOCK: Added IP '{target}' to edge firewall drop table.",
                "rule_id": f"FW-BLOCK-{target.replace('.', '_')}",
                "perimeter": "Inbound & Outbound Traffic Filtered"
            }
        elif action_id == "LOCK_USER":
            return {
                "summary": f"SIMULATED ACCOUNT LOCKOUT: Set accountDisabled=TRUE for user '{target}'.",
                "active_directory_sam": f"Account '{target}' disabled in SAM/AD database.",
                "active_sessions": "Terminated 2 active Kerberos tickets for account."
            }
        elif action_id == "TERMINATE_PROCESS":
            host_param = parameters.get("hostname", "UNKNOWN-HOST")
            return {
                "summary": f"SIMULATED PROCESS TERMINATION: Terminated process '{target}' on host '{host_param}'.",
                "process_name": target,
                "hostname": host_param,
                "agent_channel": "SOAR Endpoint Process Control (Simulated)"
            }
        elif action_id == "COLLECT_FORENSIC_ARTIFACTS":
            art_type = parameters.get("artifact_type", "triage_package")
            return {
                "summary": f"SIMULATED FORENSIC COLLECTION: Captured artifact package '{art_type}' for host '{target}'.",
                "artifact_type": art_type,
                "storage_location": f"data/forensics/triage_{target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip",
                "integrity_hash_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
            }
        return {"summary": f"Simulated execution for action '{action_id}' on target '{target}'."}
