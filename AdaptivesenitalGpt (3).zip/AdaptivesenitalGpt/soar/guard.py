"""
SOAR Execution Guard.
Enforces strict fail-closed simulation and dry-run isolation across all SOAR execution paths.
Ensures that no real endpoint containment or remediation action can be executed under any
circumstance during simulation, attack demonstrations, or dry-run mode.
"""
import os
from typing import Dict, Any, Tuple, Optional


class SOARExecutionGuard:
    """
    Fail-closed backend isolation guard for SOAR actions.
    Guarantees that:
    1. Default configuration is DRY_RUN.
    2. Only authorized safe modes ('DRY_RUN', 'SIMULATION', 'ADVISORY') are recognized.
    3. Any unrecognized, missing, or empty mode fails closed (execution strictly refused).
    4. Analyst approval clicks CANNOT bypass simulation mode or execute real actions.
    5. Real endpoint actions are permanently blocked (killswitch SOAR_ALLOW_REAL_ENDPOINT_ACTIONS=False).
    6. Structured verification returns real_endpoint_action_taken: False.
    """

    AUTHORIZED_MODES = {"DRY_RUN", "SIMULATION", "ADVISORY"}
    DEFAULT_MODE = "DRY_RUN"

    def __init__(self, mode: Optional[str] = None):
        self._configured_mode = mode

    def get_effective_mode(self) -> str:
        """
        Resolves the effective mode. If explicitly configured on instance, uses that.
        Otherwise falls back to config.settings.SOAR_EXECUTION_MODE, then os.environ,
        defaulting to 'DRY_RUN'.
        """
        if self._configured_mode is not None:
            return str(self._configured_mode).strip().upper()
        try:
            from config.settings import SOAR_EXECUTION_MODE
            if SOAR_EXECUTION_MODE:
                return str(SOAR_EXECUTION_MODE).strip().upper()
        except ImportError:
            pass
        return os.getenv("SOAR_EXECUTION_MODE", self.DEFAULT_MODE).strip().upper()

    def validate_mode(self, mode: Optional[str] = None) -> Tuple[bool, str, str]:
        """
        Validates the execution mode fail-closed.
        Returns: (is_valid: bool, active_mode: str, message: str)
        """
        active_mode = (mode if mode is not None else self.get_effective_mode()).strip().upper()
        if not active_mode:
            return False, "MISSING_MODE", "FAIL-CLOSED: SOAR execution mode is missing or empty. Execution refused."
        if active_mode not in self.AUTHORIZED_MODES:
            return (
                False,
                active_mode,
                f"FAIL-CLOSED: Unrecognized SOAR execution mode '{active_mode}'. "
                f"Only {sorted(list(self.AUTHORIZED_MODES))} are permitted. Execution refused."
            )
        return True, active_mode, f"SOAR mode '{active_mode}' verified safe for isolated execution."

    def verify_safety_before_execution(
        self,
        action_id: str,
        target: str,
        mode: Optional[str] = None,
        analyst_approval: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Comprehensive pre-execution safety check enforcing fail-closed isolation.
        Returns: (permitted: bool, reason: str, metadata: Dict[str, Any])
        """
        is_mode_valid, active_mode, mode_msg = self.validate_mode(mode)
        if not is_mode_valid:
            return False, mode_msg, {
                "guard_status": "REFUSED_FAIL_CLOSED",
                "execution_mode": active_mode,
                "real_endpoint_action_taken": False,
                "reason": mode_msg,
            }

        # Global killswitch check: real endpoint actions permanently disabled
        # Even if analyst_approval is "APPROVED", real execution is NEVER permitted.
        return True, "ISOLATION_ENFORCED", {
            "guard_status": "ISOLATION_ENFORCED",
            "execution_mode": active_mode,
            "real_endpoint_action_taken": False,
            "approval_state": analyst_approval or "NOT_SPECIFIED",
            "simulation_banner": "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN",
            "advisory_status": "Advisory Recommendation — Not Executed",
        }
