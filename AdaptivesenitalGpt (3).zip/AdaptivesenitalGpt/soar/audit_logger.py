import sqlite3
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional


class SOARAuditLogger:
    """
    Persistent Audit Logging Engine for SOAR Action Requests, Analyst Approvals,
    Dry-Run Executions, Verification Results, and Rollbacks.
    """

    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            project_root = Path(__file__).resolve().parent.parent
            data_dir = project_root / "data"
            data_dir.mkdir(parents=True, exist_ok=True)
            db_path = str(data_dir / "soar_audit.db")

        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Initializes SOAR audit log table schema."""
        with self._get_connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS soar_audit_log (
                    audit_id TEXT PRIMARY KEY,
                    incident_id TEXT NOT NULL,
                    action_id TEXT NOT NULL,
                    analyst_approval TEXT NOT NULL,
                    analyst_user TEXT,
                    target TEXT NOT NULL,
                    requested_timestamp TEXT NOT NULL,
                    execution_timestamp TEXT,
                    action_status TEXT NOT NULL,
                    verification_result TEXT,
                    error_message TEXT,
                    rollback_status TEXT NOT NULL,
                    source_of_recommendation TEXT,
                    gnn_score REAL,
                    rule_id TEXT,
                    mitre_technique TEXT,
                    dry_run INTEGER NOT NULL,
                    parameters_json TEXT,
                    details_json TEXT
                )
            """)
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(soar_audit_log)")
            cols = [row[1] for row in cursor.fetchall()]
            if "wazuh_rule_id" in cols and "rule_id" not in cols:
                try:
                    conn.execute("ALTER TABLE soar_audit_log RENAME COLUMN wazuh_rule_id TO rule_id")
                except Exception:
                    pass
            conn.commit()

    def log_event(self, record: Dict[str, Any]) -> str:
        """
        Records a SOAR audit event into persistent log store.
        Returns: audit_id
        """
        audit_id = record.get("audit_id") or f"AUDIT-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        incident_id = record.get("incident_id", "INC-UNK")
        action_id = record.get("action_id", "UNKNOWN_ACTION")
        analyst_approval = record.get("analyst_approval", "PENDING")
        analyst_user = record.get("analyst_user", "system_analyst")
        target = record.get("target", "UNKNOWN")
        requested_ts = record.get("requested_timestamp") or datetime.now().isoformat()
        execution_ts = record.get("execution_timestamp") or datetime.now().isoformat()
        action_status = record.get("action_status", "PENDING")
        verification_result = record.get("verification_result", "UNVERIFIED")
        error_message = record.get("error_message", "")
        rollback_status = record.get("rollback_status", "NOT_APPLICABLE")
        source_rec = record.get("source_of_recommendation", "SOAR Decision Engine")
        gnn_score = float(record.get("gnn_score", 0.0))
        rule_id = str(record.get("rule_id", "N/A"))
        mitre_technique = str(record.get("mitre_technique", "N/A"))
        dry_run = 1 if record.get("dry_run", True) else 0
        params_json = json.dumps(record.get("parameters", {}))
        details_json = json.dumps(record.get("details", {}))

        with self._get_connection() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO soar_audit_log (
                    audit_id, incident_id, action_id, analyst_approval, analyst_user,
                    target, requested_timestamp, execution_timestamp, action_status,
                    verification_result, error_message, rollback_status,
                    source_of_recommendation, gnn_score, rule_id, mitre_technique,
                    dry_run, parameters_json, details_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                audit_id, incident_id, action_id, analyst_approval, analyst_user,
                target, requested_ts, execution_ts, action_status,
                verification_result, error_message, rollback_status,
                source_rec, gnn_score, rule_id, mitre_technique,
                dry_run, params_json, details_json
            ))
            conn.commit()

        return audit_id

    def get_audit_records(
        self,
        incident_id: Optional[str] = None,
        action_id: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Retrieves persistent audit records matching filter criteria."""
        query = "SELECT * FROM soar_audit_log"
        params = []
        conditions = []

        if incident_id:
            conditions.append("incident_id = ?")
            params.append(incident_id)
        if action_id:
            conditions.append("action_id = ?")
            params.append(action_id)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY requested_timestamp DESC LIMIT ?"
        params.append(limit)

        records = []
        with self._get_connection() as conn:
            cursor = conn.execute(query, params)
            for row in cursor.fetchall():
                rec = dict(row)
                rec["dry_run"] = bool(rec["dry_run"])
                rec["parameters"] = json.loads(rec.get("parameters_json") or "{}")
                rec["details"] = json.loads(rec.get("details_json") or "{}")
                records.append(rec)

        return records

    def clear_audit_records(self):
        """Clears audit records (for test teardowns)."""
        with self._get_connection() as conn:
            conn.execute("DELETE FROM soar_audit_log")
            conn.commit()
