from typing import List, Dict, Any
from config.settings import SUJITH_IP, get_receiver_ip


class LogNormalizer:
    """
    Normalizes multi-source events (Windows, Sysmon, Linux, Suricata)
    into a standardized SentinelGPT event schema.
    """

    EVENT_TYPE_MAP = {
        4624: "Successful Authentication",
        4625: "Failed Authentication",
        4672: "Special Privileges Assigned",
        4688: "Windows Process Creation",
        4720: "User Account Created",
        4798: "User Local Group Membership Enumerated",
        4799: "Local Group Enumeration",
        5379: "Credential Manager Credential Read",
        7040: "Service Start Type Changed",
        1102: "Audit Log Cleared",
        1000: "Application / Informational Event (ID 1000)",
        1: "Sysmon Process Creation",
        3: "Sysmon Network Connection",
        10: "Sysmon LSASS Process Access",
        1001: "Linux SSH Login Attempt",
        2000001: "Suricata Network IDS Alert"
    }

    SEVERITY_MAP = {
        4624: "Low",
        4625: "Medium",
        4672: "Low",
        4688: "Medium",
        4720: "High",
        4798: "Medium",
        4799: "Medium",
        5379: "High",
        7040: "Medium",
        1102: "Critical",
        1000: "Low",
        1: "High",
        3: "Medium",
        10: "Critical",
        1001: "Medium",
        2000001: "High"
    }

    MITRE_TECHNIQUE_MAP = {
        4624: "T1078",      # Valid Accounts
        4625: "T1110",      # Brute Force
        4672: "T1078.001",  # Domain Accounts
        4688: "T1059",      # Command and Scripting Interpreter
        4720: "T1136",      # Create Account
        4798: "T1087.001",  # Account Discovery: Local Account
        4799: "T1087",      # Account Discovery
        5379: "T1555.004",  # Credentials from Password Stores: Windows Credential Manager
        7040: "T1543",      # Create or Modify System Process
        1102: "T1070.001",  # Clear Windows Event Logs
        1000: "N/A",        # Diagnostic Telemetry Probe
        1: "T1059.001",     # PowerShell Execution
        10: "T1003.001",    # LSASS Memory Dumping
        1001: "T1110.001",  # Password Guessing
        2000001: "T1021"    # Remote Services
    }

    DIAGNOSTIC_MARKERS = (
        "SECTOR1_RECEIVER_TEST",
        "SECTOR1_E2E",
        "DIAGNOSTIC_TEST",
        "PHASE1_",
        "RECEIVER_TEST",
        "SENTINEL_TEST",
        "ADAPTIVE SENTINEL CONNECTION TEST",
        "NXLOG TEST EVENT",
        "LIVE TEST FROM",
    )

    def normalize(self, raw_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        normalized_events = []

        for log in raw_logs:
            event_id = log.get("event_id", 0)
            desc = log.get("description") or log.get("message", "No event description provided.")
            cmd_line = log.get("command_line", "N/A")

            # Check if event is an explicit diagnostic verification probe (Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in str(desc).upper() or marker in str(cmd_line).upper()
                       for marker in self.DIAGNOSTIC_MARKERS)
            )

            mitre_tech = log.get("mitre_technique")
            if is_diagnostic:
                mitre_tech = "N/A"
            elif not mitre_tech or mitre_tech in ["N/A", "T1000"]:
                mitre_list = log.get("mitre_techniques", [])
                if isinstance(mitre_list, list) and mitre_list:
                    mitre_tech = ", ".join(str(m) for m in mitre_list)
                else:
                    mitre_tech = self.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")

            receiver_ip = get_receiver_ip()
            source = log.get("source") or "real_nxlog_windows"
            hostname = log.get("hostname") or "UNKNOWN_HOST"
            source_ip = log.get("source_ip")
            if not source_ip or source_ip in ["-", "::1", "127.0.0.1", ""] or (
                source == "real_nxlog_windows" and str(source_ip).strip() == receiver_ip
            ):
                source_ip = "N/A"

            # Determine event_type string cleanly
            extracted_evt_type = log.get("event_type")
            if is_diagnostic:
                extracted_evt_type = "Diagnostic Telemetry Probe"
            elif not extracted_evt_type or extracted_evt_type in ["NXLog Event", "Generic Event", "N/A"]:
                if event_id in self.EVENT_TYPE_MAP:
                    extracted_evt_type = self.EVENT_TYPE_MAP[event_id]
                elif event_id != 0:
                    extracted_evt_type = f"Windows Event (ID {event_id})"
                else:
                    extracted_evt_type = "Windows Event"

            # Start with original dict to preserve all custom fields
            normalized_event = log.copy()
            curr_sev = log.get("severity")
            if is_diagnostic:
                resolved_sev = "Low"
            elif not curr_sev or str(curr_sev).strip().title() in ["Low", "Informational", "Info", "N/A"]:
                resolved_sev = self.SEVERITY_MAP.get(event_id, curr_sev or "Low")
            else:
                resolved_sev = curr_sev

            dst_ip = log.get("destination_ip")
            if not dst_ip or dst_ip in ["-", ""]:
                dst_ip = receiver_ip

            normalized_event.update({
                "timestamp": log.get("timestamp"),
                "ingestion_timestamp": log.get("ingestion_timestamp"),
                "source": source,
                "event_id": event_id,
                "event_type": extracted_evt_type,
                "severity": resolved_sev,
                "hostname": hostname,
                "user": log.get("user", "SYSTEM"),
                "source_ip": source_ip,
                "destination_ip": dst_ip,
                "process_name": log.get("process_name", "N/A"),
                "command_line": cmd_line,
                "description": desc,
                "mitre_technique": mitre_tech,
                "mitre_techniques": log.get("mitre_techniques", []),
                "is_diagnostic": is_diagnostic
            })

            normalized_events.append(normalized_event)

        print(f"[INFO] LogNormalizer standardized {len(normalized_events)} log events.")
        return normalized_events


def normalize_events(raw_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return LogNormalizer().normalize(raw_logs)