import hashlib
import importlib
import os
from typing import List, Dict, Any, Set, Tuple, Optional
from datetime import datetime, timezone
import config.settings as settings
import analysis.deduplicate as _dedup_mod
import analysis.normalize as _norm_mod

if not hasattr(_dedup_mod, "get_alert_identity_key") or not hasattr(_dedup_mod, "get_alert_identity_hash"):
    importlib.reload(_dedup_mod)
if not hasattr(_norm_mod, "resolve_canonical_hostname"):
    importlib.reload(_norm_mod)

from analysis.deduplicate import (
    get_alert_identity_key,
    get_alert_identity_hash,
)
from analysis.normalize import resolve_canonical_hostname

CORRELATION_AGENT_VERSION = "20261014.3"
BRUTE_FORCE_ISOLATION_VERSION = 2


def parse_alert_timestamp_dt(ts_str: Any) -> Optional[datetime]:
    """Parses an alert/event timestamp string into a timezone-aware datetime object."""
    if not ts_str:
        return None
    try:
        s = str(ts_str).strip().replace("Z", "+00:00")
        if "+" in s or ("-" in s[10:] and len(s) > 13):
            return datetime.fromisoformat(s)
        return datetime.fromisoformat(s).replace(tzinfo=timezone.utc)
    except Exception:
        return None


def count_events_in_sliding_window(alerts_list: List[Dict[str, Any]], window_seconds: int) -> int:
    """
    Computes the maximum cluster size of alerts occurring within window_seconds.
    If timestamps are missing or invalid (e.g. synthetic test mocks), returns len(alerts_list).
    """
    if len(alerts_list) <= 1:
        return len(alerts_list)
    timestamps: List[float] = []
    for a in alerts_list:
        ev = a.get("event", {}) if isinstance(a, dict) else {}
        candidate_ts = ev.get("timestamp") or a.get("timestamp")
        dt = parse_alert_timestamp_dt(candidate_ts)
        if dt is not None:
            timestamps.append(dt.timestamp())
    if len(timestamps) < len(alerts_list) * 0.5:
        # Insufficient timestamps to evaluate sliding window; preserve total count
        return len(alerts_list)
    timestamps.sort()
    max_in_window = 1
    left = 0
    for right in range(len(timestamps)):
        while timestamps[right] - timestamps[left] > window_seconds:
            left += 1
        window_len = right - left + 1
        if window_len > max_in_window:
            max_in_window = window_len
    return max_in_window


class CorrelationAgent:
    """
    Correlation Agent correlating atomic alerts into unified multi-stage Incidents
    based on host, user, IP, and temporal attack chain analysis.
    """

    def correlate(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        incidents = []

        # Canonicalize display hostname via verified aliases + case-insensitively (e.g. 'Harsha', 'HARSHA', 'HARSHA-PC' -> 'Harsha')
        canonical_hosts: Dict[str, str] = {}
        for alert in alerts:
            raw_h = str(alert.get("event", {}).get("hostname") or alert.get("hostname") or "UNKNOWN_HOST").strip()
            resolved_h = resolve_canonical_hostname(raw_h)
            h_low = resolved_h.lower()
            if h_low not in canonical_hosts:
                canonical_hosts[h_low] = resolved_h
            elif canonical_hosts[h_low].isupper() and not resolved_h.isupper():
                canonical_hosts[h_low] = resolved_h

        # Separate diagnostic probes (grouped by canonical host + provenance) from security alerts
        diag_groups: Dict[str, List[Dict[str, Any]]] = {}
        diag_seen_keys: Dict[str, Set[Tuple[Any, ...]]] = {}
        host_groups: Dict[str, List[Dict[str, Any]]] = {}
        host_seen_keys: Dict[str, Set[Tuple[Any, ...]]] = {}

        # Pre-index non-SYSTEM users per (host_low, prov) so SYSTEM-level LSASS dumps on a host
        # with an active user brute-force chain correlate with that host's user attack chain
        host_primary_user: Dict[str, str] = {}
        for alert in alerts:
            if alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""):
                continue
            ev = alert.get("event", {})
            h_low = resolve_canonical_hostname(str(ev.get("hostname", "UNKNOWN_HOST")).strip()).lower()
            u = str(ev.get("user", "SYSTEM")).strip()
            src = str(ev.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            hp_key = f"{h_low}::{prov}"
            if u not in ("SYSTEM", "N/A", "") and hp_key not in host_primary_user:
                host_primary_user[hp_key] = u

        for alert in alerts:
            event = alert["event"]
            raw_host = str(event.get("hostname", "UNKNOWN_HOST")).strip()
            resolved_host = resolve_canonical_hostname(raw_host)
            host = canonical_hosts.get(resolved_host.lower(), resolved_host)
            user = str(event.get("user", "SYSTEM")).strip() or "SYSTEM"
            src = str(event.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            has_identity_anchor = (
                event.get("record_offset") is not None
                or event.get("record_id") is not None
                or event.get("timestamp") is not None
            )
            alert_identity = get_alert_identity_key(alert) if has_identity_anchor else None

            is_diag = bool(alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""))
            if is_diag:
                d_key = f"{host}::{prov}"
                if alert_identity is not None:
                    seen_d = diag_seen_keys.setdefault(d_key, set())
                    if alert_identity in seen_d:
                        continue
                    seen_d.add(alert_identity)
                diag_groups.setdefault(d_key, []).append(alert)
                continue

            hp_key = f"{host.lower()}::{prov}"
            if (
                user == "SYSTEM"
                and ("LSASS" in alert.get("alert_name", "") or "Mimikatz" in alert.get("alert_name", ""))
                and hp_key in host_primary_user
            ):
                user = host_primary_user[hp_key]

            key = f"{host}::{user}::{prov}"
            if alert_identity is not None:
                seen_h = host_seen_keys.setdefault(key, set())
                if alert_identity in seen_h:
                    continue
                seen_h.add(alert_identity)
            if key not in host_groups:
                host_groups[key] = []
            host_groups[key].append(alert)

        for d_key, diag_alerts in diag_groups.items():
            host, prov = d_key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"
            primary_diag_user = next(
                (str(a.get("event", {}).get("user", "SYSTEM")) for a in diag_alerts if a.get("event", {}).get("user") not in (None, "", "SYSTEM", "N/A")),
                str(diag_alerts[0].get("event", {}).get("user", "SYSTEM")),
            )
            inc_hash = hashlib.md5(f"{host}:{primary_diag_user}:diagnostic{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
            incidents.append({
                "incident_id": f"INC-DIAG-{inc_hash}",
                "incident_name": f"Diagnostic Telemetry Verification Probe ({host})",
                "severity": "Low",
                "confidence": 100,
                "is_diagnostic": True,
                "alert_count": len(diag_alerts),
                "affected_host": host,
                "affected_user": primary_diag_user,
                "alerts": diag_alerts,
                "created_at": datetime.now().isoformat()
            })

        # Collect potential password spraying across distinct accounts per (host, prov)
        consumed_spray_alert_ids: Set[int] = set()
        spray_window_sec = int(os.getenv("PASSWORD_SPRAY_WINDOW_SECONDS", str(getattr(settings, "PASSWORD_SPRAY_WINDOW_SECONDS", 900))))
        spray_acct_thresh = int(os.getenv("PASSWORD_SPRAY_ACCOUNT_THRESHOLD", str(getattr(settings, "PASSWORD_SPRAY_ACCOUNT_THRESHOLD", 3))))

        # Index all failed login alerts by (host, prov) to detect multi-account password spraying
        host_prov_auth_failures: Dict[str, List[Dict[str, Any]]] = {}
        for alert in alerts:
            if alert.get("is_diagnostic") or "Diagnostic" in str(alert.get("alert_name", "")):
                continue
            is_auth_failure = (
                "Failed Logon" in str(alert.get("alert_name", ""))
                or alert.get("rule_id") == "RULE-AUTH-4625"
            )
            if not is_auth_failure:
                continue
            ev = alert.get("event", {}) if isinstance(alert, dict) else {}
            raw_h = str(ev.get("hostname", "UNKNOWN_HOST")).strip()
            res_h = resolve_canonical_hostname(raw_h)
            h = canonical_hosts.get(res_h.lower(), res_h)
            src = str(ev.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            hp_k = f"{h}::{prov}"
            host_prov_auth_failures.setdefault(hp_k, []).append(alert)

        for hp_k, hp_failures in host_prov_auth_failures.items():
            h, prov = hp_k.split("::")
            hash_suffix = "" if prov == "real" else ":sim"
            acct_to_failures: Dict[str, List[Dict[str, Any]]] = {}
            for al in hp_failures:
                u = str(al.get("event", {}).get("user", "")).strip()
                if u and u.upper() not in ("SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "N/A", "-", "ANONYMOUS LOGON") and not u.endswith("$"):
                    acct_to_failures.setdefault(u, []).append(al)

            if len(acct_to_failures) >= spray_acct_thresh:
                flat_failures = [al for al_list in acct_to_failures.values() for al in al_list]
                window_count = count_events_in_sliding_window(flat_failures, spray_window_sec)
                if window_count >= spray_acct_thresh:
                    inc_hash = hashlib.md5(f"{h}:passwordspray{hash_suffix}".encode()).hexdigest()[:6].upper()
                    target_summary = ", ".join(sorted(acct_to_failures.keys())[:3])
                    if len(acct_to_failures) > 3:
                        target_summary += f", +{len(acct_to_failures) - 3} more"
                    incidents.append({
                        "incident_id": f"INC-{inc_hash}",
                        "incident_name": f"Automated Password Spraying Attack ({len(acct_to_failures)} Target Accounts)",
                        "severity": "High",
                        "confidence": 92,
                        "alert_count": len(flat_failures),
                        "affected_host": h,
                        "affected_user": f"Multiple Accounts ({target_summary})",
                        "alerts": flat_failures,
                        "mitre_techniques": ["T1110.003"],
                        "mitre_tactic": "Credential Access",
                        "created_at": datetime.now().isoformat()
                    })
                    for al in flat_failures:
                        consumed_spray_alert_ids.add(id(al))

        # Correlate grouped security alerts
        for key, security_alerts in host_groups.items():
            host, user, prov = key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"

            # Exclude alerts claimed by multi-account password spraying
            if consumed_spray_alert_ids:
                security_alerts = [a for a in security_alerts if id(a) not in consumed_spray_alert_ids]

            if not security_alerts:
                continue

            # 1. Context-Aware Privilege Escalation (RULE-PRIVESC-CONTEXT-01)
            privesc_alerts = [
                a for a in security_alerts
                if a.get("rule_id") == "RULE-PRIVESC-CONTEXT-01"
                or "Privilege Escalation" in str(a.get("alert_name", ""))
            ]
            if privesc_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:privesc{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Context-Aware Privilege Escalation Activity",
                    "severity": "High",
                    "confidence": 88,
                    "alert_count": len(privesc_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": privesc_alerts,
                    "mitre_techniques": ["T1548.002"],
                    "mitre_tactic": "Privilege Escalation",
                    "created_at": datetime.now().isoformat()
                })
                security_alerts = [a for a in security_alerts if a not in privesc_alerts]
                if not security_alerts:
                    continue

            # 2. Automated Brute Force & Credential Harvesting Chain
            failed_logins = [
                a for a in security_alerts
                if "Failed Logon" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-AUTH-4625"
            ]
            lsass_alerts = [
                a for a in security_alerts
                if "LSASS" in str(a.get("alert_name", ""))
                or "Mimikatz" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-CRED-LSASS-10"
            ]
            bf_window_sec = int(os.getenv("BRUTE_FORCE_WINDOW_SECONDS", str(getattr(settings, "BRUTE_FORCE_WINDOW_SECONDS", 900))))
            bf_thresh = int(os.getenv("BRUTE_FORCE_THRESHOLD", str(getattr(settings, "BRUTE_FORCE_THRESHOLD", 2))))

            window_failed_count = count_events_in_sliding_window(failed_logins, bf_window_sec)
            is_brute_force = window_failed_count >= bf_thresh

            if is_brute_force or (failed_logins and lsass_alerts) or (lsass_alerts and len(failed_logins) >= 1):
                bf_alerts = list(failed_logins)
                seen_bf_ids = {id(a) for a in bf_alerts}
                if lsass_alerts:
                    for la in lsass_alerts:
                        if id(la) not in seen_bf_ids:
                            seen_bf_ids.add(id(la))
                            bf_alerts.append(la)
                inc_hash = hashlib.md5(f"{host}:{user}:bruteforce{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                inc_title = (
                    "Automated Brute Force & Credential Dumping Attack Chain"
                    if lsass_alerts
                    else "Automated Brute Force & Password Spraying Attack"
                )
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": inc_title,
                    "severity": "Critical" if lsass_alerts else "High",
                    "confidence": 96 if lsass_alerts else 90,
                    "alert_count": len(bf_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": bf_alerts,
                    "mitre_techniques": ["T1110", "T1003.001"] if lsass_alerts else ["T1110"],
                    "mitre_tactic": "Credential Access",
                    "created_at": datetime.now().isoformat()
                })
                consumed_bf_ids = {id(a) for a in bf_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_bf_ids]
                if not security_alerts:
                    continue

            elif lsass_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:lsass_dump{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"OS Credential Dumping via LSASS Memory Access ({user})",
                    "severity": "Critical",
                    "confidence": 96,
                    "alert_count": len(lsass_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": lsass_alerts,
                    "mitre_techniques": ["T1003.001"],
                    "mitre_tactic": "Credential Access",
                    "created_at": datetime.now().isoformat()
                })
                consumed_lsass_ids = {id(a) for a in lsass_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_lsass_ids]
                if not security_alerts:
                    continue

            # 3. Windows Credential Manager Read / Vault Access & Account Discovery
            cred_manager_alerts = [
                a for a in security_alerts
                if "Credential Manager" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-CRED-5379"
            ]
            discovery_alerts = [
                a for a in security_alerts
                if "Account Discovery" in str(a.get("alert_name", ""))
                or "Group Membership" in str(a.get("alert_name", ""))
                or a.get("rule_id") in ("RULE-DISC-4798", "RULE-DISC-4799")
            ]

            recon_binaries = (
                "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
                "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
                "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
            )
            cred_vault_tools = (
                "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe",
                "rundll32", "mimikatz", "lazagne", "seatbelt", "sharphound",
                "bloodhound", "procdump", "wscript", "cscript", "mshta", "python",
            )
            has_recon_cli = any(
                any(
                    b in str(a.get("event", {}).get("process_name", "")).lower()
                    or b in str(a.get("event", {}).get("command_line", "")).lower()
                    or b in str(a.get("event", {}).get("description", "")).lower()
                    for b in recon_binaries
                )
                for a in discovery_alerts
            )
            has_cred_tool = any(
                any(
                    t in str(a.get("event", {}).get("process_name", "")).lower()
                    or t in str(a.get("event", {}).get("command_line", "")).lower()
                    or t in str(a.get("event", {}).get("description", "")).lower()
                    for t in cred_vault_tools
                )
                for a in cred_manager_alerts
            )
            has_malicious_ioc = any(
                bool(a.get("threat_intel", {}).get("is_malicious"))
                for a in security_alerts
            )

            if cred_manager_alerts and discovery_alerts:
                comb_cred_disc = cred_manager_alerts + discovery_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:recon_cred_theft{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                if (has_cred_tool and has_recon_cli) or (has_cred_tool and has_malicious_ioc):
                    chain_name = "Account Discovery & Credential Vault Harvesting Attack Chain"
                    chain_sev = "Critical"
                    chain_conf = 94
                elif has_cred_tool or has_malicious_ioc:
                    chain_name = "Account Discovery & Credential Vault Access Activity"
                    chain_sev = "High"
                    chain_conf = 88
                elif has_recon_cli:
                    chain_name = "Account Discovery & Credential Manager Read Activity"
                    chain_sev = "Medium"
                    chain_conf = 82
                else:
                    chain_name = "Account Discovery & Credential Manager Read Activity"
                    chain_sev = "Low"
                    chain_conf = 70
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": chain_name,
                    "severity": chain_sev,
                    "confidence": chain_conf,
                    "alert_count": len(comb_cred_disc),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": comb_cred_disc,
                    "mitre_techniques": ["T1555.004", "T1087.001"],
                    "mitre_tactic": "Credential Access",
                    "created_at": datetime.now().isoformat()
                })
                consumed_cd_ids = {id(a) for a in comb_cred_disc}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_cd_ids]
                if not security_alerts:
                    continue

            elif cred_manager_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:cred_vault{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                if has_cred_tool and has_malicious_ioc:
                    cred_name = "Windows Credential Manager Password Vault Harvesting"
                    cred_sev = "Critical"
                    cred_conf = 92
                elif has_cred_tool or has_malicious_ioc:
                    cred_name = "Windows Credential Manager Password Vault Access Activity"
                    cred_sev = "High"
                    cred_conf = 88
                else:
                    cred_name = "Windows Credential Manager Read Activity"
                    cred_sev = "Low"
                    cred_conf = 68
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": cred_name,
                    "severity": cred_sev,
                    "confidence": cred_conf,
                    "alert_count": len(cred_manager_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": cred_manager_alerts,
                    "mitre_techniques": ["T1555.004"],
                    "mitre_tactic": "Credential Access",
                    "created_at": datetime.now().isoformat()
                })
                consumed_cm_ids = {id(a) for a in cred_manager_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_cm_ids]
                if not security_alerts:
                    continue

            elif discovery_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:discovery{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                if has_malicious_ioc:
                    disc_severity = "High"
                    disc_conf = 90
                elif has_recon_cli:
                    disc_severity = "Medium"
                    disc_conf = 85
                else:
                    disc_severity = "Low"
                    disc_conf = 65
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Local Account Group Discovery Campaign ({user})",
                    "severity": disc_severity,
                    "confidence": disc_conf,
                    "alert_count": len(discovery_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": discovery_alerts,
                    "mitre_techniques": ["T1087.001"],
                    "mitre_tactic": "Discovery",
                    "created_at": datetime.now().isoformat()
                })
                consumed_disc_ids = {id(a) for a in discovery_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_disc_ids]
                if not security_alerts:
                    continue

            # 4. Ransomware Pre-Encryption Staging Activity
            vss_alerts = [
                a for a in security_alerts
                if "Shadow Copies" in str(a.get("alert_name", ""))
                or "Ransomware" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-IMPACT-VSS-01"
            ]
            ps_alerts = [a for a in security_alerts if "PowerShell" in str(a.get("alert_name", ""))]
            obfuscated_ps_alerts = [
                a for a in ps_alerts
                if "Obfuscated" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-EXEC-PS-01"
            ]

            if vss_alerts or obfuscated_ps_alerts:
                rw_alerts = list(vss_alerts)
                seen_rw_ids = {id(a) for a in rw_alerts}
                for extra in ps_alerts + list(security_alerts):
                    if id(extra) not in seen_rw_ids:
                        seen_rw_ids.add(id(extra))
                        rw_alerts.append(extra)
                inc_hash = hashlib.md5(f"{host}:{user}:ransomware{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Ransomware Pre-Encryption Staging Activity",
                    "severity": "Critical",
                    "confidence": 98,
                    "alert_count": len(rw_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": rw_alerts,
                    "mitre_techniques": ["T1486", "T1059.001"],
                    "mitre_tactic": "Impact",
                    "created_at": datetime.now().isoformat()
                })
                consumed_rw_ids = {id(a) for a in rw_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_rw_ids]
                if not security_alerts:
                    continue

            # 5. Backdoor Account Creation (4720)
            account_created = [
                a for a in security_alerts
                if "New Account Created" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-PERSIST-4720"
            ]
            if account_created:
                inc_hash = hashlib.md5(f"{host}:{user}:persistence{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Unauthorized Backdoor Account Creation & Persistence",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(account_created),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": account_created,
                    "mitre_techniques": ["T1136"],
                    "mitre_tactic": "Persistence",
                    "created_at": datetime.now().isoformat()
                })
                consumed_ac_ids = {id(a) for a in account_created}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_ac_ids]
                if not security_alerts:
                    continue

            # 6. Network Lateral Movement via Remote WMI (2000001)
            suricata_alerts = [
                a for a in security_alerts
                if "Suricata" in str(a.get("alert_name", ""))
                or "Lateral Movement" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-LATERAL-2000001"
            ]
            if suricata_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:lateral_movement{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Network Lateral Movement via Remote WMI Execution",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(suricata_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": suricata_alerts,
                    "mitre_techniques": ["T1021"],
                    "mitre_tactic": "Lateral Movement",
                    "created_at": datetime.now().isoformat()
                })
                consumed_suri_ids = {id(a) for a in suricata_alerts}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_suri_ids]
                if not security_alerts:
                    continue

            # 7. Audit Log Tampering (1102)
            log_cleared = [
                a for a in security_alerts
                if "Log Cleared" in str(a.get("alert_name", ""))
                or a.get("rule_id") == "RULE-EVASION-1102"
            ]
            if log_cleared:
                inc_hash = hashlib.md5(f"{host}:{user}:evasion{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Host Defense Evasion & Security Log Tampering",
                    "severity": "High",
                    "confidence": 95,
                    "alert_count": len(log_cleared),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": log_cleared,
                    "mitre_techniques": ["T1070"],
                    "mitre_tactic": "Defense Evasion",
                    "created_at": datetime.now().isoformat()
                })
                consumed_lc_ids = {id(a) for a in log_cleared}
                security_alerts = [a for a in security_alerts if id(a) not in consumed_lc_ids]
                if not security_alerts:
                    continue

            # 8. Remaining alerts fallback
            if security_alerts:
                remaining_failed = [
                    a for a in security_alerts
                    if "Failed Logon" in str(a.get("alert_name", ""))
                    or a.get("rule_id") == "RULE-AUTH-4625"
                ]
                other_remaining = [a for a in security_alerts if a not in remaining_failed]
                if remaining_failed:
                    inc_hash = hashlib.md5(f"{host}:{user}:auth_failure{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                    incidents.append({
                        "incident_id": f"INC-{inc_hash}",
                        "incident_name": f"Isolated Authentication Failure ({user})",
                        "severity": "Low",
                        "confidence": 50,
                        "alert_count": len(remaining_failed),
                        "affected_host": host,
                        "affected_user": user,
                        "alerts": remaining_failed,
                        "mitre_techniques": ["T1110"],
                        "mitre_tactic": "Credential Access",
                        "created_at": datetime.now().isoformat()
                    })
                if other_remaining:
                    inc_hash = hashlib.md5(f"{host}:{user}:{other_remaining[0].get('alert_name', 'suspicious')}{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                    fallback_tech = other_remaining[0].get("mitre_technique")
                    incidents.append({
                        "incident_id": f"INC-{inc_hash}",
                        "incident_name": f"Suspicious Activity on {host}",
                        "severity": other_remaining[0].get("severity", "Medium"),
                        "confidence": other_remaining[0].get("confidence", 80),
                        "alert_count": len(other_remaining),
                        "affected_host": host,
                        "affected_user": user,
                        "alerts": other_remaining,
                        "mitre_techniques": [fallback_tech] if fallback_tech and fallback_tech not in ("N/A", "NA", "None") else [],
                        "created_at": datetime.now().isoformat()
                    })

        for inc in incidents:
            inc.setdefault("is_diagnostic", False)
            cur_alerts = inc.get("alerts", [])
            inc["alert_count"] = len(cur_alerts)
            inc["window_alert_count"] = len(cur_alerts)
            inc["cumulative_alert_count"] = len(cur_alerts)
            inc["cumulative_scope"] = "Current Window"
            primary_h = str(inc.get("affected_host") or "UNKNOWN_HOST").strip() or "UNKNOWN_HOST"
            inc["affected_host"] = primary_h
            inc["affected_hosts"] = [primary_h]
            src_ips = []
            telemetry_sources = []
            valid_timestamps = []
            mitre_techniques = [t for t in (inc.get("mitre_techniques") or []) if t and t not in ("N/A", "NA", "None")]
            for alt in cur_alerts:
                ev = alt.get("event", {})
                ts_norm = format_alert_timestamp(ev.get("timestamp"))
                if ts_norm:
                    valid_timestamps.append(ts_norm)
                sip = str(ev.get("source_ip") or "N/A").strip()
                if sip and sip not in ("N/A", "-", "127.0.0.1", "::1") and sip not in src_ips:
                    src_ips.append(sip)
                ev_src = str(ev.get("source") or "unknown").strip()
                if ev_src and ev_src not in telemetry_sources:
                    telemetry_sources.append(ev_src)
                tech = str(alt.get("mitre_technique") or ev.get("mitre_technique") or "N/A").strip()
                if tech and tech not in ("N/A", "NA", "None") and tech not in mitre_techniques:
                    mitre_techniques.append(tech)
            if valid_timestamps:
                valid_timestamps.sort()
                inc["first_event_timestamp"] = valid_timestamps[0]
                inc["last_event_timestamp"] = valid_timestamps[-1]
            else:
                inc["first_event_timestamp"] = ""
                inc["last_event_timestamp"] = ""
            inc["observed_source_ips"] = src_ips if src_ips else ["N/A"]
            inc["telemetry_sources"] = telemetry_sources if telemetry_sources else ["unknown"]
            inc["mitre_techniques"] = mitre_techniques
            inc["primary_source"] = (
                "real_nxlog_windows"
                if "real_nxlog_windows" in inc["telemetry_sources"]
                else inc["telemetry_sources"][0]
            )
            inc["is_real_telemetry"] = any(
                s in ("real_nxlog_windows", "local_windows") for s in inc["telemetry_sources"]
            )
            inc["is_simulated"] = (not inc["is_real_telemetry"]) and any(
                "sim" in s.lower() or "synthetic" in s.lower() for s in inc["telemetry_sources"]
            )

        print(f"[INFO] Correlation Agent synthesized {len(incidents)} correlated Incident(s).")
        return incidents

    def apply_cumulative_tracking(
        self,
        incidents: List[Dict[str, Any]],
        registry: Optional[Dict[str, Dict[str, Any]]] = None,
        db: Optional[Any] = None,
        max_evidence_alerts: int = 100,
        retain_historical_incidents: bool = True,
    ) -> List[Dict[str, Any]]:
        return apply_cumulative_incident_tracking(
            incidents=incidents,
            registry=registry,
            db=db,
            max_evidence_alerts=max_evidence_alerts,
            retain_historical_incidents=retain_historical_incidents,
        )


def format_alert_timestamp(ts_val: Any) -> str:
    """
    Normalizes an event timestamp into 'YYYY-MM-DD HH:MM:SS' format for display and
    chronological min/max comparison. Returns '' if missing or non-timestamp placeholder.
    """
    if ts_val is None:
        return ""
    s = str(ts_val).strip()
    if not s or s.upper() in ("N/A", "NA", "NONE", "UNKNOWN", "-"):
        return ""
    s = s.replace("T", " ")
    if len(s) >= 19 and s[4:5] == "-" and s[7:8] == "-":
        return s[:19]
    return s


def format_incident_alert_summary(inc: Dict[str, Any]) -> Dict[str, Any]:
    """
    Builds standardized, neutral display labels for Sector 1 incident cards and Sector 5 reports:
    - Keeps Window Alerts and Cumulative Alerts explicitly separate.
    - Includes historical persistence scope and earliest/latest observed event timestamps.
    - Explains that the evidence table is capped at `evidence_alert_cap` recent records while
      the cumulative ledger tracks the full number of unique alert identities.
    - Uses neutral detection terminology without claiming confirmed attacks.
    """
    alerts_list = inc.get("alerts", [])
    fallback_cnt = int(inc.get("alert_count", len(alerts_list)))
    win_alerts = int(inc.get("window_alert_count", fallback_cnt))
    cum_alerts = int(inc.get("cumulative_alert_count", fallback_cnt))
    cum_scope = str(inc.get("cumulative_scope", "Current Window"))
    evidence_cap = int(inc.get("evidence_alert_cap", 100))
    evidence_shown = len(alerts_list)

    first_ts = format_alert_timestamp(inc.get("first_event_timestamp"))
    last_ts = format_alert_timestamp(inc.get("last_event_timestamp"))
    if (not first_ts or not last_ts) and alerts_list:
        ts_candidates = sorted(
            t for t in (format_alert_timestamp(a.get("event", {}).get("timestamp")) for a in alerts_list) if t
        )
        if ts_candidates:
            if not first_ts:
                first_ts = ts_candidates[0]
            if not last_ts:
                last_ts = ts_candidates[-1]

    if first_ts and last_ts:
        ts_range = f"{first_ts} → {last_ts}" if first_ts != last_ts else first_ts
    else:
        ts_range = first_ts or last_ts or "Active Window"

    win_fmt = f"{win_alerts:,}"
    cum_fmt = f"{cum_alerts:,}"
    ts_clause = f" ({ts_range})" if ts_range and ts_range != "Active Window" else ""

    scope_explanation = (
        f"📊 **Alert Count & Evidence Scope**: **{win_fmt}** matching detection alert(s) belong to the current "
        f"processing window, while **{cum_fmt}** unique matching alert(s) were observed across the retained "
        f"historical log range{ts_clause} [`{cum_scope}`]. The evidence table is capped at **{evidence_cap}** "
        f"recent records (**{evidence_shown}** shown), while the cumulative ledger tracks the full number of "
        f"unique alert identities."
    )

    return {
        "window_alert_count": win_alerts,
        "window_alert_formatted": win_fmt,
        "cumulative_alert_count": cum_alerts,
        "cumulative_alert_formatted": cum_fmt,
        "cumulative_scope": cum_scope,
        "first_event_timestamp": first_ts,
        "last_event_timestamp": last_ts,
        "historical_log_range": ts_range,
        "evidence_alert_cap": evidence_cap,
        "evidence_shown_count": evidence_shown,
        "scope_explanation": scope_explanation,
    }


_HIST_RECOMPUTE_CACHE: Dict[Tuple[str, int, str, str], Dict[str, Any]] = {}
_DB_LEDGER_CACHE: Dict[str, Any] = {
    "db_path": None,
    "mtime_ns": None,
    "size": None,
    "alert_keys": None,
    "snapshots": None,
}


def apply_cumulative_incident_tracking(
    incidents: List[Dict[str, Any]],
    registry: Optional[Dict[str, Dict[str, Any]]] = None,
    db: Optional[Any] = None,
    max_evidence_alerts: int = 100,
    retain_historical_incidents: bool = True,
) -> List[Dict[str, Any]]:
    """
    Reconciles current-window correlated incidents against a session registry and/or
    durable SQLite ledger (KnowledgeBaseDB):
    - Sets `window_alert_count` to the unique detection alert count in the active window.
    - Sets `cumulative_alert_count` to the total unique detection alert identities ever
      observed for that incident (monotonically non-decreasing across rolling windows).
    - Tracks earliest (`first_event_timestamp`) and latest (`last_event_timestamp`)
      observed event timestamps across historical windows.
    - Caps `inc["alerts"]` at `max_evidence_alerts` (bounded recent-evidence list) while
      preserving `cumulative_alert_count` independently of that cap.
    - Explicitly sets `cumulative_scope` to reflect persistence guarantees.
    """
    global _HIST_RECOMPUTE_CACHE
    if len(_HIST_RECOMPUTE_CACHE) > 200:
        _HIST_RECOMPUTE_CACHE.clear()

    if db is not None and registry is not None:
        scope_label = "Persistent (SQLite + Session)"
    elif db is not None:
        scope_label = "Persistent (SQLite)"
    elif registry is not None:
        scope_label = "Session-Cumulative"
    else:
        scope_label = "Current Window"

    if registry is None:
        registry = {}

    # Hydrate registry from durable SQLite ledger & snapshots if db is provided
    db_alert_keys: Dict[str, List[str]] = {}
    db_snapshots: Dict[str, Dict[str, Any]] = {}
    if db is not None:
        try:
            import os
            from pathlib import Path
            from config.settings import DB_PATH
            db_path_str = str(getattr(db, "db_path", ""))
            is_prod_db = bool(db_path_str and Path(db_path_str).resolve() == Path(DB_PATH).resolve() and os.path.exists(db_path_str))
            if is_prod_db:
                st_stat = os.stat(db_path_str)
                if (
                    _DB_LEDGER_CACHE.get("db_path") == db_path_str
                    and _DB_LEDGER_CACHE.get("mtime_ns") == st_stat.st_mtime_ns
                    and _DB_LEDGER_CACHE.get("size") == st_stat.st_size
                    and _DB_LEDGER_CACHE.get("alert_keys") is not None
                    and _DB_LEDGER_CACHE.get("snapshots") is not None
                ):
                    db_alert_keys = _DB_LEDGER_CACHE["alert_keys"]
                    db_snapshots = _DB_LEDGER_CACHE["snapshots"]
                else:
                    db_alert_keys = db.get_incident_alert_keys()
                    db_snapshots = db.get_incident_snapshots()
                    _DB_LEDGER_CACHE["db_path"] = db_path_str
                    _DB_LEDGER_CACHE["mtime_ns"] = st_stat.st_mtime_ns
                    _DB_LEDGER_CACHE["size"] = st_stat.st_size
                    _DB_LEDGER_CACHE["alert_keys"] = db_alert_keys
                    _DB_LEDGER_CACHE["snapshots"] = db_snapshots
            else:
                db_alert_keys = db.get_incident_alert_keys()
                db_snapshots = db.get_incident_snapshots()
            for db_inc_id, key_list in db_alert_keys.items():
                entry = registry.setdefault(
                    db_inc_id,
                    {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
                )
                if not isinstance(entry.get("seen_alert_keys"), set):
                    entry["seen_alert_keys"] = set(entry.get("seen_alert_keys") or [])
                entry["seen_alert_keys"].update(key_list)
                snap = db_snapshots.get(db_inc_id)
                if snap:
                    snap_meta = snap.get("metadata") or {}
                    if snap_meta:
                        cur_meta = entry.get("metadata") or {}
                        merged_meta = dict(snap_meta)
                        merged_meta.update(cur_meta)
                        f_candidates = [
                            t for t in (
                                format_alert_timestamp(snap_meta.get("first_event_timestamp")),
                                format_alert_timestamp(cur_meta.get("first_event_timestamp")),
                            ) if t
                        ]
                        l_candidates = [
                            t for t in (
                                format_alert_timestamp(snap_meta.get("last_event_timestamp")),
                                format_alert_timestamp(cur_meta.get("last_event_timestamp")),
                            ) if t
                        ]
                        if f_candidates:
                            merged_meta["first_event_timestamp"] = min(f_candidates)
                        if l_candidates:
                            merged_meta["last_event_timestamp"] = max(l_candidates)
                        entry["metadata"] = merged_meta
                    if not entry.get("recent_alerts") and snap.get("recent_alerts"):
                        entry["recent_alerts"] = list(snap["recent_alerts"])[-max_evidence_alerts:]
        except Exception:
            pass

    tracked_incidents: List[Dict[str, Any]] = []
    active_ids: Set[str] = set()

    # Determine provenance filter for retained historical incidents so real and simulated streams never mix
    provenance_flags = {bool(inc.get("is_real_telemetry", False)) for inc in incidents if inc.get("incident_id")}
    enforce_real_flag: Optional[bool] = next(iter(provenance_flags)) if len(provenance_flags) == 1 else None

    for inc in incidents:
        inc_copy = dict(inc)
        inc_id = str(inc_copy.get("incident_id") or "")
        if not inc_id:
            tracked_incidents.append(inc_copy)
            continue
        active_ids.add(inc_id)

        raw_window_alerts = inc_copy.get("alerts", [])
        window_seen: Set[str] = set()
        unique_window_alerts: List[Dict[str, Any]] = []
        for alt in raw_window_alerts:
            a_hash = get_alert_identity_hash(alt)
            if a_hash not in window_seen:
                window_seen.add(a_hash)
                unique_window_alerts.append(alt)

        window_count = len(unique_window_alerts)

        # Guard against false-positive Brute Force classification on active incidents
        has_auth_fail = any(
            "Failed Logon" in str(a.get("alert_name", "")) or a.get("rule_id") == "RULE-AUTH-4625"
            for a in inc_copy.get("alerts", [])
        )
        is_claiming_bf = (
            "Brute Force" in str(inc_copy.get("incident_name", ""))
            or "Password Spraying" in str(inc_copy.get("incident_name", ""))
            or "T1110" in inc_copy.get("mitre_techniques", [])
        )
        if is_claiming_bf and not has_auth_fail:
            has_5379 = any("Credential Manager" in str(a.get("alert_name", "")) or a.get("rule_id") == "RULE-CRED-5379" for a in inc_copy.get("alerts", []))
            has_4798 = any("Discovery" in str(a.get("alert_name", "")) or a.get("rule_id") in ("RULE-DISC-4798", "RULE-DISC-4799") for a in inc_copy.get("alerts", []))
            if has_5379 and has_4798:
                inc_copy["incident_name"] = "Account Discovery & Credential Manager Read Activity"
                inc_copy["severity"] = "Low"
                inc_copy["confidence"] = 70
                inc_copy["mitre_techniques"] = ["T1555.004", "T1087.001"]
                inc_copy["mitre_tactic"] = "Credential Access"
            elif has_5379:
                inc_copy["incident_name"] = "Windows Credential Manager Read Activity"
                inc_copy["severity"] = "Low"
                inc_copy["confidence"] = 68
                inc_copy["mitre_techniques"] = ["T1555.004"]
                inc_copy["mitre_tactic"] = "Credential Access"
            elif has_4798:
                u = inc_copy.get("affected_user", "SYSTEM")
                inc_copy["incident_name"] = f"Local Account Group Discovery Campaign ({u})"
                inc_copy["severity"] = "Low"
                inc_copy["confidence"] = 65
                inc_copy["mitre_techniques"] = ["T1087.001"]
                inc_copy["mitre_tactic"] = "Discovery"
            else:
                inc_copy["severity"] = "Low"
                inc_copy["mitre_techniques"] = [t for t in inc_copy.get("mitre_techniques", []) if not t.startswith("T1110")]

        entry = registry.setdefault(
            inc_id,
            {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
        )
        if not isinstance(entry.get("seen_alert_keys"), set):
            entry["seen_alert_keys"] = set(entry.get("seen_alert_keys") or [])

        entry["seen_alert_keys"].update(window_seen)

        # Compute cumulative earliest/latest event timestamps across prior metadata, recent_alerts, and window alerts
        prev_meta = entry.get("metadata") or {}
        ts_pool: List[str] = []
        for candidate_ts in (
            prev_meta.get("first_event_timestamp"),
            prev_meta.get("last_event_timestamp"),
            inc_copy.get("first_event_timestamp"),
            inc_copy.get("last_event_timestamp"),
        ):
            norm_t = format_alert_timestamp(candidate_ts)
            if norm_t:
                ts_pool.append(norm_t)
        for existing_alt in entry.get("recent_alerts", []):
            norm_t = format_alert_timestamp(existing_alt.get("event", {}).get("timestamp"))
            if norm_t:
                ts_pool.append(norm_t)
        for new_alt in unique_window_alerts:
            norm_t = format_alert_timestamp(new_alt.get("event", {}).get("timestamp"))
            if norm_t:
                ts_pool.append(norm_t)

        earliest_ts = min(ts_pool) if ts_pool else ""
        latest_ts = max(ts_pool) if ts_pool else ""
        inc_copy["first_event_timestamp"] = earliest_ts
        inc_copy["last_event_timestamp"] = latest_ts

        # Merge bounded recent_alerts preserving chronological order without duplicates
        merged_by_hash: Dict[str, Dict[str, Any]] = {}
        for existing_alt in entry.get("recent_alerts", []):
            if is_claiming_bf and has_auth_fail and existing_alt.get("rule_id") in ("RULE-CRED-5379", "RULE-DISC-4798", "RULE-DISC-4799"):
                continue
            eh = get_alert_identity_hash(existing_alt)
            if eh not in merged_by_hash:
                merged_by_hash[eh] = existing_alt
        candidate_recent_new = (
            unique_window_alerts[-max_evidence_alerts:]
            if (max_evidence_alerts > 0 and len(unique_window_alerts) > max_evidence_alerts)
            else unique_window_alerts
        )
        for new_alt in candidate_recent_new:
            nh = get_alert_identity_hash(new_alt)
            merged_by_hash[nh] = new_alt

        merged_alerts = list(merged_by_hash.values())
        if max_evidence_alerts > 0 and len(merged_alerts) > max_evidence_alerts:
            merged_alerts = merged_alerts[-max_evidence_alerts:]
        # Normalize cached RULE-CRED-5379 alert severity/name in-memory so historical recent_alerts
        # match current evidence-based detection rules without mutating SQLite ledger hashes.
        cred_vault_tools = (
            "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe", "rundll32",
            "mimikatz", "lazagne", "seatbelt", "sharphound", "bloodhound",
            "procdump", "wscript", "cscript", "mshta", "python"
        )
        recon_binaries = (
            "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
            "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
            "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
        )
        normalized_merged: List[Dict[str, Any]] = []
        for alt in merged_alerts:
            alt_copy = dict(alt)
            ev = dict(alt_copy.get("event") or {})
            proc_l = str(ev.get("process_name") or "").lower()
            cmd_l = str(ev.get("command_line") or "").lower()
            if alt_copy.get("rule_id") == "RULE-CRED-5379":
                has_tool = any(t in proc_l or t in cmd_l for t in cred_vault_tools)
                if not has_tool:
                    alt_copy["alert_name"] = "Windows Credential Manager Read Activity"
                    alt_copy["severity"] = "Low"
                    alt_copy["confidence"] = 68
                    ev["severity"] = "Low"
                    alt_copy["event"] = ev
            elif alt_copy.get("rule_id") == "RULE-DISC-4798":
                has_recon = any(b in proc_l or b in cmd_l for b in recon_binaries)
                if not has_recon:
                    alt_copy["severity"] = "Low"
                    alt_copy["confidence"] = 65
                    ev["severity"] = "Low"
                    alt_copy["event"] = ev
            normalized_merged.append(alt_copy)
        merged_alerts = normalized_merged
        entry["recent_alerts"] = merged_alerts

        meta_snapshot = {
            k: v
            for k, v in inc_copy.items()
            if k not in ("alerts", "alert_count", "window_alert_count", "cumulative_alert_count")
        }
        meta_snapshot["first_event_timestamp"] = earliest_ts
        meta_snapshot["last_event_timestamp"] = latest_ts
        entry["metadata"] = meta_snapshot

        if db is not None:
            try:
                existing_db_set = set(db_alert_keys.get(inc_id, []))
                new_db_keys = entry["seen_alert_keys"] - existing_db_set
                prev_db_meta = (db_snapshots.get(inc_id) or {}).get("metadata") or {}
                meta_changed = any(
                    meta_snapshot.get(f) != prev_db_meta.get(f)
                    for f in ("incident_name", "severity", "confidence", "first_event_timestamp", "last_event_timestamp")
                )
                if new_db_keys or inc_id not in db_snapshots or meta_changed:
                    db_total = db.record_incident_alerts(
                        incident_id=inc_id,
                        alert_keys=list(new_db_keys) if existing_db_set else list(entry["seen_alert_keys"]),
                        metadata=meta_snapshot,
                        recent_alerts=merged_alerts,
                    )
                    db_alert_keys[inc_id] = list(entry["seen_alert_keys"])
                    db_snapshots[inc_id] = {"metadata": dict(meta_snapshot), "recent_alerts": list(merged_alerts)}
                    cumulative_count = max(len(entry["seen_alert_keys"]), db_total)
                else:
                    cumulative_count = max(len(entry["seen_alert_keys"]), len(existing_db_set))
            except Exception:
                cumulative_count = len(entry["seen_alert_keys"])
        else:
            cumulative_count = len(entry["seen_alert_keys"])

        inc_copy["window_alert_count"] = window_count
        inc_copy["cumulative_alert_count"] = cumulative_count
        inc_copy["cumulative_scope"] = scope_label
        inc_copy["evidence_alert_cap"] = max_evidence_alerts
        inc_copy["alerts"] = list(merged_alerts)
        inc_copy["alert_count"] = len(inc_copy["alerts"])
        tracked_incidents.append(inc_copy)

    if retain_historical_incidents:
        cred_vault_tools = (
            "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe", "rundll32",
            "mimikatz", "lazagne", "seatbelt", "sharphound", "bloodhound",
            "procdump", "wscript", "cscript", "mshta", "python"
        )
        recon_binaries = (
            "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
            "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
            "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
        )
        re_correlator: Optional[CorrelationAgent] = None
        for hist_id, entry in list(registry.items()):
            if hist_id in active_ids:
                continue
            seen_keys = entry.get("seen_alert_keys") or set()
            meta = entry.get("metadata") or {}
            if not seen_keys or not meta:
                continue
            if enforce_real_flag is not None and bool(meta.get("is_real_telemetry", False)) != enforce_real_flag:
                continue
            hist_inc = dict(meta)
            raw_bounded = list(entry.get("recent_alerts", []))
            if max_evidence_alerts > 0 and len(raw_bounded) > max_evidence_alerts:
                raw_bounded = raw_bounded[-max_evidence_alerts:]
            bounded_recent: List[Dict[str, Any]] = []
            for alt in raw_bounded:
                alt_copy = dict(alt)
                ev = dict(alt_copy.get("event") or {})
                proc_l = str(ev.get("process_name") or "").lower()
                cmd_l = str(ev.get("command_line") or "").lower()
                if alt_copy.get("rule_id") == "RULE-CRED-5379":
                    has_tool = any(t in proc_l or t in cmd_l for t in cred_vault_tools)
                    if not has_tool:
                        alt_copy["alert_name"] = "Windows Credential Manager Read Activity"
                        alt_copy["severity"] = "Low"
                        alt_copy["confidence"] = 68
                        ev["severity"] = "Low"
                        alt_copy["event"] = ev
                elif alt_copy.get("rule_id") == "RULE-DISC-4798":
                    has_recon = any(b in proc_l or b in cmd_l for b in recon_binaries)
                    if not has_recon:
                        alt_copy["severity"] = "Low"
                        alt_copy["confidence"] = 65
                        ev["severity"] = "Low"
                        alt_copy["event"] = ev
                bounded_recent.append(alt_copy)

            if bounded_recent and not hist_inc.get("is_diagnostic"):
                cache_key = (
                    str(hist_id),
                    len(bounded_recent),
                    str(bounded_recent[0].get("alert_id", "")),
                    str(bounded_recent[-1].get("alert_id", "")),
                )
                has_failed_login = any(
                    "Failed Logon" in str(a.get("alert_name", "")) or a.get("rule_id") == "RULE-AUTH-4625"
                    for a in bounded_recent
                )
                is_claiming_bf = (
                    "Brute Force" in str(hist_inc.get("incident_name", ""))
                    or "Password Spraying" in str(hist_inc.get("incident_name", ""))
                    or "T1110" in hist_inc.get("mitre_techniques", [])
                )
                # Bound the module-level recompute cache to prevent unbounded growth
                # in long-running Streamlit sessions (TRACK-01 — Phase 2 fix).
                if len(_HIST_RECOMPUTE_CACHE) > 200:
                    _HIST_RECOMPUTE_CACHE.clear()
                cached_recomp = _HIST_RECOMPUTE_CACHE.get(cache_key)
                if cached_recomp and not has_failed_login and is_claiming_bf:
                    cached_recomp = None

                if cached_recomp is None:
                    try:
                        if re_correlator is None:
                            re_correlator = CorrelationAgent()
                        recomputed_list = re_correlator.correlate(bounded_recent)
                        target_recomp = None
                        for recomp in recomputed_list:
                            if str(recomp.get("incident_id")) == str(hist_id):
                                target_recomp = recomp
                                break
                        if target_recomp is None and not has_failed_login and is_claiming_bf:
                            if recomputed_list:
                                target_recomp = recomputed_list[0]
                            else:
                                target_recomp = {
                                    "incident_name": "Windows Credential Manager Read Activity",
                                    "severity": "Low",
                                    "confidence": 68,
                                    "mitre_techniques": ["T1555.004"],
                                    "mitre_tactic": "Credential Access",
                                }
                        elif target_recomp is None and len(recomputed_list) == 1:
                            target_recomp = recomputed_list[0]

                        if target_recomp:
                            cached_recomp = {
                                "incident_name": target_recomp.get("incident_name"),
                                "severity": target_recomp.get("severity"),
                                "confidence": target_recomp.get("confidence"),
                                "mitre_techniques": target_recomp.get("mitre_techniques"),
                                "mitre_tactic": target_recomp.get("mitre_tactic"),
                            }
                            _HIST_RECOMPUTE_CACHE[cache_key] = cached_recomp
                    except Exception:
                        cached_recomp = None
                if cached_recomp:
                    for k_field, v_val in cached_recomp.items():
                        if v_val is not None:
                            hist_inc[k_field] = v_val

            hist_ts_pool = [
                t
                for t in (
                    [
                        format_alert_timestamp(hist_inc.get("first_event_timestamp")),
                        format_alert_timestamp(hist_inc.get("last_event_timestamp")),
                    ]
                    + [format_alert_timestamp(a.get("event", {}).get("timestamp")) for a in bounded_recent]
                )
                if t
            ]
            hist_inc["first_event_timestamp"] = min(hist_ts_pool) if hist_ts_pool else ""
            hist_inc["last_event_timestamp"] = max(hist_ts_pool) if hist_ts_pool else ""
            entry["metadata"] = dict(hist_inc)
            entry["recent_alerts"] = bounded_recent
            if db is not None:
                try:
                    prev_db_meta = (db_snapshots.get(hist_id) or {}).get("metadata") or {}
                    hist_meta_changed = any(
                        hist_inc.get(f) != prev_db_meta.get(f)
                        for f in ("incident_name", "severity", "confidence", "first_event_timestamp", "last_event_timestamp")
                    )
                    if hist_meta_changed:
                        db.record_incident_alerts(
                            incident_id=hist_id,
                            alert_keys=[],
                            metadata=dict(hist_inc),
                            recent_alerts=bounded_recent,
                        )
                        db_snapshots[hist_id] = {"metadata": dict(hist_inc), "recent_alerts": list(bounded_recent)}
                except Exception:
                    pass
            hist_inc["window_alert_count"] = 0
            hist_inc["cumulative_alert_count"] = len(seen_keys)
            hist_inc["cumulative_scope"] = scope_label
            hist_inc["evidence_alert_cap"] = max_evidence_alerts
            hist_inc["alerts"] = bounded_recent
            hist_inc["alert_count"] = len(bounded_recent)
            tracked_incidents.append(hist_inc)

    return tracked_incidents