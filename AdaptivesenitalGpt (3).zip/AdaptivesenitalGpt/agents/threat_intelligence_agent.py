import ipaddress
import json
from typing import Any, Dict, List, Optional, Set

from config.settings import ENDPOINT_STATUS_FILE_PATH, NETWORK_STATE_FILE_PATH, get_receiver_ip
from knowledge_base.database import KnowledgeBaseDB


class ThreatIntelligenceAgent:
    """
    Threat Intelligence Agent enriching incidents with Threat Feeds,
    IP Reputation scores, and SQLite Knowledge Base IOC matching.

    Distinguishes:
      1. Confirmed malicious / known IOCs from SQLite Threat Intel KB (sentinel_kb.db)
      2. Missing / local-only event IPs ('N/A', '-', '') -> Local Endpoint Telemetry
      3. Loopback addresses (127.0.0.0/8, ::1) -> Local Machine Loopback
      4. RFC 1918 Private / Link-Local / CGNAT internal addresses -> Internal / Private Network
      5. Verified NXLog telemetry sender / local subnet peers -> Authorized Telemetry Sender / Local Network Peer
      6. Unmatched public/external IP addresses -> External IP (Unknown Reputation)
    Never labels an IP malicious solely because it is the sender address or unmatched.
    """

    def __init__(self, db: Optional[KnowledgeBaseDB] = None):
        self.db = db or KnowledgeBaseDB()

    def _load_known_network_context(self) -> tuple[Set[str], str]:
        """Loads known telemetry sender/peer IPs and active receiver IP from persisted network state."""
        known_peers: Set[str] = set()
        receiver_ip = "127.0.0.1"
        try:
            receiver_ip = str(get_receiver_ip() or "127.0.0.1").strip()
        except Exception:
            pass

        try:
            if NETWORK_STATE_FILE_PATH.exists():
                state = json.loads(NETWORK_STATE_FILE_PATH.read_text(encoding="utf-8"))
                for key in (
                    "sender_ip_current",
                    "remote_peer_ip",
                    "raw_remote_peer_ip",
                    "raw_sender_ip",
                    "last_known_sender_ip",
                    "receiver_ip_current",
                    "last_known_receiver_ip",
                ):
                    val = str(state.get(key) or "").strip()
                    if val and val.upper() not in ("N/A", "NONE", "UNKNOWN", "-", "0.0.0.0", "127.0.0.1"):
                        known_peers.add(val)
                for peer in state.get("active_tcp_peers", []) or []:
                    p_str = str(peer or "").strip()
                    if p_str and p_str.upper() not in ("N/A", "NONE", "UNKNOWN", "-", "0.0.0.0", "127.0.0.1"):
                        known_peers.add(p_str)
                if receiver_ip in ("127.0.0.1", "0.0.0.0", "") and state.get("receiver_ip_current"):
                    receiver_ip = str(state["receiver_ip_current"]).strip()
        except Exception:
            pass

        try:
            if ENDPOINT_STATUS_FILE_PATH.exists():
                ep_data = json.loads(ENDPOINT_STATUS_FILE_PATH.read_text(encoding="utf-8"))
                if isinstance(ep_data, dict):
                    for ep_info in ep_data.values():
                        if isinstance(ep_info, dict):
                            sip = str(ep_info.get("source_ip") or "").strip()
                            if sip and sip.upper() not in ("N/A", "NONE", "UNKNOWN", "-", "0.0.0.0", "127.0.0.1"):
                                known_peers.add(sip)
        except Exception:
            pass

        return known_peers, receiver_ip

    @staticmethod
    def _is_same_local_subnet(ip_str: str, receiver_ip: str) -> bool:
        """
        Checks whether ip_str is on the same /16 campus/hotspot IPv4 network as receiver_ip
        (e.g., receiver 11.12.7.72 and sender 11.12.4.164 on college Wi-Fi).
        """
        try:
            ip_obj = ipaddress.ip_address(ip_str)
            rec_obj = ipaddress.ip_address(receiver_ip)
            if ip_obj.version == 4 and rec_obj.version == 4 and not rec_obj.is_loopback:
                ip_parts = ip_str.split(".")
                rec_parts = receiver_ip.split(".")
                return ip_parts[0] == rec_parts[0] and ip_parts[1] == rec_parts[1]
        except Exception:
            pass
        return False

    def classify_ip(
        self,
        ip: Any,
        known_peer_ips: Optional[Set[str]] = None,
        receiver_ip: Optional[str] = None,
        is_sender_peer: bool = False,
    ) -> Dict[str, Any]:
        """
        Classifies an IP address using SQLite IOC intelligence and standard IP address properties.
        Never assigns 'External Suspicious IP' or malicious status without actual IOC evidence.
        """
        raw_ip = str(ip if ip is not None else "").strip()

        # 1. Missing / Local-only event IP (e.g. local Windows Security Event 4798 / 5379 with source_ip='N/A')
        if not raw_ip or raw_ip.upper() in ("N/A", "NA", "NONE", "NULL", "UNKNOWN", "-", "0.0.0.0"):
            return {
                "ip": "N/A",
                "status": "Local Endpoint Telemetry (No External IP)",
                "reputation": "Local / Internal",
                "risk_score": 10,
                "category": "Local Host Activity",
                "is_malicious": False,
            }

        # 2. Authoritative SQLite Threat Intelligence IOC lookup
        kb_record = self.db.lookup_ioc(raw_ip)
        if kb_record:
            risk_score = int(kb_record.get("risk_score", 0))
            status_str = str(kb_record.get("status", "Known IOC"))
            rep_str = str(kb_record.get("reputation", "Unknown"))
            is_mal = bool(
                risk_score >= 70
                or "untrusted" in rep_str.lower()
                or "malicious" in status_str.lower()
                or "scanner" in status_str.lower()
                or "exploit" in status_str.lower()
            )
            return {
                "ip": raw_ip,
                "status": status_str,
                "reputation": rep_str,
                "risk_score": risk_score,
                "category": kb_record.get("threat_category", "IOC Match"),
                "is_malicious": is_mal,
            }

        # 3. Parse IP address for standard RFC classification
        try:
            addr = ipaddress.ip_address(raw_ip)
        except ValueError:
            return {
                "ip": raw_ip,
                "status": "Unresolved / Non-IP Identifier",
                "reputation": "Unknown (No Threat Intel Match)",
                "risk_score": 20,
                "category": "Unverified Identifier",
                "is_malicious": False,
            }

        # 4. Loopback (127.0.0.0/8, ::1)
        if addr.is_loopback:
            return {
                "ip": raw_ip,
                "status": "Local Machine Loopback",
                "reputation": "Trusted",
                "risk_score": 0,
                "category": "Loopback",
                "is_malicious": False,
            }

        # 5. RFC 1918 Private (10/8, 172.16/12, 192.168/16), Link-Local (169.254/16), or CGNAT (100.64/10)
        is_cgnat = addr.version == 4 and addr in ipaddress.ip_network("100.64.0.0/10")
        if addr.is_private or addr.is_link_local or is_cgnat:
            return {
                "ip": raw_ip,
                "status": "Internal / Private Network",
                "reputation": "Trusted Internal LAN",
                "risk_score": 10,
                "category": "LAN Traffic",
                "is_malicious": False,
            }

        # 6. Verified NXLog Telemetry Sender / Campus or Hotspot Peer (e.g., 11.12.4.164 -> 11.12.7.72)
        peers = known_peer_ips if known_peer_ips is not None else set()
        active_rec = receiver_ip or "127.0.0.1"
        if is_sender_peer or raw_ip in peers or self._is_same_local_subnet(raw_ip, active_rec):
            return {
                "ip": raw_ip,
                "status": "Authorized Telemetry Sender / Local Network Peer",
                "reputation": "Verified Local Peer (No Threat IOC Match)",
                "risk_score": 15,
                "category": "NXLog Telemetry Peer",
                "is_malicious": False,
            }

        # 7. Public / External IP with no match in Threat Intelligence KB -> Unknown Reputation
        return {
            "ip": raw_ip,
            "status": "External IP (Unknown Reputation)",
            "reputation": "Unknown (No Threat Intel Match)",
            "risk_score": 35,
            "category": "Unverified External IP",
            "is_malicious": False,
        }

    def analyze(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        known_peers, receiver_ip = self._load_known_network_context()
        ip_cache: Dict[tuple, Dict[str, Any]] = {}

        for incident in incidents:
            has_confirmed_malicious_ioc = False
            for alert in incident.get("alerts", []):
                event = alert.get("event", {})
                raw_source_ip = event.get("source_ip")
                remote_peer = str(event.get("remote_peer_ip") or "").strip()

                is_peer = False
                if remote_peer and remote_peer.upper() not in ("N/A", "NONE", "UNKNOWN", "-", "0.0.0.0", "127.0.0.1"):
                    known_peers.add(remote_peer)
                    if str(raw_source_ip or "").strip() == remote_peer:
                        is_peer = True

                cache_key = (str(raw_source_ip or ""), is_peer)
                if cache_key in ip_cache:
                    ti_info = dict(ip_cache[cache_key])
                else:
                    ti_info = self.classify_ip(
                        raw_source_ip,
                        known_peer_ips=known_peers,
                        receiver_ip=receiver_ip,
                        is_sender_peer=is_peer,
                    )
                    ip_cache[cache_key] = ti_info
                alert["threat_intel"] = ti_info
                if ti_info.get("is_malicious"):
                    has_confirmed_malicious_ioc = True

            incident["has_confirmed_malicious_ioc"] = has_confirmed_malicious_ioc
            if has_confirmed_malicious_ioc:
                curr_sev = str(incident.get("severity", "Low"))
                mitre_techs = set(incident.get("mitre_techniques", []))
                if "T1555.004" in mitre_techs and "T1087.001" in mitre_techs:
                    incident["incident_name"] = "Account Discovery & Credential Vault Harvesting Attack Chain"
                    incident["severity"] = "Critical"
                    incident["confidence"] = max(int(incident.get("confidence", 70)), 94)
                elif "T1555.004" in mitre_techs:
                    incident["incident_name"] = "Windows Credential Manager Vault Harvesting"
                    incident["severity"] = "High" if curr_sev in ("Low", "Medium", "Informational") else curr_sev
                    incident["confidence"] = max(int(incident.get("confidence", 68)), 90)
                elif curr_sev in ("Low", "Medium", "Informational"):
                    incident["severity"] = "High"
                    incident["confidence"] = max(int(incident.get("confidence", 70)), 88)

        print(f"[INFO] Threat Intelligence Agent processed {len(incidents)} Incident(s).")
        return incidents