from typing import List, Dict, Any
from datetime import datetime
from config.settings import format_network_display, get_active_tcp_peer_ip
from agents.correlation_agent import format_incident_alert_summary


class ReportingAgent:
    """
    Reporting Agent synthesizing technical incident data, threat intel,
    and response playbooks into formal SOC Incident Reports.
    """

    def generate(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        reports = []
        active_peer = get_active_tcp_peer_ip()

        for incident in incidents:
            alerts = incident.get("alerts", [])
            first_alert = alerts[0] if alerts else {}
            event = first_alert.get("event", {})
            threat = first_alert.get("threat_intel", {})

            inc_sources = incident.get("telemetry_sources") or list(dict.fromkeys(
                str(a.get("event", {}).get("source") or "unknown").strip()
                for a in alerts
            ))
            is_real = bool(
                incident.get("is_real_telemetry")
                or any(s in ("real_nxlog_windows", "local_windows") for s in inc_sources)
            )
            is_sim = bool(incident.get("is_simulated", not is_real))
            primary_src = incident.get("primary_source") or (inc_sources[0] if inc_sources else "unknown")

            raw_src_ip = event.get("source_ip")
            raw_peer_ip = event.get("remote_peer_ip")
            fallback_peer = (
                raw_peer_ip
                if (raw_peer_ip and str(raw_peer_ip).upper() not in ("N/A", "NONE", ""))
                else (active_peer if is_real else "N/A")
            )
            resolved_src_ip = format_network_display(
                raw_src_ip,
                field_role="source_ip",
                fallback_peer_ip=fallback_peer if fallback_peer != "N/A" else None,
            )

            resolved_host = format_network_display(
                incident.get("affected_host") or event.get("hostname"),
                field_role="hostname",
            )
            proc_name = format_network_display(event.get("process_name"), field_role="process_name")
            cmd_line = format_network_display(event.get("command_line"), field_role="command_line")
            evt_id = event.get("event_id", 4688)
            evt_ts = event.get("timestamp") or incident.get("timestamp") or datetime.now().isoformat()[:19]

            distinct_eids = list(dict.fromkeys(
                str(a.get("event", {}).get("event_id"))
                for a in alerts
                if a.get("event", {}).get("event_id") is not None
            ))
            eids_display = ", ".join(distinct_eids) if distinct_eids else str(evt_id)

            inc_techs = list(dict.fromkeys(
                [str(t).strip() for t in (incident.get("mitre_techniques") or []) if str(t).strip() and str(t).strip() != "N/A"]
                + [
                    str(a.get("mitre_technique") or a.get("event", {}).get("mitre_technique") or "").strip()
                    for a in alerts
                    if str(a.get("mitre_technique") or a.get("event", {}).get("mitre_technique") or "").strip() not in ("", "N/A")
                ]
            ))
            if not inc_techs:
                inc_techs = [
                    format_network_display(
                        first_alert.get("mitre_technique") or event.get("mitre_technique", "T1059"),
                        field_role="mitre_technique",
                    )
                ]
            mitre_tech_str = ", ".join(inc_techs) if inc_techs else "T1059"
            prov_label = f"Real Live Telemetry ({primary_src})" if is_real else f"Simulated Scenario ({primary_src})"

            summary_meta = format_incident_alert_summary(incident)
            win_alerts = summary_meta["window_alert_count"]
            cum_alerts = summary_meta["cumulative_alert_count"]
            cum_scope = summary_meta["cumulative_scope"]
            first_ts = summary_meta["first_event_timestamp"]
            last_ts = summary_meta["last_event_timestamp"]
            hist_range = summary_meta["historical_log_range"]
            evidence_cap = summary_meta["evidence_alert_cap"]
            evidence_shown = summary_meta["evidence_shown_count"]
            range_clause = f" ({hist_range})" if hist_range and hist_range != "Active Window" else ""

            inc_sev = str(incident.get("severity", "Low"))
            inc_conf = int(incident.get("confidence", 70))
            inc_name = str(incident.get("incident_name", "Security Incident"))
            affected_user = incident.get("affected_user") or event.get("user") or "SYSTEM"

            ti_status = threat.get("status", "Local Endpoint Telemetry (No External IP)")
            ti_rep = threat.get("reputation", "Not Applicable (Local Host Activity)")
            ti_score = int(threat.get("risk_score", 10))
            ti_malicious = bool(threat.get("is_malicious", False) or incident.get("has_confirmed_malicious_ioc", False))

            if ti_malicious:
                threat_intel_summary = (
                    f"External IP / IOC Reputation Score: {ti_score} / 100 ({ti_status} — {ti_rep}). "
                    f"Scope Note: Confirmed malicious external IOC match; this network reputation finding directly corroborates the {inc_sev} incident severity."
                )
            elif "Local Endpoint Telemetry" in ti_status or ti_score <= 15:
                threat_intel_summary = (
                    f"External IP / IOC Reputation Score: {ti_score} / 100 ({ti_status} — {ti_rep}). "
                    f"Scope Note: This score measures external network/IOC reputation only, not overall host incident severity. "
                    f"A {ti_score}/100 local endpoint telemetry score indicates no external IP was involved; it is neither proof that the activity is harmless nor proof that it is malicious."
                )
            else:
                threat_intel_summary = (
                    f"External IP / IOC Reputation Score: {ti_score} / 100 ({ti_status} — {ti_rep}). "
                    f"Scope Note: This score reflects external IP/IOC reputation and is evaluated alongside host process and correlation evidence to determine the {inc_sev} incident severity."
                )

            if inc_sev in ("Low", "Informational"):
                severity_rationale = (
                    f"Assigned {inc_sev} severity ({inc_conf}% confidence) because Event ID(s) {eids_display} on '{resolved_host}' "
                    f"for account '{affected_user}' show no suspicious command-line utilities, untrusted caller processes, or malicious IOC matches "
                    f"(Process: {proc_name}; Command Line: '{cmd_line}'). Repeated Windows background events in the same host/user bucket are not treated as an active attack chain without corroborating evidence."
                )
                recommendation_text = (
                    f"Advisory Recommendation — Not Executed: Routine local Windows telemetry (Event ID(s) {eids_display}, MITRE {mitre_tech_str}) "
                    f"without corroborating suspicious process, command-line, or external IOC evidence. Do not isolate host '{resolved_host}' or lock account '{affected_user}'. "
                    f"Optionally correlate timestamps with Process Creation logs (Event ID 4688 / Sysmon Event ID 1) if caller process verification is needed."
                )
            elif inc_sev == "Medium":
                severity_rationale = (
                    f"Assigned Medium severity ({inc_conf}% confidence) for Event ID(s) {eids_display} on '{resolved_host}' "
                    f"involving account '{affected_user}' (MITRE {mitre_tech_str}). Activity warrants analyst verification of caller process context before any containment."
                )
                recommendation_text = (
                    f"Advisory Recommendation — Not Executed: Review caller process lineage, command-line arguments ('{cmd_line}'), and user session context on '{resolved_host}' "
                    f"for Event ID(s) {eids_display}. No automated host isolation or account lockout has been executed; escalate only if analyst review confirms unauthorized reconnaissance or credential access."
                )
            else:
                severity_rationale = (
                    f"Assigned {inc_sev} severity ({inc_conf}% confidence) due to corroborated threat indicators on '{resolved_host}' "
                    f"for account '{affected_user}' across Event ID(s) {eids_display} (MITRE {mitre_tech_str}; Process: {proc_name}; Command Line: '{cmd_line}')."
                )
                recommendation_text = (
                    f"Advisory Recommendation — Not Executed: Corroborated {inc_sev}-severity activity on '{resolved_host}' (Event ID(s) {eids_display}, MITRE {mitre_tech_str}). "
                    f"Analyst approval is required before executing SOAR dry-run containment actions (inspect/terminate unauthorized caller processes, rotate affected credentials, or isolate host if compromise is confirmed)."
                )

            report = {
                "report_id": f"REP-{incident.get('incident_id', '000')}",
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": inc_name,
                "severity": inc_sev,
                "confidence": inc_conf,
                "severity_rationale": severity_rationale,
                "window_alert_count": win_alerts,
                "cumulative_alert_count": cum_alerts,
                "cumulative_scope": cum_scope,
                "first_event_timestamp": first_ts,
                "last_event_timestamp": last_ts,
                "historical_log_range": hist_range,
                "evidence_alert_cap": evidence_cap,
                "bounded_evidence_count": evidence_shown,
                "alert_scope_explanation": summary_meta["scope_explanation"],
                "alert_count": int(incident.get("alert_count", len(alerts))),
                "host": resolved_host,
                "user": affected_user,
                "source_ip": resolved_src_ip,
                "mitre_technique": mitre_tech_str,
                "mitre_techniques": list(inc_techs),
                "mitre_tactic": incident.get("mitre_tactic") or event.get("mitre_tactic", "Execution"),
                "telemetry_sources": inc_sources,
                "primary_source": primary_src,
                "is_real_telemetry": is_real,
                "is_simulated": is_sim,
                "provenance_label": prov_label,
                "executive_summary": (
                    f"A {inc_sev} severity correlated incident '{inc_name}' "
                    f"[{prov_label}] was recorded on endpoint '{resolved_host}' involving account "
                    f"'{affected_user}'. The multi-agent detection engine correlated "
                    f"{win_alerts} current-window alert(s) and {cum_alerts} cumulative alert(s) "
                    f"({cum_alerts:,} unique matching alert(s) observed across the retained historical log range{range_clause}) "
                    f"[{cum_scope}] with {inc_conf}% confidence. "
                    f"The evidence table is capped at {evidence_cap} recent records ({evidence_shown} shown), "
                    f"while the cumulative ledger tracks the full number of unique alert identities."
                ),
                "technical_analysis": (
                    f"Correlated Event ID(s): {eids_display} (Initial trigger Event ID {evt_id}: {event.get('event_type', 'Security Event')}) "
                    f"registered at {evt_ts} from telemetry source '{primary_src}'. "
                    f"Process Name: {proc_name}. "
                    f"Command Line string: '{cmd_line}'."
                ),
                "status": ti_status,
                "reputation": ti_rep,
                "risk_score": ti_score,
                "threat_intel_summary": threat_intel_summary,
                "recommendation_status": "Advisory Recommendation — Not Executed (SOAR Dry-Run Mode; Requires Analyst Approval)",
                "recommendation": recommendation_text,
                "timestamp": datetime.now().isoformat()
            }

            reports.append(report)

        print(f"[INFO] Reporting Agent generated {len(reports)} formal SOC Incident Report(s).")
        return reports