import json
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from knowledge_base.database import KnowledgeBaseDB


class FeedbackAgent:
    """
    Feedback Agent managing Human-in-the-Loop analyst interactions.
    Persists analyst verdicts, severity overrides, confidence adjustments,
    and approved guidance into the SQLite Adaptive Knowledge Base, and
    retrieves prior analyst-approved guidance with strict evidence comparison.
    """

    SUSPICIOUS_CLI_INDICATORS = (
        "vaultcmd", "cmdkey", "powershell", "pwsh", "rundll32",
        "mimikatz", "lazagne", "seatbelt", "sharphound", "bloodhound",
        "procdump", "wscript", "cscript", "mshta",
        "net.exe", "net1.exe", "whoami", "nltest", "dsquery", "adfind",
    )

    def __init__(self, db: Optional[KnowledgeBaseDB] = None):
        self.db = db or KnowledgeBaseDB()

    @classmethod
    def extract_incident_evidence_profile(cls, incident: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Extracts a deterministic evidence summary from an incident for historical comparison."""
        if not isinstance(incident, dict):
            return {
                "affected_host": "UNKNOWN",
                "affected_user": "SYSTEM",
                "mitre_techniques": [],
                "rule_ids": [],
                "event_ids": [],
                "has_suspicious_cli": False,
                "has_malicious_ioc": False,
            }
        alerts = incident.get("alerts", []) if isinstance(incident.get("alerts"), list) else []
        mitre_techs: List[str] = []
        rule_ids: List[str] = []
        event_ids: List[int] = []
        has_susp_cli = False
        has_mal_ioc = bool(incident.get("has_confirmed_malicious_ioc", False))

        for t in incident.get("mitre_techniques", []) or []:
            s = str(t).strip()
            if s and s.upper() not in ("N/A", "NA", "NONE", "UNKNOWN") and s not in mitre_techs:
                mitre_techs.append(s)

        for alt in alerts:
            if not isinstance(alt, dict):
                continue
            r_id = str(alt.get("rule_id") or "").strip()
            if r_id and r_id.upper() not in ("N/A", "NA", "NONE", "UNKNOWN") and r_id not in rule_ids:
                rule_ids.append(r_id)
            t_id = str(alt.get("mitre_technique") or "").strip()
            if t_id and t_id.upper() not in ("N/A", "NA", "NONE", "UNKNOWN") and t_id not in mitre_techs:
                mitre_techs.append(t_id)
            if alt.get("threat_intel", {}).get("is_malicious"):
                has_mal_ioc = True

            evt = alt.get("event", {}) if isinstance(alt.get("event"), dict) else {}
            eid = evt.get("event_id")
            try:
                eid_int = int(eid)
                if eid_int not in event_ids:
                    event_ids.append(eid_int)
            except (TypeError, ValueError):
                pass
            proc_l = str(evt.get("process_name") or "").lower()
            cmd_l = str(evt.get("command_line") or "").lower()
            if any(ind in proc_l or ind in cmd_l for ind in cls.SUSPICIOUS_CLI_INDICATORS):
                has_susp_cli = True

        return {
            "affected_host": str(incident.get("affected_host") or "UNKNOWN"),
            "affected_user": str(incident.get("affected_user") or "SYSTEM"),
            "mitre_techniques": sorted(mitre_techs),
            "rule_ids": sorted(rule_ids),
            "event_ids": sorted(event_ids),
            "has_suspicious_cli": has_susp_cli,
            "has_malicious_ioc": has_mal_ioc,
        }

    def process_feedback(
        self,
        incident_id: str,
        alert_name: str,
        analyst_verdict: str,
        override_severity: str = None,
        adjusted_confidence: int = 90,
        notes: str = "",
        incident: Optional[Dict[str, Any]] = None,
        approved_guidance: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Receives analyst review from the SOC Dashboard and stores the persistent
        feedback record in SQLite without automatically mutating detection rules
        or auto-executing SOAR actions.
        """
        profile = self.extract_incident_evidence_profile(incident)
        guidance_text = (
            approved_guidance
            if approved_guidance is not None
            else (notes.strip() if notes else f"Analyst marked as {analyst_verdict}.")
        )
        feedback_entry = {
            "feedback_id": f"FDB-{uuid.uuid4().hex[:6].upper()}",
            "incident_id": incident_id,
            "alert_name": alert_name,
            "analyst_verdict": analyst_verdict,
            "override_severity": override_severity,
            "adjusted_confidence": adjusted_confidence,
            "notes": notes,
            "affected_host": profile["affected_host"],
            "affected_user": profile["affected_user"],
            "mitre_techniques": json.dumps(profile["mitre_techniques"]),
            "rule_ids": json.dumps(profile["rule_ids"]),
            "approved_guidance": guidance_text,
            "evidence_fingerprint": json.dumps(profile, sort_keys=True),
            "timestamp": datetime.now().isoformat(),
        }

        self.db.save_feedback(feedback_entry)

        print(
            f"[INFO] Feedback Agent recorded analyst review for {incident_id}: "
            f"Verdict={analyst_verdict}, OverrideSeverity={override_severity}, Adjusted Confidence={adjusted_confidence}%"
        )
        return feedback_entry

    def get_feedback_history(self) -> List[Dict[str, Any]]:
        return self.db.get_all_feedback()

    def retrieve_similar_guidance(self, incident: Dict[str, Any]) -> Dict[str, Any]:
        """
        Retrieves relevant prior analyst-reviewed findings when a similar incident appears,
        comparing the current incident's evidence with the historical case before reusing guidance.
        Enforces safe knowledge reuse:
        - Clearly distinguishes historical guidance from a newly verified finding.
        - Never treats similarity alone as proof of an attack or benignity.
        - Never automatically changes detection rules or executes SOAR responses.
        """
        current_profile = self.extract_incident_evidence_profile(incident)
        inc_id = str(incident.get("incident_id") or "")
        inc_name = str(incident.get("incident_name") or "")
        all_fb = self.get_feedback_history()

        best_match: Optional[Dict[str, Any]] = None
        matched_on: List[str] = []

        for fb in all_fb:
            reasons: List[str] = []
            if inc_id and fb.get("incident_id") == inc_id:
                reasons.append("exact_incident_id")
            if inc_name and fb.get("alert_name") and fb.get("alert_name") == inc_name:
                reasons.append("incident_pattern_name")

            fb_techs: List[str] = []
            try:
                raw_t = fb.get("mitre_techniques")
                if raw_t:
                    fb_techs = json.loads(raw_t) if isinstance(raw_t, str) else list(raw_t)
            except Exception:
                fb_techs = []

            fb_rules: List[str] = []
            try:
                raw_r = fb.get("rule_ids")
                if raw_r:
                    fb_rules = json.loads(raw_r) if isinstance(raw_r, str) else list(raw_r)
            except Exception:
                fb_rules = []

            if set(current_profile["mitre_techniques"]) & set(fb_techs):
                reasons.append("mitre_technique_overlap")
            if set(current_profile["rule_ids"]) & set(fb_rules):
                reasons.append("detection_rule_overlap")
            if (
                fb.get("affected_host")
                and fb.get("affected_host") not in ("UNKNOWN", "N/A")
                and fb.get("affected_host") == current_profile["affected_host"]
            ):
                reasons.append("same_affected_host")

            if reasons:
                best_match = fb
                matched_on = reasons
                break

        if not best_match:
            return {
                "has_historical_match": False,
                "can_reuse_guidance": False,
                "guidance_origin": "Newly Analyzed Finding (No Prior Analyst Review Matched)",
                "is_newly_verified_finding": False,
                "historical_feedback": None,
                "evidence_comparison": {
                    "matched_on": [],
                    "evidence_aligned": False,
                    "comparison_summary": "No prior analyst feedback record matched this incident pattern in sentinel_kb.db.",
                },
                "reused_guidance": None,
                "safety_policy": {
                    "similarity_is_proof_of_attack": False,
                    "auto_rule_mutation": False,
                    "auto_response_execution": False,
                    "policy_statement": (
                        "Safe Knowledge Reuse: Similarity alone is never treated as proof of an attack. "
                        "Detection rules and SOAR responses are never automatically modified or executed."
                    ),
                },
            }

        hist_fp: Dict[str, Any] = {}
        try:
            if best_match.get("evidence_fingerprint"):
                hist_fp = json.loads(best_match["evidence_fingerprint"])
        except Exception:
            hist_fp = {}

        hist_verdict = str(best_match.get("analyst_verdict") or "Reviewed")
        hist_was_benign = any(
            k in hist_verdict.lower() for k in ("false positive", "benign", "expected")
        )
        current_has_escalation_evidence = (
            current_profile["has_suspicious_cli"] or current_profile["has_malicious_ioc"]
        )
        hist_had_escalation_evidence = bool(
            hist_fp.get("has_suspicious_cli") or hist_fp.get("has_malicious_ioc")
        )

        # Evidence comparison safeguard:
        # Do not reuse a prior Benign/False Positive recommendation if current incident has new suspicious CLI or IOCs!
        if hist_was_benign and current_has_escalation_evidence and not hist_had_escalation_evidence:
            evidence_aligned = False
            can_reuse = False
            comp_summary = (
                "EVIDENCE MISMATCH — DO NOT REUSE PRIOR BENIGN VERDICT: Current incident contains suspicious "
                "process/command-line or malicious IOC indicators that were absent in the historical review."
            )
        else:
            evidence_aligned = True
            can_reuse = True
            comp_summary = (
                f"Evidence aligned across {', '.join(matched_on)} "
                f"(Current suspicious CLI={current_profile['has_suspicious_cli']}, "
                f"Malicious IOC={current_profile['has_malicious_ioc']}). "
                f"Historical analyst guidance is eligible for advisory reference."
            )

        reused_text = (
            best_match.get("approved_guidance")
            or best_match.get("notes")
            or f"Prior analyst review ({best_match.get('feedback_id')}) recorded verdict '{hist_verdict}'."
        )

        return {
            "has_historical_match": True,
            "can_reuse_guidance": can_reuse,
            "guidance_origin": "Historical Analyst-Reviewed Guidance (Reference Only — Not a Newly Verified Finding)",
            "is_newly_verified_finding": False,
            "historical_feedback": {
                "feedback_id": best_match.get("feedback_id"),
                "incident_id": best_match.get("incident_id"),
                "alert_name": best_match.get("alert_name"),
                "analyst_verdict": hist_verdict,
                "override_severity": best_match.get("override_severity") or "Unchanged",
                "adjusted_confidence": best_match.get("adjusted_confidence"),
                "notes": best_match.get("notes") or "",
                "approved_guidance": reused_text,
                "created_at": best_match.get("created_at") or best_match.get("timestamp", ""),
            },
            "evidence_comparison": {
                "matched_on": matched_on,
                "evidence_aligned": evidence_aligned,
                "current_evidence_profile": current_profile,
                "historical_evidence_profile": hist_fp,
                "comparison_summary": comp_summary,
            },
            "reused_guidance": reused_text if can_reuse else None,
            "safety_policy": {
                "similarity_is_proof_of_attack": False,
                "auto_rule_mutation": False,
                "auto_response_execution": False,
                "policy_statement": (
                    "Safe Knowledge Reuse: Historical guidance is surfaced as an advisory reference only. "
                    "Similarity alone is not proof of an attack, and neither detection rules nor SOAR "
                    "actions are automatically modified or executed."
                ),
            },
        }

