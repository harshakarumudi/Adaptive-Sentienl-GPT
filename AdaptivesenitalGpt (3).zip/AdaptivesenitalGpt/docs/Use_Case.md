# 🎯 Attack Scenarios & Detection Use Cases

AdaptiveSentinelGPT detects and mitigates complex cyber threat scenarios mapped directly to the **MITRE ATT&CK Enterprise Matrix**:

---

## Scenario 1: Ransomware & Pre-Encryption Staging
- **MITRE Tactics**: Execution (`T1059.001`), Impact (`T1486`)
- **Event Indicators**:
  - `Sysmon Event ID 1`: `powershell.exe -ExecutionPolicy Bypass -Enc Qnkg...`
  - `Windows Event ID 4688`: `vssadmin.exe delete shadows /all /quiet`
- **Multi-Agent Flow**:
  - **Detection Agent** flags unsigned PowerShell execution and shadow copy deletion requests.
  - **Correlation Agent** synthesizes events into `Ransomware Pre-Encryption Staging Activity`.
  - **Response Agent** generates immediate containment actions: network segment isolation, process tree termination, and offline backup verification.

---

## Scenario 2: Automated Brute Force & Mimikatz LSASS Dump
- **MITRE Tactics**: Credential Access (`T1110`, `T1003.001`)
- **Event Indicators**:
  - `Windows Event ID 4625`: Repeated failed logins from untrusted IP (`185.220.101.5`).
  - `Sysmon Event ID 10`: `mimikatz.exe` reading `lsass.exe` process memory.
- **Multi-Agent Flow**:
  - **Threat Intel Agent** flags source IP as a known Tor exit node with a Risk Score of 95/100.
  - **Correlation Agent** combines brute force attempts and LSASS memory access into a single Critical incident.
  - **Explainability Agent** outputs LLM diagnostic rationale explaining the password spray sequence.

---

## Scenario 3: Host Defense Evasion & Log Tampering
- **MITRE Tactics**: Defense Evasion (`T1070`)
- **Event Indicators**:
  - `Windows Event ID 1102`: `wevtutil cl Security` (Audit Log Cleared)
- **Multi-Agent Flow**:
  - **Detection Agent** raises a High severity alert.
  - **Response Agent** initiates forensic memory capture before adversary wipes host artifacts.

---

## Scenario 4: Persistence via Account Creation
- **MITRE Tactics**: Persistence (`T1136`)
- **Event Indicators**:
  - `Windows Event ID 4720`: `net user backdoor_user P@ssword123! /add`
- **Multi-Agent Flow**:
  - Flagged by Detection Agent and reported in SOC Dashboard.
