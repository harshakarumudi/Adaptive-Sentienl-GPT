# 🤖 Multi-Agent Specifications: AdaptiveSentinelGPT

## 1. Agent Design Philosophy
AdaptiveSentinelGPT employs a modular multi-agent system where each agent acts as a specialized SOC tier role. Communication occurs via structured Pydantic / Dictionary JSON data payloads.

---

## 2. Agent Catalog & Responsibilities

| Agent Name | Role | Inputs | Outputs | Primary Logic |
| :--- | :--- | :--- | :--- | :--- |
| **Detection Agent** | Tier-1 Detection Specialist | Enriched Log Events | Flagged Alert Objects | MITRE ATT&CK rules, obfuscated process CLI parsing (PowerShell bypass, Mimikatz, vssadmin). |
| **Correlation Agent** | Incident Reconstruction Lead | Atomic Alert Objects | Correlated Incident Objects | Entity grouping (Host/User/IP) & temporal sequence analysis (e.g. Brute force + LSASS dump). |
| **Threat Intelligence Agent** | Threat Intel Analyst | Correlated Incidents | Incidents + Threat Intel Metadata | SQLite IOC lookup, IP reputation scoring, C2 category tagging. |
| **Explainability Agent** | AI Security Researcher | Correlated Incidents | AI Rationale & Evidence Lists | LLM Prompt engineering (Ollama/Gemini/Fallback) for human-understandable diagnostics. |
| **Response Agent** | SOAR Engineer | Correlated Incidents | SOAR Response Playbooks | Tri-phase mitigation generation (Containment, Eradication, Recovery). |
| **Reporting Agent** | SOC Operations Lead | Incidents + Playbooks | Formal SOC Incident Reports | Executive summary formatting, technical details, and strategic recommendations. |
| **Feedback Agent** | Human-in-the-Loop Curator | Analyst Dashboard Input | Updated Knowledge Base Records | Stores analyst verdicts (True/False Positive), updates SQLite DB feedback table. |

---

## 3. Inter-Agent Data Flow

```
[ Enriched Logs ] 
       │
       ▼
( Detection Agent ) ────► [ Atomic Alerts ]
                                │
                                ▼
                        ( Correlation Agent ) ────► [ Incidents ]
                                                        │
                                ┌───────────────────────┴───────────────────────┐
                                ▼                                               ▼
                    ( Threat Intel Agent )                            ( Explainability Agent )
                                │                                               │
                                ▼                                               ▼
                    ( Response Agent )                                ( Reporting Agent )
                                │                                               │
                                └───────────────────────┬───────────────────────┘
                                                        ▼
                                            ( Feedback Agent ) ◄─── [ Human Analyst ]
                                                        │
                                                        ▼
                                            [ SQLite Knowledge Base ]
```
