# 🏛 System Architecture: AdaptiveSentinelGPT

## 1. High-Level Architecture Diagram

```
                      +---------------------------------------+
                      |         Multi-Source Log Ingestion    |
                      |  (Windows, Sysmon, Linux, Suricata)   |
                      +-------------------+-------------------+
                                          |
                                          v
                      +-------------------+-------------------+
                      |          Analysis Layer               |
                      | (Parser, Normalizer, Deduplicator,    |
                      |            Enricher)                  |
                      +-------------------+-------------------+
                                          |
                                          v
                      +-------------------+-------------------+
                      |      Adaptive Multi-Agent Engine      |
                      |                                       |
                      |  1. Detection Agent (Rules + AI)      |
                      |  2. Correlation Agent (Attack Chains) |
                      |  3. Threat Intel Agent (IOC Feeds)    |
                      |  4. Explainability Agent (AI Rationale)|
                      |  5. Response Agent (SOAR Playbooks)   |
                      |  6. Reporting Agent (SOC Incident Rep)|
                      |  7. Feedback Agent (Analyst Loop)     |
                      +---------+-------------------+---------+
                                |                   |
                 +--------------+                   +---------------+
                 |                                                  |
                 v                                                  v
+-------------------------------+                  +--------------------------------+
|  Foundation LLM Engine        |                  |  Adaptive Security KB (SQLite) |
| (Ollama / Gemini / Fallback)  |                  | (MITRE ATT&CK, IOCs, History)  |
+-------------------------------+                  +--------------------------------+
                                                                    ^
                                                                    |
                      +---------------------------------------------+
                      |
                      v
      +-------------------------------+
      |   Interactive SOC Dashboard   |
      |  (Streamlit Command Center,   |
      |   Attack Simulator, Matrix)   |
      +-------------------------------+
```

---

## 2. Component Breakdown

### A. Data Ingestion & Analysis Layer (`analysis/`)
1. **LogParser (`parser.py`)**: Handles JSON, line-delimited JSON, and syslog formats.
2. **LogNormalizer (`normalize.py`)**: Maps disparate event attributes into a unified schema (`timestamp`, `source`, `event_id`, `event_type`, `severity`, `hostname`, `user`, `source_ip`, `process_name`, `command_line`, `mitre_technique`).
3. **LogDeduplicator (`deduplicate.py`)**: Removes redundant high-frequency log events based on sliding time window signatures.
4. **LogEnricher (`enrich.py`)**: Attaches MITRE Tactics, asset criticality flags, and risk scores.

### B. Adaptive Multi-Agent Engine (`agents/`)
- **Detection Agent**: Flags atomic threats using MITRE signatures and command-line heuristics.
- **Correlation Agent**: Groups alerts by host, user, and temporal sequence to reconstruct multi-stage attack scenarios.
- **Threat Intelligence Agent**: Queries local SQLite IOC tables and rates IP reputation.
- **Explainability Agent**: Interfaces with LLM Client to generate natural-language root cause diagnostic summaries.
- **Response Planning Agent**: Compiles SOAR playbooks (Containment, Eradication, Recovery).
- **Reporting Agent**: Builds executive and technical incident reports.
- **Feedback Agent**: Processes analyst feedback and updates SQLite Knowledge Base weights.

### C. LLM Integration Engine (`llm/`)
- Abstracted interface supporting local Ollama (`llama3`, `qwen2.5`), Cloud APIs (Gemini/OpenAI), with a fallback Heuristic AI Engine.

### D. Adaptive Knowledge Base (`knowledge_base/`)
- SQLite database storing Threat Intel IOCs, Historical Incident logs, and Analyst Feedback entries (`analyst_feedback`).
