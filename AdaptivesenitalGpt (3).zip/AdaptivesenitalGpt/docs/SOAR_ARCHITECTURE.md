# Controlled AI-Assisted SOAR Architecture & Safety Policy

## 1. Overview
The Controlled AI-Assisted Security Orchestration, Automation, and Response (SOAR) module in **AdaptiveSentinelGPT** automates incident response recommendations while strictly guaranteeing system safety. 

Arbitrary shell command generation by LLMs or GNN models is **strictly prohibited**. All response operations are constrained to a deterministic allowlist of predefined actions executed through a safe abstraction layer with mandatory human analyst approval, dry-run previews, persistent audit logging, and rollback support.

```
+--------------------------+
|  Incident & GNN Telemetry |
+--------------------------+
             |
             v
+--------------------------+
|   SOAR Decision Engine   |  (Evaluates Incident & Risk -> Matches Allowlisted Actions)
+--------------------------+
             |
             v
+--------------------------+
|   SOAR Action Registry   |  (Enforces Allowlist & Target Parameter Validation)
+--------------------------+
             |
             v
+--------------------------+
|  Human Analyst Approval  |  (Interactive Dashboard Console: Approve or Reject)
+--------------------------+
             |
             v
+--------------------------+
|  SOAR Executor Interface |  (Default: DRY RUN Mode | Simulated Safe Execution)
+--------------------------+
             |
             v
+--------------------------+
|   Persistent Audit Log   |  (SQLite DB Audit Trail & Rollback History)
+--------------------------+
```

---

## 2. Supported Allowlisted Actions

The SOAR system supports only the following allowlisted actions:

| Action ID | Action Name | Target Type | Reversible | Rollback Action | Purpose / Description |
|-----------|-------------|-------------|------------|-----------------|-----------------------|
| `ISOLATE_HOST` | Isolate Endpoint Host | Hostname | `Yes` | `UNISOLATE_HOST` | Applies network-level isolation firewall rule to endpoint. |
| `BLOCK_IP` | Block Malicious IP Address | IP Address | `Yes` | `UNBLOCK_IP` | Adds source IP address to perimeter/host firewall drop list. |
| `LOCK_USER` | Lock Monitored User Account | Username | `Yes` | `UNLOCK_USER` | Disables user account in Active Directory / SAM to prevent lateral movement. |
| `COLLECT_FORENSIC_ARTIFACTS` | Collect Forensic Package | Artifact | `No` | `N/A (Non-Reversible)` | Captures volatile memory dump, event logs, and triage package. |

### Rollback Operations
- `UNISOLATE_HOST`: Restores network connectivity to previously isolated host.
- `UNBLOCK_IP`: Removes IP address from perimeter firewall drop list.
- `UNLOCK_USER`: Re-enables user account in Active Directory / SAM.

---

## 3. Human Analyst Approval Workflow

Every disruptive SOAR action follows a strict step-by-step lifecycle:

1. **Detection & Correlation**: An incident is correlated from log telemetry and scored by the GNN model.
2. **Recommendation Generation**: The `SOARDecisionEngine` maps incident severity, GNN risk score, MITRE techniques, and target attributes to allowlisted action(s).
3. **Target Validation**: `SOARActionRegistry` validates target strings (e.g. valid IPv4/IPv6, non-empty host, non-wildcard username).
4. **Analyst Review**: The recommendation is presented in the Streamlit SOC Dashboard with a rationale and a `DRY RUN — NO SYSTEM CHANGE` preview.
5. **Human Approval**: The analyst explicitly clicks **Approve Action** or **Reject Action**.
6. **Execution (Simulation / Dry Run)**: Approved actions execute through `MockSOARExecutor`. Real destructive OS modifications are disabled in this phase.
7. **Verification**: The executor verifies action status (`VERIFIED_SUCCESS` / `VERIFIED_FAILURE`).
8. **Audit Trail**: The complete execution lifecycle is written to the persistent SQLite audit database (`soar_audit_log`).

---

## 4. Action Validation Rules

- **Host Isolation (`ISOLATE_HOST`)**:
  - Target must be a non-empty string matching valid hostname format (`^[A-Za-z0-9_\-\.]+$`).
  - Rejects wildcards (`*`, `"ALL"`, `"UNKNOWN"`).
- **IP Blocking (`BLOCK_IP`)**:
  - Target must parse as a valid IPv4 or IPv6 address via Python `ipaddress`.
  - Rejects loopback (`127.0.0.1`), multicast, or invalid IP strings (`999.999.999.999`).
- **Account Locking (`LOCK_USER`)**:
  - Target must be a non-empty string matching valid username format (`^[A-Za-z0-9_\-\.\@\\]+$`).
- **Forensic Collection (`COLLECT_FORENSIC_ARTIFACTS`)**:
  - Artifact type parameter must match allowlisted artifact types (`memory_dump`, `event_logs`, `triage_package`, `volatile_data`, `network_pcap`).

---

## 5. Dry-Run Mode & Safe Execution

- **Default Execution Mode**: `DRY RUN` (`dry_run = True`).
- All previews explicitly display: `DRY RUN — NO SYSTEM CHANGE`.
- **Safe Mock Execution**: The system uses `MockSOARExecutor` to simulate action execution and verification without modifying local system state or network interfaces.

---

## 6. Audit Trail & Persistence

All SOAR operations log persistent audit records into SQLite database `data/soar_audit.db` containing:
- `audit_id`, `incident_id`, `action_id`, `analyst_approval`, `analyst_user`, `target`
- `requested_timestamp`, `execution_timestamp`, `action_status`, `verification_result`
- `error_message`, `rollback_status`, `source_of_recommendation`, `gnn_score`
- `rule_id`, `mitre_technique`, `dry_run`, `parameters`, `details`

---

## 7. Known Limitations & Safety System Description

- **System Classification**: *"Controlled AI-assisted SOAR with analyst approval and simulated execution."*
- **No Direct Real-World OS Remediation**: The current implementation runs simulated/mock execution to prevent accidental network disruption or account lockouts on live user environments.
- **Arbitrary Command Prohibition**: LLMs and GNN models generate explanatory reasoning ONLY and are restricted from generating executable scripts or shell commands.
