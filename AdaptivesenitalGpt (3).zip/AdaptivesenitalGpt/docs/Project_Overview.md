# 📄 Project Overview: AdaptiveSentinelGPT

## 1. Abstract
Modern Security Operations Centers (SOCs) face an unprecedented surge in security telemetry. Tier-1 security analysts are overwhelmed by high volume alert noise, leading to alert fatigue, missed critical indicators, and prolonged Mean-Time-To-Detect (MTTD) and Mean-Time-To-Respond (MTTR). 

**AdaptiveSentinelGPT** introduces an autonomous multi-agent AI framework designed to automate the security incident lifecycle. By combining multi-source log normalization, enterprise MITRE ATT&CK correlation, Threat Intelligence enrichment, LLM-based explainable reasoning, automated SOAR playbooks, and Human-in-the-Loop adaptive learning, AdaptiveSentinelGPT provides scalable, intelligent SOC automation.

---

## 2. Problem Statement
1. **Alert Fatigue**: Security Analysts process 10,000+ daily events with up to 70% being false positives.
2. **Context Loss**: Conventional SIEM solutions flag atomic events without correlating related attack stages across time or network hosts.
3. **Black-Box ML Limitations**: Traditional Machine Learning security tools offer risk scores without explaining *why* an event is dangerous.
4. **Static Rule Decay**: Static detection rules fail to adapt to analyst feedback or evolving threat tactics.

---

## 3. Key Objectives
- **Automate Ingestion & Normalization**: Standardize heterogeneous logs (Windows, Sysmon, Linux, Suricata) into OCSF event structures.
- **Correlate Attack Chains**: Synthesize atomic alerts into unified multi-stage attack incidents using temporal and entity grouping.
- **Provide AI Explainability**: Generate natural language root-cause rationale and key evidence lists via LLM integration.
- **Automate SOAR Playbooks**: Provide structured Containment, Eradication, and Recovery action steps for instant responder execution.
- **Enable Adaptive Learning**: Capture analyst feedback (True Positive/False Positive, severity overrides) and update the SQLite Adaptive Knowledge Base.

---

## 4. Project Scope (Phase 1 vs Phase 2)

### Phase 1 (Completed Scope)
- Multi-format Log Parsing & OCSF Normalization.
- Sliding-window Deduplication & Asset Criticality Enrichment.
- 7 Autonomous AI Agent Architecture (Detection, Correlation, Threat Intel, Explainability, Response, Reporting, Feedback).
- Universal LLM Abstraction Layer (Ollama Llama 3 / Qwen 2.5, Gemini, OpenAI, and Heuristic AI Engine Fallback).
- SQLite Adaptive Knowledge Base (`sentinel_kb.db`) for IOCs, Incidents, and Analyst Feedback storage.
- Synthetic Attack Scenario Generator (Ransomware, Brute Force, LSASS Mimikatz, Defense Evasion, Lateral Movement).
- Dark-themed Interactive Streamlit SOC Command Center Dashboard.
- Pytest Automated Test Suite & Capstone Review Documentation.

### Phase 2 (Future Roadmap)
- Live Real-Time Syslog & Kafka Streaming Integration.
- Graph Neural Network (GNN) Attack Graph Visualization.
- Automated API Endpoint Isolation Execution via EDR Integrations (CrowdStrike / Microsoft Defender APIs).
