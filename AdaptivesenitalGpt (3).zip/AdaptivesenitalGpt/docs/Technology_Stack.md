# 🛠 Technology Stack: AdaptiveSentinelGPT

## 1. Stack Components

| Layer | Technology Selected | Justification |
| :--- | :--- | :--- |
| **Language & Core Framework** | Python 3.10+ | Industry standard for AI/ML, data processing, and cybersecurity tooling. |
| **Data Validation & Schemas** | Pydantic v2 | Ensures strong typing and data schema consistency across multi-agent pipelines. |
| **User Interface** | Streamlit | Rapid, high-performance web dashboard framework with interactive widgets. |
| **Data Analytics & Charts** | Pandas & Plotly | Powerful tabular analysis and interactive security analytics visualizations. |
| **Local LLM Engine** | Ollama (Llama 3 / Qwen 2.5) | Enables privacy-first, offline LLM inference without sending sensitive logs to cloud APIs. |
| **Cloud LLM Providers** | Google Gemini API / OpenAI API | Optional cloud AI inference for advanced explainability and reasoning. |
| **Knowledge Base Storage** | SQLite 3 (`sentinel_kb.db`) | Lightweight, self-contained relational storage for IOCs, incidents, and analyst feedback. |
| **Testing Framework** | Pytest | Automated unit testing and continuous integration verification. |

---

## 2. Industry Comparison Matrix

| Feature | Legacy SIEM (Splunk/QRadar) | Traditional SOAR | AdaptiveSentinelGPT |
| :--- | :--- | :--- | :--- |
| **Log Ingestion** | ✅ High | ✅ High | ✅ Multi-source (Windows/Sysmon/Linux/Suricata) |
| **Attack Chain Correlation** | ⚠️ Complex Querying | ⚠️ Rule-based | ✅ Automatic Multi-Agent Temporal Correlation |
| **AI Explainability** | ❌ None | ❌ None | ✅ LLM Natural Language Diagnostic Rationale |
| **Adaptive Learning** | ❌ Manual Tuning | ❌ Static Playbooks | ✅ Human-in-the-Loop Feedback Loop (SQLite) |
| **Cost & Privacy** | 💰 Extremely High ($$$) | 💰 High ($$) | 🟢 Open-Source & Privacy-First (Local LLM Option) |
