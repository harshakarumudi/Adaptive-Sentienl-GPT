from typing import Dict, Any


class MitreKnowledgeBase:

    def __init__(self):
        self.techniques = {
            4625: {
                "technique": "T1110",
                "tactic": "Credential Access",
                "name": "Brute Force",
                "description": "Adversaries may use brute force attacks to attempt to gain access to accounts when passwords are unknown."
            },
            4624: {
                "technique": "N/A",
                "tactic": "Initial Access / Legitimate Access",
                "name": "Successful Logon",
                "description": "Standard user logon activity."
            },
            4688: {
                "technique": "T1059",
                "tactic": "Execution",
                "name": "Command and Scripting Interpreter",
                "description": "Adversaries may abuse command and script interpreters to execute commands, scripts, or binaries."
            },
            4720: {
                "technique": "T1136",
                "tactic": "Persistence",
                "name": "Create Account",
                "description": "Adversaries may create an account to maintain access to victim systems."
            },
            1102: {
                "technique": "T1070",
                "tactic": "Defense Evasion",
                "name": "Indicator Removal on Host: Clear Event Logs",
                "description": "Adversaries may clear system event logs to hide evidence of intrusion."
            },
            1: {
                "technique": "T1059.001",
                "tactic": "Execution",
                "name": "PowerShell Execution",
                "description": "Execution of unsigned or obfuscated PowerShell scripts."
            },
            10: {
                "technique": "T1003.001",
                "tactic": "Credential Access",
                "name": "OS Credential Dumping: LSASS Memory",
                "description": "Adversaries may attempt to access credential material stored in the Local Security Authority Subsystem Service (LSASS) process memory."
            },
            1001: {
                "technique": "T1110.001",
                "tactic": "Credential Access",
                "name": "Password Guessing",
                "description": "Adversaries may attempt to systematically guess valid account passwords."
            },
            2000001: {
                "technique": "T1021",
                "tactic": "Lateral Movement",
                "name": "Remote Services",
                "description": "Adversaries may use Valid Accounts to log into a service specifically designed to accept remote management requests."
            }
        }

    def get_mitre(self, event_id: int) -> Dict[str, Any]:
        return self.techniques.get(
            event_id,
            {
                "technique": "Unknown",
                "tactic": "Unknown",
                "name": "Unmapped Event",
                "description": "No MITRE mapping currently configured for this Event ID."
            }
        )