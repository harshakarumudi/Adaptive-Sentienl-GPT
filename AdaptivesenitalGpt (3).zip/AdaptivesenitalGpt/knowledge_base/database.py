import sqlite3
import json
from typing import List, Dict, Any, Optional
from config.settings import DB_PATH


class KnowledgeBaseDB:
    """
    SQLite-backed Adaptive Knowledge Base.
    Stores Threat Intel IOCs, Historical Incidents, and Analyst Feedback.
    """

    def __init__(self, db_path=DB_PATH):
        self.db_path = str(db_path)
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Threat Intel IOC Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS threat_intel_ioc (
                    ip TEXT PRIMARY KEY,
                    status TEXT,
                    reputation TEXT,
                    risk_score INTEGER,
                    threat_category TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Historical Incidents Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS historical_incidents (
                    incident_id TEXT PRIMARY KEY,
                    incident_name TEXT,
                    severity TEXT,
                    confidence INTEGER,
                    affected_host TEXT,
                    affected_user TEXT,
                    alerts_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Analyst Feedback Table (Human-in-the-Loop Adaptive Learning)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analyst_feedback (
                    feedback_id TEXT PRIMARY KEY,
                    incident_id TEXT,
                    alert_name TEXT,
                    analyst_verdict TEXT,
                    override_severity TEXT,
                    adjusted_confidence INTEGER,
                    notes TEXT,
                    affected_host TEXT,
                    affected_user TEXT,
                    mitre_techniques TEXT,
                    rule_ids TEXT,
                    approved_guidance TEXT,
                    evidence_fingerprint TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute("PRAGMA table_info(analyst_feedback)")
            existing_fb_cols = {row[1] for row in cursor.fetchall()}
            for col_name, col_type in (
                ("affected_host", "TEXT"),
                ("affected_user", "TEXT"),
                ("mitre_techniques", "TEXT"),
                ("rule_ids", "TEXT"),
                ("approved_guidance", "TEXT"),
                ("evidence_fingerprint", "TEXT"),
            ):
                if col_name not in existing_fb_cols:
                    try:
                        cursor.execute(f"ALTER TABLE analyst_feedback ADD COLUMN {col_name} {col_type}")
                    except Exception:
                        pass

            # Durable Incident Alert Identity Ledger (for cumulative_alert_count across rolling windows & restarts)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS incident_alert_ledger (
                    incident_id TEXT NOT NULL,
                    alert_key TEXT NOT NULL,
                    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (incident_id, alert_key)
                )
            """)

            # Durable Incident State Snapshot (bounded recent evidence & metadata for scrolled-out or restarted incidents)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS incident_state_snapshot (
                    incident_id TEXT PRIMARY KEY,
                    metadata_json TEXT,
                    recent_alerts_json TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Seed default known malicious IOCs if empty
            cursor.execute("SELECT COUNT(*) FROM threat_intel_ioc")
            if cursor.fetchone()[0] == 0:
                default_iocs = [
                    ("185.220.101.5", "Known Tor Exit Node / Malicious", "Untrusted", 95, "Command & Control / Brute Force"),
                    ("45.33.32.156", "Active Scanner / Exploitation", "Untrusted", 88, "SSH Brute Force"),
                    ("10.0.4.15", "Internal Workstation", "Trusted", 10, "Internal Network"),
                    ("127.0.0.1", "Local Host", "Trusted", 0, "Loopback")
                ]
                cursor.executemany(
                    "INSERT INTO threat_intel_ioc (ip, status, reputation, risk_score, threat_category) VALUES (?, ?, ?, ?, ?)",
                    default_iocs
                )

            conn.commit()

    def lookup_ioc(self, ip: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM threat_intel_ioc WHERE ip = ?", (ip,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def add_ioc(self, ip: str, status: str, reputation: str, risk_score: int, category: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO threat_intel_ioc (ip, status, reputation, risk_score, threat_category)
                VALUES (?, ?, ?, ?, ?)
            """, (ip, status, reputation, risk_score, category))
            conn.commit()

    def save_incident(self, incident: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO historical_incidents (incident_id, incident_name, severity, confidence, affected_host, affected_user, alerts_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                incident.get("incident_id"),
                incident.get("incident_name"),
                incident.get("severity"),
                incident.get("confidence"),
                incident.get("affected_host"),
                incident.get("affected_user"),
                json.dumps(incident.get("alerts", []))
            ))
            conn.commit()

    def record_incident_alerts(
        self,
        incident_id: str,
        alert_keys: List[str],
        metadata: Optional[Dict[str, Any]] = None,
        recent_alerts: Optional[List[Dict[str, Any]]] = None,
    ) -> int:
        """
        Idempotently records unique alert identity hashes for an incident in SQLite
        and optionally updates the bounded recent-evidence snapshot.
        Returns the total cumulative unique alert count for the incident.
        """
        if not incident_id:
            return 0
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if alert_keys:
                cursor.executemany(
                    "INSERT OR IGNORE INTO incident_alert_ledger (incident_id, alert_key) VALUES (?, ?)",
                    [(incident_id, str(k)) for k in alert_keys if k],
                )
            if metadata is not None or recent_alerts is not None:
                cursor.execute(
                    "SELECT metadata_json, recent_alerts_json FROM incident_state_snapshot WHERE incident_id = ?",
                    (incident_id,),
                )
                existing_row = cursor.fetchone()
                meta_str = (
                    json.dumps(metadata, default=str)
                    if metadata is not None
                    else (existing_row["metadata_json"] if existing_row else "{}")
                )
                alerts_str = (
                    json.dumps(recent_alerts, default=str)
                    if recent_alerts is not None
                    else (existing_row["recent_alerts_json"] if existing_row else "[]")
                )
                cursor.execute(
                    """
                    INSERT OR REPLACE INTO incident_state_snapshot (incident_id, metadata_json, recent_alerts_json, updated_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    """,
                    (incident_id, meta_str, alerts_str),
                )
            cursor.execute(
                "SELECT COUNT(*) FROM incident_alert_ledger WHERE incident_id = ?",
                (incident_id,),
            )
            total_count = int(cursor.fetchone()[0])
            conn.commit()
            return total_count

    def get_incident_alert_keys(self, incident_id: Optional[str] = None) -> Dict[str, List[str]]:
        """
        Returns a mapping of incident_id -> list of recorded alert_key hashes.
        """
        result: Dict[str, List[str]] = {}
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if incident_id:
                cursor.execute(
                    "SELECT incident_id, alert_key FROM incident_alert_ledger WHERE incident_id = ?",
                    (incident_id,),
                )
            else:
                cursor.execute("SELECT incident_id, alert_key FROM incident_alert_ledger")
            for row in cursor.fetchall():
                result.setdefault(row["incident_id"], []).append(row["alert_key"])
        return result

    def get_incident_snapshots(self) -> Dict[str, Dict[str, Any]]:
        """
        Returns a mapping of incident_id -> {'metadata': dict, 'recent_alerts': list}
        from the durable SQLite snapshot table.
        """
        snapshots: Dict[str, Dict[str, Any]] = {}
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT incident_id, metadata_json, recent_alerts_json FROM incident_state_snapshot")
            for row in cursor.fetchall():
                try:
                    meta = json.loads(row["metadata_json"] or "{}")
                except Exception:
                    meta = {}
                try:
                    rec_alerts = json.loads(row["recent_alerts_json"] or "[]")
                except Exception:
                    rec_alerts = []
                snapshots[row["incident_id"]] = {
                    "metadata": meta,
                    "recent_alerts": rec_alerts,
                }
        return snapshots

    def save_feedback(self, feedback: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            mitre_val = feedback.get("mitre_techniques")
            if isinstance(mitre_val, (list, tuple, set)):
                mitre_val = json.dumps(list(mitre_val))
            rules_val = feedback.get("rule_ids")
            if isinstance(rules_val, (list, tuple, set)):
                rules_val = json.dumps(list(rules_val))
            cursor.execute("""
                INSERT OR REPLACE INTO analyst_feedback (
                    feedback_id, incident_id, alert_name, analyst_verdict,
                    override_severity, adjusted_confidence, notes,
                    affected_host, affected_user, mitre_techniques,
                    rule_ids, approved_guidance, evidence_fingerprint
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                feedback.get("feedback_id"),
                feedback.get("incident_id"),
                feedback.get("alert_name"),
                feedback.get("analyst_verdict"),
                feedback.get("override_severity"),
                feedback.get("adjusted_confidence"),
                feedback.get("notes"),
                feedback.get("affected_host"),
                feedback.get("affected_user"),
                mitre_val,
                rules_val,
                feedback.get("approved_guidance"),
                feedback.get("evidence_fingerprint"),
            ))
            conn.commit()

    def get_all_feedback(self) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM analyst_feedback ORDER BY created_at DESC, rowid DESC")
            return [dict(row) for row in cursor.fetchall()]


