import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_LOGS_DIR = DATA_DIR / "raw_logs"
PROCESSED_LOGS_DIR = DATA_DIR / "processed_logs"
REPORTS_DIR = DATA_DIR / "reports"
DB_PATH = BASE_DIR / "knowledge_base" / "sentinel_kb.db"

LOG_FILE_PATH = RAW_LOGS_DIR / "windows_logs.json"

# Ensure directories exist
RAW_LOGS_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_LOGS_DIR.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# LLM Configurations
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "fallback")  # Options: 'ollama', 'gemini', 'openai', 'fallback'
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3")
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Detection & Correlation Thresholds
CORRELATION_TIME_WINDOW_MINUTES = 15
BRUTE_FORCE_THRESHOLD = 3
SUSPICIOUS_PROCESS_NAMES = [
    "powershell.exe", "cmd.exe", "wmic.exe", "vssadmin.exe",
    "mimikatz.exe", "whoami.exe", "net.exe", "reg.exe"
]

# Threat Intelligence Configs
THREAT_INTEL_SIMULATED_REPUTATION_THRESHOLD = 70

# Remote Endpoint Ingestion Configs
RECEIVER_HOST = os.getenv("RECEIVER_HOST", "0.0.0.0")
RECEIVER_PORT = int(os.getenv("RECEIVER_PORT", "5000"))
DEFAULT_ENDPOINT_ID = os.getenv("DEFAULT_ENDPOINT_ID", "EP-REMOTE-01")
COLLECTOR_VERSION = os.getenv("COLLECTOR_VERSION", "1.0.0")
PROJECT_TOKEN = os.getenv("PROJECT_TOKEN", "SENTINEL_SECRET_TOKEN_2026")
ENDPOINT_STATUS_FILE_PATH = DATA_DIR / "endpoint_status.json"
HEARTBEAT_TIMEOUT_SECONDS = int(os.getenv("HEARTBEAT_TIMEOUT_SECONDS", "30"))

# NXLog Ingestion Configs
NXLOG_FILE_PATH = Path(os.getenv("NXLOG_FILE_PATH", r"C:\AdaptiveSentinel\windows-events.log"))
NXLOG_CURSOR_FILE_PATH = DATA_DIR / "nxlog_cursor.json"
HARSHA_IP = os.getenv("HARSHA_IP", "10.184.216.159")
SUJITH_IP = os.getenv("SUJITH_IP", "10.184.216.57")
NXLOG_PORT = int(os.getenv("NXLOG_PORT", "2514"))


