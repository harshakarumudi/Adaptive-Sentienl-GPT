param(
    [string]$ReceiverHostname = "Sujith",
    [int]$ReceiverPort = 2514,
    [string]$BootstrapIp = "",
    [string]$NxlogConfPath = "C:\Program Files\nxlog\conf\nxlog.conf",
    [string]$SecretToken = "SENTINEL_SECRET_TOKEN_2026",
    [switch]$Loop,
    [int]$CheckIntervalSeconds = 15,
    [switch]$Once,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

function Test-ValidUnicastIPv4 {
    param([string]$IpString)
    if ([string]::IsNullOrWhiteSpace($IpString)) { return $false }
    $clean = $IpString.Trim().Trim('"', "'")
    [System.Net.IPAddress]$parsed = $null
    if (-not [System.Net.IPAddress]::TryParse($clean, [ref]$parsed)) { return $false }
    if ($parsed.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork) { return $false }
    $str = $parsed.IPAddressToString
    if ($str.StartsWith("127.") -or $str.StartsWith("169.254.") -or $str -eq "0.0.0.0" -or $str -eq "255.255.255.255") {
        return $false
    }
    return $true
}

function Test-ReceiverTcp2514 {
    param([string]$IpAddress, [int]$Port = 2514, [int]$TimeoutMs = 800)
    if (-not (Test-ValidUnicastIPv4 -IpString $IpAddress)) { return $false }
    $cleanIp = $IpAddress.Trim().Trim('"', "'")
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($cleanIp, $Port, $null, $null)
        $connected = $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)
        if ($connected -and $client.Connected) {
            $client.EndConnect($async)
            return $true
        }
        return $false
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Get-NxlogOutputHost {
    param([string]$ConfigText)
    if ([string]::IsNullOrWhiteSpace($ConfigText)) { return $null }
    $outMatches = [regex]::Matches($ConfigText, "(?is)<Output\s+[^>]+>(.*?)</Output>")
    foreach ($m in $outMatches) {
        $block = $m.Groups[1].Value
        if ($block -match "(?i)om_tcp|2514") {
            if ($block -match "(?im)^\s*Host\s+([^\s#;\r\n]+)") {
                return $Matches[1].Trim().Trim('"', "'")
            }
        }
    }
    $noInput = [regex]::Replace($ConfigText, "(?is)<Input\s+[^>]+>.*?</Input>", "")
    if ($noInput -match "(?im)^\s*Host\s+([^\s#;\r\n]+)") {
        return $Matches[1].Trim().Trim('"', "'")
    }
    return $null
}

function Get-HmacSha256Hex {
    param([string]$Secret, [string]$Message)
    $hmac = New-Object System.Security.Cryptography.HMACSHA256
    $hmac.Key = [System.Text.Encoding]::UTF8.GetBytes($Secret)
    $bytes = $hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Message))
    return ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
}

function Invoke-UdpReceiverDiscovery {
    param([string]$ExpectedHostname, [int]$Port = 2514, [string]$Secret = "SENTINEL_SECRET_TOKEN_2026")
    $nonce = "$([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())-$PID"
    $senderHost = $env:COMPUTERNAME
    $senderIp = "0.0.0.0"
    $magic = "ADAPTIVE_SENTINEL_DISCOVERY_V1"
    $ver = "1.0"
    $canonicalReq = "$magic|$ver|DISCOVERY_REQUEST|$senderHost|$senderIp|$Port|$nonce"
    $reqDigest = Get-HmacSha256Hex -Secret $Secret -Message $canonicalReq

    $payloadObj = [ordered]@{
        protocol        = $magic
        version         = $ver
        type            = "DISCOVERY_REQUEST"
        sender_hostname = $senderHost
        sender_ip       = $senderIp
        requested_port  = $Port
        nonce           = $nonce
        auth_digest     = $reqDigest
    }
    $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes(($payloadObj | ConvertTo-Json -Compress))

    $udp = New-Object System.Net.Sockets.UdpClient
    try {
        $udp.EnableBroadcast = $true
        $udp.Client.ReceiveTimeout = 900
        foreach ($bcast in @("255.255.255.255", "127.0.0.1")) {
            try {
                [void]$udp.Send($jsonBytes, $jsonBytes.Length, $bcast, $Port)
            } catch { }
        }
        $remoteEp = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
        $respBytes = $udp.Receive([ref]$remoteEp)
        $respText = [System.Text.Encoding]::UTF8.GetString($respBytes)
        $resp = $respText | ConvertFrom-Json
        if ($resp.protocol -ne $magic -or $resp.type -ne "DISCOVERY_RESPONSE" -or $resp.nonce -ne $nonce) {
            return $null
        }
        $recIp = [string]$resp.receiver_ip
        $recHost = [string]$resp.receiver_hostname
        $recPort = [int]$resp.receiver_port
        $expectedDigest = Get-HmacSha256Hex -Secret $Secret -Message "$magic|$ver|DISCOVERY_RESPONSE|$recHost|$recIp|$recPort|$nonce"
        if ($resp.auth_digest -eq $expectedDigest -and (Test-ValidUnicastIPv4 -IpString $recIp)) {
            return $recIp
        }
    } catch {
        return $null
    } finally {
        $udp.Close()
    }
    return $null
}

function Resolve-ReceiverIp {
    param([string]$Hostname, [int]$Port, [string]$FallbackIp, [string]$Secret)

    $projectRoot = Split-Path -Parent $PSScriptRoot
    $stateFile = Join-Path $projectRoot "data\network_state.json"
    $persistedState = $null
    if (Test-Path -LiteralPath $stateFile) {
        try {
            $persistedState = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
        } catch { }
    }

    $hostCandidates = New-Object System.Collections.Generic.List[string]
    if (-not [string]::IsNullOrWhiteSpace($Hostname)) { $hostCandidates.Add($Hostname.Trim()) }
    if (-not [string]::IsNullOrWhiteSpace($env:RECEIVER_OS_HOSTNAME) -and -not $hostCandidates.Contains($env:RECEIVER_OS_HOSTNAME.Trim())) {
        $hostCandidates.Add($env:RECEIVER_OS_HOSTNAME.Trim())
    }
    if ($persistedState -and $persistedState.receiver_os_hostname -and -not $hostCandidates.Contains([string]$persistedState.receiver_os_hostname)) {
        $hostCandidates.Add([string]$persistedState.receiver_os_hostname)
    }

    # Check if local machine itself is listening on TCP $Port
    $localListening = $false
    try {
        $listenConn = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
        if ($listenConn) { $localListening = $true }
    } catch { }
    if ($localListening -and $env:COMPUTERNAME -and -not $hostCandidates.Contains($env:COMPUTERNAME)) {
        $hostCandidates.Add($env:COMPUTERNAME)
    }

    # Tier 1: Standard Hostname Resolution
    foreach ($candHost in $hostCandidates) {
        try {
            $addrs = [System.Net.Dns]::GetHostAddresses($candHost) |
                Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork }
            if (-not $addrs) {
                Write-Host "  [DIAG] hostname_resolution ($candHost): failed - no IPv4 records" -ForegroundColor DarkGray
                continue
            }
            foreach ($addr in $addrs) {
                $ipStr = $addr.IPAddressToString
                if ($ipStr -match "^192\.168\.(216|222|56)\.") { continue }
                if ((Test-ValidUnicastIPv4 -IpString $ipStr) -and (Test-ReceiverTcp2514 -IpAddress $ipStr -Port $Port)) {
                    Write-Host "  [DIAG] hostname_resolution ($candHost -> $ipStr): verified on TCP $Port" -ForegroundColor Green
                    return @{ Ip = $ipStr; Method = "hostname_resolution ($candHost)" }
                }
                Write-Host "  [DIAG] hostname_resolution ($candHost -> $ipStr): failed - TCP $Port unreachable" -ForegroundColor DarkGray
            }
        } catch {
            Write-Host "  [DIAG] hostname_resolution ($candHost): failed - DNS lookup error" -ForegroundColor DarkGray
        }
    }

    # Tier 2: mDNS (.local) Resolution
    foreach ($candHost in $hostCandidates) {
        $mdnsHost = if ($candHost.ToLower().EndsWith(".local")) { $candHost } else { "$candHost.local" }
        try {
            $addrs = [System.Net.Dns]::GetHostAddresses($mdnsHost) |
                Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork }
            foreach ($addr in $addrs) {
                $ipStr = $addr.IPAddressToString
                if ($ipStr -match "^192\.168\.(216|222|56)\.") { continue }
                if ((Test-ValidUnicastIPv4 -IpString $ipStr) -and (Test-ReceiverTcp2514 -IpAddress $ipStr -Port $Port)) {
                    Write-Host "  [DIAG] mdns_resolution ($mdnsHost -> $ipStr): verified on TCP $Port" -ForegroundColor Green
                    return @{ Ip = $ipStr; Method = "mdns_resolution ($mdnsHost)" }
                }
                Write-Host "  [DIAG] mdns_resolution ($mdnsHost -> $ipStr): failed - TCP $Port unreachable" -ForegroundColor DarkGray
            }
        } catch {
            Write-Host "  [DIAG] mdns_resolution ($mdnsHost): failed - mDNS lookup error" -ForegroundColor DarkGray
        }
    }

    # Tier 3: Authenticated UDP Broadcast Discovery
    $udpIp = Invoke-UdpReceiverDiscovery -ExpectedHostname $Hostname -Port $Port -Secret $Secret
    if ($udpIp) {
        if (Test-ReceiverTcp2514 -IpAddress $udpIp -Port $Port) {
            Write-Host "  [DIAG] udp_broadcast_discovery ($udpIp): verified HMAC + TCP $Port" -ForegroundColor Green
            return @{ Ip = $udpIp; Method = "udp_broadcast_discovery" }
        }
        Write-Host "  [DIAG] udp_broadcast_discovery ($udpIp): failed - TCP $Port unreachable" -ForegroundColor DarkGray
    } else {
        Write-Host "  [DIAG] udp_broadcast_discovery (udp/$Port): failed - no authenticated response within timeout" -ForegroundColor DarkGray
    }

    # Tier 4: Persisted / Active / Bootstrap / Configured Fallback Verification
    $fallbackCandidates = New-Object System.Collections.Generic.List[string]
    if (Test-ValidUnicastIPv4 -IpString $FallbackIp) {
        $fallbackCandidates.Add($FallbackIp.Trim().Trim('"', "'"))
    }
    if ($persistedState) {
        foreach ($prop in @("last_known_receiver_ip", "receiver_ip_current", "sender_destination_ip")) {
            $val = [string]$persistedState.$prop
            if ((Test-ValidUnicastIPv4 -IpString $val) -and -not $fallbackCandidates.Contains($val.Trim())) {
                $fallbackCandidates.Add($val.Trim())
            }
        }
    }

    foreach ($candIp in $fallbackCandidates) {
        if (Test-ReceiverTcp2514 -IpAddress $candIp -Port $Port) {
            Write-Host "  [DIAG] last_known_ip_verified ($candIp): verified on TCP $Port" -ForegroundColor Green
            return @{ Ip = $candIp; Method = "last_known_ip_verified" }
        }
        Write-Host "  [DIAG] last_known_ip_verified ($candIp): failed - TCP $Port unreachable" -ForegroundColor DarkGray
    }

    return $null
}

function Invoke-SyncCycle {
    $currentConfIp = $null
    $raw = ""
    if (Test-Path -LiteralPath $NxlogConfPath) {
        $raw = Get-Content -LiteralPath $NxlogConfPath -Raw
        $currentConfIp = Get-NxlogOutputHost -ConfigText $raw
    }

    $fallback = if (-not [string]::IsNullOrWhiteSpace($BootstrapIp)) { $BootstrapIp } else { $currentConfIp }
    $resolved = Resolve-ReceiverIp -Hostname $ReceiverHostname -Port $ReceiverPort -FallbackIp $fallback -Secret $SecretToken

    if (-not $resolved -or -not $resolved.Ip) {
        $shownConf = if ($currentConfIp) { $currentConfIp } else { "none" }
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [RECONNECTING] Could not verify receiver '$ReceiverHostname' on TCP $ReceiverPort. Keeping current config ($shownConf)." -ForegroundColor Yellow
        return
    }

    $verifiedIp = $resolved.Ip
    $method = $resolved.Method

    if ($currentConfIp -eq $verifiedIp) {
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [CONNECTED] Receiver verified at ${verifiedIp}:${ReceiverPort} via $method. nxlog.conf already up to date." -ForegroundColor Green
        return
    }

    if ($DryRun) {
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [DRY-RUN] Verified receiver at ${verifiedIp}:${ReceiverPort} via $method. Would update nxlog.conf Host from '$currentConfIp' to '$verifiedIp' (service restart skipped)." -ForegroundColor Cyan
        return
    }

    if (-not (Test-Path -LiteralPath $NxlogConfPath)) {
        Write-Warning "NXLog configuration file not found at $NxlogConfPath"
        return
    }

    try {
        $backupPath = "${NxlogConfPath}.bak"
        Copy-Item -LiteralPath $NxlogConfPath -Destination $backupPath -Force
        $updatedRaw = [regex]::Replace($raw, "(?im)(^\s*Host\s+)([^\s#;\r\n]+)", "`${1}$verifiedIp")
        $tmpPath = "${NxlogConfPath}.tmp"
        Set-Content -LiteralPath $tmpPath -Value $updatedRaw -Encoding UTF8
        Move-Item -LiteralPath $tmpPath -Destination $NxlogConfPath -Force
        Restart-Service -Name "nxlog" -Force
        Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [UPDATED] Updated nxlog.conf Host from $currentConfIp to $verifiedIp via $method and restarted nxlog service." -ForegroundColor Green
    } catch {
        Write-Warning "Verified receiver at ${verifiedIp}:${ReceiverPort} via $method, but writing $NxlogConfPath failed (run PowerShell as Administrator): $($_.Exception.Message)"
    }
}

do {
    Invoke-SyncCycle
    if ($Loop -and -not $Once) {
        Start-Sleep -Seconds $CheckIntervalSeconds
    }
} while ($Loop -and -not $Once)
