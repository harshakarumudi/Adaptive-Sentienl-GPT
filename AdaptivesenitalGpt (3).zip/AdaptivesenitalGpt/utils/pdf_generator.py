def create_pdf_report(report_dict: dict) -> bytes:
    """
    Generates a clean, valid PDF binary document for a SOC Incident Report.
    Uses pure Python PDF stream generation for 100% reliability.
    """
    # Extract Report Metadata
    report_id = report_dict.get("report_id", "REP-001")
    incident_name = report_dict.get("incident_name", "Security Incident")
    severity = report_dict.get("severity", "High")
    host = report_dict.get("host", "N/A")
    user = report_dict.get("user", "N/A")
    source_ip = report_dict.get("source_ip", "N/A")
    mitre_tech = report_dict.get("mitre_technique", "T1059")
    mitre_tactic = report_dict.get("mitre_tactic", "Execution")
    exec_summary = report_dict.get("executive_summary", "")
    tech_analysis = report_dict.get("technical_analysis", "")
    threat_status = report_dict.get("status", "Suspicious")
    reputation = report_dict.get("reputation", "Untrusted")
    risk_score = report_dict.get("risk_score", 75)
    recommendation = report_dict.get("recommendation", "")
    timestamp = report_dict.get("timestamp", "")

    # Helper function to sanitize text for PDF standard encoding
    def sanitize(text):
        if not text:
            return ""
        return str(text).replace("(", "\\(").replace(")", "\\)").replace("\r", "")

    # Build PDF Content Lines
    content_lines = [
        "=======================================================================",
        "                   ADAPTIVESENTINELGPT - SOC INCIDENT REPORT",
        "=======================================================================",
        f"Report ID        : {sanitize(report_id)}",
        f"Timestamp        : {sanitize(timestamp)}",
        f"Incident Name    : {sanitize(incident_name)}",
        f"Severity         : {sanitize(severity)}",
        f"Target Host      : {sanitize(host)}",
        f"Target User      : {sanitize(user)}",
        f"Source IP        : {sanitize(source_ip)}",
        f"MITRE Mapping    : {sanitize(mitre_tech)} ({sanitize(mitre_tactic)})",
        "-----------------------------------------------------------------------",
        "",
        "1. EXECUTIVE SUMMARY:",
        f"   {sanitize(exec_summary)}",
        "",
        "2. TECHNICAL ANALYSIS & COMMAND TRAIL:",
        f"   {sanitize(tech_analysis)}",
        "",
        "3. THREAT INTELLIGENCE & RISK PROFILE:",
        f"   Threat Status : {sanitize(threat_status)}",
        f"   Reputation    : {sanitize(reputation)}",
        f"   Risk Score    : {risk_score} / 100",
        "",
        "4. STRATEGIC REMEDIATION & ACTION PLAN:",
        f"   {sanitize(recommendation)}",
        "======================================================================="
    ]

    # Convert content lines to PDF text operators
    stream_content = "BT\n/F1 10 Tf\n12 TL\n50 750 Td\n"
    for line in content_lines:
        stream_content += f"({sanitize(line)}) Tj T*\n"
    stream_content += "ET\n"

    stream_bytes = stream_content.encode("latin-1", errors="replace")
    stream_len = len(stream_bytes)

    # Construct compliant PDF objects
    pdf_parts = []
    pdf_parts.append(b"%PDF-1.4\n")

    offsets = []
    current_offset = len(pdf_parts[0])

    # Object 1: Catalog
    obj1 = b"1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"
    offsets.append(current_offset)
    pdf_parts.append(obj1)
    current_offset += len(obj1)

    # Object 2: Pages
    obj2 = b"2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n"
    offsets.append(current_offset)
    pdf_parts.append(obj2)
    current_offset += len(obj2)

    # Object 3: Page
    obj3 = b"3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n"
    offsets.append(current_offset)
    pdf_parts.append(obj3)
    current_offset += len(obj3)

    # Object 4: Stream
    obj4_header = f"4 0 obj\n<< /Length {stream_len} >>\nstream\n".encode("latin-1")
    obj4_footer = b"\nendstream\nendobj\n"
    obj4 = obj4_header + stream_bytes + obj4_footer
    offsets.append(current_offset)
    pdf_parts.append(obj4)
    current_offset += len(obj4)

    # Object 5: Font
    obj5 = b"5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>\nendobj\n"
    offsets.append(current_offset)
    pdf_parts.append(obj5)
    current_offset += len(obj5)

    # Xref Table
    xref_offset = current_offset
    xref = f"xref\n0 6\n0000000000 65535 f \n".encode("latin-1")
    for off in offsets:
        xref += f"{off:010d} 00000 n \n".encode("latin-1")

    trailer = f"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref_offset}\n%%EOF\n".encode("latin-1")

    pdf_parts.append(xref)
    pdf_parts.append(trailer)

    return b"".join(pdf_parts)
