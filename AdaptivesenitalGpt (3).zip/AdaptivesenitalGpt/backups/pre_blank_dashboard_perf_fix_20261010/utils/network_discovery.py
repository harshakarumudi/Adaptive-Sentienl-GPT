import hashlib
import hmac
import ipaddress
import json
import os
import re
import socket
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple


DISCOVERY_PROTOCOL_MAGIC = "ADAPTIVE_SENTINEL_DISCOVERY_V1"
DISCOVERY_PROTOCOL_VERSION = "1.0"
DEFAULT_RECEIVER_PORT = 2514

VIRTUAL_ADAPTER_KEYWORDS = (
    "vmware",
    "vmnet",
    "virtualbox",
    "vbox",
    "vethernet",
    "wsl",
    "hyper-v",
    "docker",
    "loopback",
    "tap-windows",
    "npcap",
    "bluetooth",
    "teredo",
    "isatap",
    "tailscale",
    "zerotier",
)

PHYSICAL_ADAPTER_PREFERENCE = (
    "wi-fi",
    "wifi",
    "wlan",
    "wireless",
    "ethernet",
    "eth",
    "en0",
    "en1",
)

INVALID_NETWORK_TOKENS = {
    "",
    "-",
    "N/A",
    "NA",
    "NONE",
    "NULL",
    "UNKNOWN",
    "UNKNOWN_HOST",
    "127.0.0.1",
    "::1",
    "0.0.0.0",
    "LOCALHOST",
}


def is_valid_unicast_ipv4(ip_str: Any) -> bool:
    """
    Returns True if ip_str is a valid, usable non-loopback, non-link-local,
    non-multicast, non-unspecified IPv4 address.
    """
    if ip_str is None:
        return False
    text = str(ip_str).strip()
    if not text or text.upper() in INVALID_NETWORK_TOKENS:
        return False
    try:
        addr = ipaddress.ip_address(text)
        if not isinstance(addr, ipaddress.IPv4Address):
            return False
        if (
            addr.is_loopback
            or addr.is_link_local
            or addr.is_multicast
            or addr.is_unspecified
            or text == "255.255.255.255"
        ):
            return False
        return True
    except ValueError:
        return False


def is_virtual_adapter_name(adapter_name: str) -> bool:
    """Returns True if the interface alias/description matches known virtual/VPN adapters."""
    lower = str(adapter_name or "").strip().lower()
    return any(keyword in lower for keyword in VIRTUAL_ADAPTER_KEYWORDS)


def score_network_adapter(adapter_name: str, ip_addr: str, preferred_route_ip: Optional[str] = None) -> int:
    """
    Computes a priority score for selecting the active local network interface.
    Higher score is better. Physical Wi-Fi/Ethernet adapters and the OS default route win
    over virtual adapters (VMware, VirtualBox, WSL, Hyper-V).
    """
    if not is_valid_unicast_ipv4(ip_addr):
        return -1000

    score = 100
    name_lower = str(adapter_name or "").strip().lower()

    if is_virtual_adapter_name(name_lower):
        score -= 80
    else:
        score += 40

    for idx, keyword in enumerate(PHYSICAL_ADAPTER_PREFERENCE):
        if keyword in name_lower:
            score += (30 - idx * 2)
            break

    if preferred_route_ip and ip_addr == preferred_route_ip and not is_virtual_adapter_name(name_lower):
        score += 60

    return score


def probe_os_route_ip() -> Optional[str]:
    """
    Uses a non-transmitting UDP socket connect lookup to identify the OS-preferred
    outbound IPv4 interface address.
    """
    for target in (("10.255.255.255", 1), ("8.8.8.8", 80), ("1.1.1.1", 53)):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.settimeout(0.1)
                sock.connect(target)
                candidate = sock.getsockname()[0]
                if is_valid_unicast_ipv4(candidate):
                    return candidate
        except Exception:
            continue
    return None


def compute_subnet_broadcast(ip_addr: str, subnet_mask: Optional[str] = None) -> Optional[str]:
    """
    Computes the directed IPv4 subnet broadcast address for (ip_addr, subnet_mask).
    For example, 11.12.7.72 with mask 255.255.224.0 (/19) yields 11.12.31.255.
    """
    if not is_valid_unicast_ipv4(ip_addr):
        return None
    mask = str(subnet_mask or "").strip()
    if not mask:
        parts = ip_addr.strip().split(".")
        return f"{parts[0]}.{parts[1]}.{parts[2]}.255"
    try:
        iface = ipaddress.IPv4Interface(f"{ip_addr.strip()}/{mask}")
        bcast = str(iface.network.broadcast_address)
        return bcast if bcast != "255.255.255.255" else None
    except Exception:
        parts = ip_addr.strip().split(".")
        return f"{parts[0]}.{parts[1]}.{parts[2]}.255"


def enumerate_windows_ipv4_interfaces(timeout_sec: float = 1.5) -> List[Dict[str, str]]:
    """
    Enumerates active IPv4 interfaces on Windows using ipconfig output parsing
    (fast, no PowerShell startup overhead, works without elevation).
    Returns a list of dicts: [{'interface': <name>, 'ip': <ipv4>, 'subnet_mask': <mask>}].
    """
    interfaces: List[Dict[str, str]] = []
    if os.name != "nt":
        return interfaces

    try:
        proc = subprocess.run(
            ["ipconfig"],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode != 0 or not proc.stdout:
            return interfaces

        current_adapter = "Local Network"
        last_entry: Optional[Dict[str, str]] = None
        for raw_line in proc.stdout.splitlines():
            line = raw_line.rstrip()
            if not line:
                continue
            # Adapter headers do not start with whitespace and end with ':'
            if not raw_line.startswith((" ", "\t")) and line.endswith(":"):
                header = line[:-1].strip()
                header = re.sub(
                    r"^(Wireless LAN adapter|Ethernet adapter|Unknown adapter|PPP adapter)\s+",
                    "",
                    header,
                    flags=re.IGNORECASE,
                ).strip()
                if header:
                    current_adapter = header
                last_entry = None
                continue

            if "Media State" in line and "disconnected" in line.lower():
                last_entry = None
                continue

            if "IPv4 Address" in line or "IP Address" in line:
                m = re.search(r":\s*([0-9]{1,3}(?:\.[0-9]{1,3}){3})", line)
                if m:
                    ip_val = m.group(1).strip()
                    if is_valid_unicast_ipv4(ip_val):
                        last_entry = {
                            "interface": current_adapter,
                            "ip": ip_val,
                        }
                        interfaces.append(last_entry)
                continue

            if "Subnet Mask" in line and last_entry is not None and last_entry.get("interface") == current_adapter:
                m_mask = re.search(r":\s*([0-9]{1,3}(?:\.[0-9]{1,3}){3})", line)
                if m_mask:
                    last_entry["subnet_mask"] = m_mask.group(1).strip()
    except Exception:
        pass

    return interfaces


def detect_active_interface_and_ip(
    interfaces_provider: Optional[Callable[[], List[Dict[str, str]]]] = None,
    route_ip_provider: Optional[Callable[[], Optional[str]]] = None,
) -> Tuple[str, str]:
    """
    Determines the active network interface name and IPv4 address.
    Avoids loopback, disconnected, APIPA, and virtual adapters (VMware/VirtualBox/WSL)
    whenever a real Wi-Fi/Ethernet interface is active.
    Returns (interface_name, ipv4_address). If no active interface is available,
    returns ('Disconnected', '127.0.0.1').
    """
    route_ip = route_ip_provider() if route_ip_provider else probe_os_route_ip()
    candidates = interfaces_provider() if interfaces_provider else enumerate_windows_ipv4_interfaces()

    valid_candidates = [
        c for c in candidates
        if is_valid_unicast_ipv4(c.get("ip"))
    ]

    if valid_candidates:
        scored = sorted(
            valid_candidates,
            key=lambda c: score_network_adapter(c.get("interface", ""), c.get("ip", ""), route_ip),
            reverse=True,
        )
        best = scored[0]
        return str(best.get("interface") or "Active-LAN"), str(best["ip"])

    if route_ip and is_valid_unicast_ipv4(route_ip):
        return "Active-IPv4", route_ip

    return "Disconnected", "127.0.0.1"


def inspect_tcp_port_connections(
    port: int = DEFAULT_RECEIVER_PORT,
    netstat_provider: Optional[Callable[[], str]] = None,
    receiver_ip: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Inspects the OS TCP connection table (`netstat -ano -p tcp`) for the specified port
    (default 2514) to determine:
      - whether the receiver port is actively in LISTENING state
      - all active ESTABLISHED remote peer IPs connected to local port `port`
    Never confuses the local receiver IP with a remote sender peer IP.
    """
    result: Dict[str, Any] = {
        "port": int(port),
        "is_listening": False,
        "listen_addresses": [],
        "established_peers": [],
        "remote_peer_ips": [],
        "outbound_receiver_ips": [],
    }

    output = ""
    if netstat_provider is not None:
        output = netstat_provider() or ""
    else:
        try:
            proc = subprocess.run(
                ["netstat", "-ano", "-p", "tcp"],
                capture_output=True,
                text=True,
                timeout=1.5,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if proc.returncode == 0 and proc.stdout:
                output = proc.stdout
        except Exception:
            output = ""

    port_suffix = f":{int(port)}"
    seen_peers = set()
    seen_outbound = set()
    active_rec_ip = str(receiver_ip or "").strip()

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or port_suffix not in line:
            continue
        parts = line.split()
        if len(parts) < 4 or parts[0].upper() != "TCP":
            continue

        local_ep = parts[1]
        remote_ep = parts[2]
        state = parts[3].upper()
        pid = parts[4] if len(parts) >= 5 else ""

        local_ip = local_ep.rsplit(":", 1)[0].strip("[]")
        remote_ip = remote_ep.rsplit(":", 1)[0].strip("[]")

        if remote_ep.endswith(port_suffix) and not local_ep.endswith(port_suffix):
            if state == "ESTABLISHED" and is_valid_unicast_ipv4(remote_ip) and remote_ip not in seen_outbound:
                seen_outbound.add(remote_ip)
                result["outbound_receiver_ips"].append(remote_ip)
            continue

        if not local_ep.endswith(port_suffix):
            continue

        try:
            remote_port = int(remote_ep.rsplit(":", 1)[1])
        except Exception:
            remote_port = 0

        if state in ("LISTENING", "LISTEN"):
            result["is_listening"] = True
            if local_ep not in result["listen_addresses"]:
                result["listen_addresses"].append(local_ep)
        elif state == "ESTABLISHED":
            if is_valid_unicast_ipv4(remote_ip) and remote_ip != active_rec_ip and remote_ip != local_ip:
                result["established_peers"].append({
                    "local_ip": local_ip,
                    "local_port": int(port),
                    "remote_ip": remote_ip,
                    "remote_port": remote_port,
                    "pid": pid,
                })
                if remote_ip not in seen_peers:
                    seen_peers.add(remote_ip)
                    result["remote_peer_ips"].append(remote_ip)

    return result


def compute_discovery_hmac(
    secret_token: str,
    protocol: str,
    version: str,
    msg_type: str,
    hostname: str,
    ip_addr: str,
    port: int,
    nonce: str,
) -> str:
    """Computes an HMAC-SHA256 authentication digest for discovery messages."""
    canonical = f"{protocol}|{version}|{msg_type}|{hostname}|{ip_addr}|{int(port)}|{nonce}"
    return hmac.new(
        secret_token.encode("utf-8"),
        canonical.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def build_discovery_request(
    sender_hostname: str,
    sender_ip: str,
    requested_port: int = DEFAULT_RECEIVER_PORT,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
    nonce: Optional[str] = None,
) -> Dict[str, Any]:
    """Constructs a signed UDP discovery request packet."""
    req_nonce = nonce or f"{int(time.time() * 1000)}-{os.getpid()}"
    digest = compute_discovery_hmac(
        secret_token=secret_token,
        protocol=DISCOVERY_PROTOCOL_MAGIC,
        version=DISCOVERY_PROTOCOL_VERSION,
        msg_type="DISCOVERY_REQUEST",
        hostname=sender_hostname,
        ip_addr=sender_ip,
        port=requested_port,
        nonce=req_nonce,
    )
    return {
        "protocol": DISCOVERY_PROTOCOL_MAGIC,
        "version": DISCOVERY_PROTOCOL_VERSION,
        "type": "DISCOVERY_REQUEST",
        "sender_hostname": sender_hostname,
        "sender_ip": sender_ip,
        "requested_port": int(requested_port),
        "nonce": req_nonce,
        "auth_digest": digest,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def build_discovery_response(
    receiver_hostname: str,
    receiver_ip: str,
    receiver_port: int = DEFAULT_RECEIVER_PORT,
    network_interface: str = "Wi-Fi",
    request_nonce: str = "",
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
) -> Dict[str, Any]:
    """Constructs a signed UDP discovery response packet from the receiver."""
    digest = compute_discovery_hmac(
        secret_token=secret_token,
        protocol=DISCOVERY_PROTOCOL_MAGIC,
        version=DISCOVERY_PROTOCOL_VERSION,
        msg_type="DISCOVERY_RESPONSE",
        hostname=receiver_hostname,
        ip_addr=receiver_ip,
        port=receiver_port,
        nonce=request_nonce,
    )
    return {
        "protocol": DISCOVERY_PROTOCOL_MAGIC,
        "version": DISCOVERY_PROTOCOL_VERSION,
        "type": "DISCOVERY_RESPONSE",
        "receiver_hostname": receiver_hostname,
        "receiver_ip": receiver_ip,
        "receiver_port": int(receiver_port),
        "network_interface": network_interface,
        "nonce": request_nonce,
        "auth_digest": digest,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def validate_discovery_request(
    payload: Dict[str, Any],
    expected_port: int = DEFAULT_RECEIVER_PORT,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
) -> Tuple[bool, str]:
    """Validates an incoming UDP discovery request before responding."""
    if not isinstance(payload, dict):
        return False, "Payload is not a JSON object"
    if payload.get("protocol") != DISCOVERY_PROTOCOL_MAGIC:
        return False, "Invalid discovery protocol header"
    if str(payload.get("version")) != DISCOVERY_PROTOCOL_VERSION:
        return False, "Unsupported discovery protocol version"
    if payload.get("type") != "DISCOVERY_REQUEST":
        return False, "Invalid discovery packet type"
    if int(payload.get("requested_port", 0) or 0) != int(expected_port):
        return False, f"Requested port does not match {expected_port}"

    sender_host = str(payload.get("sender_hostname") or "").strip()
    sender_ip = str(payload.get("sender_ip") or "").strip()
    nonce = str(payload.get("nonce") or "").strip()
    digest = str(payload.get("auth_digest") or "").strip()
    if not sender_host or not nonce or not digest:
        return False, "Missing mandatory request fields"

    expected_digest = compute_discovery_hmac(
        secret_token=secret_token,
        protocol=DISCOVERY_PROTOCOL_MAGIC,
        version=DISCOVERY_PROTOCOL_VERSION,
        msg_type="DISCOVERY_REQUEST",
        hostname=sender_host,
        ip_addr=sender_ip,
        port=expected_port,
        nonce=nonce,
    )
    if not hmac.compare_digest(digest, expected_digest):
        return False, "HMAC signature verification failed"

    return True, "VALID"


def validate_discovery_response(
    payload: Dict[str, Any],
    expected_port: int = DEFAULT_RECEIVER_PORT,
    expected_nonce: Optional[str] = None,
    expected_hostname: Optional[str] = None,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
) -> Tuple[bool, str]:
    """
    Validates a UDP discovery response from a candidate receiver.
    Rejects malformed JSON, wrong protocol headers, mismatched nonces, invalid IPs,
    wrong ports, or spoofed/unauthenticated responses.
    """
    if not isinstance(payload, dict):
        return False, "Discovery response is not a JSON object"
    if payload.get("protocol") != DISCOVERY_PROTOCOL_MAGIC:
        return False, "Invalid discovery protocol magic"
    if str(payload.get("version")) != DISCOVERY_PROTOCOL_VERSION:
        return False, "Unsupported discovery protocol version"
    if payload.get("type") != "DISCOVERY_RESPONSE":
        return False, "Packet type is not DISCOVERY_RESPONSE"

    rec_ip = str(payload.get("receiver_ip") or "").strip()
    if not is_valid_unicast_ipv4(rec_ip):
        return False, f"Invalid receiver IP in response: {rec_ip}"

    try:
        rec_port = int(payload.get("receiver_port", 0))
    except (TypeError, ValueError):
        return False, "Non-integer receiver_port in response"

    if rec_port != int(expected_port):
        return False, f"Unexpected receiver_port {rec_port} (expected {expected_port})"

    rec_host = str(payload.get("receiver_hostname") or "").strip()
    if not rec_host:
        return False, "Missing receiver_hostname in response"

    if expected_hostname and expected_hostname.strip():
        exp_lower = expected_hostname.strip().lower()
        os_host_lower = str(payload.get("receiver_os_hostname") or "").strip().lower()
        allowed_hosts = {exp_lower}
        if os_host_lower:
            allowed_hosts.add(os_host_lower)
        for env_h in (os.getenv("RECEIVER_HOSTNAME", ""), os.getenv("RECEIVER_OS_HOSTNAME", ""), "sujith"):
            if env_h and env_h.strip():
                allowed_hosts.add(env_h.strip().lower())
        try:
            local_h = socket.gethostname().strip().lower()
            if local_h:
                allowed_hosts.add(local_h)
        except Exception:
            pass
        if rec_host.lower() not in allowed_hosts:
            return False, f"Receiver hostname mismatch: got {rec_host}, expected {expected_hostname}"

    resp_nonce = str(payload.get("nonce") or "").strip()
    if expected_nonce is not None and resp_nonce != expected_nonce:
        return False, "Discovery response nonce mismatch"

    digest = str(payload.get("auth_digest") or "").strip()
    expected_digest = compute_discovery_hmac(
        secret_token=secret_token,
        protocol=DISCOVERY_PROTOCOL_MAGIC,
        version=DISCOVERY_PROTOCOL_VERSION,
        msg_type="DISCOVERY_RESPONSE",
        hostname=rec_host,
        ip_addr=rec_ip,
        port=rec_port,
        nonce=resp_nonce,
    )
    if not digest or not hmac.compare_digest(digest, expected_digest):
        return False, "Invalid discovery response HMAC signature"

    return True, "VALID"


def verify_tcp_port(ip_addr: str, port: int = DEFAULT_RECEIVER_PORT, timeout_sec: float = 0.75) -> bool:
    """
    Verifies that a candidate receiver IP is reachable over TCP on `port` (default 2514).
    """
    if not is_valid_unicast_ipv4(ip_addr):
        return False
    try:
        with socket.create_connection((ip_addr.strip(), int(port)), timeout=timeout_sec):
            return True
    except Exception:
        return False


def verify_tcp_receiver(ip_addr: str, port: int = DEFAULT_RECEIVER_PORT, timeout_sec: float = 0.75) -> bool:
    """Alias for verify_tcp_port preserving backward compatibility."""
    return verify_tcp_port(ip_addr=ip_addr, port=port, timeout_sec=timeout_sec)


def resolve_hostname_candidates(hostname: str, port: int = DEFAULT_RECEIVER_PORT) -> List[str]:
    """
    Resolves a hostname to candidate non-loopback, non-virtual IPv4 addresses.
    When resolving on a multi-homed Windows host, filters out known virtual adapter IPs
    (VMware, VirtualBox, WSL, Hyper-V) whenever a physical Wi-Fi/Ethernet IP is present
    and orders candidates by adapter priority score.
    """
    raw_candidates: List[str] = []
    if not hostname or not str(hostname).strip():
        return raw_candidates
    try:
        infos = socket.getaddrinfo(str(hostname).strip(), int(port), socket.AF_INET, socket.SOCK_STREAM)
        for info in infos:
            sockaddr = info[4]
            if sockaddr and len(sockaddr) >= 1:
                ip_val = str(sockaddr[0]).strip()
                if is_valid_unicast_ipv4(ip_val) and ip_val not in raw_candidates:
                    raw_candidates.append(ip_val)
    except Exception:
        return []

    if len(raw_candidates) <= 1:
        return raw_candidates

    # Cross-reference with local interfaces so virtual adapter IPs (e.g. VMware 192.168.x.1)
    # are deprioritized/filtered when a physical Wi-Fi/Ethernet IP is present.
    local_ifaces = enumerate_windows_ipv4_interfaces()
    ip_to_iface = {str(item.get("ip")): str(item.get("interface", "")) for item in local_ifaces if item.get("ip")}
    route_ip = probe_os_route_ip()

    non_virtual = [
        ip for ip in raw_candidates
        if not (ip in ip_to_iface and is_virtual_adapter_name(ip_to_iface[ip]))
    ]
    pool = non_virtual if non_virtual else raw_candidates
    return sorted(
        pool,
        key=lambda ip: score_network_adapter(ip_to_iface.get(ip, "Wi-Fi"), ip, route_ip),
        reverse=True,
    )


def discover_receiver_via_udp(
    sender_hostname: str,
    sender_ip: str,
    port: int = DEFAULT_RECEIVER_PORT,
    expected_receiver_hostname: Optional[str] = None,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
    timeout_sec: float = 1.0,
    broadcast_targets: Optional[List[str]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Broadcasts a signed UDP discovery request on port `port` (default 2514) and waits
    for a valid, HMAC-verified DISCOVERY_RESPONSE.
    """
    req = build_discovery_request(
        sender_hostname=sender_hostname or "Sender-Endpoint",
        sender_ip=sender_ip or "0.0.0.0",
        requested_port=port,
        secret_token=secret_token,
    )
    raw_bytes = json.dumps(req).encode("utf-8")

    targets = list(broadcast_targets or [])
    local_ifaces = enumerate_windows_ipv4_interfaces()
    local_ip_set = {str(item.get("ip")) for item in local_ifaces if item.get("ip")}

    if not targets:
        if is_valid_unicast_ipv4(sender_ip):
            # 1. Exact subnet broadcast from active interface mask (e.g. /19 -> 11.12.31.255)
            matched_mask = None
            for item in local_ifaces:
                if item.get("ip") == sender_ip and item.get("subnet_mask"):
                    matched_mask = item["subnet_mask"]
                    break
            directed_bcast = compute_subnet_broadcast(sender_ip, matched_mask)
            if directed_bcast and directed_bcast not in targets:
                targets.append(directed_bcast)

            # 2. /24 broadcast fallback
            parts = sender_ip.split(".")
            slash24_bcast = f"{parts[0]}.{parts[1]}.{parts[2]}.255"
            if slash24_bcast not in targets:
                targets.append(slash24_bcast)

        if "255.255.255.255" not in targets:
            targets.append("255.255.255.255")
        if "127.0.0.1" not in targets:
            targets.append("127.0.0.1")

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            # Bind to active physical interface IP when available so Windows routes
            # broadcast packets out Wi-Fi/Ethernet instead of VMware/VirtualBox adapters.
            if is_valid_unicast_ipv4(sender_ip) and sender_ip in local_ip_set:
                try:
                    sock.bind((sender_ip, 0))
                except Exception:
                    pass
            sock.settimeout(timeout_sec)
            for target_ip in targets:
                try:
                    sock.sendto(raw_bytes, (target_ip, int(port)))
                except Exception:
                    continue

            deadline = time.monotonic() + timeout_sec
            while time.monotonic() < deadline:
                remaining = max(0.05, deadline - time.monotonic())
                sock.settimeout(remaining)
                try:
                    data, peer_addr = sock.recvfrom(4096)
                except socket.timeout:
                    break
                except Exception:
                    break

                try:
                    resp = json.loads(data.decode("utf-8"))
                except Exception:
                    continue

                if not is_valid_unicast_ipv4(resp.get("receiver_ip")) and peer_addr and is_valid_unicast_ipv4(peer_addr[0]):
                    resp["receiver_ip"] = peer_addr[0]

                is_ok, _ = validate_discovery_response(
                    resp,
                    expected_port=port,
                    expected_nonce=req["nonce"],
                    expected_hostname=expected_receiver_hostname,
                    secret_token=secret_token,
                )
                if is_ok:
                    return resp
    except Exception:
        pass

    return None


def load_configured_discovery_fallbacks(
    receiver_hostname: str = "Sujith",
    port: int = DEFAULT_RECEIVER_PORT,
    state_file_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Loads receiver hostname aliases and fallback receiver IPs from persisted state
    (`data/network_state.json`, `data/sender_network_state.json`), environment variables,
    and local TCP 2514 listener inspection.
    Never returns unverified IPs as trusted; every returned candidate must still pass
    `verify_tcp_port(ip, 2514)`.
    """
    project_root = Path(__file__).resolve().parent.parent
    state_files = []
    if state_file_path:
        state_files.append(Path(state_file_path))
    else:
        state_files.extend([
            project_root / "data" / "network_state.json",
            project_root / "data" / "sender_network_state.json",
        ])

    persisted_records: List[Dict[str, Any]] = []
    for sf in state_files:
        if sf.exists():
            try:
                data = json.loads(sf.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    persisted_records.append(data)
            except Exception:
                continue

    # 1. Candidate receiver hostnames (logical name + actual OS hostname when known/local)
    candidate_hostnames: List[str] = []
    for raw_h in (
        receiver_hostname,
        os.getenv("RECEIVER_HOSTNAME", ""),
        os.getenv("RECEIVER_OS_HOSTNAME", ""),
    ):
        h_clean = str(raw_h or "").strip()
        if h_clean and h_clean.upper() not in INVALID_NETWORK_TOKENS and h_clean not in candidate_hostnames:
            candidate_hostnames.append(h_clean)

    for rec in persisted_records:
        for h_key in ("receiver_os_hostname", "receiver_hostname"):
            h_val = str(rec.get(h_key) or "").strip()
            if h_val and h_val.upper() not in INVALID_NETWORK_TOKENS and h_val not in candidate_hostnames:
                candidate_hostnames.append(h_val)

    # Check if local machine itself is listening on TCP `port` (e.g. Sujith's receiver laptop)
    tcp_info = inspect_tcp_port_connections(port=port)
    is_local_receiver = bool(tcp_info.get("is_listening"))
    if is_local_receiver:
        try:
            local_os_host = socket.gethostname().strip()
            if local_os_host and local_os_host not in candidate_hostnames:
                candidate_hostnames.append(local_os_host)
        except Exception:
            pass

    # 2. Candidate fallback IPs (for Tier 4 verification)
    candidate_ips: List[str] = []
    for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
        val = os.getenv(env_key, "").strip()
        if is_valid_unicast_ipv4(val) and val not in candidate_ips:
            candidate_ips.append(val)

    for rec in persisted_records:
        for ip_key in ("last_known_receiver_ip", "receiver_ip_current", "sender_destination_ip"):
            ip_val = str(rec.get(ip_key) or "").strip()
            if is_valid_unicast_ipv4(ip_val) and ip_val not in candidate_ips:
                candidate_ips.append(ip_val)

    for out_ip in tcp_info.get("outbound_receiver_ips", []):
        if is_valid_unicast_ipv4(out_ip) and out_ip not in candidate_ips:
            candidate_ips.append(out_ip)

    if is_local_receiver:
        _, local_active_ip = detect_active_interface_and_ip()
        if is_valid_unicast_ipv4(local_active_ip) and local_active_ip not in candidate_ips:
            candidate_ips.append(local_active_ip)

    return {
        "candidate_hostnames": candidate_hostnames,
        "candidate_ips": candidate_ips,
        "is_local_receiver": is_local_receiver,
    }


def discover_receiver_endpoint(
    receiver_hostname: str = "Sujith",
    port: int = DEFAULT_RECEIVER_PORT,
    sender_hostname: str = "Harsha",
    sender_ip: Optional[str] = None,
    last_known_receiver_ip: Optional[str] = None,
    manual_bootstrap_ip: Optional[str] = None,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
    hostname_resolver: Optional[Callable[[str, int], List[str]]] = None,
    udp_discoverer: Optional[Callable[[], Optional[Dict[str, Any]]]] = None,
    tcp_verifier: Optional[Callable[[str, int], bool]] = None,
    state_file_path: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Executes the multi-tier receiver discovery workflow in strict priority order:
      1. Resolvable receiver hostname (e.g. 'Sujith' and configured/OS receiver hostname)
      2. mDNS / .local hostname resolution (e.g. 'Sujith.local')
      3. Validated UDP broadcast discovery on port 2514
      4. Last known receiver IP (from parameter or persisted network_state.json / local listener)
         or manual bootstrap fallback
    Every candidate IP MUST pass TCP port 2514 reachability verification before being trusted.
    Records targeted diagnostic entries for every discovery method attempted and its failure reason.
    """
    use_config_fallbacks = (
        state_file_path is not None
        or (hostname_resolver is None and udp_discoverer is None and tcp_verifier is None)
    )
    resolver = hostname_resolver or resolve_hostname_candidates
    verifier = tcp_verifier or verify_tcp_port
    active_sender_ip = sender_ip or detect_active_interface_and_ip()[1]

    attempts: List[str] = []
    diagnostics: List[Dict[str, Any]] = []

    host_candidates: List[str] = []
    if receiver_hostname and receiver_hostname.strip():
        host_candidates.append(receiver_hostname.strip())

    fallback_info: Dict[str, Any] = {"candidate_hostnames": [], "candidate_ips": []}
    if use_config_fallbacks:
        fallback_info = load_configured_discovery_fallbacks(
            receiver_hostname=receiver_hostname,
            port=port,
            state_file_path=state_file_path,
        )
        if hostname_resolver is None:
            for extra_h in fallback_info.get("candidate_hostnames", []):
                if extra_h not in host_candidates:
                    host_candidates.append(extra_h)

    # 1. Standard Hostname Resolution
    for host_clean in host_candidates:
        resolved_ips = resolver(host_clean, port)
        if not resolved_ips:
            attempts.append(f"hostname:{host_clean}->no_ipv4_records")
            diagnostics.append({
                "method": "hostname_resolution",
                "target": host_clean,
                "status": "failed",
                "reason": f"DNS/NetBIOS lookup returned no IPv4 records for '{host_clean}'",
            })
            continue
        for ip_cand in resolved_ips:
            attempts.append(f"hostname:{host_clean}->{ip_cand}")
            if verifier(ip_cand, port):
                diagnostics.append({
                    "method": "hostname_resolution",
                    "target": f"{host_clean} ({ip_cand}:{port})",
                    "status": "verified",
                    "reason": f"Resolved '{host_clean}' to {ip_cand} and verified TCP port {port}",
                })
                return {
                    "success": True,
                    "receiver_ip": ip_cand,
                    "receiver_port": int(port),
                    "receiver_hostname": receiver_hostname or host_clean,
                    "resolved_hostname": host_clean,
                    "discovery_method": "hostname_resolution",
                    "attempts": attempts,
                    "diagnostics": diagnostics,
                    "error": None,
                }
            diagnostics.append({
                "method": "hostname_resolution",
                "target": f"{host_clean} ({ip_cand}:{port})",
                "status": "failed",
                "reason": f"Resolved '{host_clean}' to {ip_cand}, but TCP port {port} was unreachable",
            })

    # 2. mDNS (.local) Resolution
    for host_clean in host_candidates:
        mdns_host = host_clean if host_clean.lower().endswith(".local") else f"{host_clean}.local"
        resolved_mdns = resolver(mdns_host, port)
        if not resolved_mdns:
            attempts.append(f"mdns:{mdns_host}->no_ipv4_records")
            diagnostics.append({
                "method": "mdns_resolution",
                "target": mdns_host,
                "status": "failed",
                "reason": f"mDNS lookup returned no IPv4 records for '{mdns_host}'",
            })
            continue
        for ip_cand in resolved_mdns:
            attempts.append(f"mdns:{mdns_host}->{ip_cand}")
            if verifier(ip_cand, port):
                diagnostics.append({
                    "method": "mdns_resolution",
                    "target": f"{mdns_host} ({ip_cand}:{port})",
                    "status": "verified",
                    "reason": f"Resolved mDNS '{mdns_host}' to {ip_cand} and verified TCP port {port}",
                })
                return {
                    "success": True,
                    "receiver_ip": ip_cand,
                    "receiver_port": int(port),
                    "receiver_hostname": receiver_hostname or host_clean,
                    "resolved_hostname": mdns_host,
                    "discovery_method": "mdns_resolution",
                    "attempts": attempts,
                    "diagnostics": diagnostics,
                    "error": None,
                }
            diagnostics.append({
                "method": "mdns_resolution",
                "target": f"{mdns_host} ({ip_cand}:{port})",
                "status": "failed",
                "reason": f"Resolved mDNS '{mdns_host}' to {ip_cand}, but TCP port {port} was unreachable",
            })

    # 3. Authenticated UDP Broadcast Discovery
    udp_resp = (
        udp_discoverer()
        if udp_discoverer is not None
        else discover_receiver_via_udp(
            sender_hostname=sender_hostname,
            sender_ip=active_sender_ip,
            port=port,
            expected_receiver_hostname=receiver_hostname,
            secret_token=secret_token,
        )
    )
    if udp_resp and isinstance(udp_resp, dict):
        udp_ip = str(udp_resp.get("receiver_ip") or "").strip()
        attempts.append(f"udp_broadcast->{udp_ip}")
        if is_valid_unicast_ipv4(udp_ip) and verifier(udp_ip, port):
            diagnostics.append({
                "method": "udp_broadcast_discovery",
                "target": f"{udp_ip}:{port}",
                "status": "verified",
                "reason": f"Authenticated HMAC UDP response from {udp_ip} and verified TCP port {port}",
            })
            return {
                "success": True,
                "receiver_ip": udp_ip,
                "receiver_port": int(port),
                "receiver_hostname": str(udp_resp.get("receiver_hostname") or receiver_hostname),
                "discovery_method": "udp_broadcast_discovery",
                "attempts": attempts,
                "diagnostics": diagnostics,
                "error": None,
            }
        diagnostics.append({
            "method": "udp_broadcast_discovery",
            "target": f"{udp_ip}:{port}",
            "status": "failed",
            "reason": f"Received UDP discovery response ({udp_ip}), but TCP port {port} verification failed",
        })
    else:
        attempts.append(f"udp_broadcast:udp/{port}->no_response")
        diagnostics.append({
            "method": "udp_broadcast_discovery",
            "target": f"udp/{port}",
            "status": "failed",
            "reason": f"No authenticated UDP discovery response received on port {port} within timeout",
        })

    # 4a. Last Known / Persisted / Active Local Receiver IP Fallback (verified over TCP 2514)
    last_known_candidates: List[str] = []
    if last_known_receiver_ip and is_valid_unicast_ipv4(last_known_receiver_ip):
        last_known_candidates.append(last_known_receiver_ip.strip())
    if use_config_fallbacks:
        for cfg_ip in fallback_info.get("candidate_ips", []):
            if is_valid_unicast_ipv4(cfg_ip) and cfg_ip not in last_known_candidates:
                last_known_candidates.append(cfg_ip)

    if last_known_candidates:
        for ip_cand in last_known_candidates:
            attempts.append(f"last_known_ip->{ip_cand}")
            if verifier(ip_cand, port):
                diagnostics.append({
                    "method": "last_known_ip_verified",
                    "target": f"{ip_cand}:{port}",
                    "status": "verified",
                    "reason": f"Verified known/configured receiver IP {ip_cand} reachable on TCP port {port}",
                })
                return {
                    "success": True,
                    "receiver_ip": ip_cand,
                    "receiver_port": int(port),
                    "receiver_hostname": receiver_hostname,
                    "discovery_method": "last_known_ip_verified",
                    "attempts": attempts,
                    "diagnostics": diagnostics,
                    "error": None,
                }
            diagnostics.append({
                "method": "last_known_ip_verified",
                "target": f"{ip_cand}:{port}",
                "status": "failed",
                "reason": f"Candidate last-known IP {ip_cand} failed TCP port {port} verification",
            })
    else:
        attempts.append("last_known_ip->none_configured")
        diagnostics.append({
            "method": "last_known_ip_verified",
            "target": "none",
            "status": "skipped",
            "reason": "No last_known_receiver_ip provided or found in persisted state",
        })

    # 4b. Manual Bootstrap IP Fallback (verified over TCP 2514)
    bootstrap_cand = manual_bootstrap_ip or (os.getenv("RECEIVER_BOOTSTRAP_IP", "").strip() if use_config_fallbacks else None)
    if bootstrap_cand and is_valid_unicast_ipv4(bootstrap_cand):
        ip_cand = bootstrap_cand.strip()
        attempts.append(f"manual_bootstrap->{ip_cand}")
        if verifier(ip_cand, port):
            diagnostics.append({
                "method": "manual_bootstrap_verified",
                "target": f"{ip_cand}:{port}",
                "status": "verified",
                "reason": f"Verified manual bootstrap IP {ip_cand} reachable on TCP port {port}",
            })
            return {
                "success": True,
                "receiver_ip": ip_cand,
                "receiver_port": int(port),
                "receiver_hostname": receiver_hostname,
                "discovery_method": "manual_bootstrap_verified",
                "attempts": attempts,
                "diagnostics": diagnostics,
                "error": None,
            }
        diagnostics.append({
            "method": "manual_bootstrap_verified",
            "target": f"{ip_cand}:{port}",
            "status": "failed",
            "reason": f"Manual bootstrap IP {ip_cand} failed TCP port {port} verification",
        })
    else:
        attempts.append("manual_bootstrap->none_provided")
        diagnostics.append({
            "method": "manual_bootstrap_verified",
            "target": "none",
            "status": "skipped",
            "reason": "No manual_bootstrap_ip provided",
        })

    diag_summary = "; ".join(f"{d['method']}({d['target']}): {d['reason']}" for d in diagnostics)
    return {
        "success": False,
        "receiver_ip": None,
        "receiver_port": int(port),
        "receiver_hostname": receiver_hostname,
        "discovery_method": "none",
        "attempts": attempts,
        "diagnostics": diagnostics,
        "error": f"Unable to discover reachable receiver on TCP port {port}. Attempted: {diag_summary}",
    }


def format_network_display(
    value: Any,
    field_role: str = "network",
    fallback_peer_ip: Optional[str] = None,
    last_known_ip: Optional[str] = None,
) -> str:
    """
    Guarantees that NO dashboard sector, card, report, or table cell ever renders
    raw 'NA', 'N/A', 'None', '-', or an empty string for a network field.
    Provides accurate, human-readable status descriptions when a value is not present.
    """
    text = str(value).strip() if value is not None else ""
    if text and text.upper() not in INVALID_NETWORK_TOKENS:
        return text

    role = field_role.lower()
    if role in ("source_ip", "event_source_ip"):
        if fallback_peer_ip and is_valid_unicast_ipv4(fallback_peer_ip):
            return f"{fallback_peer_ip} (TCP 2514 Peer)"
        return "Local Event (No Network IP in Log)"
    if role in ("sender_ip", "remote_peer_ip", "endpoint_ip", "monitored_ip"):
        if fallback_peer_ip and is_valid_unicast_ipv4(fallback_peer_ip):
            return fallback_peer_ip
        if last_known_ip and is_valid_unicast_ipv4(last_known_ip):
            return f"Waiting for peer (Last known: {last_known_ip})"
        return "Waiting for sender connection on TCP 2514"
    if role in ("receiver_ip", "destination_ip", "sender_destination_ip"):
        if last_known_ip and is_valid_unicast_ipv4(last_known_ip):
            return f"Reconnecting (Last known: {last_known_ip})"
        return "Detecting active receiver interface…"
    if role in ("sender_hostname", "endpoint_hostname", "hostname"):
        return "Waiting for endpoint telemetry…"
    if role in ("receiver_hostname",):
        return socket.gethostname() or "Sujith-SOC-Receiver"
    if role in ("mitre_technique",):
        return "Informational / Non-Attack"
    if role in ("command_line", "process_name"):
        return "Not applicable for event type"

    return "Not reported in event"


class CentralNetworkStateService:
    """
    Single authoritative source of truth for AdaptiveSentinelGPT network state.
    Tracks receiver IP/hostname/port/interface, sender IP/hostname/destination,
    active TCP 2514 peer connections, connection status, timestamps, and last known IPs.
    """

    def __init__(
        self,
        state_file_path: Path,
        endpoint_status_file_path: Optional[Path] = None,
        receiver_port: int = DEFAULT_RECEIVER_PORT,
        default_receiver_hostname: str = "Sujith",
        secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
    ):
        self.state_file_path = Path(state_file_path)
        self.endpoint_status_file_path = Path(endpoint_status_file_path) if endpoint_status_file_path else None
        self.receiver_port = int(receiver_port)
        self.default_receiver_hostname = default_receiver_hostname
        self.secret_token = secret_token
        self._udp_Sort_lock = threading.Lock()
        self._persisted: Dict[str, Any] = self._load_persisted_state()

    def _load_persisted_state(self) -> Dict[str, Any]:
        if self.state_file_path.exists():
            try:
                with open(self.state_file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
            except Exception:
                pass
        return {}

    def _save_persisted_state(self, state: Dict[str, Any]) -> None:
        try:
            self.state_file_path.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = self.state_file_path.with_suffix(".json.tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2)
            os.replace(tmp_path, self.state_file_path)
        except Exception:
            pass

    def _read_Legacy_endpoint_status(self) -> Dict[str, Any]:
        if self.endpoint_status_file_path and self.endpoint_status_file_path.exists():
            try:
                with open(self.endpoint_status_file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
            except Exception:
                pass
        return {}

    def refresh_state(
        self,
        observed_events: Optional[List[Dict[str, Any]]] = None,
        interfaces_provider: Optional[Callable[[], List[Dict[str, str]]]] = None,
        route_ip_provider: Optional[Callable[[], Optional[str]]] = None,
        netstat_provider: Optional[Callable[[], str]] = None,
    ) -> Dict[str, Any]:
        """
        Refreshes and returns the complete centralized network state dictionary.
        """
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        persisted = self._load_persisted_state()
        legacy_ep = self._read_Legacy_endpoint_status()

        # 1. Receiver Hostname & Active Local Interface IP
        rec_hostname = os.getenv("RECEIVER_HOSTNAME", "").strip()
        if not rec_hostname or rec_hostname.upper() in INVALID_NETWORK_TOKENS:
            rec_hostname = self.default_receiver_hostname or socket.gethostname() or "Sujith"

        iface_name, detected_ip = detect_active_interface_and_ip(
            interfaces_provider=interfaces_provider,
            route_ip_provider=route_ip_provider,
        )

        # Check explicit environment override first
        override_ip = None
        for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
            val = os.getenv(env_key, "").strip()
            if is_valid_unicast_ipv4(val):
                override_ip = val
                iface_name = f"EnvOverride ({env_key})"
                break

        current_rec_ip = override_ip or (detected_ip if is_valid_unicast_ipv4(detected_ip) else None)
        last_known_rec_ip = persisted.get("last_known_receiver_ip")
        if current_rec_ip and is_valid_unicast_ipv4(current_rec_ip):
            last_known_rec_ip = current_rec_ip

        # 2. Live OS TCP 2514 Socket Inspection
        tcp_info = inspect_tcp_port_connections(
            port=self.receiver_port,
            netstat_provider=netstat_provider,
            receiver_ip=current_rec_ip,
        )
        is_listening = bool(tcp_info["is_listening"])
        active_peers: List[str] = list(tcp_info["remote_peer_ips"])

        # 3. Extract observed sender metadata from live NXLog events & endpoint status
        obs_sender_host = None
        obs_sender_ip = None
        latest_event_ts = None

        if observed_events:
            for evt in reversed(observed_events):
                if evt.get("source") not in (None, "real_nxlog_windows"):
                    continue
                h = str(evt.get("hostname") or "").strip()
                if not obs_sender_host and h and h.upper() not in INVALID_NETWORK_TOKENS:
                    obs_sender_host = h
                for ip_field in ("remote_peer_ip", "source_ip"):
                    cand_ip = str(evt.get(ip_field) or "").strip()
                    if (
                        not obs_sender_ip
                        and is_valid_unicast_ipv4(cand_ip)
                        and cand_ip != current_rec_ip
                    ):
                        obs_sender_ip = cand_ip
                evt_ts = str(evt.get("timestamp") or evt.get("ingestion_timestamp") or "").strip()
                if not latest_event_ts and evt_ts and evt_ts.upper() not in INVALID_NETWORK_TOKENS:
                    latest_event_ts = evt_ts
                if obs_sender_host and obs_sender_ip and latest_event_ts:
                    break

        # Environment or active TCP peer enrichment for sender IP
        env_sender_ip = None
        for env_key in ("ENDPOINT_IP", "HARSHA_IP"):
            val = os.getenv(env_key, "").strip()
            if is_valid_unicast_ipv4(val) and val != current_rec_ip:
                env_sender_ip = val
                break

        remote_peer_ip = active_peers[0] if active_peers else (obs_sender_ip or env_sender_ip)
        if remote_peer_ip == current_rec_ip:
            remote_peer_ip = None

        # Check UDP discovery or endpoint_status.json for sender_ip_current & sender_hostname
        ep_reported_ip = str(legacy_ep.get("ip_address") or legacy_ep.get("sender_ip_current") or "").strip()
        if not is_valid_unicast_ipv4(ep_reported_ip) or ep_reported_ip == current_rec_ip:
            ep_reported_ip = ""

        sender_ip_current = remote_peer_ip or ep_reported_ip or obs_sender_ip or env_sender_ip
        last_known_sender_ip = persisted.get("last_known_sender_ip")
        if sender_ip_current and is_valid_unicast_ipv4(sender_ip_current):
            last_known_sender_ip = sender_ip_current

        env_sender_host = os.getenv("ENDPOINT_HOSTNAME", "").strip()
        if env_sender_host.upper() in INVALID_NETWORK_TOKENS:
            env_sender_host = ""

        ep_reported_host = str(legacy_ep.get("hostname") or persisted.get("sender_hostname") or "").strip()
        if ep_reported_host.upper() in INVALID_NETWORK_TOKENS or ep_reported_host.startswith("Waiting"):
            ep_reported_host = ""

        sender_hostname = obs_sender_host or env_sender_host or ep_reported_host or "Harsha"

        # 4. Determine Connection Status & Timestamps
        last_success = persisted.get("last_successful_connection")
        last_error = "None — Operating normally"

        if not current_rec_ip:
            connection_status = "DISCONNECTED"
            last_error = "No active IPv4 network interface detected on receiver"
        elif active_peers:
            connection_status = "CONNECTED"
            last_success = now_iso
        elif is_listening:
            if obs_sender_host or latest_event_ts:
                connection_status = "LISTENING"
                if not last_success and latest_event_ts:
                    last_success = latest_event_ts
            else:
                connection_status = "SEARCHING"
        else:
            connection_status = "RECONNECTING"
            last_error = f"NXLog TCP listener on port {self.receiver_port} is not currently bound"

        sender_dest_ip = (
            current_rec_ip
            if (active_peers or connection_status in ("CONNECTED", "LISTENING")) and current_rec_ip
            else (last_known_rec_ip or "Detecting receiver IP…")
        )

        state: Dict[str, Any] = {
            "receiver_hostname": rec_hostname,
            "receiver_os_hostname": socket.gethostname() or rec_hostname,
            "receiver_ip_current": current_rec_ip or format_network_display(None, "receiver_ip", last_known_ip=last_known_rec_ip),
            "receiver_port": int(self.receiver_port),
            "sender_hostname": sender_hostname,
            "sender_ip_current": (
                sender_ip_current
                if sender_ip_current and is_valid_unicast_ipv4(sender_ip_current)
                else format_network_display(None, "sender_ip", last_known_ip=last_known_sender_ip)
            ),
            "sender_destination_ip": sender_dest_ip,
            "remote_peer_ip": (
                remote_peer_ip
                if remote_peer_ip and is_valid_unicast_ipv4(remote_peer_ip)
                else format_network_display(None, "remote_peer_ip", last_known_ip=last_known_sender_ip)
            ),
            "raw_remote_peer_ip": remote_peer_ip if (remote_peer_ip and is_valid_unicast_ipv4(remote_peer_ip)) else "N/A",
            "raw_sender_ip": sender_ip_current if (sender_ip_current and is_valid_unicast_ipv4(sender_ip_current)) else "N/A",
            "active_tcp_peers": active_peers,
            "is_port_listening": is_listening,
            "connection_status": connection_status,
            "last_successful_connection": last_success or (latest_event_ts if latest_event_ts else "Awaiting first TCP 2514 session"),
            "last_discovery_time": now_iso,
            "last_error": last_error,
            "network_interface": iface_name,
            "last_known_receiver_ip": last_known_rec_ip or (current_rec_ip or "Not yet recorded"),
            "last_known_sender_ip": last_known_sender_ip or (sender_ip_current or "Not yet recorded"),
        }

        self._persisted = state
        self._save_persisted_state(state)
        return state


_UDP_RESPONDER_THREAD: Optional[threading.Thread] = None
_UDP_RESPONDER_LOCK = threading.Lock()


def ensure_udp_discovery_responder(
    state_service: CentralNetworkStateService,
    port: int = DEFAULT_RECEIVER_PORT,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
) -> bool:
    """
    Starts a lightweight background daemon UDP discovery responder on `0.0.0.0:port`
    (default UDP 2514) if not already running in this process.
    """
    global _UDP_RESPONDER_THREAD
    with _UDP_RESPONDER_LOCK:
        if _UDP_RESPONDER_THREAD is not None and _UDP_RESPONDER_THREAD.is_alive():
            return True

        def _serve_udp() -> None:
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    sock.bind(("0.0.0.0", int(port)))
                    while True:
                        try:
                            data, addr = sock.recvfrom(4096)
                            payload = json.loads(data.decode("utf-8"))
                            valid, _ = validate_discovery_request(
                                payload,
                                expected_port=port,
                                secret_token=secret_token,
                            )
                            if not valid:
                                continue
                            st_now = state_service.refresh_state()
                            rec_ip = st_now.get("receiver_ip_current", "")
                            if not is_valid_unicast_ipv4(rec_ip):
                                _, rec_ip = detect_active_interface_and_ip()
                            resp = build_discovery_response(
                                receiver_hostname=st_now.get("receiver_hostname", "Sujith"),
                                receiver_ip=rec_ip,
                                receiver_port=port,
                                network_interface=st_now.get("network_interface", "Wi-Fi"),
                                request_nonce=str(payload.get("nonce") or ""),
                                secret_token=secret_token,
                            )
                            sock.sendto(json.dumps(resp).encode("utf-8"), addr)
                        except Exception:
                            continue
            except Exception:
                return

        t = threading.Thread(target=_serve_udp, name="AdaptiveSentinelUDPResponder", daemon=True)
        t.start()
        _UDP_RESPONDER_THREAD = t
        return True
