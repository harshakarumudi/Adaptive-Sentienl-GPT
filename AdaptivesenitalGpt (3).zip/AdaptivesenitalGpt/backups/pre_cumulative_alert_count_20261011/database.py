import sqlite3
import json
from typing import List, Dict, Any, Optional
from config.settings import DB_PATH


class KnowledgeBaseDB:
    """
    SQLite-backed Adaptive Knowledge Base.
    Stores Threat Intel IOCs, Historical Incidents, and Analyst Feedback.
    """

    def __init__(self, db_path=DB_PATH):
        self.db_path = str(db_path)
        self.init_db()

    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()

            # Threat Intel IOC Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS threat_intel_ioc (
                    ip TEXT PRIMARY KEY,
                    status TEXT,
                    reputation TEXT,
                    risk_score INTEGER,
                    threat_category TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Historical Incidents Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS historical_incidents (
                    incident_id TEXT PRIMARY KEY,
                    incident_name TEXT,
                    severity TEXT,
                    confidence INTEGER,
                    affected_host TEXT,
                    affected_user TEXT,
                    alerts_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Analyst Feedback Table (Human-in-the-Loop Adaptive Learning)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS analyst_feedback (
                    feedback_id TEXT PRIMARY KEY,
                    incident_id TEXT,
                    alert_name TEXT,
                    analyst_verdict TEXT,
                    override_severity TEXT,
                    adjusted_confidence INTEGER,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Seed default known malicious IOCs if empty
            cursor.execute("SELECT COUNT(*) FROM threat_intel_ioc")
            if cursor.fetchone()[0] == 0:
                default_iocs = [
                    ("185.220.101.5", "Known Tor Exit Node / Malicious", "Untrusted", 95, "Command & Control / Brute Force"),
                    ("45.33.32.156", "Active Scanner / Exploitation", "Untrusted", 88, "SSH Brute Force"),
                    ("10.0.4.15", "Internal Workstation", "Trusted", 10, "Internal Network"),
                    ("127.0.0.1", "Local Host", "Trusted", 0, "Loopback")
                ]
                cursor.executemany(
                    "INSERT INTO threat_intel_ioc (ip, status, reputation, risk_score, threat_category) VALUES (?, ?, ?, ?, ?)",
                    default_iocs
                )

            conn.commit()

    def lookup_ioc(self, ip: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM threat_intel_ioc WHERE ip = ?", (ip,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def add_ioc(self, ip: str, status: str, reputation: str, risk_score: int, category: str):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO threat_intel_ioc (ip, status, reputation, risk_score, threat_category)
                VALUES (?, ?, ?, ?, ?)
            """, (ip, status, reputation, risk_score, category))
            conn.commit()

    def save_incident(self, incident: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO historical_incidents (incident_id, incident_name, severity, confidence, affected_host, affected_user, alerts_json)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                incident.get("incident_id"),
                incident.get("incident_name"),
                incident.get("severity"),
                incident.get("confidence"),
                incident.get("affected_host"),
                incident.get("affected_user"),
                json.dumps(incident.get("alerts", []))
            ))
            conn.commit()

    def save_feedback(self, feedback: Dict[str, Any]):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO analyst_feedback (feedback_id, incident_id, alert_name, analyst_verdict, override_severity, adjusted_confidence, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                feedback.get("feedback_id"),
                feedback.get("incident_id"),
                feedback.get("alert_name"),
                feedback.get("analyst_verdict"),
                feedback.get("override_severity"),
                feedback.get("adjusted_confidence"),
                feedback.get("notes")
            ))
            conn.commit()

    def get_all_feedback(self) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM analyst_feedback ORDER BY created_at DESC")
            return [dict(row) for row in cursor.fetchall()]
