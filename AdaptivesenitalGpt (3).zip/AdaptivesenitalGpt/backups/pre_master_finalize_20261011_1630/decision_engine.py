from typing import Dict, Any, List, Optional
from soar.action_registry import SOARActionRegistry


class SOARDecisionEngine:
    """
    Deterministic Decision Engine evaluating security incidents and GNN risk scores
    to output structured response recommendations using strictly allowlisted SOAR actions.
    Prohibits arbitrary AI shell command generation.
    """

    def __init__(self, registry: Optional[SOARActionRegistry] = None):
        self.registry = registry or SOARActionRegistry()

    def evaluate_incident(self, incident: Dict[str, Any], gnn_risk_score: float = 0.0) -> List[Dict[str, Any]]:
        """
        Evaluates an incident and returns list of structured response recommendations.
        """
        recommendations = []
        inc_id = incident.get("incident_id", "INC-UNK")
        host = incident.get("affected_host", "UNKNOWN-HOST")
        user = incident.get("affected_user", "SYSTEM")
        severity = incident.get("severity", "Medium")

        # Extract alerts & metadata from incident, alert, and underlying event levels
        alerts = incident.get("alerts", [])
        source_ips: List[str] = []
        mitre_techs_ordered: List[str] = []
        detected_rules_ordered: List[str] = []

        def _add_tech(val: Any) -> None:
            if not val:
                return
            if isinstance(val, (list, tuple, set)):
                for item in val:
                    _add_tech(item)
                return
            s = str(val).strip()
            if s and s.upper() not in ("N/A", "NA", "NONE", "UNKNOWN", "-"):
                if s not in mitre_techs_ordered:
                    mitre_techs_ordered.append(s)

        def _add_rule(val: Any) -> None:
            if not val:
                return
            s = str(val).strip()
            if s and s.upper() not in ("N/A", "NA", "NONE", "UNKNOWN", "-"):
                if s not in detected_rules_ordered:
                    detected_rules_ordered.append(s)

        _add_tech(incident.get("mitre_techniques", []))
        _add_tech(incident.get("mitre_technique"))
        _add_rule(incident.get("rule_id"))

        suspicious_Indicators = (
            "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe", "rundll32",
            "mimikatz", "lazagne", "seatbelt", "sharphound", "bloodhound",
            "procdump", "wscript", "cscript", "mshta", "python",
            "net.exe", "net1.exe", "whoami", "nltest", "dsquery", "csvde", "ldifde", "adfind"
        )
        has_suspicious_process_or_cli = False
        has_malicious_ti = bool(incident.get("has_confirmed_malicious_ioc", False))

        for alt in alerts:
            if not isinstance(alt, dict):
                continue
            _add_rule(alt.get("rule_id"))
            _add_tech(alt.get("mitre_technique"))
            _add_tech(alt.get("mitre_techniques", []))
            if alt.get("threat_intel", {}).get("is_malicious"):
                has_malicious_ti = True

            evt = alt.get("event", {}) if isinstance(alt.get("event"), dict) else {}
            raw_ip = str(evt.get("source_ip") or "").strip()
            if raw_ip and raw_ip.upper() not in ("N/A", "NA", "NONE", "UNKNOWN", "-") and raw_ip not in source_ips:
                source_ips.append(raw_ip)
            _add_rule(evt.get("rule_id"))
            _add_tech(evt.get("mitre_technique"))
            _add_tech(evt.get("mitre_techniques", []))

            proc_l = str(evt.get("process_name") or "").lower()
            cmd_l = str(evt.get("command_line") or "").lower()
            if any(ind in proc_l or ind in cmd_l for ind in suspicious_Indicators):
                has_suspicious_process_or_cli = True

        mitre_techs = set(mitre_techs_ordered)
        primary_ip = source_ips[0] if source_ips else "127.0.0.1"
        primary_rule = detected_rules_ordered[0] if detected_rules_ordered else "N/A"
        primary_tech = mitre_techs_ordered[0] if mitre_techs_ordered else "N/A"

        # Safeguard: Do not recommend disruptive containment (ISOLATE_HOST, LOCK_USER)
        # solely because repeated routine Event ID 5379 / 4798 events caused an inflated severity
        # or inherited a default host GNN risk score without suspicious tooling, command-line indicators,
        # or confirmed malicious IOCs.
        only_routine_5379_4798_techs = (
            bool(mitre_techs)
            and mitre_techs.issubset({"T1555.004", "T1087.001"})
            and not has_suspicious_process_or_cli
            and not has_malicious_ti
        )
        effective_severity = "Low" if only_routine_5379_4798_techs else severity
        effective_gnn_score = min(gnn_risk_score, 0.25) if only_routine_5379_4798_techs else gnn_risk_score

        # 1. Recommendation Rule: Host Isolation (ISOLATE_HOST)
        # Recommended if Critical/High effective severity OR GNN risk score >= 0.70 OR Critical techniques present
        critical_tech_match = any(t in mitre_techs for t in ("T1003", "T1003.001", "T1486", "T1490", "T1055", "T1059.001", "T1505.003", "T1558.001"))
        if effective_severity in ("Critical", "High") or effective_gnn_score >= 0.70 or critical_tech_match:
            is_valid, _ = self.registry.validate_action_request("ISOLATE_HOST", host)
            if is_valid:
                why_msg = (
                    f"Advisory Recommendation — Not Executed: Recommended network isolation for endpoint '{host}' because incident '{inc_id}' "
                    f"has {effective_severity} severity (GNN Risk Score: {gnn_risk_score:.4f}) and detected "
                    f"technique(s) {sorted(list(mitre_techs))}."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "ISOLATE_HOST",
                    "action_name": "Isolate Endpoint Host",
                    "target": host,
                    "parameters": {"hostname": host},
                    "why_recommended": why_msg,
                    "advisory_status": "Advisory Recommendation — Not Executed",
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute ISOLATE_HOST on target '{host}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": effective_severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 2. Recommendation Rule: Forensic Artifact Collection (COLLECT_FORENSIC_ARTIFACTS)
        # Recommended for all High/Critical incidents or elevated GNN risk score
        if effective_severity in ("Critical", "High") or effective_gnn_score >= 0.50:
            is_valid, _ = self.registry.validate_action_request("COLLECT_FORENSIC_ARTIFACTS", host, {"artifact_type": "triage_package"})
            if is_valid:
                why_msg = (
                    f"Advisory Recommendation — Not Executed: Recommended automated forensic triage collection for host '{host}' to capture "
                    f"volatile memory, process tree, and event logs for post-incident analysis."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "COLLECT_FORENSIC_ARTIFACTS",
                    "action_name": "Collect Forensic Artifact Package",
                    "target": host,
                    "parameters": {"hostname": host, "artifact_type": "triage_package"},
                    "why_recommended": why_msg,
                    "advisory_status": "Advisory Recommendation — Not Executed",
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute COLLECT_FORENSIC_ARTIFACTS (triage_package) on target '{host}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": effective_severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 3. Recommendation Rule: Block IP (BLOCK_IP)
        # Recommended if external non-loopback IP is present and involved in brute force / unauthorized access
        if primary_ip and primary_ip not in ("127.0.0.1", "0.0.0.0", "localhost") and not only_routine_5379_4798_techs:
            is_valid, _ = self.registry.validate_action_request("BLOCK_IP", primary_ip)
            if is_valid:
                why_msg = (
                    f"Advisory Recommendation — Not Executed: Recommended perimeter IP block for source IP '{primary_ip}' due to suspicious "
                    f"authentication failures or network activity targeting '{host}'."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "BLOCK_IP",
                    "action_name": "Block Malicious IP Address",
                    "target": primary_ip,
                    "parameters": {"ip_address": primary_ip},
                    "why_recommended": why_msg,
                    "advisory_status": "Advisory Recommendation — Not Executed",
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute BLOCK_IP on target '{primary_ip}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": effective_severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        # 4. Recommendation Rule: Lock User Account (LOCK_USER)
        # Recommended if credential theft, brute force, or golden ticket is detected
        cred_tech_match = any(t in mitre_techs for t in ("T1003", "T1003.001", "T1110", "T1110.003", "T1558", "T1558.001", "T1558.003"))
        if user and user not in ("SYSTEM", "LOCAL SERVICE", "NETWORK SERVICE", "IUSR") and (cred_tech_match or effective_severity == "Critical"):
            is_valid, _ = self.registry.validate_action_request("LOCK_USER", user)
            if is_valid:
                why_msg = (
                    f"Advisory Recommendation — Not Executed: Recommended account lockout for monitored user '{user}' to prevent credential misuse "
                    f"and lateral movement across domain infrastructure."
                )
                recommendations.append({
                    "incident_id": inc_id,
                    "action_id": "LOCK_USER",
                    "action_name": "Lock Monitored User Account",
                    "target": user,
                    "parameters": {"username": user},
                    "why_recommended": why_msg,
                    "advisory_status": "Advisory Recommendation — Not Executed",
                    "requires_analyst_approval": True,
                    "dry_run": True,
                    "dry_run_preview": f"DRY RUN — NO SYSTEM CHANGE: Would execute LOCK_USER on target '{user}'.",
                    "gnn_risk_score": gnn_risk_score,
                    "severity": effective_severity,
                    "rule_id": primary_rule,
                    "mitre_technique": primary_tech
                })

        return recommendations
