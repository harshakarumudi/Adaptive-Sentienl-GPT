import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional

from config.settings import (
    NXLOG_FILE_PATH,
    NXLOG_CURSOR_FILE_PATH,
    get_receiver_ip,
)


class LogParser:

    def __init__(self, log_file: str):
        self.log_file = Path(log_file)

    def parse(self) -> List[Dict[str, Any]]:
        """
        Parses JSON or line-delimited log files into Python dictionaries.
        """
        if not self.log_file.exists():
            print(f"[ERROR] Log file not found: {self.log_file}")
            return []

        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    print(f"[WARNING] Log file is empty: {self.log_file}")
                    return []

                # JSON Array format
                if content.startswith("[") and content.endswith("]"):
                    logs = json.loads(content)
                else:
                    # JSON Lines format
                    logs = [json.loads(line) for line in content.splitlines() if line.strip()]

            print(f"[INFO] LogParser ingested {len(logs)} raw events from {self.log_file.name}.")
            return logs

        except Exception as e:
            print(f"[ERROR] Failed to parse log file {self.log_file}: {str(e)}")
            return []


def parse_log_file(file_path: str) -> List[Dict[str, Any]]:
    return LogParser(file_path).parse()


class NXLogReader:
    """
    Reads and parses live/ingested Windows Event Logs emitted by NXLog
    to C:\\AdaptiveSentinel\\windows-events.log. Supports incremental reading via cursor tracking.
    """

    def __init__(
        self,
        log_file: Optional[Path] = None,
        cursor_file: Optional[Path] = None
    ):
        self.log_file = Path(log_file) if log_file else NXLOG_FILE_PATH
        self.cursor_file = Path(cursor_file) if cursor_file else NXLOG_CURSOR_FILE_PATH
        self.last_error: Optional[str] = None
        self.diagnostics: List[Dict[str, Any]] = []

    def load_cursor(self) -> int:
        if self.cursor_file.exists():
            try:
                with open(self.cursor_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data.get("byte_offset", 0)
            except Exception:
                return 0
        return 0

    def save_cursor(self, offset: int) -> None:
        try:
            self.cursor_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cursor_file, "w", encoding="utf-8") as f:
                json.dump({"byte_offset": offset, "last_updated": datetime.now(timezone.utc).isoformat()}, f)
        except Exception as e:
            print(f"[!] Failed to save NXLog cursor: {e}")

    def reset_cursor_to_end(self) -> int:
        """
        Advances the NXLog cursor to the current end of windows-events.log.
        Events up to this point will be treated as baseline history,
        and subsequent incremental reads will only capture newly arriving events.
        """
        if not self.log_file.exists():
            self.save_cursor(0)
            return 0
        try:
            with open(self.log_file, "r", encoding="utf-8", errors="replace") as f:
                f.seek(0, os.SEEK_END)
                end_offset = f.tell()
            self.save_cursor(end_offset)
            return end_offset
        except Exception as e:
            print(f"[!] Failed to reset NXLog cursor to end: {e}")
            return 0

    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        line = raw_line.strip()
        if not line:
            return None

        # Try parsing as JSON first
        if line.startswith("{") and line.endswith("}"):
            try:
                data = json.loads(line)
                return self._normalize_nxlog_json(data, raw_line)
            except Exception:
                pass

        # Parse non-JSON lines (syslog / KV / test lines / EventLog text)
        return self._normalize_nxlog_text(line, raw_line)

    def _extract_event_id(self, source_dict_or_text: Any) -> int:
        if isinstance(source_dict_or_text, dict):
            for key in ["EventID", "event_id", "EventCode", "event_code", "ID", "id"]:
                val = source_dict_or_text.get(key)
                if val is not None:
                    try:
                        eid = int(val)
                        if eid > 0:
                            return eid
                    except (ValueError, TypeError):
                        pass
            text_to_search = source_dict_or_text.get("Message") or source_dict_or_text.get("description") or str(source_dict_or_text)
        else:
            text_to_search = str(source_dict_or_text)

        # XML / Tags
        xml_match = re.search(r"<EventID>(\d+)</EventID>", text_to_search, re.IGNORECASE)
        if xml_match:
            try:
                return int(xml_match.group(1))
            except ValueError:
                pass

        # Key-Value or Label format (e.g. EventID: 4624, Event ID = 4624, ID: 1000)
        kv_match = re.search(r"(?:EventID|EventCode|Event_ID|Event\s*ID|EventCode|ID)[:=><\s]+(\d{1,6})\b", text_to_search, re.IGNORECASE)
        if kv_match:
            try:
                return int(kv_match.group(1))
            except ValueError:
                pass

        # Event ID in eventcreate or syslog string (e.g. "Event 1000", "ID 4624")
        evt_match = re.search(r"\b(?:Event|ID)\s+(\d{3,5})\b", text_to_search, re.IGNORECASE)
        if evt_match:
            try:
                return int(evt_match.group(1))
            except ValueError:
                pass

        return 0

    def _normalize_nxlog_json(self, data: Dict[str, Any], raw_line: str) -> Dict[str, Any]:
        from analysis.normalize import LogNormalizer
        norm = LogNormalizer()
        event_id = self._extract_event_id(data)
        now_iso = datetime.now(timezone.utc).isoformat()
        receiver_ip = str(data.get("receiver_ip") or getattr(self, "_batch_receiver_ip", None) or get_receiver_ip() or "N/A").strip()

        raw_hostname = (
            data.get("Hostname")
            or data.get("Computer")
            or data.get("ComputerName")
            or data.get("Host")
            or data.get("hostname")
            or "UNKNOWN_HOST"
        )
        raw_hostname = str(raw_hostname).strip() or "UNKNOWN_HOST"
        hostname = raw_hostname
        provider = str(
            data.get("SourceName")
            or data.get("ProviderName")
            or data.get("Provider")
            or data.get("provider")
            or "Microsoft-Windows-Security-Auditing"
        ).strip() or "Microsoft-Windows-Security-Auditing"

        user = (
            data.get("TargetUserName")
            or data.get("SubjectUserName")
            or data.get("AccountName")
            or data.get("user")
        )
        if not user or user in ["-", "", "SYSTEM"]:
            domain_user = re.search(r'\b([A-Za-z0-9._-]+)\\([A-Za-z0-9._-]+)\b', str(data.get("Message", "")))
            if domain_user and domain_user.group(2).upper() not in ['SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']:
                user = domain_user.group(2)
            else:
                user = user or "SYSTEM"

        invalid_ips = {"-", "127.0.0.1", "::1", "N/A", "0.0.0.0", "", "NONE", "UNKNOWN"}

        src_ip = (
            data.get("IpAddress")
            or data.get("SourceAddress")
            or data.get("SourceNetworkAddress")
            or data.get("source_ip")
        )
        src_ip_str = str(src_ip).strip() if src_ip is not None else ""
        if not src_ip_str or src_ip_str.upper() in invalid_ips or src_ip_str == receiver_ip:
            src_ip_str = "N/A"

        remote_peer = (
            data.get("MessageSourceAddress")
            or data.get("RemoteIp")
            or data.get("PeerIp")
            or data.get("RemoteAddress")
            or data.get("PeerAddress")
            or data.get("remote_peer_ip")
        )
        remote_peer_str = str(remote_peer).strip() if remote_peer is not None else ""
        if not remote_peer_str or remote_peer_str.upper() in invalid_ips or remote_peer_str == receiver_ip:
            remote_peer_str = "N/A"

        dst_ip = (
            data.get("DestinationIpAddress")
            or data.get("DestAddress")
            or data.get("destination_ip")
            or "N/A"
        )
        record_id = (
            data.get("RecordNumber")
            or data.get("EventRecordID")
            or data.get("record_id")
            or data.get("event_record_id")
        )
        process_name = (
            data.get("NewProcessName")
            or data.get("ProcessName")
            or data.get("process_name")
            or "N/A"
        )
        command_line = data.get("CommandLine") or data.get("command_line") or "N/A"
        event_time = (
            data.get("EventTime")
            or data.get("TimeCreated")
            or data.get("timestamp")
            or now_iso
        )
        description = (
            data.get("Message")
            or data.get("description")
            or f"NXLog Windows Event {event_id}"
        )

        is_diagnostic = any(
            k in str(description).upper() or k in str(command_line).upper()
            for k in norm.DIAGNOSTIC_MARKERS
        )

        if is_diagnostic:
            severity = "Low"
            mitre_tech = "N/A"
            event_type = "Diagnostic Telemetry Probe"
        else:
            severity = norm.resolve_event_severity(
                event_id=event_id,
                process_name=str(process_name or ""),
                command_line=str(command_line or ""),
                description=str(description or ""),
                curr_sev=str(data.get("severity") or ""),
            )

            mitre_tech = data.get("mitre_technique")
            if not mitre_tech or mitre_tech == "N/A":
                mitre_tech = norm.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")

            event_type = data.get("event_type")
            if not event_type or event_type in ["NXLog Event", "Generic Event", "N/A"]:
                event_type = norm.EVENT_TYPE_MAP.get(event_id, f"Windows Event (ID {event_id})" if event_id else "Windows Event")

        return {
            "timestamp": event_time,
            "ingestion_timestamp": now_iso,
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "event_id": event_id,
            "event_type": event_type,
            "severity": severity,
            "hostname": hostname,
            "raw_hostname": raw_hostname,
            "provider": provider,
            "user": user,
            "source_ip": src_ip_str,
            "remote_peer_ip": remote_peer_str,
            "receiver_ip": receiver_ip,
            "destination_ip": dst_ip,
            "record_id": record_id,
            "process_name": process_name,
            "command_line": command_line,
            "description": description,
            "message": description,
            "mitre_technique": mitre_tech,
            "is_diagnostic": is_diagnostic,
            "raw_line": raw_line
        }

    def _normalize_nxlog_text(self, text: str, raw_line: str) -> Dict[str, Any]:
        from analysis.normalize import LogNormalizer
        norm = LogNormalizer()
        receiver_ip = str(getattr(self, "_batch_receiver_ip", None) or get_receiver_ip() or "N/A").strip()

        lines = [l.strip() for l in text.splitlines() if l.strip()]
        first_line = lines[0] if lines else text.strip()

        header_re = re.compile(
            r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(\S+)\s+(\d{1,6})\s+(.*)$'
        )
        syslog_host_re = re.compile(
            r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(?!\[)([A-Za-z0-9._-]+)\s+(.*)$'
        )
        m = header_re.match(first_line)
        now_iso = datetime.now(timezone.utc).isoformat()

        if m:
            event_time, hostname, _audit_status, eid_str, description = m.groups()
            try:
                event_id = int(eid_str)
            except ValueError:
                event_id = 0
        else:
            event_id = self._extract_event_id(text)
            comp_m = re.findall(r'(?:Computer|Hostname|Host):\s*([^\r\n;,]+)', text, re.IGNORECASE)
            from_m = re.search(r'\bfrom\s+([A-Za-z0-9._-]+)\b', text, re.IGNORECASE)
            sm = syslog_host_re.match(first_line)
            invalid_hosts = {
                "INFO", "WARN", "WARNING", "ERROR", "CRITICAL", "DEBUG",
                "AUDIT_SUCCESS", "AUDIT_FAILURE", "ADDRESS", "USER", "LOCAL",
                "LOCALHOST", "SYSTEM", "PROCESS", "CLIENT", "SERVER", "ACCOUNT",
                "DOMAIN", "SESSION", "TOKEN", "FILE", "PIPE", "SERVICE", "CONTAINER"
            }
            if comp_m:
                hostname = comp_m[0].strip()
                event_time = sm.group(1) if sm else now_iso
                description = sm.group(3) if sm else first_line
            elif sm and sm.group(2).upper() not in invalid_hosts:
                event_time = sm.group(1)
                hostname = sm.group(2).strip()
                description = sm.group(3)
            elif from_m and from_m.group(1).upper() not in invalid_hosts:
                hostname = from_m.group(1).strip()
                event_time = now_iso
                description = first_line
            else:
                hostname = "UNKNOWN_HOST"
                event_time = now_iso
                description = first_line

        hostname = str(hostname).strip() or "UNKNOWN_HOST"

        # Extract Target / User accounts cleanly
        target_users = re.findall(
            r'(?:User|TargetUserName):\s*\n?\s*Security ID:.*?\n?\s*Account Name:\s*([^\r\n;,]+)',
            text, re.IGNORECASE
        )
        general_users = re.findall(r'Account\s+Name:\s*([^\r\n;,]+)', text, re.IGNORECASE)

        user = None
        if target_users:
            user = target_users[0].strip()
        elif general_users:
            filtered = [
                u.strip() for u in general_users
                if not u.strip().endswith('$') and u.strip() not in ['-', 'SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']
            ]
            user = filtered[0] if filtered else general_users[-1].strip()

        if not user or user in ['-', '', 'SYSTEM', 'N/A']:
            domain_user = re.search(r'\b([A-Za-z0-9._-]+)\\([A-Za-z0-9._-]+)\b', text)
            if domain_user and domain_user.group(2).upper() not in ['SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']:
                user = domain_user.group(2)
            else:
                user = user or "SYSTEM"

        # Process Name
        proc_matches = re.findall(r'(?:Process\s+Name|NewProcessName|Process):\s*([^\r\n;,]+)', text, re.IGNORECASE)
        process_name = proc_matches[0].strip() if proc_matches else "N/A"

        # Command Line
        cmd_matches = re.findall(r'(?:Process\s+Command\s+Line|CommandLine):\s*([^\r\n]+)', text, re.IGNORECASE)
        command_line = cmd_matches[0].strip() if cmd_matches else "N/A"

        invalid_ips = {'-', '::1', '127.0.0.1', 'N/A', '0.0.0.0', '', 'NONE', 'UNKNOWN'}

        # Source IP: Extract only if explicitly present in event, never infer from receiver IP
        ip_matches = re.findall(
            r'(?:Source\s+Network\s+Address|IpAddress|SourceAddress|SourceIp|ClientIP|src_ip)\s*[:=]\s*([^\r\n;,\s]+)',
            text,
            re.IGNORECASE,
        )
        raw_src_ip = ip_matches[0].strip() if ip_matches else ""
        src_ip = (
            raw_src_ip
            if (raw_src_ip and raw_src_ip.upper() not in invalid_ips and raw_src_ip != receiver_ip)
            else "N/A"
        )

        # Remote TCP Peer IP: Extract only if collector metadata explicitly includes it
        peer_matches = re.findall(
            r'(?:MessageSourceAddress|RemoteAddress|PeerAddress|RemoteIp|PeerIp|remote_peer_ip)\s*[:=]\s*([^\r\n;,\s]+)',
            text,
            re.IGNORECASE,
        )
        raw_peer_ip = peer_matches[0].strip() if peer_matches else ""
        remote_peer_ip = (
            raw_peer_ip
            if (raw_peer_ip and raw_peer_ip.upper() not in invalid_ips and raw_peer_ip != receiver_ip)
            else "N/A"
        )

        # Destination IP
        dst_matches = re.findall(
            r'(?:Destination\s+Network\s+Address|DestAddress|DestinationIpAddress)\s*[:=]\s*([^\r\n;,\s]+)',
            text,
            re.IGNORECASE,
        )
        raw_dst_ip = dst_matches[0].strip() if dst_matches else ""
        dst_ip = raw_dst_ip if (raw_dst_ip and raw_dst_ip.upper() not in invalid_ips) else "N/A"

        # Record ID if present
        rec_matches = re.findall(r'(?:RecordNumber|EventRecordID|record_id)\s*[:=]\s*(\d+)', text, re.IGNORECASE)
        record_id = int(rec_matches[0]) if rec_matches else None

        is_diagnostic = any(
            marker in str(description).upper() or marker in str(command_line).upper()
            for marker in norm.DIAGNOSTIC_MARKERS
        )

        if is_diagnostic:
            severity = "Low"
            mitre_tech = "N/A"
            event_type = "Diagnostic Telemetry Probe"
        else:
            severity = norm.resolve_event_severity(
                event_id=event_id,
                process_name=str(process_name or ""),
                command_line=str(command_line or ""),
                description=str(description or ""),
            )
            mitre_tech = norm.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")
            event_type = norm.EVENT_TYPE_MAP.get(event_id, f"Windows Event (ID {event_id})" if event_id else "Windows Event")

        prov_matches = re.findall(r'(?:SourceName|ProviderName|Provider)\s*[:=]\s*([^\r\n;,]+)', text, re.IGNORECASE)
        provider = prov_matches[0].strip() if prov_matches else "Microsoft-Windows-Security-Auditing"

        return {
            "timestamp": event_time,
            "ingestion_timestamp": now_iso,
            "source": "real_nxlog_windows",
            "source_type": "real_nxlog_windows",
            "event_id": event_id,
            "event_type": event_type,
            "severity": severity,
            "hostname": hostname,
            "raw_hostname": hostname,
            "provider": provider,
            "user": user,
            "source_ip": src_ip,
            "remote_peer_ip": remote_peer_ip,
            "receiver_ip": receiver_ip,
            "destination_ip": dst_ip,
            "record_id": record_id,
            "process_name": process_name,
            "command_line": command_line,
            "description": description,
            "message": description,
            "mitre_technique": mitre_tech,
            "is_diagnostic": is_diagnostic,
            "raw_line": raw_line
        }

    @staticmethod
    def _is_json_record_line(s: str) -> bool:
        """
        Returns True only if the line is a valid JSON object record (and not a
        Windows CLSID/GUID line such as '{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}').
        """
        if not (s.startswith("{") and s.endswith("}") and ":" in s):
            return False
        try:
            parsed = json.loads(s)
            return isinstance(parsed, dict)
        except Exception:
            return False

    @staticmethod
    def _split_into_blocks_with_spans(chunk: str, base_offset: int, require_header_start: bool = False):
        """
        Splits a decoded log chunk into (block_text, block_start_offset, block_end_offset) tuples.
        Recognizes multiline Windows Security/Application event headers, single-line timestamped
        syslog headers, and JSON object records while keeping multiline continuation lines
        (including Windows GUID lines like '{...}') attached to their parent event.
        """
        header_re = re.compile(
            r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+'
        )
        multiline_hdr_re = re.compile(
            r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(AUDIT_SUCCESS|AUDIT_FAILURE|INFO|WARNING|ERROR|CRITICAL)\s+(\d{1,6})\s+'
        )
        spans = []
        cur = []
        cur_offset = base_offset
        running_offset = base_offset
        started = not require_header_start

        for raw_line in chunk.splitlines(keepends=True):
            line_bytes_len = len(raw_line.encode("utf-8", errors="replace"))
            line_no_nl = raw_line.rstrip("\r\n")
            s = line_no_nl.strip()
            is_start = bool(header_re.match(s)) or NXLogReader._is_json_record_line(s)

            if is_start:
                started = True
                if cur:
                    spans.append(("\n".join(cur), cur_offset, running_offset))
                    cur = []
                cur_offset = running_offset
            elif not require_header_start and cur:
                prev_first = cur[0].strip()
                is_prev_multiline_hdr = bool(multiline_hdr_re.match(prev_first))
                if not is_prev_multiline_hdr and s:
                    spans.append(("\n".join(cur), cur_offset, running_offset))
                    cur = []
                    cur_offset = running_offset

            if started:
                if not cur:
                    if not s:
                        running_offset += line_bytes_len
                        continue
                    cur_offset = running_offset
                cur.append(line_no_nl)

            running_offset += line_bytes_len

        if cur:
            spans.append(("\n".join(cur), cur_offset, running_offset))

        return spans

    @staticmethod
    def _split_into_blocks_with_offsets(chunk: str, base_offset: int, require_header_start: bool = False):
        """
        Splits a decoded log chunk into (block_text, block_byte_offset) tuples.
        """
        return [
            (blk, start_off)
            for blk, start_off, _ in NXLogReader._split_into_blocks_with_spans(
                chunk, base_offset, require_header_start=require_header_start
            )
        ]

    @staticmethod
    def _is_incomplete_trailing_block(last_blk: str) -> bool:
        """
        Returns True if the trailing block at EOF is an incomplete multiline Windows
        Security/Event block that has not yet been fully flushed by NXLog.
        """
        has_subject = bool(re.search(r"\n\s*(?:Subject|Security ID):", last_blk))
        has_completion = any(
            sec in last_blk for sec in (
                "Process Name:",
                "Network Information:",
                "Additional Information:",
                "Detailed Authentication Information:",
                "This event occurs",
                "Privileges:",
                "Read Operation:",
                "Enumerated:",
                "Group:",
                "Access Reasons:",
                "Error Code:",
            )
        )
        return (has_subject and not has_completion) or last_blk.rstrip().endswith(":")

    def read_events(self, incremental: bool = True) -> List[Dict[str, Any]]:
        self.last_error = None
        self.diagnostics = []
        if not self.log_file.exists():
            self.last_error = f"NXLog file not found: {self.log_file}"
            self.diagnostics.append({"reason": "file_not_found", "file": str(self.log_file)})
            print(f"[WARNING] {self.last_error}")
            return []

        start_offset = self.load_cursor() if incremental else 0
        events = []

        try:
            self._batch_receiver_ip = str(get_receiver_ip() or "N/A").strip()
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()

                if start_offset > file_len:
                    self.diagnostics.append({
                        "reason": "cursor_exceeded_file_len_reset_to_zero",
                        "previous_offset": start_offset,
                        "file_len": file_len,
                    })
                    start_offset = 0

                f.seek(start_offset)
                b_chunk = f.read()

            if not b_chunk:
                return []

            # Cleanly handle trailing incomplete records at EOF
            last_nl = b_chunk.rfind(b"\n")
            if last_nl != -1 and last_nl < len(b_chunk) - 1:
                valid_bytes = b_chunk[:last_nl + 1]
                new_offset = start_offset + (last_nl + 1)
                self.diagnostics.append({
                    "reason": "deferred_unterminated_trailing_line",
                    "byte_offset": new_offset,
                })
            elif last_nl == -1:
                if start_offset > 0:
                    self.diagnostics.append({
                        "reason": "deferred_partial_line_at_eof",
                        "byte_offset": start_offset,
                    })
                    return []
                valid_bytes = b_chunk
                new_offset = start_offset + len(b_chunk)
            else:
                valid_bytes = b_chunk
                new_offset = start_offset + len(b_chunk)

            chunk = valid_bytes.decode("utf-8", errors="replace")
            spans = self._split_into_blocks_with_spans(chunk, start_offset, require_header_start=False)

            # Protect against incomplete trailing multiline Windows Security blocks at EOF
            if incremental and spans:
                last_blk, last_start, _ = spans[-1]
                if self._is_incomplete_trailing_block(last_blk):
                    new_offset = last_start
                    spans.pop()
                    self.diagnostics.append({
                        "reason": "deferred_incomplete_trailing_block",
                        "byte_offset": last_start,
                        "preview": last_blk[:120],
                    })

            safe_cursor_offset = start_offset
            parse_failed = False

            for b, b_offset, b_end_offset in spans:
                b_str = b.strip()
                if not b_str:
                    safe_cursor_offset = b_end_offset
                    continue
                try:
                    parsed = self.parse_line(b_str)
                except Exception as parse_err:
                    self.last_error = f"Failed to parse block at offset {b_offset}: {parse_err}"
                    self.diagnostics.append({
                        "reason": "parse_exception",
                        "byte_offset": b_offset,
                        "error": str(parse_err),
                        "preview": b_str[:120],
                    })
                    print(f"[WARNING] NXLogReader {self.last_error}")
                    parsed = None

                if not parsed:
                    # Do not silently advance cursor past an unparsed record
                    if not self.last_error:
                        self.last_error = f"Unparseable record encountered at byte offset {b_offset}"
                    self.diagnostics.append({
                        "reason": "unparseable_record",
                        "byte_offset": b_offset,
                        "error": self.last_error,
                        "preview": b_str[:120],
                    })
                    safe_cursor_offset = b_offset
                    parse_failed = True
                    break

                parsed["record_offset"] = b_offset
                events.append(parsed)
                safe_cursor_offset = b_end_offset

            if not parse_failed:
                safe_cursor_offset = new_offset

            if incremental and safe_cursor_offset != start_offset:
                self.save_cursor(safe_cursor_offset)

            print(f"[INFO] NXLogReader ingested {len(events)} events from {self.log_file}")
            return events

        except Exception as e:
            self.last_error = f"Failed to read NXLog file {self.log_file}: {e}"
            self.diagnostics.append({"reason": "read_exception", "error": str(e)})
            print(f"[ERROR] {self.last_error}")
            return []
        finally:
            self._batch_receiver_ip = None

    def replay_events(
        self,
        from_offset: Optional[int] = None,
        max_events: Optional[int] = None,
        scan_bytes: int = 20000000
    ) -> List[Dict[str, Any]]:
        """
        Safely replay or inspect events without advancing or modifying the incremental cursor.
        Preserves diagnostic verification probes and live verification markers within the scanned window.
        """
        if not self.log_file.exists():
            return []

        try:
            self._batch_receiver_ip = str(get_receiver_ip() or "N/A").strip()
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()
                if file_len == 0:
                    return []
                if from_offset is None:
                    actual_offset = max(0, file_len - max(scan_bytes, 5000000))
                else:
                    actual_offset = 0 if from_offset > file_len else from_offset
                f.seek(actual_offset)
                b_chunk = f.read()

            if not b_chunk:
                return []

            seeked_mid_file = actual_offset > 0
            if seeked_mid_file:
                first_nl = b_chunk.find(b"\n")
                if first_nl != -1:
                    b_chunk = b_chunk[first_nl + 1:]
                    actual_offset += (first_nl + 1)

            chunk = b_chunk.decode("utf-8", errors="replace")
            blocks = self._split_into_blocks_with_offsets(chunk, actual_offset, require_header_start=seeked_mid_file)

            events = []
            for b, b_offset in blocks:
                b_str = b.strip()
                if not b_str:
                    continue
                parsed = self.parse_line(b_str)
                if parsed:
                    parsed["record_offset"] = b_offset
                    events.append(parsed)

            if max_events is not None and len(events) > max_events:
                from analysis.normalize import LogNormalizer
                preserved_markers = getattr(
                    LogNormalizer,
                    "PRESERVED_LIVE_MARKERS",
                    ("ADAPTIVESENTINEL_LIVE_", "ADAPTIVESENTINEL_"),
                )
                diag_evts = [e for e in events[:-max_events] if e.get("is_diagnostic")]
                preserved_live = [
                    e
                    for e in events[:-max_events]
                    if not e.get("is_diagnostic")
                    and any(
                        m in str(e.get("description", "")).upper() or m in str(e.get("raw_line", "")).upper()
                        for m in preserved_markers
                    )
                ]
                tail = events[-max_events:]
                if preserved_live:
                    keep_count = max(0, max_events - len(preserved_live))
                    tail = preserved_live[-max_events:] + (tail[-keep_count:] if keep_count > 0 else [])
                return diag_evts + tail
            return events
        except Exception as e:
            print(f"[!] Error in replay_events: {e}")
            return []
        finally:
            self._batch_receiver_ip = None

    def get_recent_events(self, max_events: int = 500, scan_bytes: int = 20000000) -> List[Dict[str, Any]]:
        """
        Efficiently retrieves up to `max_events` from the end of the log file
        without loading the entire historical backlog into memory or parsing every
        non-diagnostic record in the 20 MB window, while preserving byte offsets,
        multiline Windows Event Log records, incomplete trailing records, diagnostic
        markers, live verification markers, endpoint identity, and the production
        ingestion cursor.
        """
        if not self.log_file.exists():
            return []

        try:
            self._batch_receiver_ip = str(get_receiver_ip() or "N/A").strip()
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()
                if file_len == 0:
                    return []
                chunk_size = min(file_len, max(scan_bytes, 5000000))
                actual_offset = file_len - chunk_size
                f.seek(actual_offset)
                b_chunk = f.read()

            if not b_chunk:
                return []

            seeked_mid_file = actual_offset > 0
            if seeked_mid_file:
                first_nl = b_chunk.find(b"\n")
                if first_nl != -1:
                    b_chunk = b_chunk[first_nl + 1:]
                    actual_offset += (first_nl + 1)

            chunk = b_chunk.decode("utf-8", errors="replace")
            blocks = self._split_into_blocks_with_offsets(chunk, actual_offset, require_header_start=seeked_mid_file)

            if blocks and self._is_incomplete_trailing_block(blocks[-1][0]):
                blocks.pop()

            non_empty_blocks = [(b.strip(), b_offset) for b, b_offset in blocks if b.strip()]
            if not non_empty_blocks:
                return []

            if max_events is not None and max_events > 0 and len(non_empty_blocks) > max_events:
                from analysis.normalize import LogNormalizer
                diag_markers = LogNormalizer.DIAGNOSTIC_MARKERS
                preserved_markers = getattr(
                    LogNormalizer,
                    "PRESERVED_LIVE_MARKERS",
                    ("ADAPTIVESENTINEL_LIVE_", "ADAPTIVESENTINEL_"),
                )

                tail_events_rev = []
                cutoff_idx = 0
                for idx in range(len(non_empty_blocks) - 1, -1, -1):
                    b_str, b_offset = non_empty_blocks[idx]
                    parsed = self.parse_line(b_str)
                    if parsed:
                        parsed["record_offset"] = b_offset
                        tail_events_rev.append(parsed)
                        if len(tail_events_rev) >= max_events:
                            cutoff_idx = idx
                            break

                tail_events = list(reversed(tail_events_rev))
                diag_evts = []
                preserved_live_evts = []
                for b_str, b_offset in non_empty_blocks[:cutoff_idx]:
                    b_upper = b_str.upper()
                    has_diag = any(m in b_upper for m in diag_markers) or "IS_DIAGNOSTIC" in b_upper
                    has_preserved = any(m in b_upper for m in preserved_markers)
                    if has_diag or has_preserved:
                        parsed = self.parse_line(b_str)
                        if parsed:
                            parsed["record_offset"] = b_offset
                            if parsed.get("is_diagnostic"):
                                diag_evts.append(parsed)
                            elif has_preserved:
                                preserved_live_evts.append(parsed)

                if preserved_live_evts:
                    keep_count = max(0, max_events - len(preserved_live_evts))
                    if keep_count > 0:
                        tail_events = preserved_live_evts[-max_events:] + tail_events[-keep_count:]
                    else:
                        tail_events = preserved_live_evts[-max_events:]
                return diag_evts + tail_events

            events = []
            for b_str, b_offset in non_empty_blocks:
                parsed = self.parse_line(b_str)
                if parsed:
                    parsed["record_offset"] = b_offset
                    events.append(parsed)

            if max_events is not None and len(events) > max_events:
                diag_evts = [e for e in events[:-max_events] if e.get("is_diagnostic")]
                return diag_evts + events[-max_events:]
            return events
        except Exception as e:
            print(f"[!] Exception in get_recent_events: {e}")
            return []
        finally:
            self._batch_receiver_ip = None