import os
from typing import List, Dict, Any, Optional
from config.settings import get_receiver_ip


AMBIGUOUS_HOSTNAMES = {
    "", "-", "N/A", "NA", "NONE", "NULL", "UNKNOWN", "UNKNOWN_HOST",
    "LOCAL", "LOCALHOST", "127.0.0.1", "::1", "0.0.0.0",
}

DEFAULT_VERIFIED_HOST_ALIASES: Dict[str, str] = {
    "harsha": "Harsha",
    "harsha-pc": "Harsha",
    "harsha.local": "Harsha",
    "harsha-laptop": "Harsha",
}


def get_verified_host_aliases(extra_aliases: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    """
    Returns a case-insensitive mapping of verified endpoint aliases to their canonical
    endpoint hostname (e.g., 'harsha-pc' -> 'Harsha').
    Unverified or ambiguous hostnames are never added to this mapping.
    """
    aliases = dict(DEFAULT_VERIFIED_HOST_ALIASES)

    # Support explicit verified environment aliases when configured and verified
    if os.getenv("HARSHA_ALIASES_VERIFIED", "true").strip().lower() not in ("0", "false", "no"):
        env_harsha_aliases = os.getenv("HARSHA_HOST_ALIASES", "").strip()
        if env_harsha_aliases:
            for token in env_harsha_aliases.split(","):
                tok = token.strip()
                if tok and tok.upper() not in AMBIGUOUS_HOSTNAMES:
                    aliases[tok.lower()] = "Harsha"

    # Support configured ENDPOINT_HOSTNAME only when explicitly verified to represent Harsha
    env_ep_host = os.getenv("ENDPOINT_HOSTNAME", "").strip()
    env_ep_verified = os.getenv("ENDPOINT_HOSTNAME_VERIFIED", "").strip().lower() in ("1", "true", "yes")
    if env_ep_host and env_ep_host.upper() not in AMBIGUOUS_HOSTNAMES and env_ep_verified:
        canonical_target = os.getenv("ENDPOINT_CANONICAL_NAME", "Harsha").strip() or "Harsha"
        aliases[env_ep_host.lower()] = canonical_target

    if extra_aliases:
        for k, v in extra_aliases.items():
            k_str = str(k or "").strip()
            v_str = str(v or "").strip()
            if k_str and v_str and k_str.upper() not in AMBIGUOUS_HOSTNAMES and v_str.upper() not in AMBIGUOUS_HOSTNAMES:
                aliases[k_str.lower()] = v_str

    return aliases


def resolve_canonical_hostname(
    raw_hostname: Any,
    verified_aliases: Optional[Dict[str, str]] = None,
) -> str:
    """
    Normalizes an endpoint hostname using verified aliases (e.g., 'HARSHA', 'HARSHA-PC' -> 'Harsha')
    while classifying missing or ambiguous hostnames strictly as 'UNKNOWN_HOST'.
    Never classifies missing, ambiguous, or unverified hostnames as 'Harsha'.
    """
    if raw_hostname is None:
        return "UNKNOWN_HOST"
    cleaned = str(raw_hostname).strip()
    if not cleaned or cleaned.upper() in AMBIGUOUS_HOSTNAMES:
        return "UNKNOWN_HOST"
    alias_map = get_verified_host_aliases(verified_aliases)
    low = cleaned.lower()
    if low in alias_map:
        return alias_map[low]
    return cleaned


def endpoint_matches_filter(
    hostname: Any,
    selected_endpoint: str,
    verified_aliases: Optional[Dict[str, str]] = None,
) -> bool:
    """
    Returns True if `hostname` belongs to the selected endpoint filter after verified
    canonical alias resolution. Ambiguous/missing hostnames ('UNKNOWN_HOST') never match
    a named endpoint such as 'Harsha'.
    """
    if not selected_endpoint or selected_endpoint == "ALL ENDPOINTS":
        return True
    sel_clean = str(selected_endpoint).strip()
    if not sel_clean or sel_clean.upper() == "ALL ENDPOINTS":
        return True
    evt_canonical = resolve_canonical_hostname(hostname, verified_aliases=verified_aliases)
    if sel_clean.upper() == "UNKNOWN_HOST":
        return evt_canonical == "UNKNOWN_HOST"
    target_canonical = resolve_canonical_hostname(sel_clean, verified_aliases=verified_aliases)
    if target_canonical == "UNKNOWN_HOST" or evt_canonical == "UNKNOWN_HOST":
        return False
    return evt_canonical.lower() == target_canonical.lower()


class LogNormalizer:
    """
    Normalizes multi-source events (Windows, Sysmon, Linux, Suricata)
    into a standardized SentinelGPT event schema.
    """

    def __init__(self, verified_aliases: Optional[Dict[str, str]] = None):
        self.verified_aliases = verified_aliases

    EVENT_TYPE_MAP = {
        4624: "Successful Authentication",
        4625: "Failed Authentication",
        4672: "Special Privileges Assigned",
        4688: "Windows Process Creation",
        4720: "User Account Created",
        4798: "User Local Group Membership Enumerated",
        4799: "Local Group Enumeration",
        5379: "Credential Manager Credential Read",
        7040: "Service Start Type Changed",
        1102: "Audit Log Cleared",
        1000: "Application / Informational Event (ID 1000)",
        1: "Sysmon Process Creation",
        3: "Sysmon Network Connection",
        10: "Sysmon LSASS Process Access",
        1001: "Linux SSH Login Attempt",
        2000001: "Suricata Network IDS Alert"
    }

    SEVERITY_MAP = {
        4624: "Low",
        4625: "Medium",
        4672: "Low",
        4688: "Medium",
        4720: "High",
        4798: "Low",
        4799: "Low",
        5379: "Low",
        7040: "Medium",
        1102: "Critical",
        1000: "Low",
        1: "High",
        3: "Medium",
        10: "Critical",
        1001: "Medium",
        2000001: "High"
    }

    CRED_VAULT_TOOLS = (
        "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe",
        "rundll32", "mimikatz", "lazagne", "seatbelt", "sharphound",
        "bloodhound", "procdump", "wscript", "cscript", "mshta", "python",
        "sekurlsa", "dpapi",
    )

    RECON_BINARIES = (
        "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
        "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
        "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
    )

    @classmethod
    def resolve_event_severity(
        cls,
        event_id: int,
        process_name: str = "",
        command_line: str = "",
        description: str = "",
        curr_sev: str = "",
    ) -> str:
        """
        Determines event-level severity accurately. Routine Windows background
        Event IDs 5379, 4798, and 4799 default to Low unless suspicious credential
        harvesting or reconnaissance tools appear in the process/command telemetry.
        """
        combined = f"{process_name or ''} {command_line or ''} {description or ''}".lower()
        if event_id == 5379:
            return "High" if any(t in combined for t in cls.CRED_VAULT_TOOLS) else "Low"
        if event_id in (4798, 4799):
            return "Medium" if any(b in combined for b in cls.RECON_BINARIES) else "Low"
        if curr_sev and str(curr_sev).strip().title() not in ["Low", "Informational", "Info", "N/A"]:
            return str(curr_sev).strip().title()
        return cls.SEVERITY_MAP.get(event_id, curr_sev or "Low")

    MITRE_TECHNIQUE_MAP = {
        4624: "T1078",      # Valid Accounts
        4625: "T1110",      # Brute Force
        4672: "T1078.001",  # Domain Accounts
        4688: "T1059",      # Command and Scripting Interpreter
        4720: "T1136",      # Create Account
        4798: "T1087.001",  # Account Discovery: Local Account
        4799: "T1087",      # Account Discovery
        5379: "T1555.004",  # Credentials from Password Stores: Windows Credential Manager
        7040: "T1543",      # Create or Modify System Process
        1102: "T1070.001",  # Clear Windows Event Logs
        1000: "N/A",        # Diagnostic Telemetry Probe
        1: "T1059.001",     # PowerShell Execution
        10: "T1003.001",    # LSASS Memory Dumping
        1001: "T1110.001",  # Password Guessing
        2000001: "T1021"    # Remote Services
    }

    DIAGNOSTIC_MARKERS = (
        "SECTOR1_RECEIVER_TEST",
        "SECTOR1_E2E",
        "DIAGNOSTIC_TEST",
        "PHASE1_",
        "PHASE2_",
        "PHASE3_",
        "MULTI_ENDPOINT_",
        "RECEIVER_TEST",
        "SENTINEL_TEST",
        "ADAPTIVESENTINEL_LIVE_TEST",
        "ADAPTIVESENTINEL_CONTINUOUS_TEST",
        "ADAPTIVESENTINEL_FINAL_VERIFY",
        "ADAPTIVESENTINEL_LIVE_VERIFY",
        "ADAPTIVESENTINEL_TEST",
        "ADAPTIVESENTINEL_DIAG",
        "CONTINUOUS_TEST",
        "FINAL_VERIFY",
        "LIVE_VERIFY",
        "ADAPTIVESENTINELGPT TEST EVENT",
        "ADAPTIVE SENTINEL CONNECTION TEST",
        "NXLOG TEST EVENT",
        "LIVE TEST FROM",
        "LIVE_TEST_",
    )

    PRESERVED_LIVE_MARKERS = (
        "ADAPTIVESENTINEL_LIVE_",
        "ADAPTIVESENTINEL_",
    )

    def normalize(self, raw_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        normalized_events = []
        if not raw_logs:
            return normalized_events
        invalid_ips = {"-", "::1", "127.0.0.1", "", "N/A", "0.0.0.0", "NONE", "UNKNOWN"}
        batch_receiver_ip = str(get_receiver_ip() or "N/A").strip()

        for log in raw_logs:
            event_id = log.get("event_id", 0)
            desc = log.get("description") or log.get("message", "No event description provided.")
            cmd_line = log.get("command_line", "N/A")
            proc_name_lower = str(log.get("process_name") or "").lower()
            cmd_lower = str(cmd_line or "").lower()
            desc_lower = str(desc or "").lower()

            # Distinguish overloaded Event IDs (1, 10, 1001) between Sysmon/SSH attacks and benign Windows OS informational events
            is_benign_overloaded_eid = False
            if event_id == 1 and not (
                "powershell" in proc_name_lower
                or "pwsh" in proc_name_lower
                or "powershell" in cmd_lower
                or "pwsh" in cmd_lower
                or "powershell" in desc_lower
                or "pwsh" in desc_lower
            ):
                is_benign_overloaded_eid = True
            elif event_id == 10 and not (
                "mimikatz" in proc_name_lower
                or "mimikatz" in cmd_lower
                or "mimikatz" in desc_lower
                or "lsass" in proc_name_lower
                or "lsass" in cmd_lower
                or "lsass" in desc_lower
                or "sekurlsa" in cmd_lower
                or "sekurlsa" in desc_lower
                or "process accessed" in desc_lower
            ):
                is_benign_overloaded_eid = True
            elif event_id == 1001 and (
                "fault bucket" in desc_lower
                or not (
                    "ssh" in proc_name_lower
                    or "ssh" in desc_lower
                    or "failed" in desc_lower
                    or "login" in desc_lower
                    or "logon" in desc_lower
                )
            ):
                is_benign_overloaded_eid = True

            # Check if event is an explicit diagnostic verification probe (Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in str(desc).upper() or marker in str(cmd_line).upper()
                       for marker in self.DIAGNOSTIC_MARKERS)
            )

            mitre_tech = log.get("mitre_technique")
            if is_diagnostic or is_benign_overloaded_eid:
                mitre_tech = "N/A"
            elif not mitre_tech or mitre_tech in ["N/A", "T1000"]:
                mitre_list = log.get("mitre_techniques", [])
                if isinstance(mitre_list, list) and mitre_list:
                    mitre_tech = ", ".join(str(m) for m in mitre_list)
                else:
                    mitre_tech = self.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")

            receiver_ip = str(log.get("receiver_ip") or batch_receiver_ip or "N/A").strip()
            source = log.get("source") or "real_nxlog_windows"
            raw_hostname = (
                str(log.get("raw_hostname") or log.get("hostname") or "UNKNOWN_HOST").strip()
                or "UNKNOWN_HOST"
            )
            hostname = resolve_canonical_hostname(
                raw_hostname,
                verified_aliases=self.verified_aliases,
            )
            provider = str(log.get("provider") or "N/A").strip() or "N/A"

            raw_source_ip = log.get("source_ip")
            src_ip_str = str(raw_source_ip).strip() if raw_source_ip is not None else ""
            if not src_ip_str or src_ip_str.upper() in invalid_ips or (
                source == "real_nxlog_windows" and src_ip_str == receiver_ip
            ):
                source_ip = "N/A"
            else:
                source_ip = src_ip_str

            raw_peer_ip = (
                log.get("remote_peer_ip")
                or log.get("MessageSourceAddress")
                or log.get("RemoteIp")
                or log.get("PeerIp")
            )
            peer_ip_str = str(raw_peer_ip).strip() if raw_peer_ip is not None else ""
            if not peer_ip_str or peer_ip_str.upper() in invalid_ips or peer_ip_str == receiver_ip:
                remote_peer_ip = "N/A"
            else:
                remote_peer_ip = peer_ip_str

            # Determine event_type string cleanly
            extracted_evt_type = log.get("event_type")
            if is_diagnostic:
                extracted_evt_type = "Diagnostic Telemetry Probe"
            elif is_benign_overloaded_eid:
                if event_id == 1:
                    extracted_evt_type = "Windows System Event (ID 1)"
                elif event_id == 1001:
                    extracted_evt_type = "Windows Error Reporting Event (ID 1001)"
                else:
                    extracted_evt_type = f"Windows Informational Event (ID {event_id})"
            elif not extracted_evt_type or extracted_evt_type in ["NXLog Event", "Generic Event", "N/A", "Diagnostic Telemetry Probe"]:
                if event_id in self.EVENT_TYPE_MAP:
                    extracted_evt_type = self.EVENT_TYPE_MAP[event_id]
                elif event_id != 0:
                    extracted_evt_type = f"Windows Event (ID {event_id})"
                else:
                    extracted_evt_type = "Windows Event"

            # Start with original dict to preserve all custom fields (including record_offset, record_id)
            normalized_event = log.copy()
            curr_sev = log.get("severity")
            if is_diagnostic or is_benign_overloaded_eid:
                resolved_sev = "Low"
            else:
                resolved_sev = self.resolve_event_severity(
                    event_id=event_id,
                    process_name=str(log.get("process_name") or ""),
                    command_line=str(cmd_line or ""),
                    description=str(desc or ""),
                    curr_sev=str(curr_sev or ""),
                )

            dst_ip = log.get("destination_ip")
            if not dst_ip or dst_ip in ["-", ""]:
                dst_ip = receiver_ip

            raw_channel = str(log.get("log_channel") or "").strip()
            if not raw_channel:
                if event_id == 2000001 or "suricata" in proc_name_lower or "suricata" in desc_lower:
                    raw_channel = "Suricata IDS"
                elif event_id == 1001 and ("ssh" in proc_name_lower or "ssh" in desc_lower):
                    raw_channel = "Linux Auth"
                else:
                    raw_channel = source

            normalized_event.update({
                "timestamp": log.get("timestamp"),
                "ingestion_timestamp": log.get("ingestion_timestamp"),
                "source": source,
                "source_type": str(log.get("source_type") or source),
                "log_channel": raw_channel,
                "provider": provider,
                "event_id": event_id,
                "event_type": extracted_evt_type,
                "severity": resolved_sev,
                "hostname": hostname,
                "raw_hostname": raw_hostname,
                "user": log.get("user", "SYSTEM"),
                "source_ip": source_ip,
                "remote_peer_ip": remote_peer_ip,
                "receiver_ip": receiver_ip,
                "destination_ip": dst_ip,
                "process_name": log.get("process_name", "N/A"),
                "command_line": cmd_line,
                "description": desc,
                "message": desc,
                "mitre_technique": mitre_tech,
                "mitre_techniques": log.get("mitre_techniques", []),
                "is_diagnostic": is_diagnostic
            })

            normalized_events.append(normalized_event)

        print(f"[INFO] LogNormalizer standardized {len(normalized_events)} log events.")
        return normalized_events


def normalize_events(
    raw_logs: List[Dict[str, Any]],
    verified_aliases: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    return LogNormalizer(verified_aliases=verified_aliases).normalize(raw_logs)


def build_endpoint_inventory(
    events: List[Dict[str, Any]],
    receiver_ip: str = None,
    active_tcp_peer_ip: str = None,
    verified_aliases: Optional[Dict[str, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Builds a per-endpoint inventory from observed telemetry events.
    Preserves each distinct hostname (unifying verified aliases and Windows case
    variants such as 'HARSHA', 'HARSHA-PC', and 'Harsha') and tracks:
      - hostname (canonical endpoint hostname)
      - raw_hostnames (sorted list of raw hostnames observed for this endpoint)
      - event_count
      - latest_timestamp
      - observed_source_ip ('N/A' when unknown; never uses receiver_ip)
      - observed_remote_peer_ip ('N/A' when unknown; never uses receiver_ip)
      - sources
    """
    active_receiver = str(receiver_ip or get_receiver_ip() or "N/A").strip()
    invalid_ips = {"", "-", "N/A", "NONE", "UNKNOWN", "127.0.0.1", "::1", "0.0.0.0", active_receiver.upper()}
    fallback_peer = str(active_tcp_peer_ip or "").strip()
    if fallback_peer.upper() in invalid_ips or fallback_peer == active_receiver:
        fallback_peer = ""

    alias_map = get_verified_host_aliases(verified_aliases)
    inventory_map: Dict[str, Dict[str, Any]] = {}

    for evt in events:
        raw_host = str(evt.get("raw_hostname") or evt.get("hostname") or "UNKNOWN_HOST").strip() or "UNKNOWN_HOST"
        canonical_host = resolve_canonical_hostname(
            evt.get("hostname") or raw_host,
            verified_aliases=alias_map,
        )
        host_key = canonical_host.lower()
        ts = str(evt.get("timestamp") or evt.get("ingestion_timestamp") or "N/A")[:19].replace("T", " ")
        src_ip = str(evt.get("source_ip") or "N/A").strip()
        peer_ip = str(evt.get("remote_peer_ip") or "N/A").strip()
        source_name = str(evt.get("source") or "real_nxlog_windows").strip()

        if host_key not in inventory_map:
            inventory_map[host_key] = {
                "hostname": canonical_host,
                "raw_hostnames": set(),
                "event_count": 0,
                "latest_timestamp": ts,
                "observed_source_ip": "N/A",
                "observed_remote_peer_ip": "N/A",
                "sources": set(),
            }
        else:
            existing_host = inventory_map[host_key]["hostname"]
            if existing_host.isupper() and not canonical_host.isupper():
                inventory_map[host_key]["hostname"] = canonical_host

        entry = inventory_map[host_key]
        entry["raw_hostnames"].add(raw_host)
        entry["event_count"] += 1
        if ts != "N/A" and (entry["latest_timestamp"] == "N/A" or ts >= entry["latest_timestamp"]):
            entry["latest_timestamp"] = ts

        if src_ip.upper() not in invalid_ips and src_ip != active_receiver:
            entry["observed_source_ip"] = src_ip

        if peer_ip.upper() not in invalid_ips and peer_ip != active_receiver:
            entry["observed_remote_peer_ip"] = peer_ip
        elif fallback_peer and source_name == "real_nxlog_windows" and entry["observed_remote_peer_ip"] == "N/A":
            entry["observed_remote_peer_ip"] = fallback_peer

        if source_name:
            entry["sources"].add(source_name)

    inventory_list = []
    for _, data in inventory_map.items():
        data["sources"] = sorted(list(data["sources"]))
        data["raw_hostnames"] = sorted(list(data["raw_hostnames"]))
        inventory_list.append(data)

    inventory_list.sort(
        key=lambda item: (
            item["latest_timestamp"] if item["latest_timestamp"] != "N/A" else "",
            item["event_count"],
        ),
        reverse=True,
    )
    return inventory_list


SOURCE_FILTER_MAP: Dict[str, Optional[str]] = {
    "ALL SOURCES": None,
    "REAL NXLOG WINDOWS (real_nxlog_windows)": "real_nxlog_windows",
    "real_nxlog_windows": "real_nxlog_windows",
    "SYNTHETIC TELEMETRY (synthetic)": "synthetic",
    "synthetic": "synthetic",
    "LOCAL WINDOWS EVENT LOG (local_windows)": "local_windows",
    "local_windows": "local_windows",
    "LIVE SIMULATION API (api_simulation)": "api_simulation",
    "api_simulation": "api_simulation",
}


def resolve_source_filter_code(selected_source: Optional[str]) -> Optional[str]:
    """Resolves a UI source filter label or raw source code to its canonical source string (or None for ALL SOURCES)."""
    if not selected_source:
        return None
    s = str(selected_source).strip()
    if s in SOURCE_FILTER_MAP:
        return SOURCE_FILTER_MAP[s]
    s_upper = s.upper()
    if s_upper == "ALL SOURCES":
        return None
    for k, v in SOURCE_FILTER_MAP.items():
        if k.upper() == s_upper:
            return v
    return s


def event_matches_source_filter(evt: Dict[str, Any], selected_source: Optional[str]) -> bool:
    """Returns True if `evt` belongs to `selected_source` (or if `ALL SOURCES` is active)."""
    target_source = resolve_source_filter_code(selected_source)
    if not target_source:
        return True
    evt_source = str(evt.get("source") or "").strip()
    return evt_source == target_source


def filter_telemetry_by_endpoint(
    logs: List[Dict[str, Any]],
    incidents: List[Dict[str, Any]],
    selected_endpoint: str,
    verified_aliases: Optional[Dict[str, str]] = None,
):
    """
    Filters logs and correlated incidents by endpoint hostname (supporting verified
    aliases and case-insensitive matching) and ensures returned incidents are backed
    by matching evidence in the selected scope.
    """
    alias_map = get_verified_host_aliases(verified_aliases)

    if not selected_endpoint or selected_endpoint == "ALL ENDPOINTS":
        # Even when ALL ENDPOINTS is selected, exclude historical zero-window snapshots
        # that have no supporting alerts in the active window if window_alert_count == 0
        active_incidents = [
            inc for inc in incidents
            if inc.get("window_alert_count", 1) > 0
            and ("alerts" not in inc or len(inc.get("alerts") or []) > 0)
        ]
        return logs, active_incidents

    filtered_logs = [
        l for l in logs
        if endpoint_matches_filter(
            l.get("hostname") or l.get("raw_hostname"),
            selected_endpoint,
            verified_aliases=alias_map,
        )
    ]

    filtered_incidents = []
    for inc in incidents:
        # Exclude stale zero-window historical snapshots that have no active evidence
        if inc.get("window_alert_count", 1) == 0:
            continue

        host_matches = endpoint_matches_filter(
            inc.get("affected_host"),
            selected_endpoint,
            verified_aliases=alias_map,
        )
        inc_alerts = inc.get("alerts")
        if isinstance(inc_alerts, list):
            matching_alerts = [
                alt for alt in inc_alerts
                if endpoint_matches_filter(
                    alt.get("hostname")
                    or (alt.get("event") or {}).get("hostname")
                    or (alt.get("event") or {}).get("raw_hostname"),
                    selected_endpoint,
                    verified_aliases=alias_map,
                )
            ]
            if matching_alerts:
                inc_copy = dict(inc)
                inc_copy["alerts"] = matching_alerts
                inc_copy["alert_count"] = len(matching_alerts)
                inc_copy["affected_host"] = resolve_canonical_hostname(
                    inc.get("affected_host") or selected_endpoint,
                    verified_aliases=alias_map,
                )
                inc_copy["affected_hosts"] = [inc_copy["affected_host"]]
                filtered_incidents.append(inc_copy)
        elif host_matches:
            filtered_incidents.append(inc)

    return filtered_logs, filtered_incidents


def compute_filtered_telemetry_scope(
    all_events: List[Dict[str, Any]],
    selected_source: str = "ALL SOURCES",
    selected_endpoint: str = "ALL ENDPOINTS",
    verified_aliases: Optional[Dict[str, str]] = None,
    incident_registry: Optional[Dict[str, Any]] = None,
    kb_db: Any = None,
    max_evidence_alerts: int = 100,
) -> Dict[str, Any]:
    """
    Computes a consistent, end-to-end filtered telemetry scope for the selected
    Telemetry Source and Endpoint Host:
      - source_scoped_events (all events matching selected_source, used for endpoint inventory)
      - endpoint_inventory (built from source_scoped_events)
      - scoped_all_events (matching both selected_source and selected_endpoint)
      - security_events (non-diagnostic events in scope)
      - unique_security_events (deduplicated non-diagnostic events in scope)
      - diagnostic_events (diagnostic verification probes in scope)
      - security_alerts (DetectionAgent alerts from unique_security_events)
      - diagnostic_alerts (DetectionAgent alerts from diagnostic_events)
      - active_incidents (correlated security incidents backed by matching scope evidence)
      - diagnostic_incidents (correlated diagnostic incidents in scope)
      - severity_counts (Critical, High, Medium, Low counts for unique_security_events)
      - mitre_counts (MITRE technique frequency map for unique_security_events)
    """
    from analysis.deduplicate import get_event_identity_key
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent, apply_cumulative_incident_tracking
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    alias_map = get_verified_host_aliases(verified_aliases)

    # Ensure events are normalized with canonical hostnames while preserving raw_hostname
    norm_events = []
    normalizer = LogNormalizer(verified_aliases=alias_map)
    need_full_normalize = any(
        "is_diagnostic" not in e or "raw_hostname" not in e or "severity" not in e
        for e in all_events
    )
    if need_full_normalize:
        norm_events = enrich_events(normalizer.normalize(all_events))
    else:
        for e in all_events:
            ec = dict(e)
            raw_h = str(ec.get("raw_hostname") or ec.get("hostname") or "UNKNOWN_HOST").strip() or "UNKNOWN_HOST"
            ec["raw_hostname"] = raw_h
            ec["hostname"] = resolve_canonical_hostname(ec.get("hostname") or raw_h, verified_aliases=alias_map)
            norm_events.append(ec)

    # 1. Filter by Telemetry Source
    source_scoped_events = [
        e for e in norm_events
        if event_matches_source_filter(e, selected_source)
    ]

    # Build endpoint inventory from source-scoped non-diagnostic + diagnostic events
    endpoint_inventory = build_endpoint_inventory(
        source_scoped_events,
        verified_aliases=alias_map,
    )

    # 2. Filter by Endpoint Host
    if not selected_endpoint or selected_endpoint == "ALL ENDPOINTS":
        scoped_all_events = list(source_scoped_events)
    else:
        scoped_all_events = [
            e for e in source_scoped_events
            if endpoint_matches_filter(
                e.get("hostname") or e.get("raw_hostname"),
                selected_endpoint,
                verified_aliases=alias_map,
            )
        ]

    # 3. Separate security telemetry from diagnostic verification probes
    security_events = [e for e in scoped_all_events if not e.get("is_diagnostic")]
    diagnostic_events = [e for e in scoped_all_events if e.get("is_diagnostic")]

    # Deduplicate security events by event identity key
    seen_keys = set()
    unique_security_events = []
    for evt in security_events:
        k = get_event_identity_key(evt)
        if k not in seen_keys:
            seen_keys.add(k)
            unique_security_events.append(evt)

    seen_diag_keys = set()
    unique_diagnostic_events = []
    for evt in diagnostic_events:
        k = get_event_identity_key(evt)
        if k not in seen_diag_keys:
            seen_diag_keys.add(k)
            unique_diagnostic_events.append(evt)

    # 4. Run Detection & Correlation on the filtered scope
    detector = DetectionAgent()
    correlator = CorrelationAgent()
    ti_agent = ThreatIntelligenceAgent()

    security_alerts = detector.detect(unique_security_events)
    diagnostic_alerts = detector.detect(unique_diagnostic_events)

    raw_correlated = ti_agent.analyze(correlator.correlate(security_alerts))
    active_incidents = [i for i in raw_correlated if not i.get("is_diagnostic")]
    if incident_registry is not None or kb_db is not None:
        reg_ref = incident_registry if incident_registry is not None else {}
        active_incidents = apply_cumulative_incident_tracking(
            active_incidents,
            registry=reg_ref,
            db=kb_db,
            max_evidence_alerts=max_evidence_alerts,
            retain_historical_incidents=False,
        )

    # Ensure every active incident meets the strict scope & supporting evidence rules
    _, active_incidents = filter_telemetry_by_endpoint(
        unique_security_events,
        active_incidents,
        selected_endpoint,
        verified_aliases=alias_map,
    )
    target_src = resolve_source_filter_code(selected_source)
    if target_src:
        active_incidents = [
            inc for inc in active_incidents
            if target_src in (inc.get("telemetry_sources") or [target_src])
            and len(inc.get("alerts") or []) > 0
        ]
    else:
        active_incidents = [
            inc for inc in active_incidents
            if len(inc.get("alerts") or []) > 0
        ]

    diagnostic_incidents = [
        i for i in correlator.correlate(diagnostic_alerts)
        if i.get("is_diagnostic")
    ]

    severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
    mitre_counts: Dict[str, int] = {}
    for evt in unique_security_events:
        sev = str(evt.get("severity") or "Low").capitalize()
        if sev in severity_counts:
            severity_counts[sev] += 1
        else:
            severity_counts["Low"] += 1
        mt = str(evt.get("mitre_technique") or "N/A").strip()
        if mt and mt != "N/A":
            mitre_counts[mt] = mitre_counts.get(mt, 0) + 1

    excluded_events_summary = {
        "excluded_by_source_filter": len(norm_events) - len(source_scoped_events),
        "excluded_by_endpoint_filter": len(source_scoped_events) - len(scoped_all_events),
        "separated_diagnostic_probes": len(diagnostic_events),
        "duplicates_removed": len(security_events) - len(unique_security_events),
    }

    return {
        "selected_source": selected_source,
        "selected_source_code": target_src or "ALL SOURCES",
        "selected_endpoint": selected_endpoint or "ALL ENDPOINTS",
        "source_scoped_events": source_scoped_events,
        "endpoint_inventory": endpoint_inventory,
        "scoped_all_events": scoped_all_events,
        "security_events": security_events,
        "unique_security_events": unique_security_events,
        "diagnostic_events": unique_diagnostic_events,
        "security_alerts": security_alerts,
        "diagnostic_alerts": diagnostic_alerts,
        "active_incidents": active_incidents,
        "diagnostic_incidents": diagnostic_incidents,
        "severity_counts": severity_counts,
        "mitre_counts": mitre_counts,
        "excluded_events_summary": excluded_events_summary,
    }