import uuid
from typing import List, Dict, Any


class DetectionAgent:
    """
    Detection Agent evaluating normalized events against MITRE ATT&CK rules,
    heuristic thresholds, and signature checks.
    """

    def detect(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        alerts = []

        for log in logs:
            event_id = log.get("event_id")
            process_name = str(log.get("process_name", "")).lower()
            cmd_line = str(log.get("command_line", "")).lower()
            desc = str(log.get("description", ""))

            alert = None

            # Diagnostic Telemetry Verification Probe (explicit diagnostic markers; Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in desc.upper() or marker in cmd_line.upper() for marker in [
                    "SECTOR1_RECEIVER_TEST",
                    "SECTOR1_E2E",
                    "DIAGNOSTIC_TEST",
                    "PHASE1_",
                    "PHASE2_",
                    "PHASE3_",
                    "MULTI_ENDPOINT_",
                    "RECEIVER_TEST",
                    "SENTINEL_TEST",
                    "ADAPTIVE SENTINEL CONNECTION TEST",
                    "ADAPTIVESENTINEL_LIVE_TEST",
                    "ADAPTIVESENTINELGPT TEST EVENT",
                    "LIVE_TEST_",
                    "NXLOG TEST EVENT",
                    "LIVE TEST FROM",
                ])
            )

            if is_diagnostic:
                alert = {
                    "alert_id": f"ALT-DIAG-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Diagnostic Telemetry Verification Probe",
                    "rule_id": "RULE-DIAG-001",
                    "severity": "Low",
                    "confidence": 100,
                    "mitre_technique": "N/A",
                    "is_diagnostic": True,
                    "event": log
                }

            # Failed Logon Attempt (Windows 4625 or SSH/auth 1001; exclude Windows Error Reporting Fault bucket 1001)
            elif event_id == 4625 or (
                event_id == 1001
                and "fault bucket" not in desc.lower()
                and (
                    "ssh" in process_name
                    or "ssh" in desc.lower()
                    or "ssh" in str(log.get("event_type", "")).lower()
                    or "failed" in desc.lower()
                    or "login" in desc.lower()
                    or "logon" in desc.lower()
                )
            ):
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Failed Logon Attempt",
                    "rule_id": "RULE-AUTH-4625",
                    "severity": "Medium",
                    "confidence": 85,
                    "mitre_technique": log.get("mitre_technique") if log.get("mitre_technique") not in (None, "", "N/A") else "T1110",
                    "event": log
                }

            # Unsigned/Bypass PowerShell Execution (require PowerShell/pwsh evidence; do not flag benign Event ID 1 low-power state)
            elif (
                "powershell" in process_name
                or "pwsh" in process_name
                or "powershell" in cmd_line
                or "pwsh" in cmd_line
                or (
                    event_id in (1, 4104, 4688)
                    and (
                        "powershell" in desc.lower()
                        or "pwsh" in desc.lower()
                        or "-encodedcommand" in desc.lower()
                        or "executionpolicy bypass" in desc.lower()
                    )
                )
            ):
                desc_lower = desc.lower()
                if (
                    "bypass" in cmd_line
                    or "enc" in cmd_line
                    or "executionpolicy" in cmd_line
                    or "bypass" in desc_lower
                    or "-encodedcommand" in desc_lower
                    or " -enc " in desc_lower
                ):
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "Suspicious Obfuscated PowerShell Execution",
                        "rule_id": "RULE-EXEC-PS-01",
                        "severity": "High",
                        "confidence": 92,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }
                else:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "PowerShell Script Execution",
                        "rule_id": "RULE-EXEC-PS-02",
                        "severity": "Low",
                        "confidence": 75,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }

            # Shadow Copy Deletion (Ransomware Prep)
            elif "vssadmin" in process_name or "delete shadows" in cmd_line or "delete shadows" in desc.lower():
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Volume Shadow Copies Deletion (Ransomware Activity)",
                    "rule_id": "RULE-IMPACT-VSS-01",
                    "severity": "Critical",
                    "confidence": 98,
                    "mitre_technique": "T1486",
                    "event": log
                }

            # Mimikatz LSASS Memory Access
            elif (
                "mimikatz" in process_name
                or "mimikatz" in cmd_line
                or "mimikatz" in desc.lower()
                or "lsass" in cmd_line
                or "lsass" in desc.lower()
                or "sekurlsa" in cmd_line
                or "sekurlsa" in desc.lower()
                or (
                    event_id == 10
                    and (
                        "lsass" in process_name
                        or "process accessed" in desc.lower()
                    )
                )
            ):
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "OS Credential Dumping via LSASS Access",
                    "rule_id": "RULE-CRED-LSASS-10",
                    "severity": "Critical",
                    "confidence": 96,
                    "mitre_technique": "T1003.001",
                    "event": log
                }

            # Audit Log Clearing
            elif event_id == 1102 or "wevtutil cl" in cmd_line:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Security Audit Log Cleared",
                    "rule_id": "RULE-EVASION-1102",
                    "severity": "High",
                    "confidence": 95,
                    "mitre_technique": "T1070",
                    "event": log
                }

            # New Account Created
            elif event_id == 4720:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "New Account Created",
                    "rule_id": "RULE-PERSIST-4720",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1136",
                    "event": log
                }

            # Network IDS Alert (Suricata)
            elif event_id == 2000001:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Suricata IDS: Lateral Movement via Remote WMI Execution",
                    "rule_id": "RULE-LATERAL-2000001",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1021",
                    "event": log
                }

            # Windows Credential Manager Access & Password Vault Harvesting
            elif event_id == 5379 or "credential manager" in str(log.get("description", "")).lower():
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Windows Credential Manager Access & Harvesting",
                    "rule_id": "RULE-CRED-5379",
                    "severity": "High",
                    "confidence": 94,
                    "mitre_technique": "T1555.004",
                    "event": log
                }

            # Local Account & Group Enumeration / Reconnaissance Discovery (ignore computer accounts ending in '$')
            elif event_id in [4798, 4799] or "group membership was enumerated" in str(log.get("description", "")).lower():
                target_user = str(log.get("user", "SYSTEM")).strip()
                if not target_user.endswith("$"):
                    is_admin_enum = target_user.lower() in ["administrator", "admin", "guest"]
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": f"Account Discovery: Group Membership Enumeration ({target_user})" if target_user not in ["SYSTEM", "N/A"] else "Account Discovery: Group Membership Enumeration",
                        "rule_id": "RULE-DISC-4798",
                        "severity": "High" if is_admin_enum else "Medium",
                        "confidence": 90 if is_admin_enum else 85,
                        "mitre_technique": "T1087.001" if event_id == 4798 else "T1087",
                        "event": log
                    }

            if alert:
                alert.setdefault("is_diagnostic", False)
                alert.setdefault("rule_id", "RULE-GEN-001")
                alert["hostname"] = log.get("hostname", "UNKNOWN_HOST")
                alert["source_ip"] = log.get("source_ip", "N/A")
                if not log.get("rule_id") or log.get("rule_id") == "N/A":
                    log["rule_id"] = alert["rule_id"]
                if alert.get("mitre_technique") not in (None, "", "N/A") and log.get("mitre_technique") in (None, "", "N/A"):
                    log["mitre_technique"] = alert["mitre_technique"]
                alerts.append(alert)

        print(f"[INFO] Detection Agent flagged {len(alerts)} suspicious alert(s).")
        return alerts