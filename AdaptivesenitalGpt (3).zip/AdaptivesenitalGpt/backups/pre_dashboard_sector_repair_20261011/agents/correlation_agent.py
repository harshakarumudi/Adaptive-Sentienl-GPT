import hashlib
import uuid
from typing import List, Dict, Any
from datetime import datetime


class CorrelationAgent:
    """
    Correlation Agent correlating atomic alerts into unified multi-stage Incidents
    based on host, user, IP, and temporal attack chain analysis.
    """

    def correlate(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        incidents = []

        # Canonicalize display hostname case-insensitively (e.g. 'Harsha' and 'HARSHA' -> 'Harsha')
        canonical_hosts: Dict[str, str] = {}
        for alert in alerts:
            raw_h = str(alert.get("event", {}).get("hostname") or alert.get("hostname") or "UNKNOWN_HOST").strip()
            h_low = raw_h.lower()
            if h_low not in canonical_hosts:
                canonical_hosts[h_low] = raw_h
            elif canonical_hosts[h_low].isupper() and not raw_h.isupper():
                canonical_hosts[h_low] = raw_h

        # Separate diagnostic probes (grouped by canonical host + provenance) from security alerts
        diag_groups: Dict[str, List[Dict[str, Any]]] = {}
        host_groups: Dict[str, List[Dict[str, Any]]] = {}

        # Pre-index non-SYSTEM users per (host_low, prov) so SYSTEM-level LSASS dumps on a host
        # with an active user brute-force chain correlate with that host's user attack chain
        host_primary_user: Dict[str, str] = {}
        for alert in alerts:
            if alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""):
                continue
            ev = alert.get("event", {})
            h_low = str(ev.get("hostname", "UNKNOWN_HOST")).strip().lower()
            u = str(ev.get("user", "SYSTEM")).strip()
            src = str(ev.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            hp_key = f"{h_low}::{prov}"
            if u not in ("SYSTEM", "N/A", "") and hp_key not in host_primary_user:
                host_primary_user[hp_key] = u

        for alert in alerts:
            event = alert["event"]
            raw_host = str(event.get("hostname", "UNKNOWN_HOST")).strip()
            host = canonical_hosts.get(raw_host.lower(), raw_host)
            user = str(event.get("user", "SYSTEM")).strip() or "SYSTEM"
            src = str(event.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"

            is_diag = bool(alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""))
            if is_diag:
                d_key = f"{host}::{prov}"
                diag_groups.setdefault(d_key, []).append(alert)
                continue

            hp_key = f"{host.lower()}::{prov}"
            if (
                user == "SYSTEM"
                and ("LSASS" in alert.get("alert_name", "") or "Mimikatz" in alert.get("alert_name", ""))
                and hp_key in host_primary_user
            ):
                user = host_primary_user[hp_key]

            key = f"{host}::{user}::{prov}"
            if key not in host_groups:
                host_groups[key] = []
            host_groups[key].append(alert)

        for d_key, diag_alerts in diag_groups.items():
            host, prov = d_key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"
            primary_diag_user = next(
                (str(a.get("event", {}).get("user", "SYSTEM")) for a in diag_alerts if a.get("event", {}).get("user") not in (None, "", "SYSTEM", "N/A")),
                str(diag_alerts[0].get("event", {}).get("user", "SYSTEM")),
            )
            inc_hash = hashlib.md5(f"{host}:{primary_diag_user}:diagnostic{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
            incidents.append({
                "incident_id": f"INC-DIAG-{inc_hash}",
                "incident_name": f"Diagnostic Telemetry Verification Probe ({host})",
                "severity": "Low",
                "confidence": 100,
                "is_diagnostic": True,
                "alert_count": len(diag_alerts),
                "affected_host": host,
                "affected_user": primary_diag_user,
                "alerts": diag_alerts,
                "created_at": datetime.now().isoformat()
            })

        # Correlate grouped security alerts
        for key, security_alerts in host_groups.items():
            host, user, prov = key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"

            if not security_alerts:
                continue

            failed_logins = [a for a in security_alerts if "Failed Logon" in a["alert_name"]]
            lsass_alerts = [a for a in security_alerts if "LSASS" in a["alert_name"] or "Mimikatz" in a["alert_name"]]
            cred_manager_alerts = [a for a in security_alerts if "Credential Manager" in a["alert_name"]]
            discovery_alerts = [a for a in security_alerts if "Account Discovery" in a["alert_name"] or "Group Membership" in a["alert_name"]]
            ps_alerts = [a for a in security_alerts if "PowerShell" in a["alert_name"]]
            obfuscated_ps_alerts = [a for a in ps_alerts if "Obfuscated" in a["alert_name"]]
            vss_alerts = [a for a in security_alerts if "Shadow Copies" in a["alert_name"] or "Ransomware" in a["alert_name"]]
            log_cleared = [a for a in security_alerts if "Log Cleared" in a["alert_name"]]
            account_created = [a for a in security_alerts if "New Account Created" in a["alert_name"]]
            suricata_alerts = [a for a in security_alerts if "Suricata" in a["alert_name"] or "Lateral Movement" in a["alert_name"]]

            # Ransomware Attack Sequence Correlation (Obfuscated PowerShell + VSSAdmin Deletion + co-occurring host stages)
            if vss_alerts or obfuscated_ps_alerts:
                combined_alerts = list(vss_alerts) + [a for a in ps_alerts if a not in vss_alerts]
                for extra in security_alerts:
                    if extra not in combined_alerts:
                        combined_alerts.append(extra)
                inc_hash = hashlib.md5(f"{host}:{user}:ransomware{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Ransomware Pre-Encryption Staging Activity",
                    "severity": "Critical",
                    "confidence": 98,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Brute Force & Credential Harvesting Chain (Failed Logins + Mimikatz LSASS, or 2+ Failed Logins)
            elif len(failed_logins) >= 2 or (failed_logins and lsass_alerts) or lsass_alerts:
                combined_alerts = list(failed_logins) + [a for a in lsass_alerts if a not in failed_logins]
                for extra in security_alerts:
                    if extra not in combined_alerts:
                        combined_alerts.append(extra)
                inc_hash = hashlib.md5(f"{host}:{user}:bruteforce{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                inc_title = (
                    "Automated Brute Force & Credential Dumping Attack Chain"
                    if lsass_alerts
                    else "Automated Brute Force & Password Spraying Attack"
                )
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": inc_title,
                    "severity": "Critical" if lsass_alerts else "High",
                    "confidence": 96 if lsass_alerts else 90,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Account Discovery & Credential Vault Harvesting Attack Chain
            elif cred_manager_alerts and discovery_alerts:
                combined_alerts = cred_manager_alerts + discovery_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:recon_cred_theft{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Account Discovery & Credential Vault Harvesting Attack Chain",
                    "severity": "Critical",
                    "confidence": 96,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Windows Credential Manager Access Activity (Event 5379)
            elif cred_manager_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:cred_vault{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Windows Credential Manager Password Vault Access Activity",
                    "severity": "Critical" if len(cred_manager_alerts) >= 2 else "High",
                    "confidence": 95 if len(cred_manager_alerts) >= 2 else 90,
                    "alert_count": len(cred_manager_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": cred_manager_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Local Account Group Discovery Campaign (Event 4798 / 4799)
            elif discovery_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:discovery{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Local Account Group Discovery Campaign ({user})",
                    "severity": "High" if len(discovery_alerts) >= 2 else "Medium",
                    "confidence": 92 if len(discovery_alerts) >= 2 else 85,
                    "alert_count": len(discovery_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": discovery_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Unauthorized Backdoor Account Creation & Persistence (Event 4720)
            elif account_created:
                inc_hash = hashlib.md5(f"{host}:{user}:persistence{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Unauthorized Backdoor Account Creation & Persistence",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(account_created),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": account_created,
                    "created_at": datetime.now().isoformat()
                })

            # Network Lateral Movement via Remote WMI Execution (Suricata Event 2000001)
            elif suricata_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:lateral_movement{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Network Lateral Movement via Remote WMI Execution",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(suricata_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": suricata_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Defense Evasion & Anti-Forensics Correlation
            elif log_cleared:
                inc_hash = hashlib.md5(f"{host}:{user}:evasion{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Host Defense Evasion & Security Log Tampering",
                    "severity": "High",
                    "confidence": 95,
                    "alert_count": len(log_cleared),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": log_cleared,
                    "created_at": datetime.now().isoformat()
                })

            # Fallback for remaining single alerts
            elif security_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:{security_alerts[0].get('alert_name', 'suspicious')}{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Suspicious Activity on {host}",
                    "severity": security_alerts[0].get("severity", "Medium"),
                    "confidence": security_alerts[0].get("confidence", 80),
                    "alert_count": len(security_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": security_alerts,
                    "created_at": datetime.now().isoformat()
                })

        for inc in incidents:
            inc.setdefault("is_diagnostic", False)
            src_ips = []
            telemetry_sources = []
            mitre_techniques = []
            for alt in inc.get("alerts", []):
                ev = alt.get("event", {})
                sip = str(ev.get("source_ip") or "N/A").strip()
                if sip and sip not in ("N/A", "-", "127.0.0.1", "::1") and sip not in src_ips:
                    src_ips.append(sip)
                ev_src = str(ev.get("source") or "unknown").strip()
                if ev_src and ev_src not in telemetry_sources:
                    telemetry_sources.append(ev_src)
                tech = str(alt.get("mitre_technique") or ev.get("mitre_technique") or "N/A").strip()
                if tech and tech not in ("N/A", "NA", "None") and tech not in mitre_techniques:
                    mitre_techniques.append(tech)
            inc["observed_source_ips"] = src_ips if src_ips else ["N/A"]
            inc["telemetry_sources"] = telemetry_sources if telemetry_sources else ["unknown"]
            inc["mitre_techniques"] = mitre_techniques
            inc["primary_source"] = (
                "real_nxlog_windows"
                if "real_nxlog_windows" in inc["telemetry_sources"]
                else inc["telemetry_sources"][0]
            )
            inc["is_real_telemetry"] = any(
                s in ("real_nxlog_windows", "local_windows") for s in inc["telemetry_sources"]
            )
            inc["is_simulated"] = (not inc["is_real_telemetry"]) and any(
                "sim" in s.lower() or "synthetic" in s.lower() for s in inc["telemetry_sources"]
            )

        print(f"[INFO] Correlation Agent synthesized {len(incidents)} correlated Incident(s).")
        return incidents