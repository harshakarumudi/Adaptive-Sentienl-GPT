import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agents.correlation_agent import CorrelationAgent
from agents.detection_agent import DetectionAgent
from agents.reporting_agent import ReportingAgent
from analysis.deduplicate import LogDeduplicator, get_event_identity_key
from analysis.normalize import LogNormalizer, build_endpoint_inventory
from analysis.parser import NXLogReader
from config.settings import format_network_display, get_endpoint_ip
from utils.network_discovery import (
    CentralNetworkStateService,
    DISCOVERY_PROTOCOL_MAGIC,
    DISCOVERY_PROTOCOL_VERSION,
    build_discovery_request,
    build_discovery_response,
    detect_active_interface_and_ip,
    discover_receiver_endpoint,
    inspect_tcp_port_connections,
    validate_discovery_request,
    validate_discovery_response,
    verify_tcp_receiver,
)
from utils.sender_reconnect_agent import (
    compute_reconnect_backoff,
    extract_nxlog_tcp_host_and_port,
    run_sender_discovery_and_sync_cycle,
    update_sender_nxlog_config_if_needed,
)


# ---------------------------------------------------------------------------
# 1. Detecting the receiver's current active IPv4 address
# ---------------------------------------------------------------------------
def test_01_detect_receiver_current_active_ipv4():
    mock_interfaces = [
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    iface, ip_addr = detect_active_interface_and_ip(
        interfaces_provider=lambda: mock_interfaces,
        route_ip_provider=lambda: "11.12.7.72",
    )
    assert iface == "Wi-Fi"
    assert ip_addr == "11.12.7.72"


# ---------------------------------------------------------------------------
# 2. Ignoring loopback, disconnected, and virtual interfaces when physical exists
# ---------------------------------------------------------------------------
def test_02_ignore_loopback_disconnected_and_virtual_adapters():
    mock_interfaces = [
        {"interface": "Loopback Pseudo-Interface 1", "ip": "127.0.0.1"},
        {"interface": "Autoconfiguration APIPA", "ip": "169.254.44.12"},
        {"interface": "VMware Network Adapter VMnet1", "ip": "192.168.216.1"},
        {"interface": "VMware Network Adapter VMnet8", "ip": "192.168.222.1"},
        {"interface": "vEthernet (WSL)", "ip": "172.24.16.1"},
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    iface, ip_addr = detect_active_interface_and_ip(
        interfaces_provider=lambda: mock_interfaces,
        route_ip_provider=lambda: "11.12.7.72",
    )
    assert iface == "Wi-Fi"
    assert ip_addr == "11.12.7.72"


# ---------------------------------------------------------------------------
# 3. Detecting the sender's current active IPv4 address
# ---------------------------------------------------------------------------
def test_03_detect_sender_current_active_ipv4(tmp_path):
    nxlog_conf = tmp_path / "nxlog.conf"
    nxlog_conf.write_text(
        "<Output send_to_sujith>\n    Module om_tcp\n    Host 11.12.7.72\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    state_file = tmp_path / "sender_state.json"
    sender_state = run_sender_discovery_and_sync_cycle(
        nxlog_conf_path=nxlog_conf,
        state_file_path=state_file,
        receiver_hostname="Sujith",
        receiver_port=2514,
        restart_service=False,
        interfaces_provider=lambda: [
            {"interface": "VirtualBox Host-Only Network", "ip": "192.168.56.1"},
            {"interface": "Wi-Fi", "ip": "11.12.4.164"},
        ],
        hostname_resolver=lambda host, port: ["11.12.7.72"],
        tcp_verifier=lambda ip, port: ip == "11.12.7.72" and port == 2514,
    )
    assert sender_state["sender_ip_current"] == "11.12.4.164"
    assert sender_state["network_interface"] == "Wi-Fi"
    assert sender_state["connection_status"] == "CONNECTED"


# ---------------------------------------------------------------------------
# 4. Discovering the receiver IP using the multi-tier discovery mechanism
# ---------------------------------------------------------------------------
def test_04_discover_receiver_ip_multi_tier_priority():
    # Tier 1: Hostname resolution succeeds
    res1 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.42.0.10"] if h == "Sujith" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "10.42.0.10" and p == 2514,
    )
    assert res1["success"] is True
    assert res1["receiver_ip"] == "10.42.0.10"
    assert res1["discovery_method"] == "hostname_resolution"

    # Tier 2: Standard hostname fails, mDNS (.local) succeeds
    res2 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.42.0.20"] if h == "Sujith.local" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "10.42.0.20" and p == 2514,
    )
    assert res2["success"] is True
    assert res2["receiver_ip"] == "10.42.0.20"
    assert res2["discovery_method"] == "mdns_resolution"

    # Tier 3: Hostname & mDNS fail, UDP broadcast discovery succeeds
    res3 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: [],
        udp_discoverer=lambda: {"receiver_ip": "10.42.0.30", "receiver_hostname": "Sujith", "receiver_port": 2514},
        tcp_verifier=lambda ip, p: ip == "10.42.0.30" and p == 2514,
    )
    assert res3["success"] is True
    assert res3["receiver_ip"] == "10.42.0.30"
    assert res3["discovery_method"] == "udp_broadcast_discovery"


# ---------------------------------------------------------------------------
# 5. Validating a legitimate discovery response
# ---------------------------------------------------------------------------
def test_05_validate_legitimate_discovery_response():
    secret = "TEST_SHARED_SECRET_2026"
    req = build_discovery_request(
        sender_hostname="Harsha",
        sender_ip="11.12.4.164",
        requested_port=2514,
        secret_token=secret,
        nonce="nonce-12345",
    )
    req_ok, req_reason = validate_discovery_request(req, expected_port=2514, secret_token=secret)
    assert req_ok is True
    assert req_reason == "VALID"

    resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="11.12.7.72",
        receiver_port=2514,
        network_interface="Wi-Fi",
        request_nonce="nonce-12345",
        secret_token=secret,
    )
    is_valid, reason = validate_discovery_response(
        resp,
        expected_port=2514,
        expected_nonce="nonce-12345",
        expected_hostname="Sujith",
        secret_token=secret,
    )
    assert is_valid is True
    assert reason == "VALID"


# ---------------------------------------------------------------------------
# 6. Rejecting a malformed or spoofed discovery response
# ---------------------------------------------------------------------------
def test_06_reject_malformed_or_spoofed_discovery_response():
    secret = "TEST_SHARED_SECRET_2026"
    valid_resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="11.12.7.72",
        receiver_port=2514,
        request_nonce="nonce-abc",
        secret_token=secret,
    )

    # Case A: Spoofed IP without valid HMAC
    spoofed_ip = dict(valid_resp, receiver_ip="192.168.1.250")
    ok_a, _ = validate_discovery_response(spoofed_ip, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_a is False

    # Case B: Wrong protocol magic
    bad_proto = dict(valid_resp, protocol="ROGUE_PROTOCOL")
    ok_b, _ = validate_discovery_response(bad_proto, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_b is False

    # Case C: Nonce mismatch (replay attack)
    ok_c, _ = validate_discovery_response(valid_resp, expected_port=2514, expected_nonce="different-nonce", secret_token=secret)
    assert ok_c is False

    # Case D: Loopback / invalid IP in response
    loopback_resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="127.0.0.1",
        receiver_port=2514,
        request_nonce="nonce-abc",
        secret_token=secret,
    )
    ok_d, _ = validate_discovery_response(loopback_resp, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_d is False


# ---------------------------------------------------------------------------
# 7. Verifying TCP port 2514 reachability before trusting a discovered receiver IP
# ---------------------------------------------------------------------------
def test_07_verify_tcp_2514_before_trusting_discovered_ip():
    # Hostname resolves to 10.10.10.50 (unreachable on TCP 2514), UDP resolves to 10.10.10.88 (reachable on TCP 2514)
    res = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.10.10.50"],
        udp_discoverer=lambda: {"receiver_ip": "10.10.10.88", "receiver_hostname": "Sujith", "receiver_port": 2514},
        tcp_verifier=lambda ip, p: ip == "10.10.10.88" and p == 2514,
    )
    assert res["success"] is True
    assert res["receiver_ip"] == "10.10.10.88"
    assert res["discovery_method"] == "udp_broadcast_discovery"


# ---------------------------------------------------------------------------
# 8. Updating sender NXLog target IP only when verified receiver IP changes
# ---------------------------------------------------------------------------
def test_08_update_sender_nxlog_target_ip_when_verified_ip_changes(tmp_path):
    conf_file = tmp_path / "nxlog.conf"
    conf_file.write_text(
        "<Input eventlog>\n    Module im_msvistalog\n    SavePos TRUE\n</Input>\n\n"
        "<Output out_tcp>\n    Module om_tcp\n    Host 10.184.216.159\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    restarted = []
    upd = update_sender_nxlog_config_if_needed(
        nxlog_conf_path=conf_file,
        verified_receiver_ip="11.12.7.72",
        receiver_port=2514,
        restart_service=True,
        service_restarter=lambda: (restarted.append(True) or (True, "Restarted mock nxlog")),
    )
    assert upd["config_updated"] is True
    assert upd["service_restarted"] is True
    assert upd["previous_host"] == "10.184.216.159"
    assert upd["new_host"] == "11.12.7.72"
    assert Path(upd["backup_path"]).exists()
    assert len(restarted) == 1

    new_host, new_port = extract_nxlog_tcp_host_and_port(conf_file.read_text(encoding="utf-8"))
    assert new_host == "11.12.7.72"
    assert new_port == 2514
    assert "SavePos TRUE" in conf_file.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# 9. Avoiding unnecessary NXLog service restarts when receiver IP has not changed
# ---------------------------------------------------------------------------
def test_09_avoid_unnecessary_nxlog_restart_when_ip_unchanged(tmp_path):
    conf_file = tmp_path / "nxlog.conf"
    conf_file.write_text(
        "<Output out_tcp>\n    Module om_tcp\n    Host 11.12.7.72\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    restarted = []
    upd = update_sender_nxlog_config_if_needed(
        nxlog_conf_path=conf_file,
        verified_receiver_ip="11.12.7.72",
        receiver_port=2514,
        restart_service=True,
        service_restarter=lambda: (restarted.append(True) or (True, "Restarted")),
    )
    assert upd["config_updated"] is False
    assert upd["service_restarted"] is False
    assert len(restarted) == 0


# ---------------------------------------------------------------------------
# 10. Preserving receiver port 2514
# ---------------------------------------------------------------------------
def test_10_preserve_receiver_port_2514(tmp_path):
    state_service = CentralNetworkStateService(
        state_file_path=tmp_path / "network_state.json",
        receiver_port=2514,
    )
    state = state_service.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n",
    )
    assert state["receiver_port"] == 2514


# ---------------------------------------------------------------------------
# 11. Handling network switches from Hotspot A to Hotspot B
# ---------------------------------------------------------------------------
def test_11_network_switch_hotspot_a_to_hotspot_b(tmp_path):
    state_file = tmp_path / "net_state.json"
    nxlog_conf = tmp_path / "nxlog.conf"
    nxlog_conf.write_text(
        "<Output out_tcp>\n    Module om_tcp\n    Host 192.168.43.10\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    svc = CentralNetworkStateService(state_file_path=state_file, receiver_port=2514)

    # Hotspot A: Receiver=192.168.43.10, Sender=192.168.43.25
    state_a = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "192.168.43.10"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    192.168.43.10:2514     192.168.43.25:51200    ESTABLISHED     3400\n"
        ),
    )
    assert state_a["receiver_ip_current"] == "192.168.43.10"
    assert state_a["sender_ip_current"] == "192.168.43.25"
    assert state_a["connection_status"] == "CONNECTED"

    # Switch to Hotspot B: Receiver=172.20.10.2, Sender=172.20.10.5
    state_b = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.2"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    172.20.10.2:2514       172.20.10.5:51300      ESTABLISHED     3400\n"
        ),
    )
    assert state_b["receiver_ip_current"] == "172.20.10.2"
    assert state_b["sender_ip_current"] == "172.20.10.5"
    assert state_b["sender_destination_ip"] == "172.20.10.2"

    # Sender auto-updates nxlog.conf from 192.168.43.10 -> 172.20.10.2
    sender_res = run_sender_discovery_and_sync_cycle(
        nxlog_conf_path=nxlog_conf,
        state_file_path=tmp_path / "sender_state.json",
        receiver_hostname="Sujith",
        receiver_port=2514,
        restart_service=False,
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.5"}],
        hostname_resolver=lambda h, p: ["172.20.10.2"],
        tcp_verifier=lambda ip, p: ip == "172.20.10.2" and p == 2514,
    )
    assert sender_res["config_updated"] is True
    assert sender_res["sender_destination_ip"] == "172.20.10.2"


# ---------------------------------------------------------------------------
# 12. Handling network switches from Hotspot B to College Wi-Fi
# ---------------------------------------------------------------------------
def test_12_network_switch_hotspot_b_to_college_wifi(tmp_path):
    state_file = tmp_path / "net_state.json"
    svc = CentralNetworkStateService(state_file_path=state_file, receiver_port=2514)

    # Hotspot B
    svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.2"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    172.20.10.2:2514       172.20.10.5:51300      ESTABLISHED     3400\n"
        ),
    )

    # Switch to College Wi-Fi: Receiver=11.12.7.72, Sender=11.12.4.164
    state_college = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.4.164:37826      ESTABLISHED     3400\n"
        ),
    )
    assert state_college["receiver_ip_current"] == "11.12.7.72"
    assert state_college["sender_ip_current"] == "11.12.4.164"
    assert state_college["remote_peer_ip"] == "11.12.4.164"
    assert state_college["sender_destination_ip"] == "11.12.7.72"
    assert state_college["connection_status"] == "CONNECTED"


# ---------------------------------------------------------------------------
# 13. Keeping sender_ip, remote_peer_ip, receiver_ip, and sender_destination_ip separate
# ---------------------------------------------------------------------------
def test_13_keep_sender_peer_receiver_and_destination_ips_separate(tmp_path):
    svc = CentralNetworkStateService(state_file_path=tmp_path / "state.json", receiver_port=2514)
    state = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.4.164:7926       ESTABLISHED     3400\n"
        ),
    )
    assert "receiver_ip_current" in state
    assert "sender_ip_current" in state
    assert "remote_peer_ip" in state
    assert "sender_destination_ip" in state
    assert state["receiver_ip_current"] == "11.12.7.72"
    assert state["sender_destination_ip"] == "11.12.7.72"
    assert state["remote_peer_ip"] == "11.12.4.164"
    assert state["sender_ip_current"] == "11.12.4.164"
    assert state["remote_peer_ip"] != state["receiver_ip_current"]


# ---------------------------------------------------------------------------
# 14. Preventing receiver_ip from being displayed as sender_ip
# ---------------------------------------------------------------------------
def test_14_prevent_receiver_ip_from_being_labeled_as_sender_ip(tmp_path):
    # Even if a loopback/self connection from 11.12.7.72 -> 11.12.7.72:2514 exists in netstat,
    # inspect_tcp_port_connections must reject receiver_ip as a remote peer IP.
    tcp_info = inspect_tcp_port_connections(
        port=2514,
        receiver_ip="11.12.7.72",
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.7.72:59001       ESTABLISHED     3400\n"
        ),
    )
    assert tcp_info["remote_peer_ips"] == []
    assert get_endpoint_ip(observed_ip="11.12.7.72", receiver_ip="11.12.7.72") == "N/A"


# ---------------------------------------------------------------------------
# 15. Replacing NA, N/A, None, and empty network values with meaningful status messages
# ---------------------------------------------------------------------------
def test_15_replace_na_none_and_empty_with_meaningful_status_messages():
    for raw_bad in ("NA", "N/A", "None", None, "", "-", "UNKNOWN"):
        for role in (
            "source_ip",
            "sender_ip",
            "remote_peer_ip",
            "receiver_ip",
            "sender_hostname",
            "receiver_hostname",
            "mitre_technique",
            "command_line",
        ):
            formatted = format_network_display(raw_bad, field_role=role)
            assert formatted not in ("NA", "N/A", "None", "", "-"), f"Role {role} returned forbidden '{formatted}'"
            assert len(formatted) > 3

    # With fallback TCP peer IP, source_ip and sender_ip use the peer IP cleanly
    assert format_network_display("N/A", field_role="source_ip", fallback_peer_ip="11.12.4.164") == "11.12.4.164 (TCP 2514 Peer)"
    assert format_network_display("N/A", field_role="sender_ip", fallback_peer_ip="11.12.4.164") == "11.12.4.164"


# ---------------------------------------------------------------------------
# 16. Ensuring all nine dashboard sectors read from the central network state and render no N/A
# ---------------------------------------------------------------------------
def test_16_all_nine_dashboard_sectors_use_central_network_state_and_no_na():
    app_path = PROJECT_ROOT / "dashboard" / "app.py"
    app_text = app_path.read_text(encoding="utf-8")

    # Verify CentralNetworkState is invoked at top level
    assert "net_state = get_central_network_state(" in app_text

    # Verify all 9 sector tabs exist and none contain raw '"N/A"' display fallbacks
    for sector_num in range(1, 10):
        tab_marker = f"with tab{sector_num}:"
        assert tab_marker in app_text, f"Missing {tab_marker} in dashboard/app.py"

    # Extract content from `with tab1:` to the end of `dashboard/app.py`
    sectors_body = app_text.split("with tab1:", 1)[1]
    # Ensure no `st.metric(..., "N/A")` or `.get(..., "N/A")` display fallbacks remain in Sectors 1-9
    assert '.get("status", "N/A")' not in sectors_body
    assert '.get("inference_status", "N/A")' not in sectors_body
    assert '.get("inference_source", "N/A")' not in sectors_body
    assert '.get("rule_id", "N/A")' not in sectors_body
    assert '.get("mitre_technique", "N/A")' not in sectors_body

    # Also verify ReportingAgent (Sector 5) never outputs "N/A"
    reports = ReportingAgent().generate([
        {
            "incident_id": "INC-TEST-01",
            "incident_name": "Suspicious Process Activity",
            "severity": "High",
            "confidence": 92,
            "affected_host": "Harsha",
            "affected_user": "harsha_user",
            "alerts": [
                {
                    "alert_name": "Process Creation",
                    "event": {
                        "event_id": 4688,
                        "event_type": "Windows Process Creation",
                        "source_ip": "N/A",
                        "remote_peer_ip": "11.12.4.164",
                        "process_name": "N/A",
                        "command_line": "N/A",
                        "mitre_technique": "N/A",
                    },
                }
            ],
        }
    ])
    assert len(reports) == 1
    rep = reports[0]
    assert rep["source_ip"] not in ("N/A", "NA", "None", "")
    assert "N/A" not in rep["technical_analysis"]


# ---------------------------------------------------------------------------
# 17. Ensuring newly ingested real NXLog events appear in stream and raw inspector
# ---------------------------------------------------------------------------
def test_17_newly_ingested_nxlog_events_appear_in_stream_and_inspector(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    marker = "PHASE3_WINDOWS_EVENT_20261010_160833"
    raw_line = f"2026-10-10 16:08:33 HARSHA INFO 1000 {marker}\n"
    log_file.write_text(raw_line, encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    events = normalize_events_list = LogNormalizer().normalize(reader.read_events(incremental=True))
    assert len(events) == 1
    assert marker in events[0]["description"]
    assert marker in events[0]["raw_line"]
    assert events[0]["event_id"] == 1000


# ---------------------------------------------------------------------------
# 18. Ensuring failed parses do not advance the NXLog cursor past unprocessed records
# ---------------------------------------------------------------------------
def test_18_failed_parse_does_not_advance_cursor_past_unprocessed_records(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    line1 = "2026-10-10 16:00:01 Harsha INFO 4624 First valid event\n"
    line2 = "2026-10-10 16:00:02 Harsha INFO 1000 Second event temporarily fails\n"
    log_file.write_text(line1 + line2, encoding="utf-8", newline="\n")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    orig_parse = reader.parse_line

    def flaky_parse(line: str):
        if "Second event temporarily fails" in line:
            raise RuntimeError("Simulated parser error")
        return orig_parse(line)

    with patch.object(reader, "parse_line", side_effect=flaky_parse):
        batch1 = reader.read_events(incremental=True)

    assert len(batch1) == 1
    assert reader.load_cursor() == len(line1.encode("utf-8"))

    # Next read without error picks up the previously failed record
    batch2 = reader.read_events(incremental=True)
    assert len(batch2) == 1
    assert "Second event temporarily fails" in batch2[0]["description"]


# ---------------------------------------------------------------------------
# 19. Ensuring repeated dashboard reruns do not inflate counts
# ---------------------------------------------------------------------------
def test_19_repeated_dashboard_reruns_do_not_inflate_counts(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    content = (
        "2026-10-10 16:10:01 Harsha INFO 4688 A new process has been created. Creator Process Name: cmd.exe\n"
        "2026-10-10 16:10:02 Harsha WARNING 4625 An account failed to log on. Account Name: admin\n"
    )
    log_file.write_text(content, encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    normalizer = LogNormalizer()

    live_events = normalizer.normalize(reader.get_recent_events(max_events=300))
    existing_keys = {get_event_identity_key(e) for e in live_events}
    initial_count = len(live_events)
    assert initial_count == 2

    # Simulate 5 consecutive Streamlit reruns merging get_recent_events()
    for _ in range(5):
        tail_evts = normalizer.normalize(reader.get_recent_events(max_events=300))
        for evt in tail_evts:
            k = get_event_identity_key(evt)
            if k not in existing_keys:
                live_events.append(evt)
                existing_keys.add(k)

    assert len(live_events) == initial_count


# ---------------------------------------------------------------------------
# 20. Ensuring diagnostic test markers do not become fake security incidents
# ---------------------------------------------------------------------------
def test_20_diagnostic_markers_do_not_become_fake_security_incidents():
    raw_events = [
        {
            "timestamp": "2026-10-10 16:20:00",
            "hostname": "Harsha",
            "event_id": 4688,
            "description": "PHASE1_LIVE_VERIFY_20261010_140257 diagnostic probe",
            "source": "real_nxlog_windows",
        },
        {
            "timestamp": "2026-10-10 16:21:00",
            "hostname": "Harsha",
            "event_id": 4688,
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -EncodedCommand JABzAD0ATgBlAHcA",
            "description": "Suspicious encoded PowerShell execution",
            "source": "real_nxlog_windows",
        },
    ]
    norm = LogNormalizer().normalize(raw_events)
    alerts = DetectionAgent().detect(norm)
    incidents = CorrelationAgent().correlate(alerts)

    sec_incidents = [i for i in incidents if not i.get("is_diagnostic")]
    diag_incidents = [i for i in incidents if i.get("is_diagnostic")]

    assert len(sec_incidents) == 1
    assert len(diag_incidents) == 1
    assert "PHASE1_LIVE_VERIFY" in diag_incidents[0]["alerts"][0]["event"]["description"]


# ---------------------------------------------------------------------------
# 21. Regression: Receiver discovery succeeds when logical hostname ('Sujith')
#     differs from OS hostname ('LAPTOP-GEEF5A3A') or uses persisted state
# ---------------------------------------------------------------------------
def test_21_regression_discover_receiver_when_logical_hostname_differs_from_os_hostname(tmp_path):
    state_file = tmp_path / "network_state.json"
    state_file.write_text(
        json.dumps({
            "receiver_hostname": "Sujith",
            "receiver_os_hostname": "LAPTOP-GEEF5A3A",
            "receiver_ip_current": "11.12.7.72",
            "last_known_receiver_ip": "11.12.7.72",
            "receiver_port": 2514,
        }),
        encoding="utf-8",
    )

    # Case A: 'Sujith' fails DNS, but persisted state fallback '11.12.7.72' is verified on TCP 2514
    res_fallback = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "11.12.7.72" and p == 2514,
        state_file_path=state_file,
    )
    assert res_fallback["success"] is True
    assert res_fallback["receiver_ip"] == "11.12.7.72"
    assert res_fallback["receiver_port"] == 2514
    assert res_fallback["discovery_method"] == "last_known_ip_verified"
    assert any("hostname:Sujith->no_ipv4_records" in a for a in res_fallback["attempts"])
    assert any(d["method"] == "last_known_ip_verified" and d["status"] == "verified" for d in res_fallback["diagnostics"])


# ---------------------------------------------------------------------------
# 22. Regression: Discovery failure reports each method attempted and its reason
# ---------------------------------------------------------------------------
def test_22_regression_discovery_failure_reports_each_method_and_reason():
    res_fail = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        last_known_receiver_ip="10.99.99.99",
        manual_bootstrap_ip="10.88.88.88",
        hostname_resolver=lambda h, p: ["10.77.77.77"] if h == "Sujith" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: False,
    )
    assert res_fail["success"] is False
    assert res_fail["receiver_ip"] is None
    assert res_fail["discovery_method"] == "none"

    methods_logged = [d["method"] for d in res_fail["diagnostics"]]
    assert "hostname_resolution" in methods_logged
    assert "mdns_resolution" in methods_logged
    assert "udp_broadcast_discovery" in methods_logged
    assert "last_known_ip_verified" in methods_logged
    assert "manual_bootstrap_verified" in methods_logged
    assert "Attempted:" in res_fail["error"]


# ---------------------------------------------------------------------------
# 23. Regression: Virtual adapter filtering in hostname resolution, /19 subnet
#     broadcast calculation, verify_tcp_port, and <Input> Host 0.0.0.0 exclusion
# ---------------------------------------------------------------------------
def test_23_regression_virtual_adapter_filtering_subnet_bcast_and_nxlog_input_host():
    from utils.network_discovery import (
        compute_subnet_broadcast,
        resolve_hostname_candidates,
        verify_tcp_port,
    )

    # /19 subnet mask (255.255.224.0) for 11.12.7.72 -> 11.12.31.255
    assert compute_subnet_broadcast("11.12.7.72", "255.255.224.0") == "11.12.31.255"
    assert compute_subnet_broadcast("11.12.4.164", "255.255.224.0") == "11.12.31.255"

    # Virtual adapter IPs (VMware 192.168.222.1 / 192.168.216.1) filtered out when Wi-Fi is present
    fake_addrinfo = [
        (2, 1, 6, "", ("192.168.222.1", 2514)),
        (2, 1, 6, "", ("192.168.216.1", 2514)),
        (2, 1, 6, "", ("11.12.7.72", 2514)),
    ]
    fake_ifaces = [
        {"interface": "VMware Network Adapter VMnet8", "ip": "192.168.222.1"},
        {"interface": "VMware Network Adapter VMnet1", "ip": "192.168.216.1"},
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    with patch("socket.getaddrinfo", return_value=fake_addrinfo), \
         patch("utils.network_discovery.enumerate_windows_ipv4_interfaces", return_value=fake_ifaces), \
         patch("utils.network_discovery.probe_os_route_ip", return_value="11.12.7.72"):
        cands = resolve_hostname_candidates("LAPTOP-GEEF5A3A", 2514)
        assert cands == ["11.12.7.72"]

    # Receiver nxlog.conf with <Input> Host 0.0.0.0 must not return 0.0.0.0 as sender output Host
    receiver_conf = (
        "<Input receive_logs>\n    Module im_tcp\n    Host 0.0.0.0\n    Port 2514\n</Input>\n"
        "<Output save_logs>\n    Module om_file\n    File 'C:\\AdaptiveSentinel\\windows-events.log'\n</Output>\n"
    )
    host_val, _ = extract_nxlog_tcp_host_and_port(receiver_conf)
    assert host_val is None

    # verify_tcp_port rejects invalid/loopback IPs immediately
    assert verify_tcp_port("0.0.0.0", 2514) is False
    assert verify_tcp_port("127.0.0.1", 2514) is False


# ---------------------------------------------------------------------------
# 24. Regression: Receiver IP & interface cache expiry and dynamic IP change detection
# ---------------------------------------------------------------------------
def test_24_regression_receiver_ip_cache_expiry_and_ip_change_detection(monkeypatch):
    import config.settings as settings
    import utils.network_discovery as net_disc

    for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
        monkeypatch.delenv(env_key, raising=False)

    settings.clear_receiver_ip_cache()

    call_count = {"ifaces": 0}
    current_net = {"ip": "11.12.7.72"}
    fake_clock = {"t": 1000.0}

    def fake_enumerate():
        call_count["ifaces"] += 1
        return [{"interface": "Wi-Fi", "ip": current_net["ip"], "subnet_mask": "255.255.224.0"}]

    monkeypatch.setattr(net_disc, "enumerate_windows_ipv4_interfaces", fake_enumerate)
    monkeypatch.setattr(net_disc, "probe_os_route_ip", lambda: current_net["ip"])
    monkeypatch.setattr(net_disc.time, "monotonic", lambda: fake_clock["t"])
    monkeypatch.setattr(settings.time, "monotonic", lambda: fake_clock["t"])

    # Within 6.0s TTL window: multiple calls reuse cached IP and do not re-spawn ipconfig
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert net_disc.detect_active_interface_and_ip() == ("Wi-Fi", "11.12.7.72")
    assert call_count["ifaces"] == 1
    assert settings.NXLOG_PORT == 2514

    # Network changes to a new hotspot IP, but before TTL expiry cached value is still active
    current_net["ip"] = "172.20.10.9"
    fake_clock["t"] = 1003.0  # +3.0s (< 6.0s TTL)
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert call_count["ifaces"] == 1

    # After 6.0s TTL expires: new IP is detected immediately and stale IP is never returned as current
    fake_clock["t"] = 1007.0  # +7.0s (> 6.0s TTL)
    assert settings.get_receiver_ip() == "172.20.10.9"
    assert net_disc.detect_active_interface_and_ip() == ("Wi-Fi", "172.20.10.9")
    assert call_count["ifaces"] == 2

    settings.clear_receiver_ip_cache()


# ---------------------------------------------------------------------------
# 25. Regression: Receiver IP resolved once per normalization/parser batch
# ---------------------------------------------------------------------------
def test_25_regression_batch_receiver_ip_resolved_once_per_batch(tmp_path):
    import analysis.normalize as norm_mod
    import analysis.parser as parser_mod

    raw_batch = [
        {"event_id": 4624, "hostname": "Harsha", "description": f"Login event {i}"}
        for i in range(50)
    ]
    with patch.object(norm_mod, "get_receiver_ip", return_value="11.12.7.72") as mock_norm_ip:
        out = LogNormalizer().normalize(raw_batch)
        assert len(out) == 50
        assert mock_norm_ip.call_count == 1
        assert all(e["receiver_ip"] == "11.12.7.72" for e in out)

    log_file = tmp_path / "batch-events.log"
    cursor_file = tmp_path / "batch-cursor.json"
    lines = [
        f"2026-10-10 18:00:{i:02d} Harsha INFO 4624 Batch test event {i}\n"
        for i in range(40)
    ]
    log_file.write_text("".join(lines), encoding="utf-8")
    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)

    with patch.object(parser_mod, "get_receiver_ip", return_value="11.12.7.72") as mock_parse_ip:
        recent = reader.get_recent_events(max_events=15)
        assert len(recent) == 15
        assert mock_parse_ip.call_count == 1


# ---------------------------------------------------------------------------
# 26. Regression: get_recent_events() tail optimization, multiline events,
#     incomplete trailing records, diagnostic probes, offsets, and cursor safety
# ---------------------------------------------------------------------------
def test_26_regression_get_recent_events_tail_optimization_offsets_multiline_and_cursor(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "nxlog_cursor.json"
    cursor_file.write_text(json.dumps({"byte_offset": 128, "last_updated": "2026-10-10T00:00:00Z"}), encoding="utf-8")

    records = []
    # Record 0: Early diagnostic probe that must be preserved even when outside tail max_events
    records.append("2026-10-10 19:00:00 Harsha INFO 1000 PHASE3_WINDOWS_EVENT_DIAG_EARLY_001\n")
    # Records 1..20: 20 older routine events that should NOT be parsed when max_events=4
    for idx in range(1, 21):
        records.append(f"2026-10-10 19:01:{idx:02d} Harsha INFO 4624 Routine historical event {idx}\n")
    # Records 21..24: 4 recent tail events across multiple endpoints including multiline Security event
    records.append("2026-10-10 19:05:01 Harsha INFO 4688 Process created cmd.exe\n")
    records.append("2026-10-10 19:05:02 Analyst-Laptop-2 WARNING 4625 Failed logon for user bob Source Network Address: 11.12.4.200\n")
    records.append(
        "2026-10-10 19:05:03 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on.\n"
        "\tSubject:\n"
        "\t\tSecurity ID:\t\tS-1-5-18\n"
        "\t\tAccount Name:\t\tharsha_admin\n"
        "\t\t{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}\n"
        "\tNetwork Information:\n"
        "\t\tSource Network Address:\t11.12.4.164\n"
    )
    records.append("2026-10-10 19:05:04 Sujith-SecOps INFO 4672 Special privileges assigned to new logon\n")
    # Incomplete trailing multiline block at EOF (must not be parsed prematurely)
    incomplete_tail = (
        "2026-10-10 19:05:05 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on.\n"
        "\tSubject:\n"
        "\t\tSecurity ID:\t\tS-1-5-18\n"
    )

    full_text = "".join(records) + incomplete_tail
    log_file.write_bytes(full_text.encode("utf-8"))

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    orig_parse_line = reader.parse_line
    parse_calls = []

    def spy_parse_line(line: str):
        parse_calls.append(line)
        return orig_parse_line(line)

    with patch.object(reader, "parse_line", side_effect=spy_parse_line):
        recent = reader.get_recent_events(max_events=4)

    # 1. Production cursor file was untouched
    assert reader.load_cursor() == 128

    # 2. Only the 4 tail blocks + 1 early diagnostic block were parsed (5 total out of 25 complete blocks)
    assert len(parse_calls) == 5

    # 3. Returned list has 1 early diagnostic probe + 4 valid recent tail events = 5 events
    assert len(recent) == 5
    assert recent[0]["is_diagnostic"] is True
    assert "PHASE3_WINDOWS_EVENT_DIAG_EARLY_001" in recent[0]["description"]
    assert recent[0]["record_offset"] == 0

    # 4. All 4 recent tail events are present in chronological order with exact byte offsets & endpoint identity
    tail_four = recent[1:]
    assert [e["event_id"] for e in tail_four] == [4688, 4625, 4624, 4672]
    assert [e["hostname"] for e in tail_four] == ["Harsha", "Analyst-Laptop-2", "Harsha", "Sujith-SecOps"]
    assert tail_four[1]["source_ip"] == "11.12.4.200"
    assert tail_four[2]["source_ip"] == "11.12.4.164"
    assert "{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}" in tail_four[2]["raw_line"]

    # Verify byte offsets match exact positions in file
    raw_bytes = full_text.encode("utf-8")
    for evt in recent:
        off = evt["record_offset"]
        first_line_bytes = evt["raw_line"].splitlines()[0].encode("utf-8")
        assert raw_bytes[off:off + len(first_line_bytes)] == first_line_bytes


# ---------------------------------------------------------------------------
# 27. Regression: Live NXLog event (diagnostic marker & genuine security event)
#     reaches enrichment, detection, correlation, threat intel, and reporting
# ---------------------------------------------------------------------------
def test_27_regression_live_nxlog_event_reaches_detection_and_correlation_pipeline(tmp_path):
    from analysis.enrich import enrich_events
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.explainability_agent import ExplainabilityAgent
    from agents.response_planning_agent import ResponsePlanningAgent

    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        # Exact live test marker sent by Harsha
        "2026-10-11 00:30:11 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_TEST_20261011_003011\n",
        # Genuine live Windows Credential Manager & Group Discovery events on Harsha
        "2026-10-11 00:31:00 Harsha AUDIT_SUCCESS 5379 Credential Manager credentials were read. Account Name: Harsha\n",
        "2026-10-11 00:31:02 Harsha AUDIT_SUCCESS 4798 A user's local group membership was enumerated. Account Name: Harsha\n",
    ]
    log_file.write_text("".join(lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    raw_events = reader.read_events(incremental=True)
    assert len(raw_events) == 3

    normalized = LogNormalizer().normalize(raw_events)
    enriched = enrich_events(normalized)
    alerts = DetectionAgent().detect(enriched)
    assert len(alerts) == 3

    incidents = CorrelationAgent().correlate(alerts)
    incidents = ThreatIntelligenceAgent().analyze(incidents)

    diag_inc = [i for i in incidents if i.get("is_diagnostic")]
    sec_inc = [i for i in incidents if not i.get("is_diagnostic")]

    assert len(diag_inc) == 1
    assert "ADAPTIVESENTINEL_LIVE_TEST_20261011_003011" in diag_inc[0]["alerts"][0]["event"]["description"]
    assert diag_inc[0]["is_real_telemetry"] is True
    assert diag_inc[0]["is_simulated"] is False

    assert len(sec_inc) == 1
    assert sec_inc[0]["affected_host"] == "Harsha"
    assert sec_inc[0]["incident_name"] == "Account Discovery & Credential Vault Harvesting Attack Chain"
    assert sec_inc[0]["is_real_telemetry"] is True
    assert sec_inc[0]["is_simulated"] is False
    assert sec_inc[0]["telemetry_sources"] == ["real_nxlog_windows"]

    explanations = ExplainabilityAgent().explain(sec_inc)
    plans = ResponsePlanningAgent().plan(sec_inc)
    reports = ReportingAgent().generate(sec_inc)
    assert len(explanations) == 1
    assert len(plans) == 1
    assert len(reports) == 1


# ---------------------------------------------------------------------------
# 28. Regression: Benign informational Windows events (Event 1 low-power wake,
#     Event 1001 Fault bucket, routine Event 1000/4624/10) are not misclassified
# ---------------------------------------------------------------------------
def test_28_regression_informational_windows_events_not_misclassified_as_malicious(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    benign_lines = [
        # Windows Power-Troubleshooter Event ID 1 (wake from low power state, NOT Sysmon PowerShell)
        "2026-10-10 23:25:06 Harsha INFO 1 The system has returned from a low power state.\n",
        # Windows Error Reporting Event ID 1001 (Fault bucket, NOT SSH failed login)
        "2026-10-10 23:25:10 Harsha INFO 1001 Fault bucket , type 0 Event Name: BlueScreen Response: Not available\n",
        # Routine application Event ID 1000 without diagnostic marker
        "2026-10-10 23:25:15 Harsha INFO 1000 Application background service heartbeat completed normally.\n",
        # Routine successful logon Event ID 4624
        "2026-10-10 23:25:20 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on. Account Name: Harsha\n",
        # Generic Event ID 10 without mimikatz/lsass/sysmon
        "2026-10-10 23:25:25 Harsha INFO 10 Device configuration state check completed.\n",
    ]
    log_file.write_text("".join(benign_lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    norm_events = LogNormalizer().normalize(reader.read_events(incremental=True))
    assert len(norm_events) == 5

    alerts = DetectionAgent().detect(norm_events)
    assert alerts == [], f"Expected 0 alerts for benign informational events, got: {alerts}"

    incidents = CorrelationAgent().correlate(alerts)
    assert incidents == []


# ---------------------------------------------------------------------------
# 29. Regression: Simulated evidence (api_simulation / synthetic) is explicitly
#     tagged and never misrepresented or merged with real_nxlog_windows telemetry
# ---------------------------------------------------------------------------
def test_29_regression_simulated_evidence_distinguished_and_never_merged_with_real_telemetry():
    mixed_events = [
        # Simulated ransomware event from api_simulation
        {
            "timestamp": "2026-10-11 00:10:00",
            "hostname": "FINANCE-WORKSTATION",
            "user": "john.doe",
            "event_id": 1,
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -ExecutionPolicy Bypass -NoP -Enc JABzAD0ATgBlAHcA",
            "description": "Suspicious PowerShell execution",
            "source": "api_simulation",
        },
        # Simulated event on Harsha (must NEVER merge with real_nxlog_windows on Harsha)
        {
            "timestamp": "2026-10-11 00:11:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 4688,
            "process_name": "vssadmin.exe",
            "command_line": "vssadmin.exe delete shadows /all /quiet",
            "description": "Simulated shadow copy deletion",
            "source": "api_simulation",
        },
        # Real NXLog event on Harsha
        {
            "timestamp": "2026-10-11 00:12:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 5379,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "source": "real_nxlog_windows",
        },
    ]

    norm = LogNormalizer().normalize(mixed_events)
    alerts = DetectionAgent().detect(norm)
    assert len(alerts) == 3

    incidents = CorrelationAgent().correlate(alerts)
    assert len(incidents) == 3

    real_incidents = [inc for inc in incidents if inc["is_real_telemetry"]]
    sim_incidents = [inc for inc in incidents if inc["is_simulated"]]

    assert len(real_incidents) == 1
    assert len(sim_incidents) == 2

    # Verify real incident contains ONLY real_nxlog_windows telemetry
    real_inc = real_incidents[0]
    assert real_inc["affected_host"] == "Harsha"
    assert real_inc["telemetry_sources"] == ["real_nxlog_windows"]
    assert real_inc["primary_source"] == "real_nxlog_windows"
    assert real_inc["is_simulated"] is False

    # Verify simulated incidents are explicitly marked is_real_telemetry=False, is_simulated=True
    for s_inc in sim_incidents:
        assert s_inc["is_real_telemetry"] is False
        assert s_inc["is_simulated"] is True
        assert s_inc["telemetry_sources"] == ["api_simulation"]
        assert s_inc["primary_source"] == "api_simulation"


# ---------------------------------------------------------------------------
# 30. Safe Replay / Scan Test Events is idempotent and preserves cursor
# ---------------------------------------------------------------------------
def test_30_safe_replay_is_idempotent_and_preserves_production_cursor(tmp_path):
    from analysis.enrich import enrich_events

    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        "2026-10-11 01:00:01 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_TEST_20261011_010001\n",
        "2026-10-11 01:00:05 Harsha AUDIT_FAILURE 4625 An account failed to log on. Account Name: demo_harsha\n",
        "2026-10-11 01:00:06 Harsha AUDIT_FAILURE 4625 An account failed to log on. Account Name: demo_harsha\n",
    ]
    log_file.write_text("".join(lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    reader.save_cursor(95)
    assert reader.load_cursor() == 95

    # First replay
    replay_1 = enrich_events(LogNormalizer().normalize(reader.replay_events(scan_bytes=524288)))
    assert reader.load_cursor() == 95  # Cursor untouched!

    # Second replay merged via deduplication key (simulating clicking Safe Replay twice)
    replay_2 = enrich_events(LogNormalizer().normalize(reader.replay_events(scan_bytes=524288)))
    assert reader.load_cursor() == 95

    merged = list(replay_1)
    seen_keys = {
        (e.get("record_offset"), e.get("timestamp"), e.get("hostname"), e.get("event_id"), str(e.get("description", ""))[:160])
        for e in merged
    }
    for e in replay_2:
        k = (e.get("record_offset"), e.get("timestamp"), e.get("hostname"), e.get("event_id"), str(e.get("description", ""))[:160])
        if k not in seen_keys:
            merged.append(e)
            seen_keys.add(k)

    # No duplicate events or inflated incidents after repeated Safe Replay
    assert len(merged) == 3
    alerts = DetectionAgent().detect(merged)
    incidents = CorrelationAgent().correlate(alerts)
    sec_incidents = [i for i in incidents if not i.get("is_diagnostic")]
    diag_incidents = [i for i in incidents if i.get("is_diagnostic")]
    assert len(sec_incidents) == 1
    assert len(diag_incidents) == 1
    assert sec_incidents[0]["incident_name"] == "Automated Brute Force & Password Spraying Attack"


# ---------------------------------------------------------------------------
# 31. APT Scenario & Synthetic Attack generators preserve log_channel & correlate
#     multi-stage chains accurately (including SYSTEM LSASS on same host)
# ---------------------------------------------------------------------------
def test_31_apt_and_synthetic_generators_preserve_log_channel_and_correlate_chains(tmp_path):
    import utils.generate_apt_logs as apt_mod
    import utils.generate_logs as syn_mod
    import config.settings as settings_mod
    from analysis.enrich import enrich_events

    apt_out = tmp_path / "apt_logs.json"

    with patch.object(settings_mod, "LOG_FILE_PATH", apt_out), \
         patch.object(apt_mod, "RAW_LOGS_DIR", tmp_path):
        apt_mod.generate_apt_attack_logs()

    with patch.object(syn_mod, "RAW_LOGS_DIR", tmp_path), \
         patch("utils.generate_logs.random.sample", side_effect=lambda pop, k: list(pop)):
        syn_path = syn_mod.generate_synthetic_attack_logs(num_background_logs=20)

    apt_raw = json.loads(apt_out.read_text(encoding="utf-8"))
    syn_raw = json.loads(syn_path.read_text(encoding="utf-8"))

    # Verify log_channel is preserved for Suricata IDS and Linux Auth filters
    apt_norm = enrich_events(LogNormalizer().normalize(apt_raw))
    channels = {e.get("log_channel") for e in apt_norm}
    assert "Suricata IDS" in channels
    assert "Linux Auth" in channels
    assert "Sysmon" in channels
    assert "Windows Security" in channels

    apt_incidents = CorrelationAgent().correlate(DetectionAgent().detect(apt_norm))
    apt_inc_names = {i["incident_name"] for i in apt_incidents}
    assert "Unauthorized Backdoor Account Creation & Persistence" in apt_inc_names
    assert "Ransomware Pre-Encryption Staging Activity" in apt_inc_names
    assert "Automated Brute Force & Password Spraying Attack" in apt_inc_names

    # Verify correlation on synthetic dataset associates SYSTEM LSASS dump with DC-PRIMARY::admin
    syn_norm = enrich_events(LogNormalizer().normalize(syn_raw))
    syn_alerts = DetectionAgent().detect(syn_norm)
    syn_incidents = CorrelationAgent().correlate(syn_alerts)

    syn_inc_names = {i["incident_name"] for i in syn_incidents}
    assert "Ransomware Pre-Encryption Staging Activity" in syn_inc_names
    assert "Automated Brute Force & Credential Dumping Attack Chain" in syn_inc_names
    assert "Host Defense Evasion & Security Log Tampering" in syn_inc_names
    assert "Network Lateral Movement via Remote WMI Execution" in syn_inc_names


# ---------------------------------------------------------------------------
# 32. Machine account exclusion (HARSHA$) and case-insensitive hostname grouping
# ---------------------------------------------------------------------------
def test_32_machine_account_excluded_and_hostname_case_canonicalized():
    events = [
        # Machine account HARSHA$ in Event 4798 must NOT trigger a user account discovery alert
        {
            "timestamp": "2026-10-10 23:25:07",
            "hostname": "Harsha",
            "user": "HARSHA$",
            "event_id": 4798,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "source": "real_nxlog_windows",
        },
        # Diagnostic event with mixed case "Harsha"
        {
            "timestamp": "2026-10-10 23:26:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 1000,
            "process_name": "powershell.exe",
            "command_line": "Write-EventLog",
            "description": "PHASE1_DIAGNOSTIC_OK",
            "source": "real_nxlog_windows",
            "is_diagnostic": True,
        },
        # Diagnostic event with uppercase "HARSHA"
        {
            "timestamp": "2026-10-10 23:27:00",
            "hostname": "HARSHA",
            "user": "Harsha",
            "event_id": 1000,
            "process_name": "powershell.exe",
            "command_line": "Write-EventLog",
            "description": "ADAPTIVESENTINEL_LIVE_TEST_20261011",
            "source": "real_nxlog_windows",
            "is_diagnostic": True,
        },
    ]

    norm = LogNormalizer().normalize(events)
    alerts = DetectionAgent().detect(norm)
    # Only the 2 diagnostic events should alert; HARSHA$ Event 4798 is ignored
    assert len(alerts) == 2

    incidents = CorrelationAgent().correlate(alerts)
    # Both "Harsha" and "HARSHA" diagnostic probes canonicalize into 1 diagnostic group on "Harsha"
    assert len(incidents) == 1
    assert incidents[0]["is_diagnostic"] is True
    assert incidents[0]["affected_host"] == "Harsha"
    assert incidents[0]["alert_count"] == 2


# ---------------------------------------------------------------------------
# 33. Exact incident count consistency (Resolves 12 vs 5 real + 4 simulated)
# ---------------------------------------------------------------------------
def test_33_incident_count_consistency_resolves_12_vs_5_real_plus_4_simulated():
    from main import main as run_soc_pipeline
    from analysis.enrich import enrich_events
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    # 1. Run file-backed pipeline (simulated incidents from windows_logs.json)
    res = run_soc_pipeline(include_nxlog=False)
    sim_incidents = [i for i in res["incidents"] if not i.get("is_diagnostic")]

    # 2. Run live NXLog replay pipeline
    reader = NXLogReader()
    nx_raw = reader.get_recent_events(max_events=250)
    nx_norm = enrich_events(LogNormalizer().normalize(nx_raw))
    nx_alerts = DetectionAgent().detect(nx_norm)
    nx_all_inc = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(nx_alerts))

    nx_sec_incidents = [i for i in nx_all_inc if not i.get("is_diagnostic")]
    nx_diag_incidents = [i for i in nx_all_inc if i.get("is_diagnostic")]

    # Combine strictly genuine security incidents (excluding diagnostic probes)
    display_incidents = list(sim_incidents) + [i for i in nx_sec_incidents if i not in sim_incidents]

    real_count = sum(1 for i in display_incidents if i.get("is_real_telemetry"))
    sim_count = sum(1 for i in display_incidents if i.get("is_simulated"))
    crit_count = sum(1 for i in display_incidents if i.get("severity") == "Critical")
    high_count = sum(1 for i in display_incidents if i.get("severity") == "High")
    med_count = sum(1 for i in display_incidents if i.get("severity") == "Medium")
    low_count = sum(1 for i in display_incidents if i.get("severity") == "Low")

    # Every displayed count has one clear definition and adds up 100% consistently:
    assert len(display_incidents) == real_count + sim_count
    assert len(display_incidents) == crit_count + high_count + med_count + low_count
    assert all(not i.get("is_diagnostic") for i in display_incidents)
    assert all(i.get("is_diagnostic") for i in nx_diag_incidents)


# ---------------------------------------------------------------------------
# 34. Unified pipeline consistency across Enrichment, Graph, Explainability,
#     Response Planning, Reporting, and AI Chatbot Grounding
# ---------------------------------------------------------------------------
def test_34_unified_pipeline_consistency_across_all_agents_and_graph():
    from analysis.enrich import enrich_events
    from analysis.graph_visualizer import AttackGraphBuilder
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.explainability_agent import ExplainabilityAgent
    from agents.response_planning_agent import ResponsePlanningAgent
    from llm.llm_client import LLMClient

    raw_events = [
        {
            "timestamp": "2026-10-11 01:15:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 5379,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "source": "real_nxlog_windows",
        },
        {
            "timestamp": "2026-10-11 01:15:05",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 4798,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "source": "real_nxlog_windows",
        },
    ]

    norm = enrich_events(LogNormalizer().normalize(raw_events))
    alerts = DetectionAgent().detect(norm)
    assert all(a.get("rule_id") not in (None, "", "N/A") for a in alerts)
    assert all(a["event"].get("mitre_tactic") in ("Credential Access", "Discovery") for a in alerts)

    incidents = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(alerts))
    assert len(incidents) == 1
    inc = incidents[0]
    assert set(inc["mitre_techniques"]) == {"T1087.001", "T1555.004"}

    explanations = ExplainabilityAgent().explain(incidents)
    assert explanations[0]["incident_id"] == inc["incident_id"]
    assert "5379" in explanations[0]["reason"] or "Credential" in explanations[0]["reason"]

    plans = ResponsePlanningAgent().plan(incidents)
    assert plans[0]["incident_id"] == inc["incident_id"]
    assert len(plans[0]["containment_actions"]) >= 2

    builder = AttackGraphBuilder()
    builder.build_graph(incidents=incidents, logs=norm)
    stats = builder.get_graph_stats()
    assert stats["mitre_techniques_count"] == 2
    # Ensure no bogus N/A nodes were created
    node_labels = {d.get("label") for _, d in builder.graph.nodes(data=True)}
    assert "N/A" not in node_labels

    # Verify chatbot grounds response in active incidents
    llm = LLMClient()
    reply = llm.query_chatbot(
        "What are the critical threats detected right now?",
        {"logs": norm, "alerts": alerts, "incidents": incidents},
    )
    assert inc["incident_name"] in reply
    assert "Harsha" in reply

