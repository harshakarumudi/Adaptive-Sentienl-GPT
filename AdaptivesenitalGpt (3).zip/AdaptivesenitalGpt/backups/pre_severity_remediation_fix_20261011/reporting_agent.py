from typing import List, Dict, Any
from datetime import datetime
from config.settings import format_network_display, get_active_tcp_peer_ip
from agents.correlation_agent import format_incident_alert_summary


class ReportingAgent:
    """
    Reporting Agent synthesizing technical incident data, threat intel,
    and response playbooks into formal SOC Incident Reports.
    """

    def generate(self, incidents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        reports = []
        active_peer = get_active_tcp_peer_ip()

        for incident in incidents:
            alerts = incident.get("alerts", [])
            first_alert = alerts[0] if alerts else {}
            event = first_alert.get("event", {})
            threat = first_alert.get("threat_intel", {})

            inc_sources = incident.get("telemetry_sources") or list(dict.fromkeys(
                str(a.get("event", {}).get("source") or "unknown").strip()
                for a in alerts
            ))
            is_real = bool(
                incident.get("is_real_telemetry")
                or any(s in ("real_nxlog_windows", "local_windows") for s in inc_sources)
            )
            is_sim = bool(incident.get("is_simulated", not is_real))
            primary_src = incident.get("primary_source") or (inc_sources[0] if inc_sources else "unknown")

            raw_src_ip = event.get("source_ip")
            raw_peer_ip = event.get("remote_peer_ip")
            fallback_peer = (
                raw_peer_ip
                if (raw_peer_ip and str(raw_peer_ip).upper() not in ("N/A", "NONE", ""))
                else (active_peer if is_real else "N/A")
            )
            resolved_src_ip = format_network_display(
                raw_src_ip,
                field_role="source_ip",
                fallback_peer_ip=fallback_peer if fallback_peer != "N/A" else None,
            )

            resolved_host = format_network_display(
                incident.get("affected_host") or event.get("hostname"),
                field_role="hostname",
            )
            proc_name = format_network_display(event.get("process_name"), field_role="process_name")
            cmd_line = format_network_display(event.get("command_line"), field_role="command_line")
            evt_id = event.get("event_id", 4688)
            evt_ts = event.get("timestamp") or incident.get("timestamp") or datetime.now().isoformat()[:19]
            inc_techs = incident.get("mitre_techniques") or [
                format_network_display(
                    first_alert.get("mitre_technique") or event.get("mitre_technique", "T1059"),
                    field_role="mitre_technique",
                )
            ]
            mitre_tech_str = ", ".join(inc_techs) if inc_techs else "T1059"
            prov_label = f"Real Live Telemetry ({primary_src})" if is_real else f"Simulated Scenario ({primary_src})"

            summary_meta = format_incident_alert_summary(incident)
            win_alerts = summary_meta["window_alert_count"]
            cum_alerts = summary_meta["cumulative_alert_count"]
            cum_scope = summary_meta["cumulative_scope"]
            first_ts = summary_meta["first_event_timestamp"]
            last_ts = summary_meta["last_event_timestamp"]
            hist_range = summary_meta["historical_log_range"]
            evidence_cap = summary_meta["evidence_alert_cap"]
            evidence_shown = summary_meta["evidence_shown_count"]
            range_clause = f" ({hist_range})" if hist_range and hist_range != "Active Window" else ""

            report = {
                "report_id": f"REP-{incident.get('incident_id', '000')}",
                "incident_id": incident.get("incident_id", "INC-000"),
                "incident_name": incident.get("incident_name", "Security Incident"),
                "severity": incident.get("severity", "High"),
                "confidence": incident.get("confidence", 90),
                "window_alert_count": win_alerts,
                "cumulative_alert_count": cum_alerts,
                "cumulative_scope": cum_scope,
                "first_event_timestamp": first_ts,
                "last_event_timestamp": last_ts,
                "historical_log_range": hist_range,
                "evidence_alert_cap": evidence_cap,
                "bounded_evidence_count": evidence_shown,
                "alert_scope_explanation": summary_meta["scope_explanation"],
                "alert_count": int(incident.get("alert_count", len(alerts))),
                "host": resolved_host,
                "user": incident.get("affected_user") or event.get("user") or "SYSTEM",
                "source_ip": resolved_src_ip,
                "mitre_technique": mitre_tech_str,
                "mitre_techniques": list(inc_techs),
                "mitre_tactic": event.get("mitre_tactic", "Execution"),
                "telemetry_sources": inc_sources,
                "primary_source": primary_src,
                "is_real_telemetry": is_real,
                "is_simulated": is_sim,
                "provenance_label": prov_label,
                "executive_summary": (
                    f"A {incident.get('severity')} severity correlated incident '{incident.get('incident_name')}' "
                    f"[{prov_label}] was recorded on endpoint '{resolved_host}' involving account "
                    f"'{incident.get('affected_user', 'SYSTEM')}'. The multi-agent detection engine correlated "
                    f"{win_alerts} current-window alert(s) and {cum_alerts} cumulative alert(s) "
                    f"({cum_alerts:,} unique matching alert(s) observed across the retained historical log range{range_clause}) "
                    f"[{cum_scope}] with {incident.get('confidence')}% confidence. "
                    f"The evidence table is capped at {evidence_cap} recent records ({evidence_shown} shown), "
                    f"while the cumulative ledger tracks the full number of unique alert identities."
                ),
                "technical_analysis": (
                    f"Initial trigger event ID {evt_id} ({event.get('event_type', 'Process Creation')}) "
                    f"was registered at {evt_ts} from telemetry source '{primary_src}'. "
                    f"Process Name: {proc_name}. "
                    f"Command Line string: '{cmd_line}'."
                ),
                "status": threat.get("status", "Local Endpoint Telemetry (No External IP)"),
                "reputation": threat.get("reputation", "Unknown (No Threat Intel Match)"),
                "risk_score": threat.get("risk_score", 15),
                "recommendation": event.get("recommendation", "Review telemetry context and apply appropriate response controls if activity is unauthorized."),
                "timestamp": datetime.now().isoformat()
            }

            reports.append(report)

        print(f"[INFO] Reporting Agent generated {len(reports)} formal SOC Incident Report(s).")
        return reports