from typing import List, Dict, Any
from config.settings import SUJITH_IP, get_receiver_ip


class LogNormalizer:
    """
    Normalizes multi-source events (Windows, Sysmon, Linux, Suricata)
    into a standardized SentinelGPT event schema.
    """

    EVENT_TYPE_MAP = {
        4624: "Successful Authentication",
        4625: "Failed Authentication",
        4672: "Special Privileges Assigned",
        4688: "Windows Process Creation",
        4720: "User Account Created",
        4798: "User Local Group Membership Enumerated",
        4799: "Local Group Enumeration",
        5379: "Credential Manager Credential Read",
        7040: "Service Start Type Changed",
        1102: "Audit Log Cleared",
        1000: "Application / Informational Event (ID 1000)",
        1: "Sysmon Process Creation",
        3: "Sysmon Network Connection",
        10: "Sysmon LSASS Process Access",
        1001: "Linux SSH Login Attempt",
        2000001: "Suricata Network IDS Alert"
    }

    SEVERITY_MAP = {
        4624: "Low",
        4625: "Medium",
        4672: "Low",
        4688: "Medium",
        4720: "High",
        4798: "Low",
        4799: "Low",
        5379: "Low",
        7040: "Medium",
        1102: "Critical",
        1000: "Low",
        1: "High",
        3: "Medium",
        10: "Critical",
        1001: "Medium",
        2000001: "High"
    }

    CRED_VAULT_TOOLS = (
        "vaultcmd", "cmdkey", "powershell", "pwsh", "cmd.exe",
        "rundll32", "mimikatz", "lazagne", "seatbelt", "sharphound",
        "bloodhound", "procdump", "wscript", "cscript", "mshta", "python",
        "sekurlsa", "dpapi",
    )

    RECON_BINARIES = (
        "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
        "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
        "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
    )

    @classmethod
    def resolve_event_severity(
        cls,
        event_id: int,
        process_name: str = "",
        command_line: str = "",
        description: str = "",
        curr_sev: str = "",
    ) -> str:
        """
        Determines event-level severity accurately. Routine Windows background
        Event IDs 5379, 4798, and 4799 default to Low unless suspicious credential
        harvesting or reconnaissance tools appear in the process/command telemetry.
        """
        combined = f"{process_name or ''} {command_line or ''} {description or ''}".lower()
        if event_id == 5379:
            return "High" if any(t in combined for t in cls.CRED_VAULT_TOOLS) else "Low"
        if event_id in (4798, 4799):
            return "Medium" if any(b in combined for b in cls.RECON_BINARIES) else "Low"
        if curr_sev and str(curr_sev).strip().title() not in ["Low", "Informational", "Info", "N/A"]:
            return str(curr_sev).strip().title()
        return cls.SEVERITY_MAP.get(event_id, curr_sev or "Low")

    MITRE_TECHNIQUE_MAP = {
        4624: "T1078",      # Valid Accounts
        4625: "T1110",      # Brute Force
        4672: "T1078.001",  # Domain Accounts
        4688: "T1059",      # Command and Scripting Interpreter
        4720: "T1136",      # Create Account
        4798: "T1087.001",  # Account Discovery: Local Account
        4799: "T1087",      # Account Discovery
        5379: "T1555.004",  # Credentials from Password Stores: Windows Credential Manager
        7040: "T1543",      # Create or Modify System Process
        1102: "T1070.001",  # Clear Windows Event Logs
        1000: "N/A",        # Diagnostic Telemetry Probe
        1: "T1059.001",     # PowerShell Execution
        10: "T1003.001",    # LSASS Memory Dumping
        1001: "T1110.001",  # Password Guessing
        2000001: "T1021"    # Remote Services
    }

    DIAGNOSTIC_MARKERS = (
        "SECTOR1_RECEIVER_TEST",
        "SECTOR1_E2E",
        "DIAGNOSTIC_TEST",
        "PHASE1_",
        "PHASE2_",
        "PHASE3_",
        "MULTI_ENDPOINT_",
        "RECEIVER_TEST",
        "SENTINEL_TEST",
        "ADAPTIVESENTINEL_",
        "ADAPTIVESENTINEL_LIVE_TEST",
        "ADAPTIVESENTINEL_CONTINUOUS_TEST",
        "ADAPTIVESENTINEL_FINAL_VERIFY",
        "ADAPTIVESENTINEL_LIVE_VERIFY",
        "CONTINUOUS_TEST",
        "FINAL_VERIFY",
        "LIVE_VERIFY",
        "ADAPTIVESENTINELGPT TEST EVENT",
        "ADAPTIVE SENTINEL CONNECTION TEST",
        "NXLOG TEST EVENT",
        "LIVE TEST FROM",
        "LIVE_TEST_",
    )

    def normalize(self, raw_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        normalized_events = []
        if not raw_logs:
            return normalized_events
        invalid_ips = {"-", "::1", "127.0.0.1", "", "N/A", "0.0.0.0", "NONE", "UNKNOWN"}
        batch_receiver_ip = str(get_receiver_ip() or "N/A").strip()

        for log in raw_logs:
            event_id = log.get("event_id", 0)
            desc = log.get("description") or log.get("message", "No event description provided.")
            cmd_line = log.get("command_line", "N/A")
            proc_name_lower = str(log.get("process_name") or "").lower()
            cmd_lower = str(cmd_line or "").lower()
            desc_lower = str(desc or "").lower()

            # Distinguish overloaded Event IDs (1, 10, 1001) between Sysmon/SSH attacks and benign Windows OS informational events
            is_benign_overloaded_eid = False
            if event_id == 1 and not (
                "powershell" in proc_name_lower
                or "pwsh" in proc_name_lower
                or "powershell" in cmd_lower
                or "pwsh" in cmd_lower
                or "powershell" in desc_lower
                or "pwsh" in desc_lower
            ):
                is_benign_overloaded_eid = True
            elif event_id == 10 and not (
                "mimikatz" in proc_name_lower
                or "mimikatz" in cmd_lower
                or "mimikatz" in desc_lower
                or "lsass" in proc_name_lower
                or "lsass" in cmd_lower
                or "lsass" in desc_lower
                or "sekurlsa" in cmd_lower
                or "sekurlsa" in desc_lower
                or "process accessed" in desc_lower
            ):
                is_benign_overloaded_eid = True
            elif event_id == 1001 and (
                "fault bucket" in desc_lower
                or not (
                    "ssh" in proc_name_lower
                    or "ssh" in desc_lower
                    or "failed" in desc_lower
                    or "login" in desc_lower
                    or "logon" in desc_lower
                )
            ):
                is_benign_overloaded_eid = True

            # Check if event is an explicit diagnostic verification probe (Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in str(desc).upper() or marker in str(cmd_line).upper()
                       for marker in self.DIAGNOSTIC_MARKERS)
            )

            mitre_tech = log.get("mitre_technique")
            if is_diagnostic or is_benign_overloaded_eid:
                mitre_tech = "N/A"
            elif not mitre_tech or mitre_tech in ["N/A", "T1000"]:
                mitre_list = log.get("mitre_techniques", [])
                if isinstance(mitre_list, list) and mitre_list:
                    mitre_tech = ", ".join(str(m) for m in mitre_list)
                else:
                    mitre_tech = self.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")

            receiver_ip = str(log.get("receiver_ip") or batch_receiver_ip or "N/A").strip()
            source = log.get("source") or "real_nxlog_windows"
            hostname = str(log.get("hostname") or "UNKNOWN_HOST").strip() or "UNKNOWN_HOST"

            raw_source_ip = log.get("source_ip")
            src_ip_str = str(raw_source_ip).strip() if raw_source_ip is not None else ""
            if not src_ip_str or src_ip_str.upper() in invalid_ips or (
                source == "real_nxlog_windows" and src_ip_str == receiver_ip
            ):
                source_ip = "N/A"
            else:
                source_ip = src_ip_str

            raw_peer_ip = (
                log.get("remote_peer_ip")
                or log.get("MessageSourceAddress")
                or log.get("RemoteIp")
                or log.get("PeerIp")
            )
            peer_ip_str = str(raw_peer_ip).strip() if raw_peer_ip is not None else ""
            if not peer_ip_str or peer_ip_str.upper() in invalid_ips or peer_ip_str == receiver_ip:
                remote_peer_ip = "N/A"
            else:
                remote_peer_ip = peer_ip_str

            # Determine event_type string cleanly
            extracted_evt_type = log.get("event_type")
            if is_diagnostic:
                extracted_evt_type = "Diagnostic Telemetry Probe"
            elif is_benign_overloaded_eid:
                if event_id == 1:
                    extracted_evt_type = "Windows System Event (ID 1)"
                elif event_id == 1001:
                    extracted_evt_type = "Windows Error Reporting Event (ID 1001)"
                else:
                    extracted_evt_type = f"Windows Informational Event (ID {event_id})"
            elif not extracted_evt_type or extracted_evt_type in ["NXLog Event", "Generic Event", "N/A"]:
                if event_id in self.EVENT_TYPE_MAP:
                    extracted_evt_type = self.EVENT_TYPE_MAP[event_id]
                elif event_id != 0:
                    extracted_evt_type = f"Windows Event (ID {event_id})"
                else:
                    extracted_evt_type = "Windows Event"

            # Start with original dict to preserve all custom fields (including record_offset, record_id)
            normalized_event = log.copy()
            curr_sev = log.get("severity")
            if is_diagnostic or is_benign_overloaded_eid:
                resolved_sev = "Low"
            else:
                resolved_sev = self.resolve_event_severity(
                    event_id=event_id,
                    process_name=str(log.get("process_name") or ""),
                    command_line=str(cmd_line or ""),
                    description=str(desc or ""),
                    curr_sev=str(curr_sev or ""),
                )

            dst_ip = log.get("destination_ip")
            if not dst_ip or dst_ip in ["-", ""]:
                dst_ip = receiver_ip

            raw_channel = str(log.get("log_channel") or "").strip()
            if not raw_channel:
                if event_id == 2000001 or "suricata" in proc_name_lower or "suricata" in desc_lower:
                    raw_channel = "Suricata IDS"
                elif event_id == 1001 and ("ssh" in proc_name_lower or "ssh" in desc_lower):
                    raw_channel = "Linux Auth"
                else:
                    raw_channel = source

            normalized_event.update({
                "timestamp": log.get("timestamp"),
                "ingestion_timestamp": log.get("ingestion_timestamp"),
                "source": source,
                "log_channel": raw_channel,
                "event_id": event_id,
                "event_type": extracted_evt_type,
                "severity": resolved_sev,
                "hostname": hostname,
                "user": log.get("user", "SYSTEM"),
                "source_ip": source_ip,
                "remote_peer_ip": remote_peer_ip,
                "receiver_ip": receiver_ip,
                "destination_ip": dst_ip,
                "process_name": log.get("process_name", "N/A"),
                "command_line": cmd_line,
                "description": desc,
                "mitre_technique": mitre_tech,
                "mitre_techniques": log.get("mitre_techniques", []),
                "is_diagnostic": is_diagnostic
            })

            normalized_events.append(normalized_event)

        print(f"[INFO] LogNormalizer standardized {len(normalized_events)} log events.")
        return normalized_events


def normalize_events(raw_logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return LogNormalizer().normalize(raw_logs)


def build_endpoint_inventory(
    events: List[Dict[str, Any]],
    receiver_ip: str = None,
    active_tcp_peer_ip: str = None,
) -> List[Dict[str, Any]]:
    """
    Builds a per-endpoint inventory from observed telemetry events.
    Preserves each distinct hostname (unifying Windows case variants such as
    'HARSHA' and 'Harsha') and tracks:
      - hostname
      - event_count
      - latest_timestamp
      - observed_source_ip ('N/A' when unknown; never uses receiver_ip)
      - observed_remote_peer_ip ('N/A' when unknown; never uses receiver_ip)
      - sources
    """
    active_receiver = str(receiver_ip or get_receiver_ip() or "N/A").strip()
    invalid_ips = {"", "-", "N/A", "NONE", "UNKNOWN", "127.0.0.1", "::1", "0.0.0.0", active_receiver.upper()}
    fallback_peer = str(active_tcp_peer_ip or "").strip()
    if fallback_peer.upper() in invalid_ips or fallback_peer == active_receiver:
        fallback_peer = ""

    inventory_map: Dict[str, Dict[str, Any]] = {}

    for evt in events:
        host = str(evt.get("hostname") or "UNKNOWN_HOST").strip() or "UNKNOWN_HOST"
        host_key = host.lower()
        ts = str(evt.get("timestamp") or evt.get("ingestion_timestamp") or "N/A")[:19].replace("T", " ")
        src_ip = str(evt.get("source_ip") or "N/A").strip()
        peer_ip = str(evt.get("remote_peer_ip") or "N/A").strip()
        source_name = str(evt.get("source") or "real_nxlog_windows").strip()

        if host_key not in inventory_map:
            inventory_map[host_key] = {
                "hostname": host,
                "event_count": 0,
                "latest_timestamp": ts,
                "observed_source_ip": "N/A",
                "observed_remote_peer_ip": "N/A",
                "sources": set(),
            }
        else:
            # Prefer mixed-case hostname (e.g. 'Harsha') over all-uppercase ('HARSHA') when both appear
            existing_host = inventory_map[host_key]["hostname"]
            if existing_host.isupper() and not host.isupper():
                inventory_map[host_key]["hostname"] = host

        entry = inventory_map[host_key]
        entry["event_count"] += 1
        if ts != "N/A" and (entry["latest_timestamp"] == "N/A" or ts >= entry["latest_timestamp"]):
            entry["latest_timestamp"] = ts

        if src_ip.upper() not in invalid_ips and src_ip != active_receiver:
            entry["observed_source_ip"] = src_ip

        if peer_ip.upper() not in invalid_ips and peer_ip != active_receiver:
            entry["observed_remote_peer_ip"] = peer_ip
        elif fallback_peer and source_name == "real_nxlog_windows" and entry["observed_remote_peer_ip"] == "N/A":
            entry["observed_remote_peer_ip"] = fallback_peer

        if source_name:
            entry["sources"].add(source_name)

    inventory_list = []
    for _, data in inventory_map.items():
        data["sources"] = sorted(list(data["sources"]))
        inventory_list.append(data)

    inventory_list.sort(
        key=lambda item: (
            item["latest_timestamp"] if item["latest_timestamp"] != "N/A" else "",
            item["event_count"],
        ),
        reverse=True,
    )
    return inventory_list


def filter_telemetry_by_endpoint(
    logs: List[Dict[str, Any]],
    incidents: List[Dict[str, Any]],
    selected_endpoint: str,
):
    """
    Filters logs and correlated incidents by endpoint hostname (case-insensitively)
    without breaking existing telemetry source filters or scenario isolation.
    """
    if not selected_endpoint or selected_endpoint == "ALL ENDPOINTS":
        return logs, incidents

    target = str(selected_endpoint).strip().lower()
    filtered_logs = [
        l for l in logs
        if str(l.get("hostname", "")).strip().lower() == target
    ]
    filtered_incidents = [
        inc for inc in incidents
        if str(inc.get("affected_host", "")).strip().lower() == target
        or any(
            str(alt.get("event", {}).get("hostname", "")).strip().lower() == target
            for alt in inc.get("alerts", [])
        )
    ]
    return filtered_logs, filtered_incidents