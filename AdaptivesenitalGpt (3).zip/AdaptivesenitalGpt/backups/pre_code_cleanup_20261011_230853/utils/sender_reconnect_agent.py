import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

from utils.network_discovery import (
    DEFAULT_RECEIVER_PORT,
    detect_active_interface_and_ip,
    discover_receiver_endpoint,
    is_valid_unicast_ipv4,
    verify_tcp_receiver,
)


DEFAULT_WINDOWS_NXLOG_CONF = Path(r"C:\Program Files\nxlog\conf\nxlog.conf")


def compute_reconnect_backoff(attempt: int, base_sec: float = 5.0, max_sec: float = 60.0) -> float:
    """
    Computes a bounded exponential backoff interval (in seconds) for reconnection retries
    so the sender never enters an aggressive infinite loop or floods the network.
    """
    step = max(0, int(attempt))
    delay = base_sec * (1.5 ** min(step, 8))
    return round(min(max_sec, max(base_sec, delay)), 2)


def extract_nxlog_tcp_host_and_port(config_text: str) -> Tuple[Optional[str], Optional[int]]:
    """
    Parses an NXLog configuration string to extract the current `Host` and `Port`
    from an `om_tcp` `<Output ...>` block (or top-level Host/Port directives).
    """
    if not config_text:
        return None, None

    # First look inside <Output ...> blocks that use om_tcp
    output_blocks = re.findall(
        r"<Output\s+[^>]+>(.*?)</Output>",
        config_text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    for block in output_blocks:
        if "om_tcp" in block.lower() or "2514" in block:
            host_m = re.search(r"^\s*Host\s+([^\s#;]+)", block, flags=re.IGNORECASE | re.MULTILINE)
            port_m = re.search(r"^\s*Port\s+(\d+)", block, flags=re.IGNORECASE | re.MULTILINE)
            host_val = host_m.group(1).strip().strip("\"'") if host_m else None
            port_val = int(port_m.group(1)) if port_m else None
            return host_val, port_val

    # Fallback: match any Host / Port directive outside <Input ...> blocks
    non_input_text = re.sub(
        r"<Input\s+[^>]+>.*?</Input>",
        "",
        config_text,
        flags=re.IGNORECASE | re.DOTALL,
    )
    host_m = re.search(r"^\s*Host\s+([^\s#;]+)", non_input_text, flags=re.IGNORECASE | re.MULTILINE)
    port_m = re.search(r"^\s*Port\s+(\d+)", non_input_text, flags=re.IGNORECASE | re.MULTILINE)
    host_val = host_m.group(1).strip().strip("\"'") if host_m else None
    port_val = int(port_m.group(1)) if port_m else None
    return host_val, port_val


def render_updated_nxlog_config(
    original_text: str,
    new_receiver_ip: str,
    receiver_port: int = DEFAULT_RECEIVER_PORT,
) -> str:
    """
    Safely updates only the sender's `om_tcp` `<Output ...>` `Host` (and `Port` if needed)
    directive in `nxlog.conf`, preserving all comments, `<Input ...>` blocks, bookmarks,
    `SavePos TRUE`, `ReadFromLast TRUE`, and `CacheDir` settings.
    """
    if not is_valid_unicast_ipv4(new_receiver_ip):
        raise ValueError(f"Refusing to write invalid receiver IP to nxlog.conf: {new_receiver_ip}")
    if int(receiver_port) != DEFAULT_RECEIVER_PORT and not (1 <= int(receiver_port) <= 65535):
        raise ValueError(f"Refusing to write invalid TCP port to nxlog.conf: {receiver_port}")

    target_ip = new_receiver_ip.strip()
    target_port = int(receiver_port)

    replaced_in_output = False

    def _replace_output_block(match: re.Match) -> str:
        nonlocal replaced_in_output
        full_block = match.group(0)
        inner = match.group(1)
        if "om_tcp" not in inner.lower() and str(target_port) not in inner:
            return full_block

        updated_inner = re.sub(
            r"(^\s*Host\s+)([^\s#;\r\n]+)",
            rf"\g<1>{target_ip}",
            inner,
            flags=re.IGNORECASE | re.MULTILINE,
        )
        updated_inner = re.sub(
            r"(^\s*Port\s+)(\d+)",
            rf"\g<1>{target_port}",
            updated_inner,
            flags=re.IGNORECASE | re.MULTILINE,
        )
        replaced_in_output = True
        return full_block.replace(inner, updated_inner, 1)

    updated_text = re.sub(
        r"<Output\s+[^>]+>(.*?)</Output>",
        _replace_output_block,
        original_text,
        flags=re.IGNORECASE | re.DOTALL,
    )

    if not replaced_in_output:
        updated_text = re.sub(
            r"(^\s*Host\s+)([^\s#;\r\n]+)",
            rf"\g<1>{target_ip}",
            original_text,
            count=1,
            flags=re.IGNORECASE | re.MULTILINE,
        )

    return updated_text


def restart_windows_nxlog_service(timeout_sec: float = 15.0) -> Tuple[bool, str]:
    """
    Controlled restart of the Windows `nxlog` service using `Restart-Service -Name nxlog -Force`.
    """
    if os.name != "nt":
        return False, "Non-Windows OS: nxlog service restart skipped"
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command", "Restart-Service -Name nxlog -Force -ErrorAction Stop"],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode == 0:
            return True, "nxlog service restarted successfully"
        return False, (proc.stderr or proc.stdout or f"Exit code {proc.returncode}").strip()
    except Exception as exc:
        return False, str(exc)


def update_sender_nxlog_config_if_needed(
    nxlog_conf_path: Path,
    verified_receiver_ip: str,
    receiver_port: int = DEFAULT_RECEIVER_PORT,
    restart_service: bool = True,
    service_restarter: Optional[Callable[[], Tuple[bool, str]]] = None,
) -> Dict[str, Any]:
    """
    Atomically updates the sender's `nxlog.conf` ONLY when the verified receiver IP
    differs from the currently configured `Host` (or `Port` differs from 2514).
    Creates a `.bak` backup before modifying and restarts `nxlog` only when changed.
    """
    conf_path = Path(nxlog_conf_path)
    if not is_valid_unicast_ipv4(verified_receiver_ip):
        return {
            "config_updated": False,
            "service_restarted": False,
            "previous_host": None,
            "new_host": verified_receiver_ip,
            "backup_path": None,
            "error": f"Invalid receiver IP rejected: {verified_receiver_ip}",
        }

    if not conf_path.exists():
        return {
            "config_updated": False,
            "service_restarted": False,
            "previous_host": None,
            "new_host": verified_receiver_ip,
            "backup_path": None,
            "error": f"NXLog configuration file not found at {conf_path}",
        }

    original_text = conf_path.read_text(encoding="utf-8")
    current_host, current_port = extract_nxlog_tcp_host_and_port(original_text)
    target_ip = verified_receiver_ip.strip()
    target_port = int(receiver_port)

    # Idempotency check: do not rewrite or restart if already pointing to target_ip:target_port
    if current_host == target_ip and (current_port is None or current_port == target_port):
        return {
            "config_updated": False,
            "service_restarted": False,
            "previous_host": current_host,
            "new_host": target_ip,
            "backup_path": None,
            "error": None,
            "message": f"nxlog.conf already configured for {target_ip}:{target_port} — no restart needed",
        }

    # Render and validate updated configuration
    updated_text = render_updated_nxlog_config(original_text, target_ip, target_port)
    verify_host, verify_port = extract_nxlog_tcp_host_and_port(updated_text)
    if verify_host != target_ip:
        return {
            "config_updated": False,
            "service_restarted": False,
            "previous_host": current_host,
            "new_host": target_ip,
            "backup_path": None,
            "error": "Validation failed: updated config did not contain the expected Host directive",
        }

    # Save backup before replacing
    backup_path = conf_path.with_suffix(conf_path.suffix + ".bak")
    shutil.copy2(conf_path, backup_path)

    # Atomic write via temporary file
    tmp_path = conf_path.with_suffix(conf_path.suffix + ".tmp")
    tmp_path.write_text(updated_text, encoding="utf-8")
    os.replace(tmp_path, conf_path)

    service_restarted = False
    restart_msg = "Service restart skipped (dry-run / disabled)"
    if restart_service:
        restarter = service_restarter or restart_windows_nxlog_service
        ok, restart_msg = restarter()
        service_restarted = bool(ok)
        if not ok:
            return {
                "config_updated": True,
                "service_restarted": False,
                "previous_host": current_host,
                "new_host": target_ip,
                "backup_path": str(backup_path),
                "error": f"Config updated to {target_ip}:{target_port}, but nxlog restart failed: {restart_msg}",
            }

    return {
        "config_updated": True,
        "service_restarted": service_restarted,
        "previous_host": current_host,
        "new_host": target_ip,
        "backup_path": str(backup_path),
        "error": None,
        "message": f"Updated nxlog.conf Host from {current_host} to {target_ip}:{target_port}. {restart_msg}",
    }


def run_sender_discovery_and_sync_cycle(
    nxlog_conf_path: Path = DEFAULT_WINDOWS_NXLOG_CONF,
    state_file_path: Optional[Path] = None,
    receiver_hostname: str = "Sujith",
    receiver_port: int = DEFAULT_RECEIVER_PORT,
    manual_bootstrap_ip: Optional[str] = None,
    secret_token: str = "SENTINEL_SECRET_TOKEN_2026",
    restart_service: bool = True,
    interfaces_provider: Optional[Callable] = None,
    hostname_resolver: Optional[Callable] = None,
    udp_discoverer: Optional[Callable] = None,
    tcp_verifier: Optional[Callable[[str, int], bool]] = None,
    service_restarter: Optional[Callable[[], Tuple[bool, str]]] = None,
) -> Dict[str, Any]:
    """
    Executes one complete, bounded sender discovery and reconnection cycle:
      1. Detects sender's current local interface and IPv4 address (`sender_ip_current`).
      2. Checks whether the currently configured `Host` in `nxlog.conf` is already reachable on TCP 2514.
      3. If not reachable (or if discovery finds a new IP), runs the 4-tier receiver discovery chain.
      4. Atomically updates `nxlog.conf` and restarts `nxlog` ONLY if the verified receiver IP changed.
      5. Persists and returns the structured sender network state.
    """
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    sender_hostname = os.getenv("ENDPOINT_HOSTNAME", "").strip()
    if not sender_hostname or sender_hostname.upper() in ("N/A", "NONE", "UNKNOWN"):
        sender_hostname = socket.gethostname() or "Harsha"

    iface_name, sender_ip = detect_active_interface_and_ip(interfaces_provider=interfaces_provider)
    verifier = tcp_verifier or verify_tcp_receiver

    persisted: Dict[str, Any] = {}
    if state_file_path and Path(state_file_path).exists():
        try:
            persisted = json.loads(Path(state_file_path).read_text(encoding="utf-8"))
        except Exception:
            persisted = {}

    last_known_rec_ip = persisted.get("last_known_receiver_ip")
    current_conf_host = None
    if Path(nxlog_conf_path).exists():
        try:
            current_conf_host, _ = extract_nxlog_tcp_host_and_port(
                Path(nxlog_conf_path).read_text(encoding="utf-8")
            )
        except Exception:
            current_conf_host = None

    if not is_valid_unicast_ipv4(sender_ip):
        state = {
            "sender_hostname": sender_hostname,
            "sender_ip_current": "Disconnected (Waiting for active Wi-Fi/LAN)",
            "sender_destination_ip": current_conf_host or last_known_rec_ip or "Searching for receiver…",
            "receiver_hostname": receiver_hostname,
            "receiver_ip_current": last_known_rec_ip or "Searching for receiver…",
            "receiver_port": int(receiver_port),
            "connection_status": "DISCONNECTED",
            "network_interface": iface_name,
            "last_successful_connection": persisted.get("last_successful_connection", "Not yet connected"),
            "last_discovery_time": now_iso,
            "last_error": "Sender has no active non-loopback IPv4 interface",
            "last_known_receiver_ip": last_known_rec_ip or "Not yet recorded",
            "last_known_sender_ip": persisted.get("last_known_sender_ip", "Not yet recorded"),
            "config_updated": False,
            "service_restarted": False,
        }
        if state_file_path:
            Path(state_file_path).parent.mkdir(parents=True, exist_ok=True)
            Path(state_file_path).write_text(json.dumps(state, indent=2), encoding="utf-8")
        return state

    # Run discovery (passing current_conf_host or last_known_rec_ip as fallback)
    fallback_ip = current_conf_host if is_valid_unicast_ipv4(current_conf_host) else last_known_rec_ip
    disc = discover_receiver_endpoint(
        receiver_hostname=receiver_hostname,
        port=receiver_port,
        sender_hostname=sender_hostname,
        sender_ip=sender_ip,
        last_known_receiver_ip=fallback_ip,
        manual_bootstrap_ip=manual_bootstrap_ip,
        secret_token=secret_token,
        hostname_resolver=hostname_resolver,
        udp_discoverer=udp_discoverer,
        tcp_verifier=verifier,
    )

    if not disc.get("success") or not disc.get("receiver_ip"):
        state = {
            "sender_hostname": sender_hostname,
            "sender_ip_current": sender_ip,
            "sender_destination_ip": current_conf_host or fallback_ip or "Searching for receiver…",
            "receiver_hostname": receiver_hostname,
            "receiver_ip_current": fallback_ip or "Receiver unreachable on TCP 2514",
            "receiver_port": int(receiver_port),
            "connection_status": "RECONNECTING",
            "network_interface": iface_name,
            "last_successful_connection": persisted.get("last_successful_connection", "Not yet connected"),
            "last_discovery_time": now_iso,
            "last_error": disc.get("error") or f"Receiver {receiver_hostname} unreachable on TCP {receiver_port}",
            "last_known_receiver_ip": fallback_ip or "Not yet recorded",
            "last_known_sender_ip": sender_ip,
            "config_updated": False,
            "service_restarted": False,
            "discovery_method": "none",
            "attempts": disc.get("attempts", []),
            "diagnostics": disc.get("diagnostics", []),
        }
        if state_file_path:
            Path(state_file_path).parent.mkdir(parents=True, exist_ok=True)
            Path(state_file_path).write_text(json.dumps(state, indent=2), encoding="utf-8")
        return state

    verified_rec_ip = str(disc["receiver_ip"]).strip()
    upd = update_sender_nxlog_config_if_needed(
        nxlog_conf_path=Path(nxlog_conf_path),
        verified_receiver_ip=verified_rec_ip,
        receiver_port=receiver_port,
        restart_service=restart_service,
        service_restarter=service_restarter,
    )

    status = "CONNECTED" if not upd.get("error") else "ERROR"
    state = {
        "sender_hostname": sender_hostname,
        "sender_ip_current": sender_ip,
        "sender_destination_ip": verified_rec_ip,
        "receiver_hostname": str(disc.get("receiver_hostname") or receiver_hostname),
        "receiver_ip_current": verified_rec_ip,
        "receiver_port": int(receiver_port),
        "connection_status": status,
        "network_interface": iface_name,
        "last_successful_connection": now_iso if status == "CONNECTED" else persisted.get("last_successful_connection", "Not yet connected"),
        "last_discovery_time": now_iso,
        "last_error": upd.get("error") or "None — Operating normally",
        "last_known_receiver_ip": verified_rec_ip,
        "last_known_sender_ip": sender_ip,
        "config_updated": bool(upd.get("config_updated")),
        "service_restarted": bool(upd.get("service_restarted")),
        "discovery_method": disc.get("discovery_method", "verified"),
        "attempts": disc.get("attempts", []),
        "diagnostics": disc.get("diagnostics", []),
    }
    if state_file_path:
        Path(state_file_path).parent.mkdir(parents=True, exist_ok=True)
        Path(state_file_path).write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state


def main() -> None:
    parser = argparse.ArgumentParser(
        description="AdaptiveSentinelGPT Sender Auto-Discovery & NXLog Reconnection Agent (Harsha -> Sujith TCP 2514)"
    )
    parser.add_argument("--nxlog-conf", type=str, default=str(DEFAULT_WINDOWS_NXLOG_CONF))
    parser.add_argument("--receiver-hostname", type=str, default=os.getenv("RECEIVER_HOSTNAME", "Sujith"))
    parser.add_argument("--port", type=int, default=DEFAULT_RECEIVER_PORT)
    parser.add_argument("--bootstrap-ip", type=str, default=os.getenv("RECEIVER_BOOTSTRAP_IP", ""))
    parser.add_argument("--state-file", type=str, default=str(Path("data") / "sender_network_state.json"))
    parser.add_argument("--once", action="store_true", help="Run a single discovery/update check and exit")
    parser.add_argument("--no-restart", action="store_true", help="Update nxlog.conf without restarting nxlog service")
    args = parser.parse_args()

    attempt = 0
    while True:
        res = run_sender_discovery_and_sync_cycle(
            nxlog_conf_path=Path(args.nxlog_conf),
            state_file_path=Path(args.state_file),
            receiver_hostname=args.receiver_hostname,
            receiver_port=args.port,
            manual_bootstrap_ip=args.bootstrap_ip or None,
            restart_service=not args.no_restart,
        )
        print(
            f"[{res['last_discovery_time']}] Status={res['connection_status']} | "
            f"Sender={res['sender_hostname']} ({res['sender_ip_current']}) -> "
            f"Receiver={res['receiver_hostname']} ({res['sender_destination_ip']}:{res['receiver_port']}) | "
            f"Method={res.get('discovery_method')} | Updated={res['config_updated']}"
        )
        for diag in res.get("diagnostics", []):
            print(f"  [DIAG] {diag.get('method')} ({diag.get('target')}): {diag.get('status')} - {diag.get('reason')}")
        if args.once:
            break
        if res["connection_status"] == "CONNECTED":
            attempt = 0
            time.sleep(15.0)
        else:
            delay = compute_reconnect_backoff(attempt)
            attempt += 1
            time.sleep(delay)


if __name__ == "__main__":
    main()
