import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agents.correlation_agent import CorrelationAgent
from agents.detection_agent import DetectionAgent
from agents.reporting_agent import ReportingAgent
from analysis.deduplicate import LogDeduplicator, get_event_identity_key
from analysis.normalize import LogNormalizer, build_endpoint_inventory
from analysis.parser import NXLogReader
from config.settings import format_network_display, get_endpoint_ip
from utils.network_discovery import (
    CentralNetworkStateService,
    DISCOVERY_PROTOCOL_MAGIC,
    DISCOVERY_PROTOCOL_VERSION,
    build_discovery_request,
    build_discovery_response,
    detect_active_interface_and_ip,
    discover_receiver_endpoint,
    inspect_tcp_port_connections,
    validate_discovery_request,
    validate_discovery_response,
    verify_tcp_receiver,
)
from utils.sender_reconnect_agent import (
    compute_reconnect_backoff,
    extract_nxlog_tcp_host_and_port,
    run_sender_discovery_and_sync_cycle,
    update_sender_nxlog_config_if_needed,
)


# ---------------------------------------------------------------------------
# 1. Detecting the receiver's current active IPv4 address
# ---------------------------------------------------------------------------
def test_01_detect_receiver_current_active_ipv4():
    mock_interfaces = [
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    iface, ip_addr = detect_active_interface_and_ip(
        interfaces_provider=lambda: mock_interfaces,
        route_ip_provider=lambda: "11.12.7.72",
    )
    assert iface == "Wi-Fi"
    assert ip_addr == "11.12.7.72"


# ---------------------------------------------------------------------------
# 2. Ignoring loopback, disconnected, and virtual interfaces when physical exists
# ---------------------------------------------------------------------------
def test_02_ignore_loopback_disconnected_and_virtual_adapters():
    mock_interfaces = [
        {"interface": "Loopback Pseudo-Interface 1", "ip": "127.0.0.1"},
        {"interface": "Autoconfiguration APIPA", "ip": "169.254.44.12"},
        {"interface": "VMware Network Adapter VMnet1", "ip": "192.168.216.1"},
        {"interface": "VMware Network Adapter VMnet8", "ip": "192.168.222.1"},
        {"interface": "vEthernet (WSL)", "ip": "172.24.16.1"},
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    iface, ip_addr = detect_active_interface_and_ip(
        interfaces_provider=lambda: mock_interfaces,
        route_ip_provider=lambda: "11.12.7.72",
    )
    assert iface == "Wi-Fi"
    assert ip_addr == "11.12.7.72"


# ---------------------------------------------------------------------------
# 3. Detecting the sender's current active IPv4 address
# ---------------------------------------------------------------------------
def test_03_detect_sender_current_active_ipv4(tmp_path):
    nxlog_conf = tmp_path / "nxlog.conf"
    nxlog_conf.write_text(
        "<Output send_to_sujith>\n    Module om_tcp\n    Host 11.12.7.72\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    state_file = tmp_path / "sender_state.json"
    sender_state = run_sender_discovery_and_sync_cycle(
        nxlog_conf_path=nxlog_conf,
        state_file_path=state_file,
        receiver_hostname="Sujith",
        receiver_port=2514,
        restart_service=False,
        interfaces_provider=lambda: [
            {"interface": "VirtualBox Host-Only Network", "ip": "192.168.56.1"},
            {"interface": "Wi-Fi", "ip": "11.12.4.164"},
        ],
        hostname_resolver=lambda host, port: ["11.12.7.72"],
        tcp_verifier=lambda ip, port: ip == "11.12.7.72" and port == 2514,
    )
    assert sender_state["sender_ip_current"] == "11.12.4.164"
    assert sender_state["network_interface"] == "Wi-Fi"
    assert sender_state["connection_status"] == "CONNECTED"


# ---------------------------------------------------------------------------
# 4. Discovering the receiver IP using the multi-tier discovery mechanism
# ---------------------------------------------------------------------------
def test_04_discover_receiver_ip_multi_tier_priority():
    # Tier 1: Hostname resolution succeeds
    res1 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.42.0.10"] if h == "Sujith" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "10.42.0.10" and p == 2514,
    )
    assert res1["success"] is True
    assert res1["receiver_ip"] == "10.42.0.10"
    assert res1["discovery_method"] == "hostname_resolution"

    # Tier 2: Standard hostname fails, mDNS (.local) succeeds
    res2 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.42.0.20"] if h == "Sujith.local" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "10.42.0.20" and p == 2514,
    )
    assert res2["success"] is True
    assert res2["receiver_ip"] == "10.42.0.20"
    assert res2["discovery_method"] == "mdns_resolution"

    # Tier 3: Hostname & mDNS fail, UDP broadcast discovery succeeds
    res3 = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: [],
        udp_discoverer=lambda: {"receiver_ip": "10.42.0.30", "receiver_hostname": "Sujith", "receiver_port": 2514},
        tcp_verifier=lambda ip, p: ip == "10.42.0.30" and p == 2514,
    )
    assert res3["success"] is True
    assert res3["receiver_ip"] == "10.42.0.30"
    assert res3["discovery_method"] == "udp_broadcast_discovery"


# ---------------------------------------------------------------------------
# 5. Validating a legitimate discovery response
# ---------------------------------------------------------------------------
def test_05_validate_legitimate_discovery_response():
    secret = "TEST_SHARED_SECRET_2026"
    req = build_discovery_request(
        sender_hostname="Harsha",
        sender_ip="11.12.4.164",
        requested_port=2514,
        secret_token=secret,
        nonce="nonce-12345",
    )
    req_ok, req_reason = validate_discovery_request(req, expected_port=2514, secret_token=secret)
    assert req_ok is True
    assert req_reason == "VALID"

    resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="11.12.7.72",
        receiver_port=2514,
        network_interface="Wi-Fi",
        request_nonce="nonce-12345",
        secret_token=secret,
    )
    is_valid, reason = validate_discovery_response(
        resp,
        expected_port=2514,
        expected_nonce="nonce-12345",
        expected_hostname="Sujith",
        secret_token=secret,
    )
    assert is_valid is True
    assert reason == "VALID"


# ---------------------------------------------------------------------------
# 6. Rejecting a malformed or spoofed discovery response
# ---------------------------------------------------------------------------
def test_06_reject_malformed_or_spoofed_discovery_response():
    secret = "TEST_SHARED_SECRET_2026"
    valid_resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="11.12.7.72",
        receiver_port=2514,
        request_nonce="nonce-abc",
        secret_token=secret,
    )

    # Case A: Spoofed IP without valid HMAC
    spoofed_ip = dict(valid_resp, receiver_ip="192.168.1.250")
    ok_a, _ = validate_discovery_response(spoofed_ip, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_a is False

    # Case B: Wrong protocol magic
    bad_proto = dict(valid_resp, protocol="ROGUE_PROTOCOL")
    ok_b, _ = validate_discovery_response(bad_proto, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_b is False

    # Case C: Nonce mismatch (replay attack)
    ok_c, _ = validate_discovery_response(valid_resp, expected_port=2514, expected_nonce="different-nonce", secret_token=secret)
    assert ok_c is False

    # Case D: Loopback / invalid IP in response
    loopback_resp = build_discovery_response(
        receiver_hostname="Sujith",
        receiver_ip="127.0.0.1",
        receiver_port=2514,
        request_nonce="nonce-abc",
        secret_token=secret,
    )
    ok_d, _ = validate_discovery_response(loopback_resp, expected_port=2514, expected_nonce="nonce-abc", secret_token=secret)
    assert ok_d is False


# ---------------------------------------------------------------------------
# 7. Verifying TCP port 2514 reachability before trusting a discovered receiver IP
# ---------------------------------------------------------------------------
def test_07_verify_tcp_2514_before_trusting_discovered_ip():
    # Hostname resolves to 10.10.10.50 (unreachable on TCP 2514), UDP resolves to 10.10.10.88 (reachable on TCP 2514)
    res = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: ["10.10.10.50"],
        udp_discoverer=lambda: {"receiver_ip": "10.10.10.88", "receiver_hostname": "Sujith", "receiver_port": 2514},
        tcp_verifier=lambda ip, p: ip == "10.10.10.88" and p == 2514,
    )
    assert res["success"] is True
    assert res["receiver_ip"] == "10.10.10.88"
    assert res["discovery_method"] == "udp_broadcast_discovery"


# ---------------------------------------------------------------------------
# 8. Updating sender NXLog target IP only when verified receiver IP changes
# ---------------------------------------------------------------------------
def test_08_update_sender_nxlog_target_ip_when_verified_ip_changes(tmp_path):
    conf_file = tmp_path / "nxlog.conf"
    conf_file.write_text(
        "<Input eventlog>\n    Module im_msvistalog\n    SavePos TRUE\n</Input>\n\n"
        "<Output out_tcp>\n    Module om_tcp\n    Host 10.184.216.159\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    restarted = []
    upd = update_sender_nxlog_config_if_needed(
        nxlog_conf_path=conf_file,
        verified_receiver_ip="11.12.7.72",
        receiver_port=2514,
        restart_service=True,
        service_restarter=lambda: (restarted.append(True) or (True, "Restarted mock nxlog")),
    )
    assert upd["config_updated"] is True
    assert upd["service_restarted"] is True
    assert upd["previous_host"] == "10.184.216.159"
    assert upd["new_host"] == "11.12.7.72"
    assert Path(upd["backup_path"]).exists()
    assert len(restarted) == 1

    new_host, new_port = extract_nxlog_tcp_host_and_port(conf_file.read_text(encoding="utf-8"))
    assert new_host == "11.12.7.72"
    assert new_port == 2514
    assert "SavePos TRUE" in conf_file.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# 9. Avoiding unnecessary NXLog service restarts when receiver IP has not changed
# ---------------------------------------------------------------------------
def test_09_avoid_unnecessary_nxlog_restart_when_ip_unchanged(tmp_path):
    conf_file = tmp_path / "nxlog.conf"
    conf_file.write_text(
        "<Output out_tcp>\n    Module om_tcp\n    Host 11.12.7.72\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    restarted = []
    upd = update_sender_nxlog_config_if_needed(
        nxlog_conf_path=conf_file,
        verified_receiver_ip="11.12.7.72",
        receiver_port=2514,
        restart_service=True,
        service_restarter=lambda: (restarted.append(True) or (True, "Restarted")),
    )
    assert upd["config_updated"] is False
    assert upd["service_restarted"] is False
    assert len(restarted) == 0


# ---------------------------------------------------------------------------
# 10. Preserving receiver port 2514
# ---------------------------------------------------------------------------
def test_10_preserve_receiver_port_2514(tmp_path):
    state_service = CentralNetworkStateService(
        state_file_path=tmp_path / "network_state.json",
        receiver_port=2514,
    )
    state = state_service.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n",
    )
    assert state["receiver_port"] == 2514


# ---------------------------------------------------------------------------
# 11. Handling network switches from Hotspot A to Hotspot B
# ---------------------------------------------------------------------------
def test_11_network_switch_hotspot_a_to_hotspot_b(tmp_path):
    state_file = tmp_path / "net_state.json"
    nxlog_conf = tmp_path / "nxlog.conf"
    nxlog_conf.write_text(
        "<Output out_tcp>\n    Module om_tcp\n    Host 192.168.43.10\n    Port 2514\n</Output>\n",
        encoding="utf-8",
    )
    svc = CentralNetworkStateService(state_file_path=state_file, receiver_port=2514)

    # Hotspot A: Receiver=192.168.43.10, Sender=192.168.43.25
    state_a = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "192.168.43.10"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    192.168.43.10:2514     192.168.43.25:51200    ESTABLISHED     3400\n"
        ),
    )
    assert state_a["receiver_ip_current"] == "192.168.43.10"
    assert state_a["sender_ip_current"] == "192.168.43.25"
    assert state_a["connection_status"] == "CONNECTED"

    # Switch to Hotspot B: Receiver=172.20.10.2, Sender=172.20.10.5
    state_b = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.2"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    172.20.10.2:2514       172.20.10.5:51300      ESTABLISHED     3400\n"
        ),
    )
    assert state_b["receiver_ip_current"] == "172.20.10.2"
    assert state_b["sender_ip_current"] == "172.20.10.5"
    assert state_b["sender_destination_ip"] == "172.20.10.2"

    # Sender auto-updates nxlog.conf from 192.168.43.10 -> 172.20.10.2
    sender_res = run_sender_discovery_and_sync_cycle(
        nxlog_conf_path=nxlog_conf,
        state_file_path=tmp_path / "sender_state.json",
        receiver_hostname="Sujith",
        receiver_port=2514,
        restart_service=False,
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.5"}],
        hostname_resolver=lambda h, p: ["172.20.10.2"],
        tcp_verifier=lambda ip, p: ip == "172.20.10.2" and p == 2514,
    )
    assert sender_res["config_updated"] is True
    assert sender_res["sender_destination_ip"] == "172.20.10.2"


# ---------------------------------------------------------------------------
# 12. Handling network switches from Hotspot B to College Wi-Fi
# ---------------------------------------------------------------------------
def test_12_network_switch_hotspot_b_to_college_wifi(tmp_path):
    state_file = tmp_path / "net_state.json"
    svc = CentralNetworkStateService(state_file_path=state_file, receiver_port=2514)

    # Hotspot B
    svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "172.20.10.2"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    172.20.10.2:2514       172.20.10.5:51300      ESTABLISHED     3400\n"
        ),
    )

    # Switch to College Wi-Fi: Receiver=11.12.7.72, Sender=11.12.4.164
    state_college = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.4.164:37826      ESTABLISHED     3400\n"
        ),
    )
    assert state_college["receiver_ip_current"] == "11.12.7.72"
    assert state_college["sender_ip_current"] == "11.12.4.164"
    assert state_college["remote_peer_ip"] == "11.12.4.164"
    assert state_college["sender_destination_ip"] == "11.12.7.72"
    assert state_college["connection_status"] == "CONNECTED"


# ---------------------------------------------------------------------------
# 13. Keeping sender_ip, remote_peer_ip, receiver_ip, and sender_destination_ip separate
# ---------------------------------------------------------------------------
def test_13_keep_sender_peer_receiver_and_destination_ips_separate(tmp_path):
    svc = CentralNetworkStateService(state_file_path=tmp_path / "state.json", receiver_port=2514)
    state = svc.refresh_state(
        interfaces_provider=lambda: [{"interface": "Wi-Fi", "ip": "11.12.7.72"}],
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.4.164:7926       ESTABLISHED     3400\n"
        ),
    )
    assert "receiver_ip_current" in state
    assert "sender_ip_current" in state
    assert "remote_peer_ip" in state
    assert "sender_destination_ip" in state
    assert state["receiver_ip_current"] == "11.12.7.72"
    assert state["sender_destination_ip"] == "11.12.7.72"
    assert state["remote_peer_ip"] == "11.12.4.164"
    assert state["sender_ip_current"] == "11.12.4.164"
    assert state["remote_peer_ip"] != state["receiver_ip_current"]


# ---------------------------------------------------------------------------
# 14. Preventing receiver_ip from being displayed as sender_ip
# ---------------------------------------------------------------------------
def test_14_prevent_receiver_ip_from_being_labeled_as_sender_ip(tmp_path):
    # Even if a loopback/self connection from 11.12.7.72 -> 11.12.7.72:2514 exists in netstat,
    # inspect_tcp_port_connections must reject receiver_ip as a remote peer IP.
    tcp_info = inspect_tcp_port_connections(
        port=2514,
        receiver_ip="11.12.7.72",
        netstat_provider=lambda: (
            "  TCP    0.0.0.0:2514           0.0.0.0:0              LISTENING       3400\n"
            "  TCP    11.12.7.72:2514        11.12.7.72:59001       ESTABLISHED     3400\n"
        ),
    )
    assert tcp_info["remote_peer_ips"] == []
    assert get_endpoint_ip(observed_ip="11.12.7.72", receiver_ip="11.12.7.72") == "N/A"


# ---------------------------------------------------------------------------
# 15. Replacing NA, N/A, None, and empty network values with meaningful status messages
# ---------------------------------------------------------------------------
def test_15_replace_na_none_and_empty_with_meaningful_status_messages():
    for raw_bad in ("NA", "N/A", "None", None, "", "-", "UNKNOWN"):
        for role in (
            "source_ip",
            "sender_ip",
            "remote_peer_ip",
            "receiver_ip",
            "sender_hostname",
            "receiver_hostname",
            "mitre_technique",
            "command_line",
        ):
            formatted = format_network_display(raw_bad, field_role=role)
            assert formatted not in ("NA", "N/A", "None", "", "-"), f"Role {role} returned forbidden '{formatted}'"
            assert len(formatted) > 3

    # With fallback TCP peer IP, source_ip and sender_ip use the peer IP cleanly
    assert format_network_display("N/A", field_role="source_ip", fallback_peer_ip="11.12.4.164") == "11.12.4.164 (TCP 2514 Peer)"
    assert format_network_display("N/A", field_role="sender_ip", fallback_peer_ip="11.12.4.164") == "11.12.4.164"


# ---------------------------------------------------------------------------
# 16. Ensuring all nine dashboard sectors read from the central network state and render no N/A
# ---------------------------------------------------------------------------
def test_16_all_nine_dashboard_sectors_use_central_network_state_and_no_na():
    app_path = PROJECT_ROOT / "dashboard" / "app.py"
    app_text = app_path.read_text(encoding="utf-8")

    # Verify CentralNetworkState is invoked at top level
    assert "net_state = get_central_network_state(" in app_text

    # Verify all 6 sector tabs exist and none contain raw '"N/A"' display fallbacks
    for sector_num in range(1, 7):
        tab_marker = f"with tab{sector_num}:"
        assert tab_marker in app_text, f"Missing {tab_marker} in dashboard/app.py"
    assert "with tab7:" not in app_text
    assert "with tab8:" not in app_text
    assert "with tab9:" not in app_text
    assert "Agent Performance & IEEE Benchmark" not in app_text
    assert "SIEM Benchmarks & Attack Graph" not in app_text
    assert "Final System Evaluation" not in app_text

    # Extract content from `with tab1:` to the end of `dashboard/app.py`
    sectors_body = app_text.split("with tab1:", 1)[1]
    # Ensure no `st.metric(..., "N/A")` or `.get(..., "N/A")` display fallbacks remain in Sectors 1-8
    assert '.get("status", "N/A")' not in sectors_body
    assert '.get("inference_status", "N/A")' not in sectors_body
    assert '.get("inference_source", "N/A")' not in sectors_body
    assert '.get("rule_id", "N/A")' not in sectors_body
    assert '.get("mitre_technique", "N/A")' not in sectors_body

    # Also verify ReportingAgent (Sector 5) never outputs "N/A"
    reports = ReportingAgent().generate([
        {
            "incident_id": "INC-TEST-01",
            "incident_name": "Suspicious Process Activity",
            "severity": "High",
            "confidence": 92,
            "affected_host": "Harsha",
            "affected_user": "harsha_user",
            "alerts": [
                {
                    "alert_name": "Process Creation",
                    "event": {
                        "event_id": 4688,
                        "event_type": "Windows Process Creation",
                        "source_ip": "N/A",
                        "remote_peer_ip": "11.12.4.164",
                        "process_name": "N/A",
                        "command_line": "N/A",
                        "mitre_technique": "N/A",
                    },
                }
            ],
        }
    ])
    assert len(reports) == 1
    rep = reports[0]
    assert rep["source_ip"] not in ("N/A", "NA", "None", "")
    assert "N/A" not in rep["technical_analysis"]


# ---------------------------------------------------------------------------
# 17. Ensuring newly ingested real NXLog events appear in stream and raw inspector
# ---------------------------------------------------------------------------
def test_17_newly_ingested_nxlog_events_appear_in_stream_and_inspector(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    marker = "PHASE3_WINDOWS_EVENT_20261010_160833"
    raw_line = f"2026-10-10 16:08:33 HARSHA INFO 1000 {marker}\n"
    log_file.write_text(raw_line, encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    events = normalize_events_list = LogNormalizer().normalize(reader.read_events(incremental=True))
    assert len(events) == 1
    assert marker in events[0]["description"]
    assert marker in events[0]["raw_line"]
    assert events[0]["event_id"] == 1000


# ---------------------------------------------------------------------------
# 18. Ensuring failed parses do not advance the NXLog cursor past unprocessed records
# ---------------------------------------------------------------------------
def test_18_failed_parse_does_not_advance_cursor_past_unprocessed_records(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    line1 = "2026-10-10 16:00:01 Harsha INFO 4624 First valid event\n"
    line2 = "2026-10-10 16:00:02 Harsha INFO 1000 Second event temporarily fails\n"
    log_file.write_text(line1 + line2, encoding="utf-8", newline="\n")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    orig_parse = reader.parse_line

    def flaky_parse(line: str):
        if "Second event temporarily fails" in line:
            raise RuntimeError("Simulated parser error")
        return orig_parse(line)

    with patch.object(reader, "parse_line", side_effect=flaky_parse):
        batch1 = reader.read_events(incremental=True)

    assert len(batch1) == 1
    assert reader.load_cursor() == len(line1.encode("utf-8"))

    # Next read without error picks up the previously failed record
    batch2 = reader.read_events(incremental=True)
    assert len(batch2) == 1
    assert "Second event temporarily fails" in batch2[0]["description"]


# ---------------------------------------------------------------------------
# 19. Ensuring repeated dashboard reruns do not inflate counts
# ---------------------------------------------------------------------------
def test_19_repeated_dashboard_reruns_do_not_inflate_counts(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"
    content = (
        "2026-10-10 16:10:01 Harsha INFO 4688 A new process has been created. Creator Process Name: cmd.exe\n"
        "2026-10-10 16:10:02 Harsha WARNING 4625 An account failed to log on. Account Name: admin\n"
    )
    log_file.write_text(content, encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    normalizer = LogNormalizer()

    live_events = normalizer.normalize(reader.get_recent_events(max_events=300))
    existing_keys = {get_event_identity_key(e) for e in live_events}
    initial_count = len(live_events)
    assert initial_count == 2

    # Simulate 5 consecutive Streamlit reruns merging get_recent_events()
    for _ in range(5):
        tail_evts = normalizer.normalize(reader.get_recent_events(max_events=300))
        for evt in tail_evts:
            k = get_event_identity_key(evt)
            if k not in existing_keys:
                live_events.append(evt)
                existing_keys.add(k)

    assert len(live_events) == initial_count


# ---------------------------------------------------------------------------
# 20. Ensuring diagnostic test markers do not become fake security incidents
# ---------------------------------------------------------------------------
def test_20_diagnostic_markers_do_not_become_fake_security_incidents():
    raw_events = [
        {
            "timestamp": "2026-10-10 16:20:00",
            "hostname": "Harsha",
            "event_id": 4688,
            "description": "PHASE1_LIVE_VERIFY_20261010_140257 diagnostic probe",
            "source": "real_nxlog_windows",
        },
        {
            "timestamp": "2026-10-10 16:21:00",
            "hostname": "Harsha",
            "event_id": 4688,
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -EncodedCommand JABzAD0ATgBlAHcA",
            "description": "Suspicious encoded PowerShell execution",
            "source": "real_nxlog_windows",
        },
    ]
    norm = LogNormalizer().normalize(raw_events)
    alerts = DetectionAgent().detect(norm)
    incidents = CorrelationAgent().correlate(alerts)

    sec_incidents = [i for i in incidents if not i.get("is_diagnostic")]
    diag_incidents = [i for i in incidents if i.get("is_diagnostic")]

    assert len(sec_incidents) == 1
    assert len(diag_incidents) == 1
    assert "PHASE1_LIVE_VERIFY" in diag_incidents[0]["alerts"][0]["event"]["description"]


# ---------------------------------------------------------------------------
# 21. Regression: Receiver discovery succeeds when logical hostname ('Sujith')
#     differs from OS hostname ('LAPTOP-GEEF5A3A') or uses persisted state
# ---------------------------------------------------------------------------
def test_21_regression_discover_receiver_when_logical_hostname_differs_from_os_hostname(tmp_path):
    state_file = tmp_path / "network_state.json"
    state_file.write_text(
        json.dumps({
            "receiver_hostname": "Sujith",
            "receiver_os_hostname": "LAPTOP-GEEF5A3A",
            "receiver_ip_current": "11.12.7.72",
            "last_known_receiver_ip": "11.12.7.72",
            "receiver_port": 2514,
        }),
        encoding="utf-8",
    )

    # Case A: 'Sujith' fails DNS, but persisted state fallback '11.12.7.72' is verified on TCP 2514
    res_fallback = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        hostname_resolver=lambda h, p: [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: ip == "11.12.7.72" and p == 2514,
        state_file_path=state_file,
    )
    assert res_fallback["success"] is True
    assert res_fallback["receiver_ip"] == "11.12.7.72"
    assert res_fallback["receiver_port"] == 2514
    assert res_fallback["discovery_method"] == "last_known_ip_verified"
    assert any("hostname:Sujith->no_ipv4_records" in a for a in res_fallback["attempts"])
    assert any(d["method"] == "last_known_ip_verified" and d["status"] == "verified" for d in res_fallback["diagnostics"])


# ---------------------------------------------------------------------------
# 22. Regression: Discovery failure reports each method attempted and its reason
# ---------------------------------------------------------------------------
def test_22_regression_discovery_failure_reports_each_method_and_reason():
    res_fail = discover_receiver_endpoint(
        receiver_hostname="Sujith",
        port=2514,
        last_known_receiver_ip="10.99.99.99",
        manual_bootstrap_ip="10.88.88.88",
        hostname_resolver=lambda h, p: ["10.77.77.77"] if h == "Sujith" else [],
        udp_discoverer=lambda: None,
        tcp_verifier=lambda ip, p: False,
    )
    assert res_fail["success"] is False
    assert res_fail["receiver_ip"] is None
    assert res_fail["discovery_method"] == "none"

    methods_logged = [d["method"] for d in res_fail["diagnostics"]]
    assert "hostname_resolution" in methods_logged
    assert "mdns_resolution" in methods_logged
    assert "udp_broadcast_discovery" in methods_logged
    assert "last_known_ip_verified" in methods_logged
    assert "manual_bootstrap_verified" in methods_logged
    assert "Attempted:" in res_fail["error"]


# ---------------------------------------------------------------------------
# 23. Regression: Virtual adapter filtering in hostname resolution, /19 subnet
#     broadcast calculation, verify_tcp_port, and <Input> Host 0.0.0.0 exclusion
# ---------------------------------------------------------------------------
def test_23_regression_virtual_adapter_filtering_subnet_bcast_and_nxlog_input_host():
    from utils.network_discovery import (
        compute_subnet_broadcast,
        resolve_hostname_candidates,
        verify_tcp_port,
    )

    # /19 subnet mask (255.255.224.0) for 11.12.7.72 -> 11.12.31.255
    assert compute_subnet_broadcast("11.12.7.72", "255.255.224.0") == "11.12.31.255"
    assert compute_subnet_broadcast("11.12.4.164", "255.255.224.0") == "11.12.31.255"

    # Virtual adapter IPs (VMware 192.168.222.1 / 192.168.216.1) filtered out when Wi-Fi is present
    fake_addrinfo = [
        (2, 1, 6, "", ("192.168.222.1", 2514)),
        (2, 1, 6, "", ("192.168.216.1", 2514)),
        (2, 1, 6, "", ("11.12.7.72", 2514)),
    ]
    fake_ifaces = [
        {"interface": "VMware Network Adapter VMnet8", "ip": "192.168.222.1"},
        {"interface": "VMware Network Adapter VMnet1", "ip": "192.168.216.1"},
        {"interface": "Wi-Fi", "ip": "11.12.7.72"},
    ]
    with patch("socket.getaddrinfo", return_value=fake_addrinfo), \
         patch("utils.network_discovery.enumerate_windows_ipv4_interfaces", return_value=fake_ifaces), \
         patch("utils.network_discovery.probe_os_route_ip", return_value="11.12.7.72"):
        cands = resolve_hostname_candidates("LAPTOP-GEEF5A3A", 2514)
        assert cands == ["11.12.7.72"]

    # Receiver nxlog.conf with <Input> Host 0.0.0.0 must not return 0.0.0.0 as sender output Host
    receiver_conf = (
        "<Input receive_logs>\n    Module im_tcp\n    Host 0.0.0.0\n    Port 2514\n</Input>\n"
        "<Output save_logs>\n    Module om_file\n    File 'C:\\AdaptiveSentinel\\windows-events.log'\n</Output>\n"
    )
    host_val, _ = extract_nxlog_tcp_host_and_port(receiver_conf)
    assert host_val is None

    # verify_tcp_port rejects invalid/loopback IPs immediately
    assert verify_tcp_port("0.0.0.0", 2514) is False
    assert verify_tcp_port("127.0.0.1", 2514) is False


# ---------------------------------------------------------------------------
# 24. Regression: Receiver IP & interface cache expiry and dynamic IP change detection
# ---------------------------------------------------------------------------
def test_24_regression_receiver_ip_cache_expiry_and_ip_change_detection(monkeypatch):
    import config.settings as settings
    import utils.network_discovery as net_disc

    for env_key in ("RECEIVER_ADVERTISED_IP", "RECEIVER_IP", "SUJITH_IP"):
        monkeypatch.delenv(env_key, raising=False)

    settings.clear_receiver_ip_cache()

    call_count = {"ifaces": 0}
    current_net = {"ip": "11.12.7.72"}
    fake_clock = {"t": 1000.0}

    def fake_enumerate():
        call_count["ifaces"] += 1
        return [{"interface": "Wi-Fi", "ip": current_net["ip"], "subnet_mask": "255.255.224.0"}]

    monkeypatch.setattr(net_disc, "enumerate_windows_ipv4_interfaces", fake_enumerate)
    monkeypatch.setattr(net_disc, "probe_os_route_ip", lambda: current_net["ip"])
    monkeypatch.setattr(net_disc.time, "monotonic", lambda: fake_clock["t"])
    monkeypatch.setattr(settings.time, "monotonic", lambda: fake_clock["t"])

    # Within 6.0s TTL window: multiple calls reuse cached IP and do not re-spawn ipconfig
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert net_disc.detect_active_interface_and_ip() == ("Wi-Fi", "11.12.7.72")
    assert call_count["ifaces"] == 1
    assert settings.NXLOG_PORT == 2514

    # Network changes to a new hotspot IP, but before TTL expiry cached value is still active
    current_net["ip"] = "172.20.10.9"
    fake_clock["t"] = 1003.0  # +3.0s (< 6.0s TTL)
    assert settings.get_receiver_ip() == "11.12.7.72"
    assert call_count["ifaces"] == 1

    # After 6.0s TTL expires: new IP is detected immediately and stale IP is never returned as current
    fake_clock["t"] = 1007.0  # +7.0s (> 6.0s TTL)
    assert settings.get_receiver_ip() == "172.20.10.9"
    assert net_disc.detect_active_interface_and_ip() == ("Wi-Fi", "172.20.10.9")
    assert call_count["ifaces"] == 2

    settings.clear_receiver_ip_cache()


# ---------------------------------------------------------------------------
# 25. Regression: Receiver IP resolved once per normalization/parser batch
# ---------------------------------------------------------------------------
def test_25_regression_batch_receiver_ip_resolved_once_per_batch(tmp_path):
    import analysis.normalize as norm_mod
    import analysis.parser as parser_mod

    raw_batch = [
        {"event_id": 4624, "hostname": "Harsha", "description": f"Login event {i}"}
        for i in range(50)
    ]
    with patch.object(norm_mod, "get_receiver_ip", return_value="11.12.7.72") as mock_norm_ip:
        out = LogNormalizer().normalize(raw_batch)
        assert len(out) == 50
        assert mock_norm_ip.call_count == 1
        assert all(e["receiver_ip"] == "11.12.7.72" for e in out)

    log_file = tmp_path / "batch-events.log"
    cursor_file = tmp_path / "batch-cursor.json"
    lines = [
        f"2026-10-10 18:00:{i:02d} Harsha INFO 4624 Batch test event {i}\n"
        for i in range(40)
    ]
    log_file.write_text("".join(lines), encoding="utf-8")
    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)

    with patch.object(parser_mod, "get_receiver_ip", return_value="11.12.7.72") as mock_parse_ip:
        recent = reader.get_recent_events(max_events=15)
        assert len(recent) == 15
        assert mock_parse_ip.call_count == 1


# ---------------------------------------------------------------------------
# 26. Regression: get_recent_events() tail optimization, multiline events,
#     incomplete trailing records, diagnostic probes, offsets, and cursor safety
# ---------------------------------------------------------------------------
def test_26_regression_get_recent_events_tail_optimization_offsets_multiline_and_cursor(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "nxlog_cursor.json"
    cursor_file.write_text(json.dumps({"byte_offset": 128, "last_updated": "2026-10-10T00:00:00Z"}), encoding="utf-8")

    records = []
    # Record 0: Early diagnostic probe that must be preserved even when outside tail max_events
    records.append("2026-10-10 19:00:00 Harsha INFO 1000 PHASE3_WINDOWS_EVENT_DIAG_EARLY_001\n")
    # Records 1..20: 20 older routine events that should NOT be parsed when max_events=4
    for idx in range(1, 21):
        records.append(f"2026-10-10 19:01:{idx:02d} Harsha INFO 4624 Routine historical event {idx}\n")
    # Records 21..24: 4 recent tail events across multiple endpoints including multiline Security event
    records.append("2026-10-10 19:05:01 Harsha INFO 4688 Process created cmd.exe\n")
    records.append("2026-10-10 19:05:02 Analyst-Laptop-2 WARNING 4625 Failed logon for user bob Source Network Address: 11.12.4.200\n")
    records.append(
        "2026-10-10 19:05:03 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on.\n"
        "\tSubject:\n"
        "\t\tSecurity ID:\t\tS-1-5-18\n"
        "\t\tAccount Name:\t\tharsha_admin\n"
        "\t\t{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}\n"
        "\tNetwork Information:\n"
        "\t\tSource Network Address:\t11.12.4.164\n"
    )
    records.append("2026-10-10 19:05:04 Sujith-SecOps INFO 4672 Special privileges assigned to new logon\n")
    # Incomplete trailing multiline block at EOF (must not be parsed prematurely)
    incomplete_tail = (
        "2026-10-10 19:05:05 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on.\n"
        "\tSubject:\n"
        "\t\tSecurity ID:\t\tS-1-5-18\n"
    )

    full_text = "".join(records) + incomplete_tail
    log_file.write_bytes(full_text.encode("utf-8"))

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    orig_parse_line = reader.parse_line
    parse_calls = []

    def spy_parse_line(line: str):
        parse_calls.append(line)
        return orig_parse_line(line)

    with patch.object(reader, "parse_line", side_effect=spy_parse_line):
        recent = reader.get_recent_events(max_events=4)

    # 1. Production cursor file was untouched
    assert reader.load_cursor() == 128

    # 2. Only the 4 tail blocks + 1 early diagnostic block were parsed (5 total out of 25 complete blocks)
    assert len(parse_calls) == 5

    # 3. Returned list has 1 early diagnostic probe + 4 valid recent tail events = 5 events
    assert len(recent) == 5
    assert recent[0]["is_diagnostic"] is True
    assert "PHASE3_WINDOWS_EVENT_DIAG_EARLY_001" in recent[0]["description"]
    assert recent[0]["record_offset"] == 0

    # 4. All 4 recent tail events are present in chronological order with exact byte offsets & endpoint identity
    tail_four = recent[1:]
    assert [e["event_id"] for e in tail_four] == [4688, 4625, 4624, 4672]
    assert [e["hostname"] for e in tail_four] == ["Harsha", "Analyst-Laptop-2", "Harsha", "Sujith-SecOps"]
    assert tail_four[1]["source_ip"] == "11.12.4.200"
    assert tail_four[2]["source_ip"] == "11.12.4.164"
    assert "{2593F8B9-4EAF-457C-B68A-50F6B8EA6B54}" in tail_four[2]["raw_line"]

    # Verify byte offsets match exact positions in file
    raw_bytes = full_text.encode("utf-8")
    for evt in recent:
        off = evt["record_offset"]
        first_line_bytes = evt["raw_line"].splitlines()[0].encode("utf-8")
        assert raw_bytes[off:off + len(first_line_bytes)] == first_line_bytes


# ---------------------------------------------------------------------------
# 27. Regression: Live NXLog event (diagnostic marker & genuine security event)
#     reaches enrichment, detection, correlation, threat intel, and reporting
# ---------------------------------------------------------------------------
def test_27_regression_live_nxlog_event_reaches_detection_and_correlation_pipeline(tmp_path):
    from analysis.enrich import enrich_events
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.explainability_agent import ExplainabilityAgent
    from agents.response_planning_agent import ResponsePlanningAgent

    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        # Exact live test marker sent by Harsha
        "2026-10-11 00:30:11 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_TEST_20261011_003011\n",
        # Genuine live Windows Credential Manager & Group Discovery events on Harsha
        "2026-10-11 00:31:00 Harsha AUDIT_SUCCESS 5379 Credential Manager credentials were read. Account Name: Harsha\n",
        "2026-10-11 00:31:02 Harsha AUDIT_SUCCESS 4798 A user's local group membership was enumerated. Account Name: Harsha\n",
    ]
    log_file.write_text("".join(lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    raw_events = reader.read_events(incremental=True)
    assert len(raw_events) == 3

    normalized = LogNormalizer().normalize(raw_events)
    enriched = enrich_events(normalized)
    alerts = DetectionAgent().detect(enriched)
    assert len(alerts) == 3

    incidents = CorrelationAgent().correlate(alerts)
    incidents = ThreatIntelligenceAgent().analyze(incidents)

    diag_inc = [i for i in incidents if i.get("is_diagnostic")]
    sec_inc = [i for i in incidents if not i.get("is_diagnostic")]

    assert len(diag_inc) == 1
    assert "ADAPTIVESENTINEL_LIVE_TEST_20261011_003011" in diag_inc[0]["alerts"][0]["event"]["description"]
    assert diag_inc[0]["is_real_telemetry"] is True
    assert diag_inc[0]["is_simulated"] is False

    assert len(sec_inc) == 1
    assert sec_inc[0]["affected_host"] == "Harsha"
    assert sec_inc[0]["incident_name"] == "Account Discovery & Credential Manager Read Activity"
    assert sec_inc[0]["severity"] == "Low"
    assert sec_inc[0]["is_real_telemetry"] is True
    assert sec_inc[0]["is_simulated"] is False
    assert sec_inc[0]["telemetry_sources"] == ["real_nxlog_windows"]

    explanations = ExplainabilityAgent().explain(sec_inc)
    plans = ResponsePlanningAgent().plan(sec_inc)
    reports = ReportingAgent().generate(sec_inc)
    assert len(explanations) == 1
    assert len(plans) == 1
    assert len(reports) == 1


# ---------------------------------------------------------------------------
# 28. Regression: Benign informational Windows events (Event 1 low-power wake,
#     Event 1001 Fault bucket, routine Event 1000/4624/10) are not misclassified
# ---------------------------------------------------------------------------
def test_28_regression_informational_windows_events_not_misclassified_as_malicious(tmp_path):
    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    benign_lines = [
        # Windows Power-Troubleshooter Event ID 1 (wake from low power state, NOT Sysmon PowerShell)
        "2026-10-10 23:25:06 Harsha INFO 1 The system has returned from a low power state.\n",
        # Windows Error Reporting Event ID 1001 (Fault bucket, NOT SSH failed login)
        "2026-10-10 23:25:10 Harsha INFO 1001 Fault bucket , type 0 Event Name: BlueScreen Response: Not available\n",
        # Routine application Event ID 1000 without diagnostic marker
        "2026-10-10 23:25:15 Harsha INFO 1000 Application background service heartbeat completed normally.\n",
        # Routine successful logon Event ID 4624
        "2026-10-10 23:25:20 Harsha AUDIT_SUCCESS 4624 An account was successfully logged on. Account Name: Harsha\n",
        # Generic Event ID 10 without mimikatz/lsass/sysmon
        "2026-10-10 23:25:25 Harsha INFO 10 Device configuration state check completed.\n",
    ]
    log_file.write_text("".join(benign_lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    norm_events = LogNormalizer().normalize(reader.read_events(incremental=True))
    assert len(norm_events) == 5

    alerts = DetectionAgent().detect(norm_events)
    assert alerts == [], f"Expected 0 alerts for benign informational events, got: {alerts}"

    incidents = CorrelationAgent().correlate(alerts)
    assert incidents == []


# ---------------------------------------------------------------------------
# 29. Regression: Simulated evidence (api_simulation / synthetic) is explicitly
#     tagged and never misrepresented or merged with real_nxlog_windows telemetry
# ---------------------------------------------------------------------------
def test_29_regression_simulated_evidence_distinguished_and_never_merged_with_real_telemetry():
    mixed_events = [
        # Simulated ransomware event from api_simulation
        {
            "timestamp": "2026-10-11 00:10:00",
            "hostname": "FINANCE-WORKSTATION",
            "user": "john.doe",
            "event_id": 1,
            "process_name": "powershell.exe",
            "command_line": "powershell.exe -ExecutionPolicy Bypass -NoP -Enc JABzAD0ATgBlAHcA",
            "description": "Suspicious PowerShell execution",
            "source": "api_simulation",
        },
        # Simulated event on Harsha (must NEVER merge with real_nxlog_windows on Harsha)
        {
            "timestamp": "2026-10-11 00:11:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 4688,
            "process_name": "vssadmin.exe",
            "command_line": "vssadmin.exe delete shadows /all /quiet",
            "description": "Simulated shadow copy deletion",
            "source": "api_simulation",
        },
        # Real NXLog event on Harsha
        {
            "timestamp": "2026-10-11 00:12:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 5379,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "source": "real_nxlog_windows",
        },
    ]

    norm = LogNormalizer().normalize(mixed_events)
    alerts = DetectionAgent().detect(norm)
    assert len(alerts) == 3

    incidents = CorrelationAgent().correlate(alerts)
    assert len(incidents) == 3

    real_incidents = [inc for inc in incidents if inc["is_real_telemetry"]]
    sim_incidents = [inc for inc in incidents if inc["is_simulated"]]

    assert len(real_incidents) == 1
    assert len(sim_incidents) == 2

    # Verify real incident contains ONLY real_nxlog_windows telemetry
    real_inc = real_incidents[0]
    assert real_inc["affected_host"] == "Harsha"
    assert real_inc["telemetry_sources"] == ["real_nxlog_windows"]
    assert real_inc["primary_source"] == "real_nxlog_windows"
    assert real_inc["is_simulated"] is False

    # Verify simulated incidents are explicitly marked is_real_telemetry=False, is_simulated=True
    for s_inc in sim_incidents:
        assert s_inc["is_real_telemetry"] is False
        assert s_inc["is_simulated"] is True
        assert s_inc["telemetry_sources"] == ["api_simulation"]
        assert s_inc["primary_source"] == "api_simulation"


# ---------------------------------------------------------------------------
# 30. Safe Replay / Scan Test Events is idempotent and preserves cursor
# ---------------------------------------------------------------------------
def test_30_safe_replay_is_idempotent_and_preserves_production_cursor(tmp_path):
    from analysis.enrich import enrich_events

    log_file = tmp_path / "windows-events.log"
    cursor_file = tmp_path / "cursor.json"

    lines = [
        "2026-10-11 01:00:01 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_LIVE_TEST_20261011_010001\n",
        "2026-10-11 01:00:05 Harsha AUDIT_FAILURE 4625 An account failed to log on. Account Name: demo_harsha\n",
        "2026-10-11 01:00:06 Harsha AUDIT_FAILURE 4625 An account failed to log on. Account Name: demo_harsha\n",
    ]
    log_file.write_text("".join(lines), encoding="utf-8")

    reader = NXLogReader(log_file=log_file, cursor_file=cursor_file)
    reader.save_cursor(95)
    assert reader.load_cursor() == 95

    # First replay
    replay_1 = enrich_events(LogNormalizer().normalize(reader.replay_events(scan_bytes=524288)))
    assert reader.load_cursor() == 95  # Cursor untouched!

    # Second replay merged via deduplication key (simulating clicking Safe Replay twice)
    replay_2 = enrich_events(LogNormalizer().normalize(reader.replay_events(scan_bytes=524288)))
    assert reader.load_cursor() == 95

    merged = list(replay_1)
    seen_keys = {
        (e.get("record_offset"), e.get("timestamp"), e.get("hostname"), e.get("event_id"), str(e.get("description", ""))[:160])
        for e in merged
    }
    for e in replay_2:
        k = (e.get("record_offset"), e.get("timestamp"), e.get("hostname"), e.get("event_id"), str(e.get("description", ""))[:160])
        if k not in seen_keys:
            merged.append(e)
            seen_keys.add(k)

    # No duplicate events or inflated incidents after repeated Safe Replay
    assert len(merged) == 3
    alerts = DetectionAgent().detect(merged)
    incidents = CorrelationAgent().correlate(alerts)
    sec_incidents = [i for i in incidents if not i.get("is_diagnostic")]
    diag_incidents = [i for i in incidents if i.get("is_diagnostic")]
    assert len(sec_incidents) == 1
    assert len(diag_incidents) == 1
    assert sec_incidents[0]["incident_name"] == "Automated Brute Force & Password Spraying Attack"


# ---------------------------------------------------------------------------
# 31. APT Scenario & Synthetic Attack generators preserve log_channel & correlate
#     multi-stage chains accurately (including SYSTEM LSASS on same host)
# ---------------------------------------------------------------------------
def test_31_apt_and_synthetic_generators_preserve_log_channel_and_correlate_chains(tmp_path):
    import utils.generate_apt_logs as apt_mod
    import utils.generate_logs as syn_mod
    import config.settings as settings_mod
    from analysis.enrich import enrich_events

    apt_out = tmp_path / "apt_logs.json"

    with patch.object(settings_mod, "LOG_FILE_PATH", apt_out), \
         patch.object(apt_mod, "RAW_LOGS_DIR", tmp_path):
        apt_mod.generate_apt_attack_logs()

    with patch.object(syn_mod, "RAW_LOGS_DIR", tmp_path), \
         patch("utils.generate_logs.random.sample", side_effect=lambda pop, k: list(pop)):
        syn_path = syn_mod.generate_synthetic_attack_logs(num_background_logs=20)

    apt_raw = json.loads(apt_out.read_text(encoding="utf-8"))
    syn_raw = json.loads(syn_path.read_text(encoding="utf-8"))

    # Verify log_channel is preserved for Suricata IDS and Linux Auth filters
    apt_norm = enrich_events(LogNormalizer().normalize(apt_raw))
    channels = {e.get("log_channel") for e in apt_norm}
    assert "Suricata IDS" in channels
    assert "Linux Auth" in channels
    assert "Sysmon" in channels
    assert "Windows Security" in channels

    apt_incidents = CorrelationAgent().correlate(DetectionAgent().detect(apt_norm))
    apt_inc_names = {i["incident_name"] for i in apt_incidents}
    assert "Unauthorized Backdoor Account Creation & Persistence" in apt_inc_names
    assert "Ransomware Pre-Encryption Staging Activity" in apt_inc_names
    assert "Automated Brute Force & Password Spraying Attack" in apt_inc_names

    # Verify correlation on synthetic dataset associates SYSTEM LSASS dump with DC-PRIMARY::admin
    syn_norm = enrich_events(LogNormalizer().normalize(syn_raw))
    syn_alerts = DetectionAgent().detect(syn_norm)
    syn_incidents = CorrelationAgent().correlate(syn_alerts)

    syn_inc_names = {i["incident_name"] for i in syn_incidents}
    assert "Ransomware Pre-Encryption Staging Activity" in syn_inc_names
    assert "Automated Brute Force & Credential Dumping Attack Chain" in syn_inc_names
    assert "Host Defense Evasion & Security Log Tampering" in syn_inc_names
    assert "Network Lateral Movement via Remote WMI Execution" in syn_inc_names


# ---------------------------------------------------------------------------
# 32. Machine account exclusion (HARSHA$) and case-insensitive hostname grouping
# ---------------------------------------------------------------------------
def test_32_machine_account_excluded_and_hostname_case_canonicalized():
    events = [
        # Machine account HARSHA$ in Event 4798 must NOT trigger a user account discovery alert
        {
            "timestamp": "2026-10-10 23:25:07",
            "hostname": "Harsha",
            "user": "HARSHA$",
            "event_id": 4798,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "source": "real_nxlog_windows",
        },
        # Diagnostic event with mixed case "Harsha"
        {
            "timestamp": "2026-10-10 23:26:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 1000,
            "process_name": "powershell.exe",
            "command_line": "Write-EventLog",
            "description": "PHASE1_DIAGNOSTIC_OK",
            "source": "real_nxlog_windows",
            "is_diagnostic": True,
        },
        # Diagnostic event with uppercase "HARSHA"
        {
            "timestamp": "2026-10-10 23:27:00",
            "hostname": "HARSHA",
            "user": "Harsha",
            "event_id": 1000,
            "process_name": "powershell.exe",
            "command_line": "Write-EventLog",
            "description": "ADAPTIVESENTINEL_LIVE_TEST_20261011",
            "source": "real_nxlog_windows",
            "is_diagnostic": True,
        },
    ]

    norm = LogNormalizer().normalize(events)
    alerts = DetectionAgent().detect(norm)
    # Only the 2 diagnostic events should alert; HARSHA$ Event 4798 is ignored
    assert len(alerts) == 2

    incidents = CorrelationAgent().correlate(alerts)
    # Both "Harsha" and "HARSHA" diagnostic probes canonicalize into 1 diagnostic group on "Harsha"
    assert len(incidents) == 1
    assert incidents[0]["is_diagnostic"] is True
    assert incidents[0]["affected_host"] == "Harsha"
    assert incidents[0]["alert_count"] == 2


# ---------------------------------------------------------------------------
# 33. Exact incident count consistency (Resolves 12 vs 5 real + 4 simulated)
# ---------------------------------------------------------------------------
def test_33_incident_count_consistency_resolves_12_vs_5_real_plus_4_simulated():
    from main import main as run_soc_pipeline
    from analysis.enrich import enrich_events
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    # 1. Run file-backed pipeline (simulated incidents from windows_logs.json)
    res = run_soc_pipeline(include_nxlog=False)
    sim_incidents = [i for i in res["incidents"] if not i.get("is_diagnostic")]

    # 2. Run live NXLog replay pipeline
    reader = NXLogReader()
    nx_raw = reader.get_recent_events(max_events=250)
    nx_norm = enrich_events(LogNormalizer().normalize(nx_raw))
    nx_alerts = DetectionAgent().detect(nx_norm)
    nx_all_inc = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(nx_alerts))

    nx_sec_incidents = [i for i in nx_all_inc if not i.get("is_diagnostic")]
    nx_diag_incidents = [i for i in nx_all_inc if i.get("is_diagnostic")]

    # Combine strictly genuine security incidents (excluding diagnostic probes)
    display_incidents = list(sim_incidents) + [i for i in nx_sec_incidents if i not in sim_incidents]

    real_count = sum(1 for i in display_incidents if i.get("is_real_telemetry"))
    sim_count = sum(1 for i in display_incidents if i.get("is_simulated"))
    crit_count = sum(1 for i in display_incidents if i.get("severity") == "Critical")
    high_count = sum(1 for i in display_incidents if i.get("severity") == "High")
    med_count = sum(1 for i in display_incidents if i.get("severity") == "Medium")
    low_count = sum(1 for i in display_incidents if i.get("severity") == "Low")

    # Every displayed count has one clear definition and adds up 100% consistently:
    assert len(display_incidents) == real_count + sim_count
    assert len(display_incidents) == crit_count + high_count + med_count + low_count
    assert all(not i.get("is_diagnostic") for i in display_incidents)
    assert all(i.get("is_diagnostic") for i in nx_diag_incidents)


# ---------------------------------------------------------------------------
# 34. Unified pipeline consistency across Enrichment, Graph, Explainability,
#     Response Planning, Reporting, and AI Chatbot Grounding
# ---------------------------------------------------------------------------
def test_34_unified_pipeline_consistency_across_all_agents_and_graph():
    from analysis.enrich import enrich_events
    from analysis.graph_visualizer import AttackGraphBuilder
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.explainability_agent import ExplainabilityAgent
    from agents.response_planning_agent import ResponsePlanningAgent
    from llm.llm_client import LLMClient

    raw_events = [
        {
            "timestamp": "2026-10-11 01:15:00",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 5379,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "source": "real_nxlog_windows",
        },
        {
            "timestamp": "2026-10-11 01:15:05",
            "hostname": "Harsha",
            "user": "Harsha",
            "event_id": 4798,
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "source": "real_nxlog_windows",
        },
    ]

    norm = enrich_events(LogNormalizer().normalize(raw_events))
    alerts = DetectionAgent().detect(norm)
    assert all(a.get("rule_id") not in (None, "", "N/A") for a in alerts)
    assert all(a["event"].get("mitre_tactic") in ("Credential Access", "Discovery") for a in alerts)

    incidents = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(alerts))
    assert len(incidents) == 1
    inc = incidents[0]
    assert set(inc["mitre_techniques"]) == {"T1087.001", "T1555.004"}

    explanations = ExplainabilityAgent().explain(incidents)
    assert explanations[0]["incident_id"] == inc["incident_id"]
    assert "5379" in explanations[0]["reason"] or "Credential" in explanations[0]["reason"]

    plans = ResponsePlanningAgent().plan(incidents)
    assert plans[0]["incident_id"] == inc["incident_id"]
    assert len(plans[0]["containment_actions"]) >= 2

    builder = AttackGraphBuilder()
    builder.build_graph(incidents=incidents, logs=norm)
    stats = builder.get_graph_stats()
    assert stats["mitre_techniques_count"] == 2
    # Ensure no bogus N/A nodes were created
    node_labels = {d.get("label") for _, d in builder.graph.nodes(data=True)}
    assert "N/A" not in node_labels

    # Verify chatbot grounds response in active incidents
    llm = LLMClient()
    reply = llm.query_chatbot(
        "What are the critical threats detected right now?",
        {"logs": norm, "alerts": alerts, "incidents": incidents},
    )
    assert inc["incident_name"] in reply
    assert "Harsha" in reply


# ---------------------------------------------------------------------------
# 35. Regression: LogEnricher MITRE tactic fallback & full 9-sector AppTest
# ---------------------------------------------------------------------------
def test_35_regression_log_enricher_tactic_fallback_and_all_nine_sectors_render():
    from streamlit.testing.v1 import AppTest
    from analysis.enrich import LogEnricher

    # 1. Explicitly test LogEnricher.TACTIC_MAP lookup
    assert LogEnricher.TACTIC_MAP.get("T1087.001", "Execution") == "Discovery"
    assert LogEnricher.TACTIC_MAP.get("T1555.004", "Execution") == "Credential Access"
    assert LogEnricher.TACTIC_MAP.get("T9999.999", "Execution") == "Execution"

    # 2. Run Streamlit AppTest and also force the Sector 3 fallback path (mitre_tactic="Unknown Tactic")
    at = AppTest.from_file("dashboard/app.py", default_timeout=30).run()
    assert not at.exception, f"Unexpected exception during initial AppTest run: {at.exception}"
    assert len(at.error) == 0, f"Unexpected st.error elements: {at.error}"
    assert len(at.tabs) == 6

    # Verify all 6 sector subheaders rendered inside their respective tabs
    expected_sector_titles = [
        "Sector 1:",
        "Sector 2:",
        "Sector 3:",
        "Sector 4:",
        "Sector 5:",
        "Sector 6:",
    ]
    for idx, expected_prefix in enumerate(expected_sector_titles):
        tab_subheaders = [sh.value for sh in at.tabs[idx].subheader]
        assert any(expected_prefix in s for s in tab_subheaders), (
            f"Tab {idx + 1} did not render subheader '{expected_prefix}': {tab_subheaders}"
        )

    # 3. Explicitly force Sector 3 fallback branch (mitre_tactic="Unknown Tactic" / None) and re-run
    nx_inc = at.session_state["nxlog_incidents"]
    for inc in nx_inc:
        for alt in inc.get("alerts", []):
            if "event" in alt:
                alt["event"]["mitre_tactic"] = "Unknown Tactic"
    at.session_state["nxlog_incidents"] = nx_inc
    at.run()
    assert not at.exception, f"Sector 3 fallback branch raised exception: {at.exception}"
    assert len(at.error) == 0


# ---------------------------------------------------------------------------
# 36. Sector 5: Reports generated, stored, matched by incident_id, and rendered
# ---------------------------------------------------------------------------
def test_36_sector5_reports_generated_stored_filtered_and_rendered_with_pdf_buttons():
    from streamlit.testing.v1 import AppTest
    from agents.reporting_agent import ReportingAgent

    # 1. Unit-verify ReportingAgent preserves incident_id, report_id, and provenance fields
    sample_inc = {
        "incident_id": "INC-900100",
        "incident_name": "Credential Access & Account Enumeration Activity",
        "severity": "HIGH",
        "affected_host": "Harsha",
        "affected_user": "Harsha",
        "source_ips": ["10.181.201.91"],
        "mitre_techniques": ["T1087.001", "T1555.004"],
        "telemetry_sources": ["real_nxlog_windows"],
        "primary_source": "real_nxlog_windows",
        "is_real_telemetry": True,
        "is_simulated": False,
        "provenance_label": "REAL TELEMETRY",
        "alerts": [
            {
                "rule_name": "Windows Credential Manager Read / Vault Access",
                "severity": "MEDIUM",
                "mitre_technique": "T1555.004",
                "event": {
                    "timestamp": "2026-10-11 01:00:00",
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "event_id": 5379,
                    "process_name": "N/A",
                    "command_line": "N/A",
                    "description": "Credential Manager credentials were read.",
                },
            }
        ],
    }
    generated = ReportingAgent().generate([sample_inc])
    assert len(generated) == 1
    rep = generated[0]
    assert rep["incident_id"] == "INC-900100"
    assert rep["report_id"] == "REP-INC-900100"
    assert rep["is_real_telemetry"] is True
    assert rep["is_simulated"] is False
    assert rep["primary_source"] == "real_nxlog_windows"
    assert rep["mitre_technique"] == "T1087.001, T1555.004"
    assert set(rep["mitre_techniques"]) == {"T1087.001", "T1555.004"}

    # 2. End-to-end AppTest verification of Sector 5 (tab5 = at.tabs[4])
    at = AppTest.from_file("dashboard/app.py", default_timeout=30).run()
    assert not at.exception, f"Unexpected exception during AppTest: {at.exception}"

    stage_counts = at.session_state["sector5_stage_counts"]
    assert stage_counts["incidents_available"] > 0
    assert stage_counts["reports_generated"] == stage_counts["incidents_available"]
    assert stage_counts["reports_stored"] == stage_counts["incidents_available"]
    assert stage_counts["reports_after_filter"] == stage_counts["display_incidents"]
    assert stage_counts["reports_after_filter"] > 0
    assert stage_counts["real_reports_rendered"] > 0
    assert stage_counts["simulated_reports_rendered"] > 0

    tab5 = at.tabs[4]
    exp_labels = [e.label for e in tab5.expander]
    assert len(exp_labels) == stage_counts["reports_after_filter"]
    assert any("📡 REAL TELEMETRY" in lbl for lbl in exp_labels)
    assert any("🧪 SIMULATED SCENARIO" in lbl for lbl in exp_labels)

    # Verify PDF download buttons are rendered inside Sector 5
    tab5_markdown = "\n".join(m.value for m in tab5.markdown)
    assert "SOC INCIDENT REPORT:" in tab5_markdown
    assert "Executive Summary" in tab5_markdown
    assert "Technical Analysis & Command Trail" in tab5_markdown
    assert "Strategic Remediation Plan" in tab5_markdown


# ---------------------------------------------------------------------------
# 37. Repeated Event ID 4798 alert counts & genuine repeated vs duplicate ingestion
# ---------------------------------------------------------------------------
def test_37_repeated_event_4798_alert_counts_and_genuine_vs_duplicate_ingestion():
    from analysis.deduplicate import deduplicate_events

    # 1. Generate 52 genuine repeated Windows Event ID 4798 records at distinct byte offsets
    #    (matching Harsha's svchost.exe local group enumeration pattern)
    genuine_52_events = []
    for i in range(52):
        ts_sec = (i // 2) % 60
        genuine_52_events.append({
            "timestamp": f"2026-10-11 02:18:{ts_sec:02d}",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Administrator",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.4.164",
            "process_name": "C:\\Windows\\System32\\svchost.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 37073613 + (i * 2126),
        })

    norm_52 = LogNormalizer().normalize(genuine_52_events)
    dedup_52 = deduplicate_events(norm_52)
    assert len(dedup_52) == 52, "All 52 distinct byte-offset Event 4798 records must be preserved"

    alerts_52 = DetectionAgent().detect(dedup_52)
    assert len(alerts_52) == 52
    inc_52 = CorrelationAgent().correlate(alerts_52)
    assert len(inc_52) == 1
    assert inc_52[0]["incident_name"] == "Local Account Group Discovery Campaign (Administrator)"
    assert inc_52[0]["alert_count"] == 52
    assert len(inc_52[0]["alerts"]) == 52

    # 2. Duplicate ingestion of the exact same 52 records (e.g., replay / refresh overlap)
    #    must be deduplicated and keep alert_count at 52 (never 104)
    duplicated_104 = norm_52 + [dict(e) for e in norm_52]
    dedup_from_104 = deduplicate_events(duplicated_104)
    assert len(dedup_from_104) == 52

    # Even if un-deduplicated alerts are passed directly into CorrelationAgent.correlate,
    # CorrelationAgent's per-group event identity guard prevents double-counting
    duplicated_alerts = alerts_52 + [dict(a) for a in alerts_52]
    inc_after_dup = CorrelationAgent().correlate(duplicated_alerts)
    assert len(inc_after_dup) == 1
    assert inc_after_dup[0]["alert_count"] == 52

    # 3. Genuine new repeated events at new byte offsets increase count from 52 to 55
    three_new_events = [
        {
            "timestamp": f"2026-10-11 02:45:0{j}",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Administrator",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.4.164",
            "process_name": "C:\\Windows\\System32\\svchost.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 37900000 + (j * 2126),
        }
        for j in range(3)
    ]
    combined_55 = deduplicate_events(norm_52 + LogNormalizer().normalize(three_new_events))
    assert len(combined_55) == 55
    inc_55 = CorrelationAgent().correlate(DetectionAgent().detect(combined_55))
    assert inc_55[0]["alert_count"] == 55


# ---------------------------------------------------------------------------
# 38. IP Threat Classification, Standalone vs Correlated 4798 Severity & Provenance
# ---------------------------------------------------------------------------
def test_38_ip_threat_classification_and_standalone_vs_correlated_4798_severity():
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent

    ti = ThreatIntelligenceAgent()

    # 1. Missing/local IP ('N/A') and Loopback ('127.0.0.1')
    na_res = ti.classify_ip("N/A")
    assert na_res["status"] == "Local Endpoint Telemetry (No External IP)"
    assert na_res["is_malicious"] is False
    assert "External Suspicious IP" not in na_res["status"]

    loop_res = ti.classify_ip("127.0.0.1")
    assert loop_res["is_malicious"] is False
    assert loop_res["risk_score"] == 0

    # 2. Private RFC 1918 IPs (10/8, 172.16/12, 192.168/16) are never labelled external malicious
    for priv_ip in ("10.0.4.15", "10.181.201.91", "172.16.5.20", "172.31.255.1", "192.168.1.50"):
        res = ti.classify_ip(priv_ip)
        assert res["is_malicious"] is False, f"Private IP {priv_ip} must not be marked malicious"
        assert "External Suspicious IP" not in res["status"]
        assert res["risk_score"] <= 15

    # 3. Sender peer IP 11.12.4.164 is never labelled malicious solely because it is the sender
    peer_res = ti.classify_ip("11.12.4.164", known_peer_ips={"11.12.4.164"}, receiver_ip="11.12.7.72")
    assert peer_res["status"] == "Authorized Telemetry Sender / Local Network Peer"
    assert peer_res["is_malicious"] is False
    assert peer_res["risk_score"] <= 15
    assert "External Suspicious IP" not in peer_res["status"]

    # Even without known_peer_ips, 11.12.4.164 (unmatched in IOC DB) is Unknown Reputation, never malicious
    unmatched_11 = ti.classify_ip("11.12.4.164", known_peer_ips=set(), receiver_ip="127.0.0.1")
    assert unmatched_11["status"] == "External IP (Unknown Reputation)"
    assert unmatched_11["reputation"] == "Unknown (No Threat Intel Match)"
    assert unmatched_11["is_malicious"] is False

    # 4. Public IPs with unknown reputation (including 172.217.x.x outside RFC1918 172.16/12)
    for pub_ip in ("8.8.8.8", "93.184.216.34", "172.217.16.1"):
        pub_res = ti.classify_ip(pub_ip, known_peer_ips=set(), receiver_ip="127.0.0.1")
        assert pub_res["status"] == "External IP (Unknown Reputation)"
        assert pub_res["reputation"] == "Unknown (No Threat Intel Match)"
        assert pub_res["is_malicious"] is False

    # 5. Confirmed malicious-IP matches using actual SQLite Threat Intel KB (sentinel_kb.db)
    tor_res = ti.classify_ip("185.220.101.5")
    assert tor_res["is_malicious"] is True
    assert tor_res["status"] == "Known Tor Exit Node / Malicious"
    assert tor_res["reputation"] == "Untrusted"
    assert tor_res["risk_score"] == 95

    scanner_res = ti.classify_ip("45.33.32.156")
    assert scanner_res["is_malicious"] is True
    assert scanner_res["status"] == "Active Scanner / Exploitation"
    assert scanner_res["risk_score"] == 88

    # 6. Severity of standalone Event ID 4798 vs CLI recon vs correlated multi-event attack chain
    # (a) Routine OS svchost.exe standalone Event 4798 (even repeated) -> Low severity
    svchost_events = [
        {
            "timestamp": f"2026-10-11 02:18:2{k}",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Administrator",
            "source_ip": "N/A",
            "process_name": "C:\\Windows\\System32\\svchost.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 1000 + k * 500,
        }
        for k in range(5)
    ]
    svchost_alerts = DetectionAgent().detect(LogNormalizer().normalize(svchost_events))
    assert all(a["severity"] == "Low" for a in svchost_alerts)
    svchost_inc = ti.analyze(CorrelationAgent().correlate(svchost_alerts))
    assert len(svchost_inc) == 1
    assert svchost_inc[0]["severity"] == "Low"
    assert svchost_inc[0]["has_confirmed_malicious_ioc"] is False

    # (b) Explicit CLI recon binary (net.exe) standalone Event 4798 -> Medium severity (not High)
    net_enum_events = [
        {
            "timestamp": "2026-10-11 02:25:00",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Administrator",
            "source_ip": "N/A",
            "process_name": "C:\\Windows\\System32\\net.exe",
            "command_line": "net localgroup Administrators",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 9000,
        }
    ]
    net_alerts = DetectionAgent().detect(LogNormalizer().normalize(net_enum_events))
    assert net_alerts[0]["severity"] == "Medium"
    net_inc = CorrelationAgent().correlate(net_alerts)
    assert net_inc[0]["severity"] == "Medium"

    # (c) Correlated Event 4798 + Event 5379:
    #     - Routine svchost.exe / N/A -> Low severity neutral name ("Account Discovery & Credential Manager Read Activity")
    #     - Suspicious whoami.exe + vaultcmd.exe -> Critical severity ("Account Discovery & Credential Vault Harvesting Attack Chain")
    #     - Simulated incident on same host -> separate simulated incident
    mixed_chain_events = [
        {
            "timestamp": "2026-10-11 02:30:01",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": "C:\\Windows\\System32\\svchost.exe",
            "command_line": "N/A",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 12000,
        },
        {
            "timestamp": "2026-10-11 02:30:02",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "record_offset": 12500,
        },
        {
            "timestamp": "2026-10-11 02:30:05",
            "source": "api_simulation",
            "event_id": 4688,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "10.0.4.15",
            "process_name": "vssadmin.exe",
            "command_line": "vssadmin.exe delete shadows /all /quiet",
            "description": "Volume Shadow Copies deletion requested.",
            "record_offset": 13000,
        },
    ]
    mixed_alerts = DetectionAgent().detect(LogNormalizer().normalize(mixed_chain_events))
    mixed_incs = ti.analyze(CorrelationAgent().correlate(mixed_alerts))
    assert len(mixed_incs) == 2

    real_chain = next(i for i in mixed_incs if i["is_real_telemetry"])
    sim_chain = next(i for i in mixed_incs if i["is_simulated"])

    assert real_chain["incident_id"] == "INC-E8541E"
    assert real_chain["incident_name"] == "Account Discovery & Credential Manager Read Activity"
    assert real_chain["severity"] == "Low"
    assert real_chain["is_real_telemetry"] is True
    assert real_chain["is_simulated"] is False
    assert real_chain["telemetry_sources"] == ["real_nxlog_windows"]

    assert sim_chain["incident_name"] == "Ransomware Pre-Encryption Staging Activity"
    assert sim_chain["severity"] == "Critical"
    assert sim_chain["is_real_telemetry"] is False
    assert sim_chain["is_simulated"] is True
    assert sim_chain["telemetry_sources"] == ["api_simulation"]


def test_39_rolling_window_52_to_13_cumulative_alert_tracking_and_safeguards(tmp_path):
    """
    Verifies all safeguards for current-window vs cumulative incident alert-count tracking:
    1. Rolling window 52 -> 13 scenario for INC-85D28A (window_alert_count=13, cumulative_alert_count=52).
    2. Distinguishes unique raw events from detection alerts (benign events do not increment alert counts).
    3. Duplicate ingestion & repeated Streamlit reruns (with new random ALT-xxxxxx IDs) do not inflate counts.
    4. Genuine new events increment both window_alert_count and cumulative_alert_count.
    5. Server/session restart durability via SQLite KnowledgeBaseDB ledger & snapshot.
    6. Bounded evidence list independence (max_evidence_alerts cap does not reduce cumulative_alert_count).
    7. Real-vs-simulated separation.
    """
    from analysis.normalize import normalize_events
    from analysis.deduplicate import deduplicate_events, get_alert_identity_key, get_alert_identity_hash
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent, apply_cumulative_incident_tracking
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.reporting_agent import ReportingAgent
    from knowledge_base.database import KnowledgeBaseDB

    temp_db_path = tmp_path / "test_cumulative_kb.db"
    kb_db = KnowledgeBaseDB(db_path=temp_db_path)
    session_registry = {}

    def _make_admin_4798(idx: int) -> dict:
        return {
            "timestamp": f"2026-04-11T02:20:{idx % 60:02d}",
            "hostname": "Harsha",
            "event_id": 4798,
            "event_type": "AUDIT_SUCCESS",
            "severity": "Low",
            "user": "Administrator",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.4.164",
            "process_name": r"C:\Windows\System32\svchost.exe",
            "command_line": "N/A",
            "description": f"A user's local group membership was enumerated. Target Account: Administrator (idx={idx})",
            "source": "real_nxlog_windows",
            "record_id": 800000 + idx,
            "record_offset": 37074500 + (idx * 250),
        }

    def _make_benign_7036(idx: int) -> dict:
        return {
            "timestamp": f"2026-04-11T12:35:{idx % 60:02d}",
            "hostname": "Harsha",
            "event_id": 7036,
            "event_type": "INFO",
            "severity": "Low",
            "user": "SYSTEM",
            "source_ip": "N/A",
            "remote_peer_ip": "11.12.4.164",
            "process_name": "services.exe",
            "command_line": "N/A",
            "description": f"The Windows Update service entered the running state ({idx}).",
            "source": "real_nxlog_windows",
            "record_id": 900000 + idx,
            "record_offset": 37250000 + (idx * 200),
        }

    # --- Stage 1: Earlier 300-event window with 52 Administrator 4798 events + 248 benign OS events ---
    window1_raw = [_make_admin_4798(i) for i in range(52)] + [_make_benign_7036(i) for i in range(248)]
    assert len(window1_raw) == 300
    window1_norm = enrich_events(deduplicate_events(normalize_events(window1_raw)))
    window1_alerts = DetectionAgent().detect(window1_norm)
    # Only the 52 Event 4798 records generate detection alerts; 248 benign raw events do NOT
    assert len(window1_alerts) == 52

    inc_w1 = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(window1_alerts))
    inc_w1 = apply_cumulative_incident_tracking(
        inc_w1,
        registry=session_registry,
        db=kb_db,
        max_evidence_alerts=25,  # Intentionally cap bounded evidence at 25 to test independence from 52
    )
    assert len(inc_w1) == 1
    admin_inc_w1 = inc_w1[0]
    assert admin_inc_w1["incident_id"] == "INC-85D28A"
    assert admin_inc_w1["severity"] == "Low"
    assert admin_inc_w1["window_alert_count"] == 52
    assert admin_inc_w1["cumulative_alert_count"] == 52
    assert admin_inc_w1["cumulative_scope"] == "Persistent (SQLite + Session)"
    # Bounded recent evidence list is capped at 25, while cumulative_alert_count remains 52
    assert len(admin_inc_w1["alerts"]) == 25
    assert admin_inc_w1["alert_count"] == 25

    # --- Stage 2: Duplicate ingestion & repeated Streamlit reruns (fresh random ALT-xxxxxx IDs) ---
    rerun_alerts = DetectionAgent().detect(window1_norm + window1_norm[:15])
    assert rerun_alerts[0]["alert_id"] != window1_alerts[0]["alert_id"]
    assert get_alert_identity_key(rerun_alerts[0]) == get_alert_identity_key(window1_alerts[0])
    assert get_alert_identity_hash(rerun_alerts[0]) == get_alert_identity_hash(window1_alerts[0])

    inc_rerun = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(rerun_alerts))
    inc_rerun = apply_cumulative_incident_tracking(
        inc_rerun,
        registry=session_registry,
        db=kb_db,
        max_evidence_alerts=25,
    )
    assert inc_rerun[0]["window_alert_count"] == 52
    assert inc_rerun[0]["cumulative_alert_count"] == 52

    # --- Stage 3: Rolling window shifts (39 earlier 4798 records scroll out, leaving 13 in the 300-event window) ---
    window2_raw = [_make_admin_4798(i) for i in range(39, 52)] + [_make_benign_7036(i) for i in range(287)]
    assert len(window2_raw) == 300
    window2_norm = enrich_events(deduplicate_events(normalize_events(window2_raw)))
    window2_alerts = DetectionAgent().detect(window2_norm)
    assert len(window2_alerts) == 13

    inc_w2 = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(window2_alerts))
    inc_w2 = apply_cumulative_incident_tracking(
        inc_w2,
        registry=session_registry,
        db=kb_db,
        max_evidence_alerts=25,
    )
    admin_inc_w2 = inc_w2[0]
    assert admin_inc_w2["incident_id"] == "INC-85D28A"
    assert admin_inc_w2["window_alert_count"] == 13
    assert admin_inc_w2["cumulative_alert_count"] == 52
    assert len(admin_inc_w2["alerts"]) == 25

    # --- Stage 4: Genuine new events arrive (3 brand-new Administrator 4798 records enter the window) ---
    window3_raw = (
        [_make_admin_4798(i) for i in range(39, 52)]
        + [_make_admin_4798(i) for i in range(52, 55)]
        + [_make_benign_7036(i) for i in range(284)]
    )
    window3_norm = enrich_events(deduplicate_events(normalize_events(window3_raw)))
    window3_alerts = DetectionAgent().detect(window3_norm)
    assert len(window3_alerts) == 16

    inc_w3 = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(window3_alerts))
    inc_w3 = apply_cumulative_incident_tracking(
        inc_w3,
        registry=session_registry,
        db=kb_db,
        max_evidence_alerts=25,
    )
    admin_inc_w3 = inc_w3[0]
    assert admin_inc_w3["window_alert_count"] == 16
    assert admin_inc_w3["cumulative_alert_count"] == 55
    assert len(admin_inc_w3["alerts"]) == 25

    # --- Stage 5: Simulated server/session restart (fresh empty session_registry hydrated from SQLite) ---
    fresh_session_registry = {}
    restarted_db = KnowledgeBaseDB(db_path=temp_db_path)
    inc_after_restart = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(window2_alerts))
    inc_after_restart = apply_cumulative_incident_tracking(
        inc_after_restart,
        registry=fresh_session_registry,
        db=restarted_db,
        max_evidence_alerts=25,
    )
    admin_restarted = inc_after_restart[0]
    assert admin_restarted["incident_id"] == "INC-85D28A"
    assert admin_restarted["window_alert_count"] == 13
    assert admin_restarted["cumulative_alert_count"] == 55
    assert admin_restarted["cumulative_scope"] == "Persistent (SQLite + Session)"
    assert admin_restarted["first_event_timestamp"] == "2026-04-11 02:20:00"
    assert admin_restarted["last_event_timestamp"] == "2026-04-11 02:20:54"

    # Verify format_alert_timestamp & format_incident_alert_summary
    from agents.correlation_agent import format_alert_timestamp, format_incident_alert_summary
    assert format_alert_timestamp("2026-10-10T13:15:18.123456Z") == "2026-10-10 13:15:18"
    assert format_alert_timestamp("2026-10-11 12:44:42") == "2026-10-11 12:44:42"
    assert format_alert_timestamp("N/A") == ""

    summary_meta = format_incident_alert_summary(admin_restarted)
    assert summary_meta["window_alert_count"] == 13
    assert summary_meta["cumulative_alert_count"] == 55
    assert summary_meta["cumulative_scope"] == "Persistent (SQLite + Session)"
    assert summary_meta["first_event_timestamp"] == "2026-04-11 02:20:00"
    assert summary_meta["last_event_timestamp"] == "2026-04-11 02:20:54"
    assert summary_meta["historical_log_range"] == "2026-04-11 02:20:00 → 2026-04-11 02:20:54"
    assert summary_meta["evidence_alert_cap"] == 25
    assert summary_meta["evidence_shown_count"] == 25
    assert "current processing window" in summary_meta["scope_explanation"]
    assert "retained historical log range" in summary_meta["scope_explanation"]
    assert "evidence table is capped at **25** recent records" in summary_meta["scope_explanation"]
    assert "confirmed attack" not in summary_meta["scope_explanation"].lower()

    # Verify ReportingAgent propagates window_alert_count, cumulative_alert_count, timestamps, and neutral summary
    reps = ReportingAgent().generate([admin_restarted])
    assert len(reps) == 1
    assert reps[0]["window_alert_count"] == 13
    assert reps[0]["cumulative_alert_count"] == 55
    assert reps[0]["cumulative_scope"] == "Persistent (SQLite + Session)"
    assert reps[0]["first_event_timestamp"] == "2026-04-11 02:20:00"
    assert reps[0]["last_event_timestamp"] == "2026-04-11 02:20:54"
    assert reps[0]["historical_log_range"] == "2026-04-11 02:20:00 → 2026-04-11 02:20:54"
    assert reps[0]["evidence_alert_cap"] == 25
    assert reps[0]["bounded_evidence_count"] == 25
    assert "13 current-window alert(s) and 55 cumulative alert(s)" in reps[0]["executive_summary"]
    assert "retained historical log range" in reps[0]["executive_summary"]
    assert "evidence table is capped at 25 recent records" in reps[0]["executive_summary"]
    assert "confirmed attack" not in reps[0]["executive_summary"].lower()

    # --- Stage 6: Real vs Simulated separation ---
    sim_event = dict(_make_admin_4798(999), source="api_simulation")
    sim_alerts = DetectionAgent().detect(enrich_events(normalize_events([sim_event])))
    sim_inc = CorrelationAgent().correlate(sim_alerts)
    assert sim_inc[0]["incident_id"] != "INC-85D28A"
    assert sim_inc[0]["is_simulated"] is True
    assert sim_inc[0]["is_real_telemetry"] is False


def test_40_dashboard_renders_window_and_cumulative_alert_counts_across_sectors():
    """
    Verifies that:
    1. Hot-reloading agents.correlation_agent and dashboard/app.py when sys.modules['analysis.deduplicate']
       is stale (missing get_alert_identity_key / get_alert_identity_hash) reloads analysis.deduplicate
       first and never raises ImportError.
    2. dashboard/app.py renders INC-85D28A with accurate live window_alert_count and
       cumulative_alert_count>=52 (reconstructed from retained logs and persisted in SQLite + Session),
       displays both counts on Sector 1 cards and Sector 5 reports along with historical scope,
       earliest/latest timestamps, and 100-record evidence cap explanation, and keeps all 9 sectors error-free.
    """
    import importlib
    import analysis.deduplicate as dedup_mod
    import agents.correlation_agent as corr_mod
    from streamlit.testing.v1 import AppTest
    from analysis.parser import NXLogReader
    from analysis.normalize import normalize_events
    from analysis.deduplicate import deduplicate_events
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent, format_incident_alert_summary

    # Simulate stale pre-existing in-memory module before hot-reload
    delattr(dedup_mod, "get_alert_identity_key")
    delattr(dedup_mod, "get_alert_identity_hash")
    importlib.reload(corr_mod)
    assert hasattr(dedup_mod, "get_alert_identity_key")
    assert hasattr(dedup_mod, "get_alert_identity_hash")

    # Simulate stale module again right before Streamlit AppTest startup
    delattr(dedup_mod, "get_alert_identity_key")
    delattr(dedup_mod, "get_alert_identity_hash")

    at = AppTest.from_file("dashboard/app.py", default_timeout=60)
    at.run(timeout=60)
    assert len(at.exception) == 0, f"Unexpected exceptions: {[e.value for e in at.exception]}"
    assert len(at.tabs) == 6, f"Expected all 6 sectors to render, got {len(at.tabs)}"

    live_evts = enrich_events(deduplicate_events(normalize_events(NXLogReader().get_recent_events(max_events=300))))
    live_incs = CorrelationAgent().correlate(DetectionAgent().detect(live_evts))
    expected_admin_window = next(
        (i["window_alert_count"] for i in live_incs if i.get("incident_id") == "INC-85D28A"),
        0,
    )

    nx_incidents = at.session_state["nxlog_incidents"]
    admin_inc = next((i for i in nx_incidents if i.get("incident_id") == "INC-85D28A"), None)
    assert admin_inc is not None, "Expected INC-85D28A in nxlog_incidents"
    assert admin_inc["severity"] == "Low"
    assert admin_inc["confidence"] == 65
    assert admin_inc["window_alert_count"] == expected_admin_window
    assert admin_inc["cumulative_alert_count"] >= 52
    assert admin_inc["cumulative_alert_count"] >= admin_inc["window_alert_count"]
    assert admin_inc["cumulative_scope"] == "Persistent (SQLite + Session)"
    assert admin_inc["evidence_alert_cap"] == 100
    assert admin_inc.get("first_event_timestamp", "").startswith("2026-")
    assert admin_inc.get("last_event_timestamp", "").startswith("2026-")
    assert admin_inc["first_event_timestamp"] <= admin_inc["last_event_timestamp"]

    admin_summary = format_incident_alert_summary(admin_inc)
    assert "→" in admin_summary["historical_log_range"]

    all_markdown = "\n".join(m.value for m in at.markdown)
    all_captions = "\n".join(c.value for c in at.caption)
    assert "Window Alerts:" in all_markdown
    assert "Cumulative Alerts (Persistent (SQLite + Session)):" in all_markdown
    assert "Historical Log Range:" in all_markdown
    assert "Evidence Table Cap:" in all_markdown
    assert "current processing window" in all_markdown
    assert "retained historical log range" in all_markdown
    assert "evidence table is capped at <strong>100</strong> recent records" in all_markdown
    assert "cumulative ledger tracks the full number of unique alert identities" in all_markdown
    assert "evidence table is capped at **100** recent records" in all_captions
    assert "confirmed attack" not in all_captions.lower()


def test_41_severity_remediation_and_threat_intel_audit_fixes():
    """
    Verifies all evidence-based audit fixes for INC-E8541E and Event IDs 5379/4798:
    1. Routine repeated Event ID 5379 and 4798 records on the same host/user (without suspicious tools/IOCs)
       receive neutral incident names and Low severity, preserving deterministic incident ID INC-E8541E.
    2. Genuine suspicious Event ID 5379 + 4798 activity (e.g., vaultcmd.exe + whoami.exe or confirmed malicious IOC)
       escalates to Critical severity and 'Account Discovery & Credential Vault Harvesting Attack Chain'.
    3. SOARDecisionEngine extracts MITRE techniques from incident and alert levels (never 'N/A' when present)
       and does NOT recommend ISOLATE_HOST or LOCK_USER for routine 5379/4798 activity even if a high default
       host GNN score is passed.
    4. ReportingAgent and LLMClient label recommendations as 'Advisory Recommendation — Not Executed',
       distinguish 10/100 Local Endpoint Telemetry risk score from incident severity without claiming 10/100
       proves an incident is harmless or malicious, and never make unsupported Mimikatz/firewall claims for
       routine local 5379/4798 telemetry.
    """
    from analysis.normalize import normalize_events
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent
    from agents.threat_intelligence_agent import ThreatIntelligenceAgent
    from agents.reporting_agent import ReportingAgent
    from soar.decision_engine import SOARDecisionEngine
    from llm.llm_client import LLMClient

    # --- 1. Routine repeated 5379 + 4798 on Harsha/Harsha (INC-E8541E) ---
    routine_events = []
    for i in range(6):
        routine_events.append({
            "timestamp": f"2026-10-11 10:00:{i:02d}",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": "Credential Manager credentials were read.",
            "record_offset": 50000 + i * 100,
        })
    routine_events.append({
        "timestamp": "2026-10-11 10:01:00",
        "source": "real_nxlog_windows",
        "event_id": 4798,
        "hostname": "Harsha",
        "user": "Harsha",
        "source_ip": "N/A",
        "process_name": r"C:\Windows\System32\svchost.exe",
        "command_line": "N/A",
        "description": "A user's local group membership was enumerated.",
        "record_offset": 51000,
    })

    norm_routine = enrich_events(normalize_events(routine_events))
    alerts_routine = DetectionAgent().detect(norm_routine)
    assert len(alerts_routine) == 7
    assert all(a["severity"] == "Low" for a in alerts_routine)

    incs_routine = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(alerts_routine))
    assert len(incs_routine) == 1
    inc_r = incs_routine[0]
    assert inc_r["incident_id"] == "INC-E8541E"
    assert inc_r["incident_name"] == "Account Discovery & Credential Manager Read Activity"
    assert inc_r["severity"] == "Low"
    assert inc_r["confidence"] == 70
    assert set(inc_r["mitre_techniques"]) == {"T1555.004", "T1087.001"}

    # SOAR Decision Engine must NOT recommend ISOLATE_HOST or LOCK_USER for routine 5379/4798
    soar_engine = SOARDecisionEngine()
    soar_recs_routine = soar_engine.evaluate_incident(inc_r, gnn_risk_score=0.85)
    assert not any(r["action_id"] in ("ISOLATE_HOST", "LOCK_USER") for r in soar_recs_routine)

    # ReportingAgent & LLMClient verification for routine INC-E8541E
    rep_routine = ReportingAgent().generate([inc_r])[0]
    assert rep_routine["incident_id"] == "INC-E8541E"
    assert rep_routine["incident_name"] == inc_r["incident_name"]
    assert rep_routine["severity"] == "Low"
    assert rep_routine["confidence"] == 70
    assert rep_routine["recommendation"].startswith("Advisory Recommendation — Not Executed:")
    assert "Execute containment playbook and isolate host" not in rep_routine["recommendation"]
    assert "neither proof that the activity is harmless nor proof that it is malicious" in rep_routine["threat_intel_summary"]
    assert "Repeated Windows background events" in rep_routine["severity_rationale"]

    llm = LLMClient()
    exp_routine = llm.generate_explanation(inc_r)
    assert "T1555.004" in exp_routine["mitre"] and "T1087.001" in exp_routine["mitre"]
    assert exp_routine["recommendation"].startswith("Advisory Recommendation — Not Executed:")

    plan_routine = llm.generate_response_plan(inc_r)
    plan_text = " ".join(
        plan_routine["containment_actions"] + plan_routine["eradication_actions"] + plan_routine["recovery_actions"]
    ).lower()
    assert "mimikatz" not in plan_text
    assert "block source ip address on perimeter firewalls" not in plan_text

    # --- 2. Genuine suspicious 5379 + 4798 (vaultcmd.exe + whoami.exe) ---
    suspicious_events = [
        {
            "timestamp": "2026-10-11 11:00:01",
            "source": "real_nxlog_windows",
            "event_id": 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": r"C:\Windows\System32\whoami.exe",
            "command_line": "whoami /groups",
            "description": "A user's local group membership was enumerated.",
            "record_offset": 60000,
        },
        {
            "timestamp": "2026-10-11 11:00:02",
            "source": "real_nxlog_windows",
            "event_id": 5379,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": r"C:\Windows\System32\vaultcmd.exe",
            "command_line": "vaultcmd /listcreds:\"Windows Credentials\"",
            "description": "Credential Manager credentials were read.",
            "record_offset": 60500,
        },
    ]
    norm_susp = normalize_events(suspicious_events)
    assert norm_susp[0]["severity"] == "Medium"
    assert norm_susp[1]["severity"] == "High"
    norm_routine = normalize_events(routine_events)
    assert all(e["severity"] == "Low" for e in norm_routine)

    alerts_susp = DetectionAgent().detect(enrich_events(norm_susp))
    incs_susp = ThreatIntelligenceAgent().analyze(CorrelationAgent().correlate(alerts_susp))
    assert len(incs_susp) == 1
    inc_s = incs_susp[0]
    assert inc_s["incident_id"] == "INC-E8541E"
    assert inc_s["incident_name"] == "Account Discovery & Credential Vault Harvesting Attack Chain"
    assert inc_s["severity"] == "Critical"
    assert inc_s["confidence"] == 94

    soar_recs_susp = soar_engine.evaluate_incident(inc_s, gnn_risk_score=0.85)
    assert any(r["action_id"] == "ISOLATE_HOST" for r in soar_recs_susp)
    assert any(r["action_id"] == "LOCK_USER" for r in soar_recs_susp)
    for rec in soar_recs_susp:
        assert rec["mitre_technique"] in ("T1555.004", "T1087.001")
        assert rec["requires_analyst_approval"] is True
        assert rec["dry_run"] is True
        assert rec["advisory_status"] == "Advisory Recommendation — Not Executed"

    # --- 3. Continuous verification marker remains informational/diagnostic & chatbot never invents external IPs ---
    from llm.llm_client import LLMClient
    marker_evt = NXLogReader().parse_line(
        "2026-10-11 15:37:51 Harsha INFO 1000 HARSHA\\Harsha ADAPTIVESENTINEL_CONTINUOUS_TEST_20261011_153751"
    )
    assert marker_evt is not None
    assert marker_evt["is_diagnostic"] is True
    assert marker_evt["severity"] == "Low"
    assert marker_evt["mitre_technique"] == "N/A"
    marker_alts = DetectionAgent().detect(normalize_events([marker_evt]))
    marker_incs = CorrelationAgent().correlate(marker_alts)
    assert all(inc.get("is_diagnostic") is True for inc in marker_incs)
    assert sum(1 for inc in marker_incs if not inc.get("is_diagnostic")) == 0

    chat_reply = LLMClient().query_chatbot(
        "Which malicious IP addresses should I block on the firewall?",
        {"logs": norm_routine, "alerts": alerts_routine, "incidents": incs_routine, "network_state": {"sender_ip_current": "11.12.4.164", "receiver_ip_current": "11.12.7.72"}},
    )
    assert "No External Malicious IP Addresses Identified" in chat_reply
    assert "185.220.101.5" not in chat_reply


def test_42_feedback_persistence_knowledge_reuse_and_simulation_soar(tmp_path):
    """
    Verifies:
    1. Analyst feedback persistence across database reloads.
    2. Historical knowledge retrieval and evidence-compared safe recommendation reuse.
    3. Refusal to reuse a prior Benign/False Positive verdict when a new incident has suspicious CLI/IOC evidence.
    4. Simulation-only SOAR response lifecycle (PROPOSED -> APPROVED -> SIMULATED -> COMPLETED_IN_SIMULATION -> ROLLED_BACK)
       including TERMINATE_PROCESS and SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN.
    5. High-volume batch processing performance (1,000 events).
    """
    import time
    from knowledge_base.database import KnowledgeBaseDB
    from agents.feedback_agent import FeedbackAgent
    from soar.action_registry import SOARActionRegistry
    from soar.decision_engine import SOARDecisionEngine
    from soar.executor import MockSOARExecutor
    from analysis.normalize import normalize_events
    from analysis.deduplicate import deduplicate_events
    from analysis.enrich import enrich_events
    from agents.detection_agent import DetectionAgent
    from agents.correlation_agent import CorrelationAgent

    temp_db_file = tmp_path / "test_feedback_kb.db"
    kb_1 = KnowledgeBaseDB(db_path=temp_db_file)
    fb_agent_1 = FeedbackAgent(db=kb_1)

    import importlib
    import agents.feedback_agent as _fb_mod
    importlib.reload(_fb_mod)
    assert hasattr(_fb_mod.FeedbackAgent, "retrieve_similar_guidance")
    assert hasattr(_fb_mod.FeedbackAgent, "extract_incident_evidence_profile")

    routine_inc = {
        "incident_id": "INC-E8541E",
        "incident_name": "Account Discovery & Credential Manager Read Activity",
        "severity": "Low",
        "confidence": 70,
        "affected_host": "Harsha",
        "affected_user": "Harsha",
        "mitre_techniques": ["T1555.004", "T1087.001"],
        "alerts": [
            {
                "rule_id": "RULE-CRED-5379",
                "mitre_technique": "T1555.004",
                "event": {
                    "event_id": 5379,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "process_name": "N/A",
                    "command_line": "N/A",
                },
            }
        ],
    }

    # Verify missing prior match returns consistent non-matching structure
    no_match = fb_agent_1.retrieve_similar_guidance(routine_inc)
    assert no_match["has_historical_match"] is False
    assert no_match["can_reuse_guidance"] is False
    assert no_match["historical_feedback"] is None
    assert no_match["reused_guidance"] is None
    assert no_match["evidence_comparison"]["evidence_aligned"] is False

    saved = fb_agent_1.process_feedback(
        incident_id="INC-E8541E",
        alert_name="Account Discovery & Credential Manager Read Activity",
        analyst_verdict="Benign / Expected Admin Activity",
        override_severity="Low",
        adjusted_confidence=85,
        notes="Verified routine Windows background credential manager read on Harsha; no containment needed.",
        incident=routine_inc,
    )
    assert saved["feedback_id"].startswith("FDB-")

    # Simulate application reload with a fresh DB & FeedbackAgent instance pointing to the same SQLite file
    kb_reloaded = KnowledgeBaseDB(db_path=temp_db_file)
    fb_agent_reloaded = FeedbackAgent(db=kb_reloaded)
    history = fb_agent_reloaded.get_feedback_history()
    assert len(history) == 1
    assert history[0]["incident_id"] == "INC-E8541E"
    assert history[0]["analyst_verdict"] == "Benign / Expected Admin Activity"
    assert history[0]["override_severity"] == "Low"
    assert history[0]["adjusted_confidence"] == 85

    # Retrieve guidance for a similar routine incident -> evidence aligns, safe to reuse as reference
    guidance_routine = fb_agent_reloaded.retrieve_similar_guidance(routine_inc)
    assert guidance_routine["has_historical_match"] is True
    assert guidance_routine["can_reuse_guidance"] is True
    assert "Reference Only" in guidance_routine["guidance_origin"]
    assert guidance_routine["is_newly_verified_finding"] is False
    assert guidance_routine["safety_policy"]["auto_rule_mutation"] is False
    assert guidance_routine["safety_policy"]["auto_response_execution"] is False
    assert "no containment needed" in guidance_routine["reused_guidance"]

    # Retrieve guidance when a new incident on the same ID/pattern has suspicious CLI tooling (vaultcmd.exe)
    # -> Evidence comparison must detect the mismatch and refuse to reuse the prior benign verdict!
    escalated_inc = {
        "incident_id": "INC-E8541E",
        "incident_name": "Account Discovery & Credential Vault Harvesting Attack Chain",
        "severity": "Critical",
        "confidence": 94,
        "affected_host": "Harsha",
        "affected_user": "Harsha",
        "mitre_techniques": ["T1555.004", "T1087.001"],
        "alerts": [
            {
                "rule_id": "RULE-CRED-5379",
                "mitre_technique": "T1555.004",
                "event": {
                    "event_id": 5379,
                    "hostname": "Harsha",
                    "user": "Harsha",
                    "process_name": r"C:\Windows\System32\vaultcmd.exe",
                    "command_line": 'vaultcmd /listcreds:"Windows Credentials"',
                },
            }
        ],
    }
    guidance_escalated = fb_agent_reloaded.retrieve_similar_guidance(escalated_inc)
    assert guidance_escalated["has_historical_match"] is True
    assert guidance_escalated["evidence_comparison"]["evidence_aligned"] is False
    assert guidance_escalated["can_reuse_guidance"] is False
    assert guidance_escalated["reused_guidance"] is None

    # Verify simulation-only SOAR response planning & execution (including TERMINATE_PROCESS)
    reg = SOARActionRegistry()
    eng = SOARDecisionEngine(registry=reg)
    exe = MockSOARExecutor(registry=reg)
    recs = eng.evaluate_incident(escalated_inc, gnn_risk_score=0.91)
    act_ids = [r["action_id"] for r in recs]
    assert "ISOLATE_HOST" in act_ids
    assert "TERMINATE_PROCESS" in act_ids
    assert "COLLECT_FORENSIC_ARTIFACTS" in act_ids
    assert "LOCK_USER" in act_ids
    for idx, r in enumerate(recs, start=1):
        assert r["priority_order"] == idx
        assert r["proposal_state"] == "PROPOSED"
        assert r["simulation_banner"] == "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"
        assert r["expected_effect"]
        assert r["operational_impact"]

    term_res = exe.execute_action(
        "TERMINATE_PROCESS",
        "vaultcmd.exe",
        parameters={"hostname": "Harsha", "process_name": "vaultcmd.exe"},
        dry_run=False,
    )
    assert term_res["status"] == "EXECUTED"
    assert term_res["lifecycle_state"] == "COMPLETED_IN_SIMULATION"
    assert term_res["simulation_banner"] == "SIMULATION ONLY — NO REAL ENDPOINT ACTION TAKEN"

    # Verify high-volume batch processing performance (1,000 events)
    batch_1000 = [
        {
            "timestamp": f"2026-10-11 16:00:{i % 60:02d}",
            "source": "real_nxlog_windows",
            "event_id": 5379 if i % 2 == 0 else 4798,
            "hostname": "Harsha",
            "user": "Harsha",
            "source_ip": "N/A",
            "process_name": "N/A",
            "command_line": "N/A",
            "description": f"Batch test event #{i}",
            "record_offset": 100000 + i,
        }
        for i in range(1000)
    ]
    t0 = time.perf_counter()
    norm_b = normalize_events(batch_1000)
    dedup_b = deduplicate_events(norm_b)
    enr_b = enrich_events(dedup_b)
    alts_b = DetectionAgent().detect(enr_b)
    incs_b = CorrelationAgent().correlate(alts_b)
    elapsed_sec = time.perf_counter() - t0
    assert len(norm_b) == 1000
    assert len(dedup_b) == 1000
    assert len(alts_b) == 1000
    assert len(incs_b) >= 1
    assert elapsed_sec < 5.0

