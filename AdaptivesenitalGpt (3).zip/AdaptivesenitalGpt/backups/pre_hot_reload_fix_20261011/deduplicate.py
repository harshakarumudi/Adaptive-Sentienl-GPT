import hashlib
from typing import List, Dict, Any, Tuple


def get_event_identity_key(log: Dict[str, Any]) -> Tuple[Any, ...]:
    """
    Computes a safe deduplication identity key for an event.
    Includes record_offset and record_id when available so separate legitimate
    records in the log stream are never discarded solely because their raw text
    or second-precision timestamp matches.
    """
    return (
        log.get("source"),
        log.get("timestamp"),
        log.get("event_id"),
        log.get("hostname"),
        log.get("user"),
        log.get("source_ip"),
        log.get("remote_peer_ip"),
        log.get("command_line"),
        log.get("description") or log.get("message"),
        log.get("record_id"),
        log.get("record_offset"),
    )


def get_alert_identity_key(alert: Dict[str, Any]) -> Tuple[Any, ...]:
    """
    Computes a deterministic, stable identity key for a detection alert.
    Strictly distinguishes detection alerts from raw events by binding the
    triggered rule/alert identity and MITRE technique to the underlying
    event identity key. Ignores random per-run alert_id (ALT-xxxxxx) so
    repeated pipeline evaluations or Streamlit reruns never inflate counts.
    """
    ev = alert.get("event", {}) if isinstance(alert, dict) else {}
    rule_id = str(alert.get("rule_id") or alert.get("alert_name") or "UNKNOWN_RULE").strip()
    mitre = str(alert.get("mitre_technique") or ev.get("mitre_technique") or "N/A").strip()
    return (rule_id, mitre) + get_event_identity_key(ev)


def get_alert_identity_hash(alert: Dict[str, Any]) -> str:
    """
    Returns a deterministic SHA-256 hex digest of get_alert_identity_key(alert)
    suitable for durable SQLite ledger storage and cumulative set tracking.
    """
    key_tuple = get_alert_identity_key(alert)
    serialized = "|".join("" if part is None else str(part) for part in key_tuple)
    return hashlib.sha256(serialized.encode("utf-8", errors="replace")).hexdigest()


class LogDeduplicator:
    """
    Deduplicates high-frequency noise logs while preserving threat attack sequences
    and distinct endpoint records.
    """

    def remove_duplicates(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        unique_logs = []
        seen = set()

        for log in logs:
            key = get_event_identity_key(log)
            if key not in seen:
                seen.add(key)
                unique_logs.append(log)

        removed_count = len(logs) - len(unique_logs)
        print(f"[INFO] LogDeduplicator removed {removed_count} duplicate event(s). {len(unique_logs)} unique events remain.")
        return unique_logs


def deduplicate_events(logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return LogDeduplicator().remove_duplicates(logs)