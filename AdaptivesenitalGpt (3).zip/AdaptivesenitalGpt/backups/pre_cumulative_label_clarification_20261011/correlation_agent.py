import hashlib
import importlib
import uuid
from typing import List, Dict, Any, Set, Tuple, Optional
from datetime import datetime
import analysis.deduplicate as _dedup_mod

if not hasattr(_dedup_mod, "get_alert_identity_key") or not hasattr(_dedup_mod, "get_alert_identity_hash"):
    importlib.reload(_dedup_mod)

from analysis.deduplicate import (
    get_event_identity_key,
    get_alert_identity_key,
    get_alert_identity_hash,
)


class CorrelationAgent:
    """
    Correlation Agent correlating atomic alerts into unified multi-stage Incidents
    based on host, user, IP, and temporal attack chain analysis.
    """

    def correlate(self, alerts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        incidents = []

        # Canonicalize display hostname case-insensitively (e.g. 'Harsha' and 'HARSHA' -> 'Harsha')
        canonical_hosts: Dict[str, str] = {}
        for alert in alerts:
            raw_h = str(alert.get("event", {}).get("hostname") or alert.get("hostname") or "UNKNOWN_HOST").strip()
            h_low = raw_h.lower()
            if h_low not in canonical_hosts:
                canonical_hosts[h_low] = raw_h
            elif canonical_hosts[h_low].isupper() and not raw_h.isupper():
                canonical_hosts[h_low] = raw_h

        # Separate diagnostic probes (grouped by canonical host + provenance) from security alerts
        diag_groups: Dict[str, List[Dict[str, Any]]] = {}
        diag_seen_keys: Dict[str, Set[Tuple[Any, ...]]] = {}
        host_groups: Dict[str, List[Dict[str, Any]]] = {}
        host_seen_keys: Dict[str, Set[Tuple[Any, ...]]] = {}

        # Pre-index non-SYSTEM users per (host_low, prov) so SYSTEM-level LSASS dumps on a host
        # with an active user brute-force chain correlate with that host's user attack chain
        host_primary_user: Dict[str, str] = {}
        for alert in alerts:
            if alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""):
                continue
            ev = alert.get("event", {})
            h_low = str(ev.get("hostname", "UNKNOWN_HOST")).strip().lower()
            u = str(ev.get("user", "SYSTEM")).strip()
            src = str(ev.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            hp_key = f"{h_low}::{prov}"
            if u not in ("SYSTEM", "N/A", "") and hp_key not in host_primary_user:
                host_primary_user[hp_key] = u

        for alert in alerts:
            event = alert["event"]
            raw_host = str(event.get("hostname", "UNKNOWN_HOST")).strip()
            host = canonical_hosts.get(raw_host.lower(), raw_host)
            user = str(event.get("user", "SYSTEM")).strip() or "SYSTEM"
            src = str(event.get("source", "unknown")).strip().lower()
            prov = "real" if src in ("real_nxlog_windows", "local_windows") else "sim"
            has_identity_anchor = (
                event.get("record_offset") is not None
                or event.get("record_id") is not None
                or event.get("timestamp") is not None
            )
            alert_identity = get_alert_identity_key(alert) if has_identity_anchor else None

            is_diag = bool(alert.get("is_diagnostic") or "Diagnostic" in alert.get("alert_name", ""))
            if is_diag:
                d_key = f"{host}::{prov}"
                if alert_identity is not None:
                    seen_d = diag_seen_keys.setdefault(d_key, set())
                    if alert_identity in seen_d:
                        continue
                    seen_d.add(alert_identity)
                diag_groups.setdefault(d_key, []).append(alert)
                continue

            hp_key = f"{host.lower()}::{prov}"
            if (
                user == "SYSTEM"
                and ("LSASS" in alert.get("alert_name", "") or "Mimikatz" in alert.get("alert_name", ""))
                and hp_key in host_primary_user
            ):
                user = host_primary_user[hp_key]

            key = f"{host}::{user}::{prov}"
            if alert_identity is not None:
                seen_h = host_seen_keys.setdefault(key, set())
                if alert_identity in seen_h:
                    continue
                seen_h.add(alert_identity)
            if key not in host_groups:
                host_groups[key] = []
            host_groups[key].append(alert)

        for d_key, diag_alerts in diag_groups.items():
            host, prov = d_key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"
            primary_diag_user = next(
                (str(a.get("event", {}).get("user", "SYSTEM")) for a in diag_alerts if a.get("event", {}).get("user") not in (None, "", "SYSTEM", "N/A")),
                str(diag_alerts[0].get("event", {}).get("user", "SYSTEM")),
            )
            inc_hash = hashlib.md5(f"{host}:{primary_diag_user}:diagnostic{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
            incidents.append({
                "incident_id": f"INC-DIAG-{inc_hash}",
                "incident_name": f"Diagnostic Telemetry Verification Probe ({host})",
                "severity": "Low",
                "confidence": 100,
                "is_diagnostic": True,
                "alert_count": len(diag_alerts),
                "affected_host": host,
                "affected_user": primary_diag_user,
                "alerts": diag_alerts,
                "created_at": datetime.now().isoformat()
            })

        # Correlate grouped security alerts
        for key, security_alerts in host_groups.items():
            host, user, prov = key.split("::")
            hash_Export_suffix = "" if prov == "real" else ":sim"

            if not security_alerts:
                continue

            failed_logins = [a for a in security_alerts if "Failed Logon" in a["alert_name"]]
            lsass_alerts = [a for a in security_alerts if "LSASS" in a["alert_name"] or "Mimikatz" in a["alert_name"]]
            cred_manager_alerts = [a for a in security_alerts if "Credential Manager" in a["alert_name"]]
            discovery_alerts = [a for a in security_alerts if "Account Discovery" in a["alert_name"] or "Group Membership" in a["alert_name"]]
            ps_alerts = [a for a in security_alerts if "PowerShell" in a["alert_name"]]
            obfuscated_ps_alerts = [a for a in ps_alerts if "Obfuscated" in a["alert_name"]]
            vss_alerts = [a for a in security_alerts if "Shadow Copies" in a["alert_name"] or "Ransomware" in a["alert_name"]]
            log_cleared = [a for a in security_alerts if "Log Cleared" in a["alert_name"]]
            account_created = [a for a in security_alerts if "New Account Created" in a["alert_name"]]
            suricata_alerts = [a for a in security_alerts if "Suricata" in a["alert_name"] or "Lateral Movement" in a["alert_name"]]

            # Ransomware Attack Sequence Correlation (Obfuscated PowerShell + VSSAdmin Deletion + co-occurring host stages)
            if vss_alerts or obfuscated_ps_alerts:
                combined_alerts = list(vss_alerts) + [a for a in ps_alerts if a not in vss_alerts]
                for extra in security_alerts:
                    if extra not in combined_alerts:
                        combined_alerts.append(extra)
                inc_hash = hashlib.md5(f"{host}:{user}:ransomware{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Ransomware Pre-Encryption Staging Activity",
                    "severity": "Critical",
                    "confidence": 98,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Brute Force & Credential Harvesting Chain (Failed Logins + Mimikatz LSASS, or 2+ Failed Logins)
            elif len(failed_logins) >= 2 or (failed_logins and lsass_alerts) or lsass_alerts:
                combined_alerts = list(failed_logins) + [a for a in lsass_alerts if a not in failed_logins]
                for extra in security_alerts:
                    if extra not in combined_alerts:
                        combined_alerts.append(extra)
                inc_hash = hashlib.md5(f"{host}:{user}:bruteforce{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                inc_title = (
                    "Automated Brute Force & Credential Dumping Attack Chain"
                    if lsass_alerts
                    else "Automated Brute Force & Password Spraying Attack"
                )
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": inc_title,
                    "severity": "Critical" if lsass_alerts else "High",
                    "confidence": 96 if lsass_alerts else 90,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Account Discovery & Credential Vault Harvesting Attack Chain
            elif cred_manager_alerts and discovery_alerts:
                combined_alerts = cred_manager_alerts + discovery_alerts
                inc_hash = hashlib.md5(f"{host}:{user}:recon_cred_theft{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Account Discovery & Credential Vault Harvesting Attack Chain",
                    "severity": "Critical",
                    "confidence": 96,
                    "alert_count": len(combined_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Windows Credential Manager Access Activity (Event 5379)
            elif cred_manager_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:cred_vault{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Windows Credential Manager Password Vault Access Activity",
                    "severity": "Critical" if len(cred_manager_alerts) >= 2 else "High",
                    "confidence": 95 if len(cred_manager_alerts) >= 2 else 90,
                    "alert_count": len(cred_manager_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": cred_manager_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Local Account Group Discovery Campaign (Event 4798 / 4799)
            elif discovery_alerts:
                other_stage_alerts = [a for a in security_alerts if a not in discovery_alerts]
                combined_disc = list(discovery_alerts) + other_stage_alerts
                recon_binaries = (
                    "net.exe", "net1.exe", "whoami.exe", "powershell.exe",
                    "pwsh.exe", "cmd.exe", "wmic.exe", "dsquery.exe",
                    "nltest.exe", "adfind.exe", "sharphound", "bloodhound", "seatbelt",
                )
                has_recon_cli = any(
                    any(
                        b in str(a.get("event", {}).get("process_name", "")).lower()
                        or b in str(a.get("event", {}).get("command_line", "")).lower()
                        or b in str(a.get("event", {}).get("description", "")).lower()
                        for b in recon_binaries
                    )
                    for a in discovery_alerts
                )
                if other_stage_alerts:
                    disc_severity = "High"
                    disc_conf = 90
                elif has_recon_cli:
                    disc_severity = "Medium"
                    disc_conf = 85
                else:
                    disc_severity = "Low"
                    disc_conf = 65
                inc_hash = hashlib.md5(f"{host}:{user}:discovery{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Local Account Group Discovery Campaign ({user})",
                    "severity": disc_severity,
                    "confidence": disc_conf,
                    "alert_count": len(combined_disc),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": combined_disc,
                    "created_at": datetime.now().isoformat()
                })

            # Unauthorized Backdoor Account Creation & Persistence (Event 4720)
            elif account_created:
                inc_hash = hashlib.md5(f"{host}:{user}:persistence{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Unauthorized Backdoor Account Creation & Persistence",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(account_created),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": account_created,
                    "created_at": datetime.now().isoformat()
                })

            # Network Lateral Movement via Remote WMI Execution (Suricata Event 2000001)
            elif suricata_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:lateral_movement{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Network Lateral Movement via Remote WMI Execution",
                    "severity": "High",
                    "confidence": 92,
                    "alert_count": len(suricata_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": suricata_alerts,
                    "created_at": datetime.now().isoformat()
                })

            # Defense Evasion & Anti-Forensics Correlation
            elif log_cleared:
                inc_hash = hashlib.md5(f"{host}:{user}:evasion{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": "Host Defense Evasion & Security Log Tampering",
                    "severity": "High",
                    "confidence": 95,
                    "alert_count": len(log_cleared),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": log_cleared,
                    "created_at": datetime.now().isoformat()
                })

            # Fallback for remaining single alerts
            elif security_alerts:
                inc_hash = hashlib.md5(f"{host}:{user}:{security_alerts[0].get('alert_name', 'suspicious')}{hash_Export_suffix}".encode()).hexdigest()[:6].upper()
                incidents.append({
                    "incident_id": f"INC-{inc_hash}",
                    "incident_name": f"Suspicious Activity on {host}",
                    "severity": security_alerts[0].get("severity", "Medium"),
                    "confidence": security_alerts[0].get("confidence", 80),
                    "alert_count": len(security_alerts),
                    "affected_host": host,
                    "affected_user": user,
                    "alerts": security_alerts,
                    "created_at": datetime.now().isoformat()
                })

        for inc in incidents:
            inc.setdefault("is_diagnostic", False)
            cur_alerts = inc.get("alerts", [])
            inc["alert_count"] = len(cur_alerts)
            inc["window_alert_count"] = len(cur_alerts)
            inc["cumulative_alert_count"] = len(cur_alerts)
            inc["cumulative_scope"] = "Current Window"
            src_ips = []
            telemetry_sources = []
            mitre_techniques = []
            for alt in cur_alerts:
                ev = alt.get("event", {})
                sip = str(ev.get("source_ip") or "N/A").strip()
                if sip and sip not in ("N/A", "-", "127.0.0.1", "::1") and sip not in src_ips:
                    src_ips.append(sip)
                ev_src = str(ev.get("source") or "unknown").strip()
                if ev_src and ev_src not in telemetry_sources:
                    telemetry_sources.append(ev_src)
                tech = str(alt.get("mitre_technique") or ev.get("mitre_technique") or "N/A").strip()
                if tech and tech not in ("N/A", "NA", "None") and tech not in mitre_techniques:
                    mitre_techniques.append(tech)
            inc["observed_source_ips"] = src_ips if src_ips else ["N/A"]
            inc["telemetry_sources"] = telemetry_sources if telemetry_sources else ["unknown"]
            inc["mitre_techniques"] = mitre_techniques
            inc["primary_source"] = (
                "real_nxlog_windows"
                if "real_nxlog_windows" in inc["telemetry_sources"]
                else inc["telemetry_sources"][0]
            )
            inc["is_real_telemetry"] = any(
                s in ("real_nxlog_windows", "local_windows") for s in inc["telemetry_sources"]
            )
            inc["is_simulated"] = (not inc["is_real_telemetry"]) and any(
                "sim" in s.lower() or "synthetic" in s.lower() for s in inc["telemetry_sources"]
            )

        print(f"[INFO] Correlation Agent synthesized {len(incidents)} correlated Incident(s).")
        return incidents

    def apply_cumulative_tracking(
        self,
        incidents: List[Dict[str, Any]],
        registry: Optional[Dict[str, Dict[str, Any]]] = None,
        db: Optional[Any] = None,
        max_evidence_alerts: int = 100,
        retain_historical_incidents: bool = True,
    ) -> List[Dict[str, Any]]:
        return apply_cumulative_incident_tracking(
            incidents=incidents,
            registry=registry,
            db=db,
            max_evidence_alerts=max_evidence_alerts,
            retain_historical_incidents=retain_historical_incidents,
        )


def apply_cumulative_incident_tracking(
    incidents: List[Dict[str, Any]],
    registry: Optional[Dict[str, Dict[str, Any]]] = None,
    db: Optional[Any] = None,
    max_evidence_alerts: int = 100,
    retain_historical_incidents: bool = True,
) -> List[Dict[str, Any]]:
    """
    Reconciles current-window correlated incidents against a session registry and/or
    durable SQLite ledger (KnowledgeBaseDB):
    - Sets `window_alert_count` to the unique detection alert count in the active window.
    - Sets `cumulative_alert_count` to the total unique detection alert identities ever
      observed for that incident (monotonically non-decreasing across rolling windows).
    - Caps `inc["alerts"]` at `max_evidence_alerts` (bounded recent-evidence list) while
      preserving `cumulative_alert_count` independently of that cap.
    - Explicitly sets `cumulative_scope` to reflect persistence guarantees.
    """
    if db is not None and registry is not None:
        scope_label = "Persistent (SQLite + Session)"
    elif db is not None:
        scope_label = "Persistent (SQLite)"
    elif registry is not None:
        scope_label = "Session-Cumulative"
    else:
        scope_label = "Current Window"

    if registry is None:
        registry = {}

    # Hydrate registry from durable SQLite ledger & snapshots if db is provided
    if db is not None:
        try:
            db_alert_keys = db.get_incident_alert_keys()
            db_snapshots = db.get_incident_snapshots()
            for db_inc_id, key_list in db_alert_keys.items():
                entry = registry.setdefault(
                    db_inc_id,
                    {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
                )
                if not isinstance(entry.get("seen_alert_keys"), set):
                    entry["seen_alert_keys"] = set(entry.get("seen_alert_keys") or [])
                entry["seen_alert_keys"].update(key_list)
                snap = db_snapshots.get(db_inc_id)
                if snap:
                    if not entry.get("metadata") and snap.get("metadata"):
                        entry["metadata"] = dict(snap["metadata"])
                    if not entry.get("recent_alerts") and snap.get("recent_alerts"):
                        entry["recent_alerts"] = list(snap["recent_alerts"])[-max_evidence_alerts:]
        except Exception:
            pass

    tracked_incidents: List[Dict[str, Any]] = []
    active_ids: Set[str] = set()

    # Determine provenance filter for retained historical incidents so real and simulated streams never mix
    provenance_flags = {bool(inc.get("is_real_telemetry", False)) for inc in incidents if inc.get("incident_id")}
    enforce_real_flag: Optional[bool] = next(iter(provenance_flags)) if len(provenance_flags) == 1 else None

    for inc in incidents:
        inc_copy = dict(inc)
        inc_id = str(inc_copy.get("incident_id") or "")
        if not inc_id:
            tracked_incidents.append(inc_copy)
            continue
        active_ids.add(inc_id)

        raw_window_alerts = inc_copy.get("alerts", [])
        window_seen: Set[str] = set()
        unique_window_alerts: List[Dict[str, Any]] = []
        for alt in raw_window_alerts:
            a_hash = get_alert_identity_hash(alt)
            if a_hash not in window_seen:
                window_seen.add(a_hash)
                unique_window_alerts.append(alt)

        window_count = len(unique_window_alerts)

        entry = registry.setdefault(
            inc_id,
            {"seen_alert_keys": set(), "recent_alerts": [], "metadata": {}},
        )
        if not isinstance(entry.get("seen_alert_keys"), set):
            entry["seen_alert_keys"] = set(entry.get("seen_alert_keys") or [])

        entry["seen_alert_keys"].update(window_seen)

        # Merge bounded recent_alerts preserving chronological order without duplicates
        merged_alerts: List[Dict[str, Any]] = []
        merged_hashes: Set[str] = set()
        for existing_alt in entry.get("recent_alerts", []):
            eh = get_alert_identity_hash(existing_alt)
            if eh not in merged_hashes:
                merged_hashes.add(eh)
                merged_alerts.append(existing_alt)
        for new_alt in unique_window_alerts:
            nh = get_alert_identity_hash(new_alt)
            if nh not in merged_hashes:
                merged_hashes.add(nh)
                merged_alerts.append(new_alt)
            else:
                # Refresh alert payload in-place so latest enriched threat_intel fields are preserved
                for idx, prev_alt in enumerate(merged_alerts):
                    if get_alert_identity_hash(prev_alt) == nh:
                        merged_alerts[idx] = new_alt
                        break

        if max_evidence_alerts > 0 and len(merged_alerts) > max_evidence_alerts:
            merged_alerts = merged_alerts[-max_evidence_alerts:]
        entry["recent_alerts"] = merged_alerts

        meta_snapshot = {
            k: v
            for k, v in inc_copy.items()
            if k not in ("alerts", "alert_count", "window_alert_count", "cumulative_alert_count")
        }
        entry["metadata"] = meta_snapshot

        if db is not None:
            try:
                db_total = db.record_incident_alerts(
                    incident_id=inc_id,
                    alert_keys=list(entry["seen_alert_keys"]),
                    metadata=meta_snapshot,
                    recent_alerts=merged_alerts,
                )
                cumulative_count = max(len(entry["seen_alert_keys"]), db_total)
            except Exception:
                cumulative_count = len(entry["seen_alert_keys"])
        else:
            cumulative_count = len(entry["seen_alert_keys"])

        inc_copy["window_alert_count"] = window_count
        inc_copy["cumulative_alert_count"] = cumulative_count
        inc_copy["cumulative_scope"] = scope_label
        inc_copy["evidence_alert_cap"] = max_evidence_alerts
        inc_copy["alerts"] = list(merged_alerts)
        inc_copy["alert_count"] = len(inc_copy["alerts"])
        tracked_incidents.append(inc_copy)

    if retain_historical_incidents:
        for hist_id, entry in list(registry.items()):
            if hist_id in active_ids:
                continue
            seen_keys = entry.get("seen_alert_keys") or set()
            meta = entry.get("metadata") or {}
            if not seen_keys or not meta:
                continue
            if enforce_real_flag is not None and bool(meta.get("is_real_telemetry", False)) != enforce_real_flag:
                continue
            hist_inc = dict(meta)
            bounded_recent = list(entry.get("recent_alerts", []))
            if max_evidence_alerts > 0 and len(bounded_recent) > max_evidence_alerts:
                bounded_recent = bounded_recent[-max_evidence_alerts:]
            hist_inc["window_alert_count"] = 0
            hist_inc["cumulative_alert_count"] = len(seen_keys)
            hist_inc["cumulative_scope"] = scope_label
            hist_inc["evidence_alert_cap"] = max_evidence_alerts
            hist_inc["alerts"] = bounded_recent
            hist_inc["alert_count"] = len(bounded_recent)
            tracked_incidents.append(hist_inc)

    return tracked_incidents