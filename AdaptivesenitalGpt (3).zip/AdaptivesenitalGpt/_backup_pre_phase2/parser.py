import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Any, Optional

from config.settings import (
    NXLOG_FILE_PATH,
    NXLOG_CURSOR_FILE_PATH,
    HARSHA_IP,
    SUJITH_IP,
)


class LogParser:

    def __init__(self, log_file: str):
        self.log_file = Path(log_file)

    def parse(self) -> List[Dict[str, Any]]:
        """
        Parses JSON or line-delimited log files into Python dictionaries.
        """
        if not self.log_file.exists():
            print(f"[ERROR] Log file not found: {self.log_file}")
            return []

        try:
            with open(self.log_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    print(f"[WARNING] Log file is empty: {self.log_file}")
                    return []

                # JSON Array format
                if content.startswith("[") and content.endswith("]"):
                    logs = json.loads(content)
                else:
                    # JSON Lines format
                    logs = [json.loads(line) for line in content.splitlines() if line.strip()]

            print(f"[INFO] LogParser ingested {len(logs)} raw events from {self.log_file.name}.")
            return logs

        except Exception as e:
            print(f"[ERROR] Failed to parse log file {self.log_file}: {str(e)}")
            return []


def parse_log_file(file_path: str) -> List[Dict[str, Any]]:
    return LogParser(file_path).parse()


class NXLogReader:
    """
    Reads and parses live/ingested Windows Event Logs emitted by NXLog
    to C:\\AdaptiveSentinel\\windows-events.log. Supports incremental reading via cursor tracking.
    """

    def __init__(
        self,
        log_file: Optional[Path] = None,
        cursor_file: Optional[Path] = None
    ):
        self.log_file = Path(log_file) if log_file else NXLOG_FILE_PATH
        self.cursor_file = Path(cursor_file) if cursor_file else NXLOG_CURSOR_FILE_PATH

    def load_cursor(self) -> int:
        if self.cursor_file.exists():
            try:
                with open(self.cursor_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    return data.get("byte_offset", 0)
            except Exception:
                return 0
        return 0

    def save_cursor(self, offset: int) -> None:
        try:
            self.cursor_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cursor_file, "w", encoding="utf-8") as f:
                json.dump({"byte_offset": offset, "last_updated": datetime.now(timezone.utc).isoformat()}, f)
        except Exception as e:
            print(f"[!] Failed to save NXLog cursor: {e}")

    def reset_cursor_to_end(self) -> int:
        """
        Advances the NXLog cursor to the current end of windows-events.log.
        Events up to this point will be treated as baseline history,
        and subsequent incremental reads will only capture newly arriving events.
        """
        if not self.log_file.exists():
            self.save_cursor(0)
            return 0
        try:
            with open(self.log_file, "r", encoding="utf-8", errors="replace") as f:
                f.seek(0, os.SEEK_END)
                end_offset = f.tell()
            self.save_cursor(end_offset)
            return end_offset
        except Exception as e:
            print(f"[!] Failed to reset NXLog cursor to end: {e}")
            return 0

    def parse_line(self, raw_line: str) -> Optional[Dict[str, Any]]:
        line = raw_line.strip()
        if not line:
            return None

        # Try parsing as JSON first
        if line.startswith("{") and line.endswith("}"):
            try:
                data = json.loads(line)
                return self._normalize_nxlog_json(data, raw_line)
            except Exception:
                pass

        # Parse non-JSON lines (syslog / KV / test lines / EventLog text)
        return self._normalize_nxlog_text(line, raw_line)

    def _extract_event_id(self, source_dict_or_text: Any) -> int:
        if isinstance(source_dict_or_text, dict):
            for key in ["EventID", "event_id", "EventCode", "event_code", "ID", "id"]:
                val = source_dict_or_text.get(key)
                if val is not None:
                    try:
                        eid = int(val)
                        if eid > 0:
                            return eid
                    except (ValueError, TypeError):
                        pass
            text_to_search = source_dict_or_text.get("Message") or source_dict_or_text.get("description") or str(source_dict_or_text)
        else:
            text_to_search = str(source_dict_or_text)

        # XML / Tags
        xml_match = re.search(r"<EventID>(\d+)</EventID>", text_to_search, re.IGNORECASE)
        if xml_match:
            try:
                return int(xml_match.group(1))
            except ValueError:
                pass

        # Key-Value or Label format (e.g. EventID: 4624, Event ID = 4624, ID: 1000)
        kv_match = re.search(r"(?:EventID|EventCode|Event_ID|Event\s*ID|EventCode|ID)[:=><\s]+(\d{1,6})\b", text_to_search, re.IGNORECASE)
        if kv_match:
            try:
                return int(kv_match.group(1))
            except ValueError:
                pass

        # Event ID in eventcreate or syslog string (e.g. "Event 1000", "ID 4624")
        evt_match = re.search(r"\b(?:Event|ID)\s+(\d{3,5})\b", text_to_search, re.IGNORECASE)
        if evt_match:
            try:
                return int(evt_match.group(1))
            except ValueError:
                pass

        return 0

    def _normalize_nxlog_json(self, data: Dict[str, Any], raw_line: str) -> Dict[str, Any]:
        from analysis.normalize import LogNormalizer
        norm = LogNormalizer()
        event_id = self._extract_event_id(data)
        now_iso = datetime.now(timezone.utc).isoformat()

        hostname = (
            data.get("Hostname")
            or data.get("Computer")
            or data.get("ComputerName")
            or data.get("hostname")
            or "UNKNOWN_HOST"
        )
        user = (
            data.get("TargetUserName")
            or data.get("SubjectUserName")
            or data.get("AccountName")
            or data.get("user")
        )
        if not user or user in ["-", "", "SYSTEM"]:
            domain_user = re.search(r'\b([A-Za-z0-9._-]+)\\([A-Za-z0-9._-]+)\b', str(data.get("Message", "")))
            if domain_user and domain_user.group(2).upper() not in ['SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']:
                user = domain_user.group(2)
            else:
                user = user or "SYSTEM"

        src_ip = (
            data.get("IpAddress")
            or data.get("SourceAddress")
            or data.get("SourceNetworkAddress")
            or data.get("source_ip")
        )
        if not src_ip or src_ip in ["-", "127.0.0.1", "::1", "N/A"]:
            src_ip = "N/A"

        dst_ip = (
            data.get("DestinationIpAddress")
            or data.get("DestAddress")
            or data.get("destination_ip")
            or "N/A"
        )
        process_name = (
            data.get("NewProcessName")
            or data.get("ProcessName")
            or data.get("process_name")
            or "N/A"
        )
        command_line = data.get("CommandLine") or data.get("command_line") or "N/A"
        event_time = (
            data.get("EventTime")
            or data.get("TimeCreated")
            or data.get("timestamp")
            or now_iso
        )
        description = (
            data.get("Message")
            or data.get("description")
            or f"NXLog Windows Event {event_id}"
        )

        is_diagnostic = any(
            k in str(description).upper() or k in str(command_line).upper()
            for k in norm.DIAGNOSTIC_MARKERS
        )

        if is_diagnostic:
            severity = "Low"
            mitre_tech = "N/A"
            event_type = "Diagnostic Telemetry Probe"
        else:
            severity = data.get("severity")
            if not severity or str(severity).strip().title() in ["Low", "Informational", "Info", "N/A"]:
                severity = norm.SEVERITY_MAP.get(event_id, severity or "Low")

            mitre_tech = data.get("mitre_technique")
            if not mitre_tech or mitre_tech == "N/A":
                mitre_tech = norm.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")

            event_type = data.get("event_type")
            if not event_type or event_type in ["NXLog Event", "Generic Event", "N/A"]:
                event_type = norm.EVENT_TYPE_MAP.get(event_id, f"Windows Event (ID {event_id})" if event_id else "Windows Event")

        return {
            "timestamp": event_time,
            "ingestion_timestamp": now_iso,
            "source": "real_nxlog_windows",
            "event_id": event_id,
            "event_type": event_type,
            "severity": severity,
            "hostname": hostname,
            "user": user,
            "source_ip": src_ip,
            "destination_ip": dst_ip,
            "process_name": process_name,
            "command_line": command_line,
            "description": description,
            "mitre_technique": mitre_tech,
            "is_diagnostic": is_diagnostic,
            "raw_line": raw_line
        }

    def _normalize_nxlog_text(self, text: str, raw_line: str) -> Dict[str, Any]:
        from analysis.normalize import LogNormalizer
        norm = LogNormalizer()

        lines = [l.strip() for l in text.splitlines() if l.strip()]
        first_line = lines[0] if lines else text.strip()

        header_re = re.compile(
            r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(\S+)\s+(\d{1,6})\s+(.*)$'
        )
        m = header_re.match(first_line)
        now_iso = datetime.now(timezone.utc).isoformat()

        if m:
            event_time, hostname, audit_status, eid_str, description = m.groups()
            try:
                event_id = int(eid_str)
            except ValueError:
                event_id = 0
        else:
            event_id = self._extract_event_id(text)
            comp_m = re.findall(r'(?:Computer|Hostname):\s*([^\r\n;,]+)', text, re.IGNORECASE)
            from_m = re.search(r'\bfrom\s+([A-Za-z0-9._-]+)\b', text, re.IGNORECASE)
            if comp_m:
                hostname = comp_m[0].strip()
            elif from_m:
                hostname = from_m.group(1).strip()
            else:
                hostname = "UNKNOWN_HOST"
            event_time = now_iso
            description = first_line

        # Extract Target / User accounts cleanly
        # Look for Target user first (under User: section in 4798, 4720, etc.)
        target_users = re.findall(
            r'(?:User|TargetUserName):\s*\n?\s*Security ID:.*?\n?\s*Account Name:\s*([^\r\n;,]+)',
            text, re.IGNORECASE
        )
        general_users = re.findall(r'Account\s+Name:\s*([^\r\n;,]+)', text, re.IGNORECASE)

        user = None
        if target_users:
            user = target_users[0].strip()
        elif general_users:
            filtered = [
                u.strip() for u in general_users
                if not u.strip().endswith('$') and u.strip() not in ['-', 'SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']
            ]
            user = filtered[0] if filtered else general_users[-1].strip()

        if not user or user in ['-', '', 'SYSTEM', 'N/A']:
            # Try DOMAIN\User pattern e.g. HARSHA\Harsha
            domain_user = re.search(r'\b([A-Za-z0-9._-]+)\\([A-Za-z0-9._-]+)\b', text)
            if domain_user and domain_user.group(2).upper() not in ['SYSTEM', 'LOCAL SERVICE', 'NETWORK SERVICE']:
                user = domain_user.group(2)
            else:
                user = user or "SYSTEM"

        # Process Name
        proc_matches = re.findall(r'(?:Process\s+Name|NewProcessName|Process):\s*([^\r\n;,]+)', text, re.IGNORECASE)
        process_name = proc_matches[0].strip() if proc_matches else "N/A"

        # Command Line
        cmd_matches = re.findall(r'(?:Process\s+Command\s+Line|CommandLine):\s*([^\r\n]+)', text, re.IGNORECASE)
        command_line = cmd_matches[0].strip() if cmd_matches else "N/A"

        # Source IP: Extract if explicitly present, do not force endpoint IP
        ip_matches = re.findall(r'(?:Source\s+Network\s+Address|IpAddress|SourceAddress):\s*([^\r\n;,]+)', text, re.IGNORECASE)
        src_ip = ip_matches[0].strip() if (ip_matches and ip_matches[0].strip() not in ['-', '::1', '127.0.0.1', 'N/A', '']) else "N/A"

        # Destination IP
        dst_matches = re.findall(r'(?:Destination\s+Network\s+Address|DestAddress|DestinationIpAddress):\s*([^\r\n;,]+)', text, re.IGNORECASE)
        dst_ip = dst_matches[0].strip() if (dst_matches and dst_matches[0].strip() not in ['-', '::1', '127.0.0.1', 'N/A', '']) else "N/A"

        is_diagnostic = any(
            marker in str(description).upper() or marker in str(command_line).upper()
            for marker in norm.DIAGNOSTIC_MARKERS
        )

        if is_diagnostic:
            severity = "Low"
            mitre_tech = "N/A"
            event_type = "Diagnostic Telemetry Probe"
        else:
            severity = norm.SEVERITY_MAP.get(event_id, "Low")
            mitre_tech = norm.MITRE_TECHNIQUE_MAP.get(event_id, "N/A")
            event_type = norm.EVENT_TYPE_MAP.get(event_id, f"Windows Event (ID {event_id})" if event_id else "Windows Event")

        return {
            "timestamp": event_time,
            "ingestion_timestamp": now_iso,
            "source": "real_nxlog_windows",
            "event_id": event_id,
            "event_type": event_type,
            "severity": severity,
            "hostname": hostname,
            "user": user,
            "source_ip": src_ip,
            "destination_ip": dst_ip,
            "process_name": process_name,
            "command_line": command_line,
            "description": description,
            "mitre_technique": mitre_tech,
            "is_diagnostic": is_diagnostic,
            "raw_line": raw_line
        }

    def read_events(self, incremental: bool = True) -> List[Dict[str, Any]]:
        if not self.log_file.exists():
            print(f"[WARNING] NXLog file not found: {self.log_file}")
            return []

        start_offset = self.load_cursor() if incremental else 0
        events = []

        try:
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()

                if start_offset > file_len:
                    start_offset = 0

                f.seek(start_offset)
                b_chunk = f.read()

            if not b_chunk:
                return []

            # Cleanly handle trailing incomplete records at EOF
            last_nl = b_chunk.rfind(b"\n")
            if last_nl != -1 and last_nl < len(b_chunk) - 1:
                valid_bytes = b_chunk[:last_nl + 1]
                new_offset = start_offset + (last_nl + 1)
            elif last_nl == -1:
                if start_offset > 0:
                    return []
                valid_bytes = b_chunk
                new_offset = start_offset + len(b_chunk)
            else:
                valid_bytes = b_chunk
                new_offset = start_offset + len(b_chunk)

            chunk = valid_bytes.decode("utf-8", errors="replace")

            header_re = re.compile(
                r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(\S+)\s+(\d{1,6})\s+(.*)$'
            )

            lines = chunk.splitlines()
            blocks = []
            cur = []
            for l in lines:
                s = l.strip()
                if header_re.match(s) or (s.startswith('{') and s.endswith('}')):
                    if cur:
                        blocks.append("\n".join(cur))
                        cur = []
                cur.append(l)
            if cur:
                blocks.append("\n".join(cur))

            # Protect against incomplete trailing multiline Windows Security blocks at EOF
            if incremental and blocks:
                last_blk = blocks[-1]
                has_subject = "\nSubject:" in last_blk or "\n\tSecurity ID:" in last_blk
                has_completion = any(
                    sec in last_blk for sec in (
                        "Process Name:",
                        "Network Information:",
                        "Additional Information:",
                        "Detailed Authentication Information:",
                    )
                )
                if (has_subject and not has_completion) or last_blk.rstrip().endswith(":"):
                    first_hdr = last_blk.splitlines()[0].encode("utf-8", errors="replace")
                    hdr_pos = valid_bytes.rfind(first_hdr)
                    if hdr_pos != -1:
                        new_offset = start_offset + hdr_pos
                        blocks.pop()

            for b in blocks:
                b_str = b.strip()
                if not b_str:
                    continue
                parsed = self.parse_line(b_str)
                if parsed:
                    events.append(parsed)

            if incremental:
                self.save_cursor(new_offset)

            print(f"[INFO] NXLogReader ingested {len(events)} events from {self.log_file}")
            return events

        except Exception as e:
            print(f"[ERROR] Failed to read NXLog file {self.log_file}: {e}")
            return []

    def replay_events(
        self,
        from_offset: Optional[int] = None,
        max_events: Optional[int] = None,
        scan_bytes: int = 5000000
    ) -> List[Dict[str, Any]]:
        """
        Safely replay or inspect events without advancing or modifying the incremental cursor.
        Preserves diagnostic verification probes within the scanned window.
        """
        if not self.log_file.exists():
            return []

        try:
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()
                if file_len == 0:
                    return []
                if from_offset is None:
                    actual_offset = max(0, file_len - max(scan_bytes, 5000000))
                else:
                    actual_offset = 0 if from_offset > file_len else from_offset
                f.seek(actual_offset)
                b_chunk = f.read()

            if not b_chunk:
                return []

            if actual_offset > 0:
                first_nl = b_chunk.find(b"\n")
                if first_nl != -1:
                    b_chunk = b_chunk[first_nl + 1:]

            chunk = b_chunk.decode("utf-8", errors="replace")
            header_re = re.compile(
                r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(\S+)\s+(\d{1,6})\s+(.*)$'
            )
            lines = chunk.splitlines()
            blocks = []
            cur = []
            started = (actual_offset == 0)
            for l in lines:
                s = l.strip()
                is_start = bool(header_re.match(s)) or (s.startswith('{') and s.endswith('}'))
                if is_start:
                    started = True
                    if cur:
                        blocks.append("\n".join(cur))
                        cur = []
                if started:
                    cur.append(l)
            if cur:
                blocks.append("\n".join(cur))

            events = []
            for b in blocks:
                b_str = b.strip()
                if not b_str:
                    continue
                parsed = self.parse_line(b_str)
                if parsed:
                    events.append(parsed)

            if max_events is not None and len(events) > max_events:
                diag_evts = [e for e in events[:-max_events] if e.get("is_diagnostic")]
                return diag_evts + events[-max_events:]
            return events
        except Exception as e:
            print(f"[!] Error in replay_events: {e}")
            return []

    def get_recent_events(self, max_events: int = 500, scan_bytes: int = 5000000) -> List[Dict[str, Any]]:
        """
        Efficiently retrieves up to `max_events` from the end of the log file
        without loading the entire historical backlog into memory, while preserving
        diagnostic test probes within the scanned window.
        """
        if not self.log_file.exists():
            return []

        try:
            with open(self.log_file, "rb") as f:
                f.seek(0, os.SEEK_END)
                file_len = f.tell()
                if file_len == 0:
                    return []
                chunk_size = min(file_len, max(scan_bytes, 5000000))
                actual_offset = file_len - chunk_size
                f.seek(actual_offset)
                b_chunk = f.read()

            # Discard leading partial line if seeking from middle
            if actual_offset > 0:
                first_nl = b_chunk.find(b"\n")
                if first_nl != -1:
                    b_chunk = b_chunk[first_nl + 1:]

            chunk = b_chunk.decode("utf-8", errors="replace")

            header_re = re.compile(
                r'^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(\S+)\s+(\S+)\s+(\d{1,6})\s+(.*)$'
            )

            lines = chunk.splitlines()
            blocks = []
            cur = []
            started = (actual_offset == 0)
            for l in lines:
                s = l.strip()
                is_start = bool(header_re.match(s)) or (s.startswith('{') and s.endswith('}'))
                if is_start:
                    started = True
                    if cur:
                        blocks.append("\n".join(cur))
                        cur = []
                if started:
                    cur.append(l)
            if cur:
                blocks.append("\n".join(cur))

            events = []
            for b in blocks:
                b_str = b.strip()
                if not b_str:
                    continue
                parsed = self.parse_line(b_str)
                if parsed:
                    events.append(parsed)

            if len(events) > max_events:
                diag_evts = [e for e in events[:-max_events] if e.get("is_diagnostic")]
                return diag_evts + events[-max_events:]
            return events
        except Exception as e:
            print(f"[!] Exception in get_recent_events: {e}")
            return []