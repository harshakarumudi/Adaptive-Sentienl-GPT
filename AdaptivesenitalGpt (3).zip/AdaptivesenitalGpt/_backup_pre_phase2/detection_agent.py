import uuid
from typing import List, Dict, Any


class DetectionAgent:
    """
    Detection Agent evaluating normalized events against MITRE ATT&CK rules,
    heuristic thresholds, and signature checks.
    """

    def detect(self, logs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        alerts = []

        for log in logs:
            event_id = log.get("event_id")
            process_name = str(log.get("process_name", "")).lower()
            cmd_line = str(log.get("command_line", "")).lower()
            desc = str(log.get("description", ""))

            alert = None

            # Diagnostic Telemetry Verification Probe (explicit diagnostic markers; Event ID 1000 alone does not trigger)
            is_diagnostic = (
                bool(log.get("is_diagnostic", False))
                or any(marker in desc.upper() or marker in cmd_line.upper() for marker in [
                    "SECTOR1_RECEIVER_TEST",
                    "SECTOR1_E2E",
                    "DIAGNOSTIC_TEST",
                    "PHASE1_",
                    "RECEIVER_TEST",
                    "SENTINEL_TEST",
                    "ADAPTIVE SENTINEL CONNECTION TEST",
                    "NXLOG TEST EVENT",
                    "LIVE TEST FROM",
                ])
            )

            if is_diagnostic:
                alert = {
                    "alert_id": f"ALT-DIAG-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Diagnostic Telemetry Verification Probe",
                    "severity": "Low",
                    "confidence": 100,
                    "mitre_technique": "N/A",
                    "is_diagnostic": True,
                    "event": log
                }

            # Failed Logon Attempt
            elif event_id in [4625, 1001]:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Failed Logon Attempt",
                    "severity": "Medium",
                    "confidence": 85,
                    "mitre_technique": log.get("mitre_technique", "T1110"),
                    "event": log
                }

            # Unsigned/Bypass PowerShell Execution
            elif event_id == 1 or "powershell" in process_name:
                if "bypass" in cmd_line or "enc" in cmd_line or "executionpolicy" in cmd_line:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "Suspicious Obfuscated PowerShell Execution",
                        "severity": "High",
                        "confidence": 92,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }
                else:
                    alert = {
                        "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                        "alert_name": "PowerShell Script Execution",
                        "severity": "Low",
                        "confidence": 75,
                        "mitre_technique": "T1059.001",
                        "event": log
                    }

            # Shadow Copy Deletion (Ransomware Prep)
            elif "vssadmin" in process_name or "delete shadows" in cmd_line:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Volume Shadow Copies Deletion (Ransomware Activity)",
                    "severity": "Critical",
                    "confidence": 98,
                    "mitre_technique": "T1486",
                    "event": log
                }

            # Mimikatz LSASS Memory Access
            elif event_id == 10 or "mimikatz" in process_name or "lsass" in cmd_line:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "OS Credential Dumping via LSASS Access",
                    "severity": "Critical",
                    "confidence": 96,
                    "mitre_technique": "T1003.001",
                    "event": log
                }

            # Audit Log Clearing
            elif event_id == 1102 or "wevtutil cl" in cmd_line:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Security Audit Log Cleared",
                    "severity": "High",
                    "confidence": 95,
                    "mitre_technique": "T1070",
                    "event": log
                }

            # New Account Created
            elif event_id == 4720:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "New Account Created",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1136",
                    "event": log
                }

            # Network IDS Alert (Suricata)
            elif event_id == 2000001:
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Suricata IDS: Lateral Movement via Remote WMI Execution",
                    "severity": "High",
                    "confidence": 90,
                    "mitre_technique": "T1021",
                    "event": log
                }

            # Windows Credential Manager Access & Password Vault Harvesting
            elif event_id == 5379 or "credential manager" in str(log.get("description", "")).lower():
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": "Windows Credential Manager Access & Harvesting",
                    "severity": "High",
                    "confidence": 94,
                    "mitre_technique": "T1555.004",
                    "event": log
                }

            # Local Account & Group Enumeration / Reconnaissance Discovery
            elif event_id in [4798, 4799] or "group membership was enumerated" in str(log.get("description", "")).lower():
                target_user = log.get("user", "SYSTEM")
                is_admin_enum = target_user.lower() in ["administrator", "admin", "guest"]
                alert = {
                    "alert_id": f"ALT-{uuid.uuid4().hex[:6].upper()}",
                    "alert_name": f"Account Discovery: Group Membership Enumeration ({target_user})" if target_user not in ["SYSTEM", "N/A"] else "Account Discovery: Group Membership Enumeration",
                    "severity": "High" if is_admin_enum else "Medium",
                    "confidence": 90 if is_admin_enum else 85,
                    "mitre_technique": "T1087.001" if event_id == 4798 else "T1087",
                    "event": log
                }

            if alert:
                alerts.append(alert)

        print(f"[INFO] Detection Agent flagged {len(alerts)} suspicious alert(s).")
        return alerts